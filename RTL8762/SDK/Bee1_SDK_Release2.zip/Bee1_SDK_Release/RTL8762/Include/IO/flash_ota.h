#ifndef flash_ota_h
#define flash_ota_h

#define Signature_KERNEL 0x4B4E
#define Signature_USER   0x5552

#endif
