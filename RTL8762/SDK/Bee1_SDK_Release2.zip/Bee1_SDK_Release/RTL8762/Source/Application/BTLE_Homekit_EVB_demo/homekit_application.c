/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      SimpleBLEPeripheral_application.c
* @brief     Simple BLE Peripheral demo application implementation
* @details   Simple BLE Peripheral demo application implementation
* @author    ranhui
* @date      2015-03-27
* @version   v0.2
* *********************************************************************************************************
*/
#include "rtl876x.h"
#include "application.h"
#include "homekit_application.h"
#include "bee_message.h"
#include "trace.h"
#include "peripheral.h"
#include "gap.h"
#include <string.h>
#include "profileApi.h"
#include "simple_ble_service.h"
#include "hmt_api.h"
#include "hw_ctrl.h"
#include "light_bulb.h"

// gap state
gaprole_States_t gapProfileState = GAPSTATE_INIT;
extern uint8_t gGasServiceId;  //generic attribute service id
extern uint8_t gPsServiceId;   //homekit pairing service id
extern uint8_t gAisServiceId;  //homekit accessory info service id
extern uint8_t gDisServiceId;  //device information service

void peripheral_HandleBtGapMessage(BEE_IO_MSG  *pBeeIoMsg);

//for user handle prepare write  
TAppResult AppPreWrCallback(uint8_t ServiceId, uint16_t handle, uint16_t iAttribIndex,
        uint16_t wLength, uint8_t * pValue , uint16_t offset)
{
    TAppResult result = AppResult_Success;
    
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "AppPreWrCallback: serviceId: %d, attr_idx: %d, pValue:0x%x, offset:%d, wLength:%d", 5,\
                    ServiceId, iAttribIndex, pValue, offset, wLength);
    
    return result;
}

//for user handle execute write
TAppResult AppExeWrCallback(uint8_t flag, uint16_t* handle)
{
    TAppResult result = AppResult_Success;
    
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "AppExeWrCallback: flag: %d", 1, flag);
    
    //@note: pairing-process may receive execute write callback, ignore it!!!
    
    return result;
}

/******************************************************************
 * @fn          AppHandleIODriverMessage
 * @brief      All the application events are pre-handled in this function.
 *                All the IO MSGs are sent to this function, Then the event handling function 
 *                shall be called according to the MSG type.
 *
 * @param    io_driver_msg_recv  - bee io msg data
 * @return     void
 */
void AppHandleIODriverMessage(BEE_IO_MSG io_driver_msg_recv)
{
    UINT16 msgtype = io_driver_msg_recv.IoType;

    switch (msgtype)
    {

    case BT_STATUS_UPDATE:
        {
            peripheral_HandleBtGapMessage(&io_driver_msg_recv);
        }
        break;
    default:
        break;
    }
}

/******************************************************************
 * @fn          peripheral_HandleBtGapStateChangeEvt
 * @brief      All the gaprole_States_t events are pre-handled in this function.      
 *                Then the event handling function shall be called according to the newState.
 *
 * @param    newState  - new gap state 
 * @return     void
 */
uint8_t g_connect_flag = 0;
void peripheral_HandleBtGapStateChangeEvt(uint8_t newState)
{
    switch ( newState )
    {
    //connection is disconnected or idle with no advertising 
    case GAPSTATE_IDLE_NO_ADV_NO_CONN:
        {
            if (gapProfileState == GAPSTATE_CONNECTED)
            {
                //change advterising data here, and
                uint8_t disc_reason;
                peripheralGetGapParameter(GAPPRRA_DISCONNECTED_REASON, &disc_reason);
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "peripheral_HandleBtGapStateChangeEvt: disc_reason = %d", 1, disc_reason);
                
                start_disconnect_tip();
                g_connect_flag = 0;
                hmt_start_adv();
            }
        }
        break;
    //device is advertising
    case GAPSTATE_ADVERTISING:
        {
            //advterisng tip
            start_adv_tip();
        }
        break;

    //device is connected
    case GAPSTATE_CONNECTED:
        {
            start_connected_tip();
            g_connect_flag = 1;
        }
        break;

    //device is connected and advertising
    case GAPSTATE_CONNECTED_ADV:
        {
            
        }
        break;
        
    //error comes here
    default:
        {

        }
        break;

    }

    gapProfileState = (gaprole_States_t)newState;
}

/******************************************************************
 * @fn          peripheral_HandleBtGapConnParaChangeEvt
 * @brief      All the connection parameter update change  events are pre-handled in this function.    
 *                Then the event handling function shall be called according to the status.
 *
 * @param    status  - connection parameter result, 0 - success, otherwise fail. 
 * @return     void
 */
void peripheral_HandleBtGapConnParaChangeEvt(uint8_t status)
{
    if (status == 0)
    {
        uint16_t con_interval;
        uint16_t conn_slave_latency;
        uint16_t conn_supervision_timeout;

        peripheralGetGapParameter(GAPPRRA_CONN_INTERVAL, &con_interval);
        peripheralGetGapParameter(GAPPRRA_CONN_LATENCY, &conn_slave_latency);
        peripheralGetGapParameter(GAPPRRA_CONN_TIMEOUT, &conn_supervision_timeout);

        DBG_BUFFER(MODULE_APP, LEVEL_INFO,
                   "BT_MSG_TYPE_CONN_PARA_UPDATE_CHANGE success, con_interval = 0x%x, conn_slave_latency = 0x%x, conn_supervision_timeout = 0x%x",
                   3, con_interval, conn_slave_latency, conn_supervision_timeout);
    }
    else
    {
        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_CONN_PARA_UPDATE_CHANGE failed, status = %d",
                   1, status);

    }
}

/******************************************************************
 * @fn          peripheral_HandleBtGapMessage
 * @brief      All the bt gap msg  events are pre-handled in this function.    
 *                Then the event handling function shall be called according to the subType
 *                of BEE_IO_MSG.
 *
 * @param    pBeeIoMsg  - pointer to bee io msg 
 * @return     void
 */
void peripheral_HandleBtGapMessage(BEE_IO_MSG  *pBeeIoMsg)
{
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "peripheral_HandleBtGapMessage subType = %d", 1, pBeeIoMsg->subType);
    BT_STACK_MSG BtStackMsg;
    memcpy(&BtStackMsg, &pBeeIoMsg->parm, sizeof(pBeeIoMsg->parm));

    switch (pBeeIoMsg->subType)
    {
    case BT_MSG_TYPE_CONN_STATE_CHANGE:
        {
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_CONN_STATE_CHANGE:(%d->%d)",
                       2, gapProfileState, BtStackMsg.msgData.gapConnStateChange.newState);

            peripheral_HandleBtGapStateChangeEvt(BtStackMsg.msgData.gapConnStateChange.newState);
        }
        break;

    case BT_MSG_TYPE_CONN_PARA_UPDATE_CHANGE:
        {
            peripheral_HandleBtGapConnParaChangeEvt(BtStackMsg.msgData.gapConnParaUpdateChange.status);
        }
        break;

    default:
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "peripheral_HandleBtGapMessage unknown subtype", 1, pBeeIoMsg->subType);

        break;

    }

}

/******************************************************************
 * @fn          AppProfileCallback
 * @brief      All the bt profile callbacks are handled in this function.            
 *                Then the event handling function shall be called according to the serviceID
 *                of BEE_IO_MSG.
 *
 * @param    serviceID  -  service id of profile
 * @param    pData  - pointer to callback data 
 * @return     void
 */
TAppResult AppProfileCallback(uint8_t serviceID, void* pData)
{
    if (serviceID == ProfileAPI_ServiceUndefined)
    {
        TEventInfoCBs_t*pPara = (TEventInfoCBs_t*)pData;
        switch (pPara->eventId)
        {
        case PROFILE_EVT_SRV_REG_COMPLETE:// srv register result event.
            DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "profile callback PROFILE_EVT_SRV_REG_COMPLETE\n", 0);
            {
                peripheral_Init_StartAdvertising();
            }
            break;
            
        //confirmation received(for indication)
        case PROFILE_EVT_SEND_DATA_COMPLETE:
            break;

        default:
            break;
        }
    }
    //generic attribute service
    else if(serviceID == gGasServiceId)
    {
        
    }
    
    return AppResult_Success;
}

void APP_ERROR_CHECK(int CODE)
{
    if (CODE != 0)
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "APP_ERROR_CHECK:0x%x", 1, CODE);
    }
}


