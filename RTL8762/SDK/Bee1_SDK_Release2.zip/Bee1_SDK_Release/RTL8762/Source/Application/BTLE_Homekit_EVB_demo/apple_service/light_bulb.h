/**
************************************************************************************************************
*               Copyright(c) 2014, Realtek Semiconductor Corporation. All rights reserved.
************************************************************************************************************
* @file     light_bulb.h
* @brief    Head file for homekit light bulb service.
* @details  Light bulb Service data structs and external functions declaration.
* @author   tifnan_ge
* @date     2015-09-22
* @version  v0.1
*************************************************************************************************************
*/

#ifndef _LIGHT_BULB_H_
#define _LIGHT_BULB_H_

#ifdef  __cplusplus
extern "C" {
#endif      /* __cplusplus */
    
#include "stdint.h"
#include "stdbool.h"

/** @brief  Index defines for light bulb status Characteristic*/
#define GATT_SVC_LTBS_SRV_INST_INDEX          2 /**<  @brief  Index for service instant id chars's value      */
#define GATT_SVC_LTBS_ON_INDEX                5 /**<  @brief  Index for on chars's value      */
#define GATT_SVC_LTBS_BRIGHTNESS_INDEX        9 /**<  @brief  Index for brightness chars's value      */
#define GATT_SVC_LTBS_NAME_INDEX              13 /**<  @brief  Index for name chars's value      */

/****************************************************************************************************************
* exported globals are all defined here.
****************************************************************************************************************/
typedef struct _lbs_db_t
{
    uint32_t brightness;  //0-100
    uint8_t on_off;       //0 or 1
    uint8_t valid0;       //for valid
    uint8_t valid1;
    uint8_t padding;     
}lbs_db_t;

/****************************************************************************************************************
* exported globals.
****************************************************************************************************************/

/****************************************************************************************************************
* exported functions.
****************************************************************************************************************/
uint8_t lbs_init(void);
bool lbs_send_indication(uint8_t service_id, uint16_t attr_idx, uint8_t* data, uint16_t len);
uint8_t lbs_save_db(void);
uint8_t lbs_factory_reset(void);
void lbs_set_db(lbs_db_t* db);
void lbs_get_db(lbs_db_t* db);
uint8_t lbs_get_srv_id(void);

#ifdef  __cplusplus
}
#endif      /*  __cplusplus */

#endif  /* _LIGHT_BULB_H_ */
