/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file		main.c
* @brief	this is the main file of beacon project
* @details	
* @author	hunter_shuai
* @date 	23-June-2015
* @version	v1.0.0
******************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2015 Realtek Semiconductor Corporation</center></h2>
******************************************************************************
*/

#include "rtl876x.h"
#include "FreeRTOS.h"
#include "task.h"
#include "application.h"


#include "dlps_platform.h"

#include "broadcaster.h"
#include "gap.h"
#include "beacon_application.h"
#include "simple_ble_broadcaster.h"


/*
********************************************************
* parameter for btstack
*
*
*********************************************************
*/


// What is the advertising interval when device is discoverable (units of 625us, 160=100ms)
#define DEFAULT_ADVERTISING_INTERVAL_MIN            0x83 /* 20ms */
#define DEFAULT_ADVERTISING_INTERVAL_MAX            0x83 /* 30ms */
#define DEFAULT_DISCOVERABLE_MODE             GAP_ADTYPE_FLAGS_GENERAL

// Minimum connection interval (units of 1.25ms, 80=100ms) if automatic parameter update request is enabled
#define DEFAULT_DESIRED_MIN_CONN_INTERVAL     80
// Maximum connection interval (units of 1.25ms, 800=1000ms) if automatic parameter update request is enabled
#define DEFAULT_DESIRED_MAX_CONN_INTERVAL     800
// Slave latency to use if automatic parameter update request is enabled
#define DEFAULT_DESIRED_SLAVE_LATENCY         0
// Supervision timeout value (units of 10ms, 1000=10s) if automatic parameter update request is enabled
#define DEFAULT_DESIRED_CONN_TIMEOUT          1000


// GAP - SCAN RSP data (max size = 31 bytes)
static uint8_t scanRspData[] =
{
    0x03,           /* length     */
    0x03,           /* type="More 16-bit UUIDs available" */
    0x12,
    0x18,
    /* place holder for Local Name, filled by BT stack. if not present */
    /* BT stack appends Local Name.                                    */
    0x03,           /* length     */
    0x19,           /* type="Appearance" */
    0xc2, 0x03,     /* Mouse */
};

// GAP - Advertisement data (max size = 31 bytes, though this is
// best kept short to conserve power while advertisting)
static uint8_t advertData[] =
{
	/* IBeacon format data */
	0x02,				/* 1:length*/
	0x01,				/* 2:type Flag  */
	0x06,				/* 3:dicoverable mode & not support BR/EDR */
    0x1A,           	/* 4:length     */
    0xFF,           	/* 5:type="More 16-bit UUIDs available" */
    0x4C,0x00,			/* 6-7:	Apple company Id*/
	0x02,0x15,	 		/* 8-9:For all proximity beacon,specify data type & remaining data length*/	
	
	//Wechat test uuid:FDA50693-A4E2-4FB1-AFCF-C6EB07647825, Major: 10, Minor: 7
	0xFD,0xA5,0x06,0x93,
	0xA4,0xE2,0x4F,0xB1,
	0xAF,0xCF,0xC6,0xEB,
	0x07,0x64,0x78,0x25,
	0x00,0x0A,      	/* 26-27:major id*/
	0x00,0x07,			/* 28-29:minor id*/	
	0xB6,				/* 30:mesured power*/
};



void BtStack_Init_Gap()
{
      //device name and device appearance
    uint8_t DeviceName[GAP_DEVICE_NAME_LEN] = "Bee_broadcaster";
    uint16_t Appearance = GAP_GATT_APPEARANCE_UNKNOWN;
    

    //default start adv when bt stack initialized
    uint8_t  advEnableDefault = TRUE;

    //advertising parameters
    uint8_t  advEventType = GAP_ADTYPE_ADV_NONCONN_IND;
    uint8_t  advDirectType = PEER_ADDRTYPE_PUBLIC;
    uint8_t  advDirectAddr[B_ADDR_LEN] = {0};
    uint8_t  advChanMap = GAP_ADVCHAN_ALL;
    uint8_t  advFilterPolicy = GAP_FILTER_POLICY_ALL;
    uint16_t advIntMin = DEFAULT_ADVERTISING_INTERVAL_MIN;
    uint16_t advIntMax = DEFAULT_ADVERTISING_INTERVAL_MIN;
  

    //Set device name and device appearance
    broadcasterSetGapParameter(GAPPRRA_DEVICE_NAME, GAP_DEVICE_NAME_LEN, DeviceName);
    broadcasterSetGapParameter(GAPPRRA_APPEARANCE, sizeof(Appearance), &Appearance);

    //Set advertising parameters
    broadcasterSetGapParameter( GAPPRRA_ADV_ENABLE_DEFAULT, sizeof ( advEnableDefault ), &advEnableDefault );
    
    broadcasterSetGapParameter( GAPPRRA_ADV_EVENT_TYPE, sizeof ( advEventType ), &advEventType );
    broadcasterSetGapParameter( GAPPRRA_ADV_DIRECT_ADDR_TYPE, sizeof ( advDirectType ), &advDirectType );
    broadcasterSetGapParameter( GAPPRRA_ADV_DIRECT_ADDR, sizeof ( advDirectAddr ), advDirectAddr );
    broadcasterSetGapParameter( GAPPRRA_ADV_CHANNEL_MAP, sizeof ( advChanMap ), &advChanMap );
    broadcasterSetGapParameter( GAPPRRA_ADV_FILTER_POLICY, sizeof ( advFilterPolicy ), &advFilterPolicy );

    broadcasterSetGapParameter( GAPPRRA_ADVERT_DATA, sizeof( advertData ), advertData );
    broadcasterSetGapParameter( GAPPRRA_SCAN_RSP_DATA, sizeof ( scanRspData ), scanRspData );

    broadcasterSetGapParameter(GAPPRRA_ADV_INTERVAL_MIN, sizeof(advIntMin), &advIntMin);
    broadcasterSetGapParameter(GAPPRRA_ADV_INTERVAL_MAX, sizeof(advIntMax), &advIntMax);
}


/**
* @brief  Board_Init() contains the initialization of pinmux settings and pad settings.
*
* All the pinmux settings and pad settings shall be initiated in this function.
* But if legacy driver is used, the initialization of pinmux setting and pad setting
* should be peformed with the IO initializing. 
*
* @param   No parameter.
* @return  void
*/
void Board_Init()
{

}

/**
* @brief  Driver_Init() contains the initialization of peripherals.
*
* Both new architecture driver and legacy driver initialization method can be used.
*
* @param   No parameter.
* @return  void
*/
void Driver_Init()
{

}


/**
* @brief  PwrMgr_Init() contains the setting about power mode.
*
* @param   No parameter.
* @return  void
*/
void PwrMgr_Init()
{
	LPS_MODE_Set(LPM_DLPS_MODE);
	//LPS_MODE_Pause();
}


/**
* @brief  Task_Init() contains the initialization of all the tasks.
*
* There are four tasks are initiated.
* Lowerstack task and upperstack task are used by bluetooth stack.
* Application task is task which user application code resides in.
* Emergency task is reserved.
* 
* @param   No parameter.
* @return  void
*/
void Task_Init()
{
	void lowerstack_task_init();
	void upperstack_task_init();
	void emergency_task_init();
	application_task_init();
}


/**
* @brief  main() is the entry of user code.
*
* 
* @param   No parameter.
* @return  void
*/
int main(void)
{
    Board_Init();
    Driver_Init();
    BtStack_Init_Broadcaster();
    BtStack_Init_Gap();
    PwrMgr_Init();
    Task_Init();
    vTaskStartScheduler();

    return 0;
}

