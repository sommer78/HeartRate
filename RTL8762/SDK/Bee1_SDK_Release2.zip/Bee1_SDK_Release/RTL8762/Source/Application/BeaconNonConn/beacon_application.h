/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      simpleBLEPeripheral_application.h
* @brief     SimpleBLEPeripheral
* @details   SimpleBLEPeripheral
* @author    Shawn
* @date      2014-10-06
* @version   v0.1
* *********************************************************************************************************
*/

#ifndef _BEACON_APPLICATION__
#define _BEACON_APPLICATION__
#include "bee_message.h"

#ifdef __cplusplus
extern "C" {
#endif

#include "rtl876x.h"

/******************************************************************
 * @fn          AppHandleIODriverMessage
 * @brief      All the application events are pre-handled in this function.
 *                All the IO MSGs are sent to this function, Then the event handling function 
 *                shall be called according to the MSG type.
 *
 * @param    io_driver_msg_recv  - bee io msg data
 * @return     void
 */
extern void AppHandleIODriverMessage(BEE_IO_MSG io_driver_msg_recv);




#ifdef __cplusplus
}
#endif

#endif

