enum { __FILE_NUM__ = 0 };

/**
*********************************************************************************************************
*               Copyright(c) 2014, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      dtm.c
* @brief     direct test mode implementation.
* @details   none.
* @author    Tifnan
* @date      2014-08-07
* @version   v0.1
* *********************************************************************************************************
*/

#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#include "dtm.h"
#include "rtl876x_rcc.h"
#include "trace.h"
#include "rtl876x_pinmux.h"
#include "rtl876x_uart.h"

#define HCI_COMMAND_SUCCEEDED                                 0x00
/**
 * Command packet
 */
typedef struct
{
    uint16_t cmd_opcode;
    /* Length of parameter not the number of paramenters */
    uint8_t param_total_length;
    uint8_t cmd_parameter[255];
} HCI_CMD_PKT;

/* dtm task */
#define DTM_PRIORITY          (tskIDLE_PRIORITY + 2)

/* globals */
xQueueHandle    DTM_RxQueueHandle = NULL;       /**< received from uart interrupt isr */

/* extern funtion declaration */
extern UCHAR hci_handle_reset_command(void);
extern UINT8 hci_handle_le_receiver_test_cmd_only(HCI_CMD_PKT *hci_cmd_ptr);
extern UINT8 hci_handle_le_transmitter_test_cmd_only(HCI_CMD_PKT *hci_cmd_ptr);
extern UINT8 hci_handle_le_test_end_cmd_only(HCI_CMD_PKT *hci_cmd_ptr, UINT16 *pnum_of_packets);


/* static function declaration */
void DTM_Task(void *pParameters);
portBASE_TYPE DTM_SendMsgFromISR(const DTM_MSG *p_msg);
void DTM_UartInit(void);
void DTM_SendResult(DTM_MSG *p_msg);
void DTM_UartSendBytes(uint8_t *p_ch, uint16_t count);
void ConvertBytesToDtmMsg(uint8_t *p_cmd, DTM_MSG *p_dtm_msg);
void DtmDump(DTM_MSG *p_dtm_msg, uint8_t msg_type);


/**
 * @brief init dtm, create tx & rx queue and dtm task..
 *
 * @param  none.
 * @return none.
*/
void DTM_Init(void)
{
    /* create a receive queue to receive from data uart isr */
    xTaskCreate(DTM_Task, "DTM", 64, NULL, DTM_PRIORITY, NULL);
    DTM_RxQueueHandle  = xQueueCreate(4, sizeof(DTM_MSG));
}

/**
 * @brief init dtm, create tx & rx queue and dtm task..
 *
 * @param  pParameters, not used.
 * @return will not return.
*/
void DTM_Task(void *pParameters)
{
    /* DTM command */
    DTM_MSG msg;
    DTM_MSG event_msg;

    uint8_t cmd = 0;

    //for tx_rx command
    uint8_t frequency = 0;
    uint8_t lenth = 0;
    uint16_t pkt = 0;

    //for test reset and test end command
//    uint8_t ctrl = 0;
//    uint8_t para = 0;
//    uint8_t dc = 0;

    //for low stack
    uint16_t hci_cmd_pkt_buf_w[3] = {0, 0, 0};
    uint16_t no_of_pkts;
    uint8_t error_code;

    /* enable uart clock and init uart*/
    RCC_PeriphClockCmd(APBPeriph_UART, APBPeriph_UART_CLOCK, ENABLE);
    DTM_UartInit();

    for (;;)
    {
        /* wait for isr send command */
        if (xQueueReceive(DTM_RxQueueHandle, &msg, portMAX_DELAY) == pdPASS)
        {
            DtmDump(&msg, 0);
            cmd = msg.dtm_cmd.rst_end_cmd.cmd;

            switch (cmd)
            {
                case CMD_RESET:
//                    ctrl = msg.dtm_cmd.rst_end_cmd.ctrl;
//                    para = msg.dtm_cmd.rst_end_cmd.para;
//                    dc = msg.dtm_cmd.rst_end_cmd.dc;

                    error_code = hci_handle_reset_command();
                    event_msg.event.ev_status.event_type = EVENT_TYPE_TEST_STATUS;
                    event_msg.event.ev_status.dc = cmd;
                    event_msg.event.ev_status.status =
                        (error_code == HCI_COMMAND_SUCCEEDED) ?
                        DTM_STATUS_SUCCESS :
                        DTM_STATUS_ERROR;
                    break;

                case CMD_RX_TEST:
                    frequency = msg.dtm_cmd.tx_rx_cmd.freq;
                    lenth = msg.dtm_cmd.tx_rx_cmd.length;
                    pkt = msg.dtm_cmd.tx_rx_cmd.pkt;

                    *(((uint8_t *)hci_cmd_pkt_buf_w) + 3) = frequency;
                    *(((uint8_t *)hci_cmd_pkt_buf_w) + 4) = lenth;
                    *(((uint8_t *)hci_cmd_pkt_buf_w) + 5) = pkt;

                    error_code = hci_handle_le_receiver_test_cmd_only((HCI_CMD_PKT *)hci_cmd_pkt_buf_w);
                    event_msg.event.ev_status.event_type = EVENT_TYPE_TEST_STATUS;
                    event_msg.event.ev_status.dc = cmd;
                    event_msg.event.ev_status.status =
                        (error_code == HCI_COMMAND_SUCCEEDED) ?
                        DTM_STATUS_SUCCESS :
                        DTM_STATUS_ERROR;
                    break;

#if 1  //normal DTM mode              
                case CMD_TX_TEST:
                    frequency = msg.dtm_cmd.tx_rx_cmd.freq;
                    lenth = msg.dtm_cmd.tx_rx_cmd.length;
                    pkt = msg.dtm_cmd.tx_rx_cmd.pkt;

                    *(((uint8_t *)hci_cmd_pkt_buf_w) + 3) = frequency;
                    *(((uint8_t *)hci_cmd_pkt_buf_w) + 4) = lenth;
                    *(((uint8_t *)hci_cmd_pkt_buf_w) + 5) = pkt;

                    error_code = hci_handle_le_transmitter_test_cmd_only((HCI_CMD_PKT *)hci_cmd_pkt_buf_w);
                    event_msg.event.ev_status.event_type = EVENT_TYPE_TEST_STATUS;
                    event_msg.event.ev_status.dc = cmd;
                    event_msg.event.ev_status.status =
                        (error_code == HCI_COMMAND_SUCCEEDED) ?
                        DTM_STATUS_SUCCESS :
                        DTM_STATUS_ERROR;
                    break;
#endif
#if 0  //continue tx test
                case CMD_TX_TEST:
                    frequency = msg.dtm_cmd.tx_rx_cmd.freq;
                    lenth = msg.dtm_cmd.tx_rx_cmd.length;
                    pkt = msg.dtm_cmd.tx_rx_cmd.pkt;

                    *(((uint8_t *)hci_cmd_pkt_buf_w) + 3) = frequency;
                    *(((uint8_t *)hci_cmd_pkt_buf_w) + 4) = lenth;
                    *(((uint8_t *)hci_cmd_pkt_buf_w) + 5) = pkt;

                    while (true)
                    {
                        //add test end command
                        error_code = hci_handle_le_test_end_cmd_only(NULL, &no_of_pkts);
                        error_code = hci_handle_le_test_end_cmd_only(NULL, &no_of_pkts);

                        error_code = hci_handle_le_transmitter_test_cmd_only((HCI_CMD_PKT *)hci_cmd_pkt_buf_w);
                        event_msg.event.ev_status.event_type = EVENT_TYPE_TEST_STATUS;
                        event_msg.event.ev_status.dc = cmd;
                        event_msg.event.ev_status.status =
                            (error_code == HCI_COMMAND_SUCCEEDED) ?
                            DTM_STATUS_SUCCESS :
                            DTM_STATUS_ERROR;
                        vTaskDelay(500 / portTICK_RATE_MS);
                    }
                    break;
#endif
                case CMD_END:
//                    ctrl = msg.dtm_cmd.rst_end_cmd.ctrl;
//                    para = msg.dtm_cmd.rst_end_cmd.para;
//                    dc = msg.dtm_cmd.rst_end_cmd.dc;

                    error_code = hci_handle_le_test_end_cmd_only(NULL, &no_of_pkts);
                    event_msg.event.ev_pkt_report.event_type = EVENT_TYPE_PKT_REPORT;
                    //no_of_pkts = 0x25;//just for testing!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1
                    event_msg.event.ev_pkt_report.pkt_count = no_of_pkts;
                    break;

                default:
                    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "DTM: unknow command\n", 0);
                    break;
            }
            DtmDump(&event_msg, 1);
            DTM_SendResult(&event_msg);
        }
    }
}


/**
 * @brief send two rx bytes to DTM_RxQueue.
 *
 * @param  p_msg, DTM messgae pointer.
 * @return sending result.
 * &retval pdTRUE if the data was successfully sent to the queue, otherwise errQUEUE_FULL.
*/
portBASE_TYPE DTM_SendMsgFromISR(const DTM_MSG *p_msg)
{
    portBASE_TYPE ReturnValue;
    portBASE_TYPE TaskWoken = pdFALSE;

    ReturnValue = xQueueSendFromISR(DTM_RxQueueHandle, p_msg, &TaskWoken);
    portYIELD_FROM_ISR(TaskWoken);
    return (ReturnValue);
}

/**
 * @brief receive two bytes command from PC.
 *
 * @param  nonee.
 * @return void.
*/
void DtmDataUartIrqHandle(void)
{
    uint8_t rev_cmd[2] = {0, 0};
    uint8_t *p = &rev_cmd[0];
    DTM_MSG msg;
    uint32_t int_status = 0;

    /* read interrupt id */
    int_status = UART_GetIID(UART);
    /* disable interrupt */
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, DISABLE);

    switch (int_status)
    {
        /* tx fifo empty */
        case UART_INT_ID_TX_EMPTY:
            /* do nothing */
            break;

        /* rx data valiable */
        case UART_INT_ID_RX_LEVEL_REACH:
        case UART_INT_ID_RX_TMEOUT:

            while (UART_GetFlagState(UART, UART_FLAG_RX_DATA_RDY) == SET)
            {
                UART_ReceiveData(UART, p++, 1);
            }

            //dump row hex here
            DBG_BUFFER(MODULE_FRAMEWORK, LEVEL_INFO, "Form 8852B row hex: 0x%x", 1, \
                       ((uint16_t)rev_cmd[0] << 8) | (uint16_t)rev_cmd[1]);
            /* notify ltp task */
            ConvertBytesToDtmMsg(rev_cmd, &msg);
            DTM_SendMsgFromISR(&msg);
            break;

        /* receive line status interrupt */
        case UART_INT_ID_LINE_STATUS:
            DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "Line status error!!!!\n", 0);
            break;

        default:
            DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "unknow uart interrupt id", 0);
            break;
    }

    /* enable interrupt again */
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, ENABLE);
    return;
}

extern IRQ_FUN UserIrqFunTable[32 + 17];
void DTM_UartInit(void)
{
    //pinmux config
    Pinmux_Config(P3_0, DATA_UART_TX);
    Pinmux_Config(P3_1, DATA_UART_RX);

    //pad config
    Pad_Config(P3_0, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
    Pad_Config(P3_1, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);

    //uart interrupt config
    UserIrqFunTable[UART_IRQ]               = (IRQ_FUN)DtmDataUartIrqHandle;

    //uart init
    UART_InitTypeDef uartInitStruct;
    UART_StructInit(&uartInitStruct);

    uartInitStruct.rxTriggerLevel = UART_RX_FIFO_TRIGGER_LEVEL_4BYTE;
    UART_Init(UART, &uartInitStruct);

    //enable line status interrupt and rx data avaliable interrupt
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, ENABLE);

    /*  Enable UART IRQ  */
    NVIC_ClearPendingIRQ(UART_IRQ);
    NVIC_SetPriority(UART_IRQ, 0);
    NVIC_EnableIRQ(UART_IRQ);

    return;
}

/**
 * @brief send DTM event to PC.
 *
 * @param  p_msg, DTM messgae pointer.
 * @return void.
*/
void DTM_SendResult(DTM_MSG *p_msg)
{
    uint8_t event[2] = {0};
    uint8_t *p = &event[0];

    /* status event */
    if ((uint8_t)(p_msg->event.ev_status.event_type) == EVENT_TYPE_TEST_STATUS)
    {
        event[0] = ((uint8_t)p_msg->event.ev_status.event_type << 7) | ((uint16_t)p_msg->event.ev_status.dc >> 7);
        event[1] = ((uint8_t)p_msg->event.ev_status.dc << 1) | ((uint8_t)p_msg->event.ev_status.status);
    }

    /* pkt report event*/
    if ((uint8_t)(p_msg->event.ev_pkt_report.event_type) == EVENT_TYPE_PKT_REPORT)
    {
        event[0] = ((uint8_t)p_msg->event.ev_pkt_report.event_type << 7) | ((uint16_t)p_msg->event.ev_pkt_report.pkt_count >> 8);
        event[1] = (uint8_t)p_msg->event.ev_pkt_report.pkt_count;
    }
    DTM_UartSendBytes(p, 2);

    return;
}

/**
 * @brief send a char through data uart.
 *
 * @param  ch, char to be sent.
 * @param count, the number of char to sent.
 * @return void.
*/
void DTM_UartSendBytes(uint8_t *p_ch, uint16_t count)
{
    uint16_t i = 0;
    for (i = 0; i < count; i++)
    {
        while (UART_GetFlagState(UART, UART_FLAG_THR_EMPTY) != SET);
        UART_SendData(UART, p_ch++, 1);
    }
}


/**
 * @brief a tool function to convert two bytes to DTM_MSG struct.
 *
 * @param  p_cmd, pointer to two command bytes.
 * @param  p_dtm_msg, pointer to the DTM_CMD which to be init.
 * @return void.
*/
void ConvertBytesToDtmMsg(uint8_t *p_cmd, DTM_MSG *p_dtm_msg)
{
    uint8_t cmd = (*p_cmd & 0xc0) >> 6;

    if (cmd == CMD_RESET || cmd == CMD_END)
    {
        p_dtm_msg->dtm_cmd.rst_end_cmd.cmd = cmd;
        p_dtm_msg->dtm_cmd.rst_end_cmd.ctrl = (*p_cmd & 0x3f);
        p_cmd++;    /* two bytes */
        p_dtm_msg->dtm_cmd.rst_end_cmd.para = (*p_cmd & 0xfc) >> 2;
        p_dtm_msg->dtm_cmd.rst_end_cmd.dc = *p_cmd & 0x03;
    }
    else
    {
        p_dtm_msg->dtm_cmd.tx_rx_cmd.cmd = cmd;
        p_dtm_msg->dtm_cmd.tx_rx_cmd.freq = (*p_cmd & 0x3f);
        p_cmd++;    /* two bytes */
        p_dtm_msg->dtm_cmd.tx_rx_cmd.length = (*p_cmd & 0xfc) >> 2;
        p_dtm_msg->dtm_cmd.tx_rx_cmd.pkt = *p_cmd & 0x03;
    }

    return;
}

/* type: 0--cmd, 1--event */
void DtmDump(DTM_MSG *p_dtm_msg, uint8_t msg_type)
{
    /* dtm command */
    if (0 == msg_type)
    {
        if (p_dtm_msg->dtm_cmd.rst_end_cmd.cmd == CMD_RESET
                || p_dtm_msg->dtm_cmd.rst_end_cmd.cmd == CMD_END)
        {
            DBG_BUFFER(MODULE_FRAMEWORK, LEVEL_INFO, "DTM_CMD-- cmd = 0x%x, ctrl = 0x%x, Para = 0x%x, dc = 0x%x", 4, \
                       p_dtm_msg->dtm_cmd.rst_end_cmd.cmd, \
                       p_dtm_msg->dtm_cmd.rst_end_cmd.ctrl, \
                       p_dtm_msg->dtm_cmd.rst_end_cmd.para, \
                       p_dtm_msg->dtm_cmd.rst_end_cmd.dc);
        }
        else
        {
            DBG_BUFFER(MODULE_FRAMEWORK, LEVEL_INFO, "DTM_CMD-- cmd = 0x%x, freq = 0x%x, len = 0x%x, pkt = 0x%x", 4, \
                       p_dtm_msg->dtm_cmd.tx_rx_cmd.cmd, \
                       p_dtm_msg->dtm_cmd.tx_rx_cmd.freq, \
                       p_dtm_msg->dtm_cmd.tx_rx_cmd.length, \
                       p_dtm_msg->dtm_cmd.tx_rx_cmd.pkt);
        }
    }

    if (1 == msg_type)
    {
        if (EVENT_TYPE_TEST_STATUS == p_dtm_msg->event.ev_status.event_type)
        {
            DBG_BUFFER(MODULE_FRAMEWORK, LEVEL_INFO, "STA_EVT-- ev = 0x%x, dc = 0x%x, st = 0x%x", 3, \
                       p_dtm_msg->event.ev_status.event_type, p_dtm_msg->event.ev_status.dc, p_dtm_msg->event.ev_status.status);
        }

        if (EVENT_TYPE_PKT_REPORT == p_dtm_msg->event.ev_pkt_report.event_type)
        {
            DBG_BUFFER(MODULE_FRAMEWORK, LEVEL_INFO, "PKE_RPT-- ev = 0x%x, pkt_count = 0x%x", 2, \
                       p_dtm_msg->event.ev_pkt_report.event_type, p_dtm_msg->event.ev_pkt_report.pkt_count);
        }
    }
}


