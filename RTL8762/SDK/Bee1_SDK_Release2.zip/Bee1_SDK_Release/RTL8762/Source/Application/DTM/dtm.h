/**
*********************************************************************************************************
*               Copyright(c) 2014, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      dtm.h
* @brief     direct test mode macro defines.
* @details   none.
* @author    Tifnan
* @date      2014-08-07
* @version   v0.1
* *********************************************************************************************************
*/

#ifndef _BEE_DTM_H_
#define _BEE_DTM_H_

#include "rtl_types.h"
#include "freeRTOS.h"
#include "task.h"
#include "queue.h"

/* commands(16bit/2bytes):
    cmd(2bit)|freq(6bit)|len(6bit)|pkt(2bit) */

/* command */
#define CMD_MASK                    (uint8_t)0x03
#define CMD_RESET                   (uint8_t)0x00
#define CMD_RX_TEST                 (uint8_t)0x01
#define CMD_TX_TEST                 (uint8_t)0x02
#define CMD_END                     (uint8_t)0x03

/* frequency 0x00--027
    (F-2402)/2, Frequency Range 2402 MHz to 2480 MHz*/

/* len 0x00--0x25, 0x26-0x3f reserved */

/* pkt type */
#define PKT_TYPE_MASK1              (uint8_t)0x03
#define PKT_TYPE_PRBS9              (uint8_t)0x00
#define PKT_TYPE_11110000           (uint8_t)0x01
#define PKT_TYPE_10101010           (uint8_t)0x02
#define PKT_TYPE_VEND               (uint8_t)0x03

/* two type event(16bits)
    EV(1bit)|(15bits) */

#define EVENT_TYPE_TEST_STATUS      (uint8_t)0x00
#define EVENT_TYPE_PKT_REPORT       (uint8_t)0x01

/* LE_Test_Status_Event
    EV(1bit)|DC(7bits)|DC(7bit)|ST(1bit)
    DC ignore */

#define DTM_STATUS_SUCCESS          (uint8_t)0x00
#define DTM_STATUS_ERROR            (uint8_t)0x01

/* timeout, ms */
#define T_TIMEOUT                   (uint8_t)100        /* wait for DUT response */
#define T_TURN_AROUND_MIN           (uint8_t)5          /* from received a response to sending another command */
#define T_COMMADN_MAX               (uint8_t)5          /* time between two bytes in one command */
#define T_DUT_RESPONSE_MAX          (uint8_t)50         /* from DUT received a command to responsing */

/* globals*/
extern xQueueHandle DTM_CmdQueueHandle;     /**< @brief send command to low stack */
extern xQueueHandle DTM_EventQueueHandle;   /**< @brief receive event from low stack */

/* Transmitter Test and Receiver Test command */
typedef struct
{
    uint16_t cmd : 2;
    uint16_t freq : 6;
    uint16_t length : 6;
    uint16_t pkt : 2;
} DTM_TX_RX_CMD;

/* Reset and Test end command */
typedef struct
{
    uint16_t cmd : 2;
    uint16_t ctrl : 6;
    uint16_t para : 6;
    uint16_t dc : 2;
} DTM_RST_END_CMD;

typedef union
{
    DTM_TX_RX_CMD   tx_rx_cmd;
    DTM_RST_END_CMD rst_end_cmd;
} DTM_CMD;

/* LE_Test_Status_Event */
typedef struct
{
    uint16_t event_type : 1;
    uint16_t dc : 14;       /* ignored */
    uint16_t status : 1;
} EV_STATUS;

/* LE_Packet_Report_Event */
typedef struct
{
    uint16_t event_type : 1;
    uint16_t pkt_count : 15;
} EV_PKT_REPORT;

typedef union
{
    EV_STATUS ev_status;
    EV_PKT_REPORT ev_pkt_report;
} DTM_EVENT;

/* DTM message */
typedef union
{
    DTM_CMD dtm_cmd;
    DTM_EVENT event;
} DTM_MSG;

/* export functions */
void DTM_Init(void);

#endif  /* _BEE_DTM_H_ */

