#include "auto_test.h"

int main(void) 
{  	
    DBG_DIRECT("User code entry\n");
    AutoTestInit();
	  return 0;
}
