/**
**********************************************************************************************************
*               Copyright(c) 2014, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     auto_test.c
* @brief    auto test implementation.
* @details  none.
* @author   yue
* @date     2015-06-03
* @version  v0.1
**********************************************************************************************************
*/
#include "auto_test.h"
/*definition of Auto test task section*/
#define AutoTest_STACK_SIZE        		2048
#define AutoTest_PRIORITY          		(tskIDLE_PRIORITY + 2)   /* Task priorities. */
#define AutoTest_NUMBER_OF_RX_EVENT     0x20
#define AutoTest_UART_RX_EVENT     		0x01

#define BIT_PERI_UART0_EN BIT(0)
#define BIT_SOC_ACTCK_UART0_EN BIT(0)
#define BIT_SOC_ACTCK_TIMER_EN BIT(14)
#define BIT_PERI_I2C1_EN BIT(17)
#define BIT_PERI_I2C0_EN BIT(16)
#define BIT_SOC_ACTCK_I2C1_EN BIT(2)
#define BIT_SOC_ACTCK_I2C0_EN BIT(0)
#define BIT_PERI_SPI1_EN BIT(9)
#define BIT_PERI_SPI0_EN BIT(8)
#define BIT_SOC_ACTCK_SPI1_EN BIT(18)
#define BIT_SOC_ACTCK_SPI0_EN BIT(16)


AutoTest_PacketTypeDef AutoTest_Packet;
/*queue handle for communication between isr and auto test task*/
static xQueueHandle AutoTestQueueHandleEvent;

/* definition of global variable for Auto test */
AutoTest_CmdTypeDef AutoTest_cmd SRAM_OFF_BD_DATA_SECTION;
/* store state for Initialize and Deinitialize function test of uart */
uint8_t REG_PERI_uart_Params[9] SRAM_OFF_BD_DATA_SECTION; 

KEYSCAN_DATA_STRUCT  CurKeyData;

void AutoTestHandle(uint8_t cmd, uint8_t copmsk, uint8_t* pOpt, uint16_t lenPara, uint8_t* pPara);
void ConvertBytesToAutoTestCmd(uint8_t cmd, uint8_t copmsk, uint8_t* pOpt, uint16_t lenPara, uint8_t* pPara, AutoTest_CmdTypeDef *pAutoTest_cmd);
void AutoTestParameterHandle(uint8_t* pPara, uint16_t lenPara, AutoTest_CmdTypeDef *pAutoTest_cmd);

void AutoTestGPIOHandle(AutoTest_CmdTypeDef *pAutoTest_cmd );
void AutoTestGPIOParamHandle(uint8_t* pPara, GPIO_InitTypeDef *pAutoTest_GPIO_param);


void AutoTestPWMHandle(AutoTest_CmdTypeDef *pAutoTest_cmd);
void AutoTestPWMParameterHandle(uint8_t* pPara, AutoTest_pwm_Params *pAutoTest_PWMAdap);

void AutoTestTimerHandle(AutoTest_CmdTypeDef *pAutoTest_cmd );
void AutoTestTimerParamHandle(uint8_t* pPara, AutoTest_Tim_Params *pAutoTestTimerAdap);

void AutoTestUartHandle(uint8_t cmd, uint8_t copmsk, uint8_t* pOpt, uint16_t lenPara, uint8_t* pPara, AutoTest_CmdTypeDef *AutoTest_cmd );
void AutoTestUartParameterHandle(uint8_t* pPara, AutoTest_CmdTypeDef *pAutoTest_cmd);
void AutoTestUartLoopBackHandle(uint8_t cmd, uint8_t copmsk, uint8_t* pOpt,uint16_t lenPara, uint8_t* pPara);
void BaudRateModifyHandle(uint8_t ovsr, uint16_t div, uint16_t ovsr_adj);    


void AutoTestI2CHandle(AutoTest_CmdTypeDef *pAutoTest_cmd );
void AutoTestI2CParamHandle(uint8_t* pPara, AutoTest_i2c_Params *pAutoTest_I2C_Params);

void AutoTestSPIHandle(AutoTest_CmdTypeDef *pAutoTest_cmd );
void AutoTestSPIParamHandle(uint8_t* pSPIPara, AutoTest_spi_Params *pAutoTest_SPI_Params);


void AutoTestKeyScanHandle(AutoTest_CmdTypeDef *pAutoTest_cmd );
void AutoTestKeyScanParamHandle(uint8_t* pParam, AutoTest_keyscan_Params *pkeypad_param);


uint8_t AutoTest_ReadPeriFunRegister(uint32_t base, uint32_t addr, uint32_t BIT_PERI_EN);
void ReadPeriFunRegisterByPeripheralType(InitOrDeinitPeripherialType periType, uint8_t *FUNC_param, uint8_t *CLK_param);
uint8_t AutoTest_ReadPinStatus(uint8_t Pin_Num);




/* API for Auto test task */
void AutoTestTask(void *pParameters);
BOOL PacketDecoder(AutoTest_PacketTypeDef *pAutoTest_Packet, uint16_t size);
BYTE AutoTestCRC8(LPBYTE pStart, WORD length);
void DataUARTInit(void);
BOOL LoopQueueIsFull(AutoTest_PacketTypeDef *pAutoTest_Packet);
BOOL LoopQueueIsEmpty(AutoTest_PacketTypeDef *pAutoTest_Packet);
void LoopQueueInit(AutoTest_PacketTypeDef *pAutoTest_Packet);
uint8_t AutoTestSendData(uint8_t FunNum, uint8_t *sendbuffer, uint32_t buffer_length);
int AutosendInt32(uint32_t ch);
int Autosendchar(int ch);


BaseType_t AutoTestInit(void)
{
	BaseType_t xReturn = pdFAIL;

	LoopQueueInit(&AutoTest_Packet);
	DataUARTInit();
	xReturn = xTaskCreate( AutoTestTask, "Auto test", AutoTest_STACK_SIZE/sizeof(portSTACK_TYPE), NULL, AutoTest_PRIORITY, NULL );	
	/* start task schedule */
  	vTaskStartScheduler();
	return xReturn;
}

BOOL LoopQueueIsFull(AutoTest_PacketTypeDef *pAutoTest_Packet)
{
	if(pAutoTest_Packet->QueueSize >= pAutoTest_Packet->QueueCapacity)
	{
		DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_ERROR, "LoopQueue is overflow!", 0);
		return TRUE;
	}
	return FALSE;	
}
BOOL LoopQueueIsEmpty(AutoTest_PacketTypeDef *pAutoTest_Packet)
{
	return pAutoTest_Packet->QueueSize == 0; 	
}

void LoopQueueInit(AutoTest_PacketTypeDef *pAutoTest_Packet)
{
	pAutoTest_Packet->Decoderlength  = 0;				/**< length of decoder payload*/
	pAutoTest_Packet->DecoderIndex 	 = 0;
	pAutoTest_Packet->QueueCapacity  = 256;				/**<equal length of LoopQueue*/
	pAutoTest_Packet->QueueSize 	 = 0;
	pAutoTest_Packet->ReadIndex 	 = 0;				/**< index of read queue */
	pAutoTest_Packet->WriteIndex 	 = 0; 				/**< index of write queue */
	pAutoTest_Packet->PacketLength 	 = 0;
	pAutoTest_Packet->CollectorState = WaitCmd;
}

void AutoTestTask(void *pParameters)
{
	uint8_t event;
	uint16_t queueSize;
	
	/*init event queue  from uart to AutoTest task*/
	AutoTestQueueHandleEvent = xQueueCreate(AutoTest_NUMBER_OF_RX_EVENT, sizeof(unsigned char));

	while(TRUE)
	{
		if(xQueueReceive(AutoTestQueueHandleEvent, &event, portMAX_DELAY) == pdPASS)
		{
			if(event == AutoTest_UART_RX_EVENT)
			{
				do
				{
					taskENTER_CRITICAL();
					queueSize = AutoTest_Packet.QueueSize;
					taskEXIT_CRITICAL();
					
					if(PacketDecoder(&AutoTest_Packet, queueSize))
					{
						AutoTestHandle(AutoTest_Packet.DecoderData[0], AutoTest_Packet.DecoderData[1], &AutoTest_Packet.DecoderData[4], AutoTest_Packet.PacketLength - 9, &AutoTest_Packet.DecoderData[9]);
					}
					
					taskENTER_CRITICAL();
					queueSize = AutoTest_Packet.QueueSize;
					taskEXIT_CRITICAL();
				}while(queueSize);
			}
		}
		DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "Auto test-->Task is running!", 0);
	}
}

void DataUARTInit(void)
{
		/* System clock configuration */
	RCC_PeriphClockCmd(APBPeriph_UART, APBPeriph_UART_CLOCK, ENABLE);

	/* pinmux configuration */
	Pinmux_Config(P3_4, DATA_UART_TX);
	Pinmux_Config(P3_5, DATA_UART_RX);
	Pinmux_Config(P0_6, DATA_UART_CTS);
	Pinmux_Config(P0_7, DATA_UART_RTS);

	/* pad configuration */
	Pad_Config(P3_4, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
	Pad_Config(P3_5, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);
	Pad_Config(P0_6, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_HIGH);
	Pad_Config(P0_7, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_HIGH);

	/* NVIC configuration */
	NVIC_InitTypeDef NVIC_InitStruct;
	NVIC_InitStruct.NVIC_IRQChannel = UART_IRQ;
	NVIC_InitStruct.NVIC_IRQChannelPriority = 0;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStruct);

	/* uart init */
	UART_InitTypeDef uartInitStruct;
	uartInitStruct.div = 20;
	uartInitStruct.ovsr = 12;
	uartInitStruct.ovsr_adj = 0x252;

	uartInitStruct.parity = UART_PARITY_NO_PARTY;
	uartInitStruct.stopBits = UART_STOP_BITS_1;
	uartInitStruct.wordLen = UART_WROD_LENGTH_8BIT;
	uartInitStruct.dmaEn = UART_DMA_DISABLE;
	uartInitStruct.autoFlowCtrl= UART_AUTO_FLOW_CTRL_DIS;
	uartInitStruct.rxTriggerLevel= UART_RX_FIFO_TRIGGER_LEVEL_14BYTE;
	UART_Init(UART, &uartInitStruct);

	//enable rx interrupt and line status interrupt
	UART_INTConfig(UART, UART_INT_RD_AVA| UART_INT_LINE_STS, ENABLE);

}

void DataUartIntrHandler(void)

{
	uint8_t event = AutoTest_UART_RX_EVENT;
	portBASE_TYPE TaskWoken = pdFALSE;
	uint16_t len = 0;
	
	/* read interrupt id */
    UINT32 int_status = UART_GetIID(UART);
	
	/* disable interrupt */
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, DISABLE);
	
	switch(int_status & 0x0E)
	{
		/* tx fifo empty */
		case 0x02:
		/* do nothing */
		break;

		/* rx data valiable */
		case 0x04:
			if(!LoopQueueIsFull(&AutoTest_Packet))
			{
				AutoTest_Packet.WriteIndex &= (AutoTest_Packet.QueueCapacity -1);
				if(AutoTest_Packet.WriteIndex + 14 < AutoTest_Packet.QueueCapacity)
				{
					UART_ReceiveData(UART,&AutoTest_Packet.LoopQueue[AutoTest_Packet.WriteIndex], 14);
					AutoTest_Packet.WriteIndex = (AutoTest_Packet.WriteIndex + 14)&(AutoTest_Packet.QueueCapacity -1);					
				}
				else
				{
					len = AutoTest_Packet.QueueCapacity - AutoTest_Packet.WriteIndex;
					UART_ReceiveData(UART,&AutoTest_Packet.LoopQueue[AutoTest_Packet.WriteIndex], len);
					AutoTest_Packet.WriteIndex = (AutoTest_Packet.WriteIndex + len) & (AutoTest_Packet.QueueCapacity -1);
					UART_ReceiveData(UART,&AutoTest_Packet.LoopQueue[AutoTest_Packet.WriteIndex], 14 - len);
					AutoTest_Packet.WriteIndex += 14 - len;
				}
			AutoTest_Packet.QueueSize += 14;
			xQueueSendFromISR(AutoTestQueueHandleEvent, &event, &TaskWoken);
			}

#if AUTOTEST_DBG_EN
			DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "Auto test-->Receive Auto test packet!", 0);
#endif
		break;

		/*rx time out*/
		case 0x0c:
			if(!LoopQueueIsFull(&AutoTest_Packet))
			{
				while(UART_GetFlagState(UART, UART_FLAG_RX_DATA_RDY) == SET)
				{
					//Queue wrap
					AutoTest_Packet.WriteIndex &= (AutoTest_Packet.QueueCapacity -1);
					UART_ReceiveData(UART, &AutoTest_Packet.LoopQueue[AutoTest_Packet.WriteIndex++],1);
					AutoTest_Packet.QueueSize++;
				}
			xQueueSendFromISR(AutoTestQueueHandleEvent, &event, &TaskWoken);
			}
#if AUTOTEST_DBG_EN
			DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "Auto test-->Receive Auto test packet timeout!", 0);
#endif
		break;
		
		/* receive line status interrupt */
		case 0x06:
			//reg_val = UART_GetLineStatus(INDEX_DATA_UART);
			//DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "Auto test-->UART_LINE_STATUS_REG_OFF = 0x%2x", 1, reg_val);
		break;

		default:
			//UART_GetStatus(INDEX_DATA_UART);
			//UART_GetLineStatus(INDEX_DATA_UART);
			//DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "Auto test--> uart handle: default", 0);
		break;
	}
	/* enable interrupt again */
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, ENABLE);
}

BOOL PacketDecoder(AutoTest_PacketTypeDef *pAutoTest_Packet, uint16_t size)
{
	uint16_t decodedSize = size;
	BOOL PaketComplete = FALSE;
	
	switch(pAutoTest_Packet->CollectorState)
	{
		case WaitCmd:
		{
			if(size > 0)
			{
				if(pAutoTest_Packet->LoopQueue[pAutoTest_Packet->ReadIndex] == 0xf6)
				{
					pAutoTest_Packet->ReadIndex &= (pAutoTest_Packet->QueueCapacity -1);
					pAutoTest_Packet->DecoderData[pAutoTest_Packet->DecoderIndex++] = pAutoTest_Packet->LoopQueue[pAutoTest_Packet->ReadIndex++]; 
					pAutoTest_Packet->CollectorState = WaitCopmask;
					size--;
				}
				else
				{
					DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_ERROR, "Auto test-->receive error cmd: cmd = 0x%2x", 1, pAutoTest_Packet->LoopQueue[pAutoTest_Packet->ReadIndex]);
					pAutoTest_Packet->ReadIndex &= (pAutoTest_Packet->QueueCapacity -1);
					pAutoTest_Packet->ReadIndex++;
					decodedSize = 1;
					
					break;
				}
			}
			else
			{
				break;
			}
		}
		case WaitCopmask:
		{
			if(size > 0)
			{
				pAutoTest_Packet->ReadIndex &= (pAutoTest_Packet->QueueCapacity -1);
				pAutoTest_Packet->DecoderData[pAutoTest_Packet->DecoderIndex++] = pAutoTest_Packet->LoopQueue[pAutoTest_Packet->ReadIndex++]; 
				pAutoTest_Packet->CollectorState = WaitLp_h;
				size--;
			}
			else
			{
				break;
			}
		}
		case WaitLp_h:
		{
			if(size > 0)
			{
				pAutoTest_Packet->ReadIndex &= (pAutoTest_Packet->QueueCapacity -1);
				pAutoTest_Packet->DecoderData[pAutoTest_Packet->DecoderIndex++] = pAutoTest_Packet->LoopQueue[pAutoTest_Packet->ReadIndex++]; 
				pAutoTest_Packet->CollectorState = WaitLp_l;
				size--;
			}
			else
			{
				break;
			}
		}
		case WaitLp_l:
		{
			if(size > 0)
			{
				pAutoTest_Packet->ReadIndex &= (pAutoTest_Packet->QueueCapacity -1);
				pAutoTest_Packet->PacketLength = pAutoTest_Packet->LoopQueue[pAutoTest_Packet->ReadIndex]; 
				pAutoTest_Packet->DecoderData[pAutoTest_Packet->DecoderIndex++] = pAutoTest_Packet->LoopQueue[pAutoTest_Packet->ReadIndex++];
				pAutoTest_Packet->CollectorState = WaitP1;
				size--;
			}
			else
			{
				break;
			}
		}
		case WaitP1:
		{
			if(size > 0)
			{
				pAutoTest_Packet->ReadIndex &= (pAutoTest_Packet->QueueCapacity -1);
				pAutoTest_Packet->DecoderData[pAutoTest_Packet->DecoderIndex++] = pAutoTest_Packet->LoopQueue[pAutoTest_Packet->ReadIndex++];
				pAutoTest_Packet->CollectorState = WaitP2_h;
				size--;
			}
			else
			{
				break;
			}
		}
		case WaitP2_h:
		{
			if(size > 0)
			{
				pAutoTest_Packet->ReadIndex &= (pAutoTest_Packet->QueueCapacity -1);
				pAutoTest_Packet->DecoderData[pAutoTest_Packet->DecoderIndex++] = pAutoTest_Packet->LoopQueue[pAutoTest_Packet->ReadIndex++];
				pAutoTest_Packet->CollectorState = WaitP2_l;
				size--;
			}
			else
			{
				break;
			}
		}
		case WaitP2_l:
		{
			if(size > 0)
			{
				pAutoTest_Packet->ReadIndex &= (pAutoTest_Packet->QueueCapacity -1);
				pAutoTest_Packet->DecoderData[pAutoTest_Packet->DecoderIndex++] = pAutoTest_Packet->LoopQueue[pAutoTest_Packet->ReadIndex++];
				pAutoTest_Packet->CollectorState = WaitP3;
				size--;
			}
			else
			{
				break;
			}
		}
		case WaitP3:
		{
			if(size > 0)
			{
				pAutoTest_Packet->ReadIndex &= (pAutoTest_Packet->QueueCapacity -1);
				pAutoTest_Packet->DecoderData[pAutoTest_Packet->DecoderIndex++] = pAutoTest_Packet->LoopQueue[pAutoTest_Packet->ReadIndex++];
				pAutoTest_Packet->CollectorState = WaitCRC;
				size--;
			}
			else
			{
				break;
			}
		}
		case WaitCRC:
		{
			if(size > 0)
			{
				pAutoTest_Packet->ReadIndex &= (pAutoTest_Packet->QueueCapacity -1);
				
				if(AutoTestCRC8(pAutoTest_Packet->DecoderData, 4) == pAutoTest_Packet->LoopQueue[pAutoTest_Packet->ReadIndex]) 
				{
					pAutoTest_Packet->DecoderData[pAutoTest_Packet->DecoderIndex++] = pAutoTest_Packet->LoopQueue[pAutoTest_Packet->ReadIndex++];
					size--;
					
					if(pAutoTest_Packet->PacketLength == 9)
					{
						//decodedSize = size - pAutoTest_Packet->Decoderlength;
						decodedSize -= size;
						pAutoTest_Packet->CollectorState = WaitCmd;
						pAutoTest_Packet->Decoderlength = 0;
						pAutoTest_Packet->DecoderIndex = 0;
						PaketComplete = TRUE;
						break;
					}
					else
					{
						pAutoTest_Packet->CollectorState = WaitPayload;
					}
				}
				else
				{
					//CRC check fail
					DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_ERROR, "Auto test-->CRC check failed: CRC = 0x%2x, received CRC = 0x%2x!", 2, AutoTestCRC8(pAutoTest_Packet->DecoderData, 4), pAutoTest_Packet->LoopQueue[pAutoTest_Packet->ReadIndex]);
					size--;
					pAutoTest_Packet->CollectorState = WaitCmd;
					pAutoTest_Packet->DecoderIndex = 0;
					pAutoTest_Packet->ReadIndex++;
					//decodedSize = size - pAutoTest_Packet->Decoderlength;
					decodedSize -= size;					
					break;
				}
				
			}
			else
			{
				break;
			}
		}
		case WaitPayload:
		{
			if(size > 0)
			{
				while(size--)
				{
					//size--;
					pAutoTest_Packet->Decoderlength++;
					pAutoTest_Packet->ReadIndex &= (pAutoTest_Packet->QueueCapacity -1);
					pAutoTest_Packet->DecoderData[pAutoTest_Packet->DecoderIndex++] = pAutoTest_Packet->LoopQueue[pAutoTest_Packet->ReadIndex++];
					if((pAutoTest_Packet->PacketLength - 9) == pAutoTest_Packet->Decoderlength)
					{
						//decodedSize = size - pAutoTest_Packet->Decoderlength;
						decodedSize -= size;
						pAutoTest_Packet->CollectorState = WaitCmd;
						pAutoTest_Packet->Decoderlength = 0;
						pAutoTest_Packet->DecoderIndex = 0;
						PaketComplete = TRUE;
						DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "Receiving a complete packet!", 0);
						break;
					}
				}
			}
			break;
		}
		default:
		{
			DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_ERROR, "Receiving abnormal state: 0x%2x, undecoded size = 0x%2x", 2, pAutoTest_Packet->CollectorState, size);
			break;
		}					
	}
	
	if(decodedSize > 0)
	{
		taskENTER_CRITICAL();
		AutoTest_Packet.QueueSize -= decodedSize;
		taskEXIT_CRITICAL();
	}
return PaketComplete;				
}


/**
 * @used by ltp to conduct auto test module.
 * @param cmd-- auto test cmd
 		   copmsk --use cases of option parameter
 		   pOpt -- address of option parameter
 		   lenPara --payload length of LTP packet about auto test 
 		   pPara -- payload address of LTP packet about auto test
 * @return  none.
*/
void AutoTestHandle(uint8_t cmd, uint8_t copmsk, uint8_t* pOpt, uint16_t lenPara, uint8_t* pPara)
{
	ConvertBytesToAutoTestCmd(cmd, copmsk, pOpt, lenPara, pPara, &AutoTest_cmd);

	/*packet type*/
	switch((AutoTest_cmd.HeaderTypeDef.P2_l >> 4) & 0x0f)
	{
		case 0x01:
		{
			AutoTestPWMHandle(&AutoTest_cmd);
			break;
		}
		case 0x02:
		{	
			AutoTestUartHandle(cmd, copmsk, pOpt,lenPara,pPara,&AutoTest_cmd);
			break;
		}	
		case 0x03:
		{
			AutoTestGPIOHandle(&AutoTest_cmd);
			break;
		}
		case 0x04:
		{
			AutoTestTimerHandle(&AutoTest_cmd);
			break;
		}
		case 0x05:
		{
			AutoTestI2CHandle(&AutoTest_cmd);
			break;
		}
		case 0x06:
		{
			AutoTestSPIHandle(&AutoTest_cmd);
			break;
		}
		case 0x08:
		{
			//AutoTestIRHandle(&AutoTest_cmd);
		}
		case 0x09:
		{
			AutoTestKeyScanHandle(&AutoTest_cmd);	
		}
		default:
		{
			break;
		}
	}
}

void ConvertBytesToAutoTestCmd(uint8_t cmd, uint8_t copmsk, uint8_t* pOpt, 
                                               uint16_t lenPara, uint8_t* pPara, AutoTest_CmdTypeDef *pAutoTest_cmd)
{	
	/*header*/
	pAutoTest_cmd->HeaderTypeDef.cmd = cmd;
	pAutoTest_cmd->HeaderTypeDef.copmsk = copmsk;
	pAutoTest_cmd->HeaderTypeDef.lp_h = 0;
	pAutoTest_cmd->HeaderTypeDef.lp_l = 0;
	pAutoTest_cmd->HeaderTypeDef.P1 = *pOpt++;
	pAutoTest_cmd->HeaderTypeDef.P2_h = *pOpt++;
	pAutoTest_cmd->HeaderTypeDef.P2_l = *pOpt++;
	pAutoTest_cmd->HeaderTypeDef.P3 = *pOpt;
	
	/*AutoTest  parameter handle*/
	AutoTestParameterHandle(pPara, lenPara, pAutoTest_cmd);	
}

void AutoTestParameterHandle(uint8_t* pPara, uint16_t lenPara, AutoTest_CmdTypeDef *pAutoTest_cmd)
{
	uint8_t data_index = 0;
	
	if(lenPara > 0)
	{
	 	switch ((pAutoTest_cmd->HeaderTypeDef.P2_l>>4)&0x0f)
	 	{
			case 0x1:
			{
				AutoTestPWMParameterHandle(pPara, &pAutoTest_cmd->InitTypeDef.pwm_params);
				break;
			}			
			case 0x2:
			{
				/*uart change baudrate*/
				AutoTestUartParameterHandle(pPara, pAutoTest_cmd);
				break;
			}		
			case 0x3:
			{	
				
				if(pAutoTest_cmd->HeaderTypeDef.P2_l == 0x37)
				{
					/*GPIO write port*/
					pAutoTest_cmd->DataTypeDef.AutoTest_GPIO_Data.port_value= *pPara++;
					pAutoTest_cmd->DataTypeDef.AutoTest_GPIO_Data.port_value=(pAutoTest_cmd->DataTypeDef.AutoTest_GPIO_Data.port_value<<8)+ *pPara++;
					pAutoTest_cmd->DataTypeDef.AutoTest_GPIO_Data.port_value=(pAutoTest_cmd->DataTypeDef.AutoTest_GPIO_Data.port_value<<8)+ *pPara++;
					pAutoTest_cmd->DataTypeDef.AutoTest_GPIO_Data.port_value=(pAutoTest_cmd->DataTypeDef.AutoTest_GPIO_Data.port_value<<8)+ *pPara;
				}
				else
				{
					if(pAutoTest_cmd->HeaderTypeDef.P2_l == 0x32)
					{
						AutoTestGPIOParamHandle(pPara, &pAutoTest_cmd->InitTypeDef.GPIO_params);
						pAutoTest_cmd->DataTypeDef.AutoTest_GPIO_Data.GPIO_voltage_level = *(pPara+6); 
					}
				}	
				
				break;
			}			
			case 0x4:
			{
				AutoTestTimerParamHandle(pPara, &pAutoTest_cmd->InitTypeDef.TIM_params);
				break;
			}
			case 0x5:
			{
				
				/*I2C write data*/
				if((pAutoTest_cmd->HeaderTypeDef.P2_l == 0x54) |(pAutoTest_cmd->HeaderTypeDef.P2_l == 0x5e)|(pAutoTest_cmd->HeaderTypeDef.P2_l == 0x56))
				{
					pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.i2c_data_length = lenPara;
					
					/*I2C RepeatRead_ReadDataCount handle*/
					if((pAutoTest_cmd->HeaderTypeDef.P2_l == 0x5e)|(pAutoTest_cmd->HeaderTypeDef.P2_l == 0x56))
					{
						(pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.i2c_data_length)--;
						pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.ReadDataCount = *pPara++;
					}
					
					/*I2C write data handle*/
					for(data_index=0; data_index < pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.i2c_data_length; data_index++)
						{
							pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.i2c_write_buffer[data_index] = *pPara++;
#if AUTOTEST_DBG_EN	
							DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->i2c_write_buffer[%d] value = 0x%x\n",2,data_index, pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.i2c_write_buffer[data_index]);
#endif
						}
				}
				else
				{
					AutoTestI2CParamHandle(pPara, &pAutoTest_cmd->InitTypeDef.I2C_Params);	
				}						
				break;
			}
			/*SPI param*/
			case 0x6:
			{
				
				/* SPI write data */
				if((pAutoTest_cmd->HeaderTypeDef.P2_l == 0x61)| (pAutoTest_cmd->HeaderTypeDef.P2_l == 0x65)| (pAutoTest_cmd->HeaderTypeDef.P2_l == 0x66) || (pAutoTest_cmd->HeaderTypeDef.P2_l == 0x6a))
				{
					pAutoTest_cmd->DataTypeDef.AutoTest_SPI_Data.spi_data_length = lenPara;
					
					/* store test data */
					memcpy(pAutoTest_cmd->DataTypeDef.AutoTest_SPI_Data.spi_write_buffer, pPara, pAutoTest_cmd->DataTypeDef.AutoTest_SPI_Data.spi_data_length);
				}
				/*SPI read data by DMA*/
				else if((pAutoTest_cmd->HeaderTypeDef.P2_l == 0x67)| (pAutoTest_cmd->HeaderTypeDef.P2_l == 0x68))
				{
					
					pAutoTest_cmd->DataTypeDef.AutoTest_SPI_Data.spi_read_length = *pPara++;
				}
				else
				{
					AutoTestSPIParamHandle(pPara, &pAutoTest_cmd->InitTypeDef.SPI_Params);
				}
				break;
			}
			/*dump pin status*/
			case 0x07:
			{
				#if 0
				pAutoTest_cmd->PinStatusTypeDef.AutoTest_pin_status.gpio_group = (GPIOGroupDef)*pPara++;
				pAutoTest_cmd->PinStatusTypeDef.AutoTest_pin_status.gpio_pin_index= *pPara;
				data_index = AutoTest_ReadPinStatus(pAutoTest_cmd->PinStatusTypeDef.AutoTest_pin_status.gpio_group,pAutoTest_cmd->PinStatusTypeDef.AutoTest_pin_status.gpio_pin_index);
				AutoTestSendData(0x70, &data_index, 1);
				#endif
				break;
			}
			/*IR param*/
			case 0x08:
			{
				#if 0
				/*IR send data*/
				if(pAutoTest_cmd->HeaderTypeDef.P2_l == 0x8b)
				{
					pAutoTest_cmd->DataTypeDef.AutoTest_IR_Data.ir_data_length = lenPara;
						
					/*IR write data handle*/
					for(data_index=0; data_index < pAutoTest_cmd->DataTypeDef.AutoTest_IR_Data.ir_data_length; data_index++)
					{
						pAutoTest_cmd->DataTypeDef.AutoTest_IR_Data.ir_write_buffer[data_index] = (IR_KEY_DEF)*pPara++;
#if AUTOTEST_DBG_EN
						DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->ir_write_buffer[%d] value = 0x%x\n", 2, data_index, pAutoTest_cmd->DataTypeDef.AutoTest_IR_Data.ir_write_buffer[data_index]);
#endif
					}
				}
				else
				
				{
					//AutoTestIRParamHandle(pPara, &pAutoTest_cmd->InitTypeDef.IRDA_Params, pAutoTest_cmd);
				}	
				#endif
				break;
			}
			/*IR param*/
			case 0x09:
			{
				AutoTestKeyScanParamHandle(pPara, &pAutoTest_cmd->InitTypeDef.keypad_param);	
				break;
			}
			default:
			{
				break;
			}
	 	}
	}
}

uint8_t AutoTestSendData(uint8_t FunNum, uint8_t *payload, uint32_t payload_length)
{
	uint8_t idx = 0;
	uint8_t AutoTest_LTP_Packet[256] = {0xf6,0x8f,0,0,0,0,0,0,0};
	uint8_t *p_send = AutoTest_LTP_Packet; 
	
	AutoTest_LTP_Packet[3] = 9 + payload_length;
	AutoTest_LTP_Packet[6] = FunNum;
	AutoTest_LTP_Packet[8] = AutoTestCRC8(AutoTest_LTP_Packet, 4);
	
    if(payload_length > 0)
    {
		for(idx = 0; idx < payload_length; idx++)
		{
			AutoTest_LTP_Packet[9 + idx] = *payload;
			payload++;
		}
	}
	
	for(idx = 0; idx < AutoTest_LTP_Packet[3]; idx++)
   {
		while(UART_GetFlagState(UART, UART_FLAG_THR_EMPTY)==RESET);
		UART_SendData(UART, p_send++, 1);
   }
	return 1;
}

void AutoTestUartHandle(uint8_t cmd, uint8_t copmsk, uint8_t* pOpt, uint16_t lenPara, uint8_t* pPara, AutoTest_CmdTypeDef *pAutoTest_cmd )
{
	uint8_t idx;
	switch((pAutoTest_cmd->HeaderTypeDef.P2_l & 0x0f))
	{
		case 1:
		{
			AutoTestSendData(0x21, NULL, 0);
			vTaskDelay(200 / portTICK_RATE_MS);
			/* system reset */
			NVIC_SystemReset();	
			break;
		}
		case 2:
		{
			BaudRateModifyHandle(pAutoTest_cmd->InitTypeDef.uart_params.OVSR, pAutoTest_cmd->InitTypeDef.uart_params.DIV, pAutoTest_cmd->InitTypeDef.uart_params.OVSR_ADJ);	
			break;
		}
		case 3:
		{
			AutoTestUartLoopBackHandle(cmd, copmsk, pOpt, lenPara, pPara);
			break;
		}
		case 4:
		{
			AutoTestSendData(0x24, REG_PERI_uart_Params, 8);
			for(idx=0 ; idx<8; idx++)
			{
				REG_PERI_uart_Params[idx] = 0;
			}
			break;
		}
		default:
		{
			break;
		}
	}
}

void AutoTestUartParameterHandle(uint8_t* pPara, AutoTest_CmdTypeDef *pAutoTest_cmd)
{
	if(pAutoTest_cmd->HeaderTypeDef.P2_l == 0x22)
	{
		pAutoTest_cmd->InitTypeDef.uart_params.OVSR= *pPara++;
		pAutoTest_cmd->InitTypeDef.uart_params.DIV= *pPara++;
		pAutoTest_cmd->InitTypeDef.uart_params.DIV = (pAutoTest_cmd->InitTypeDef.uart_params.DIV<<8) + *pPara++;
		pAutoTest_cmd->InitTypeDef.uart_params.OVSR_ADJ= *pPara++;
		pAutoTest_cmd->InitTypeDef.uart_params.OVSR_ADJ = (pAutoTest_cmd->InitTypeDef.uart_params.OVSR_ADJ<<8) + *pPara;
	}
}

void BaudRateModifyHandle(uint8_t ovsr, uint16_t div, uint16_t ovsr_adj)
{	
	/*add for Initialize and Deinitialize function test*/
	ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_DATA_UART, &REG_PERI_uart_Params[0], &REG_PERI_uart_Params[1]);
	/* data uart deinit */
	UART_DeInit(UART);
	ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_DATA_UART, &REG_PERI_uart_Params[2], &REG_PERI_uart_Params[3]);
	


	/* pinmux configuration */
	Pinmux_Config(P3_4, DATA_UART_TX);
	Pinmux_Config(P3_5, DATA_UART_RX);
	Pinmux_Config(P0_6, DATA_UART_CTS);
	Pinmux_Config(P0_7, DATA_UART_RTS);

	/* pad configuration */
	Pad_Config(P3_4, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
	Pad_Config(P3_5, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);
	Pad_Config(P0_6, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_HIGH);
	Pad_Config(P0_7, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_HIGH);

	/* NVIC configuration */
	NVIC_InitTypeDef NVIC_InitStruct;
	NVIC_InitStruct.NVIC_IRQChannel = UART_IRQ;
	NVIC_InitStruct.NVIC_IRQChannelPriority = 0;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStruct);

	/* uart init */
	UART_InitTypeDef uartInitStruct;
	uartInitStruct.div = div;
	uartInitStruct.ovsr = ovsr;
	uartInitStruct.ovsr_adj = ovsr_adj;

	uartInitStruct.parity = UART_PARITY_NO_PARTY;
	uartInitStruct.stopBits = UART_STOP_BITS_1;
	uartInitStruct.wordLen = UART_WROD_LENGTH_8BIT;
	uartInitStruct.dmaEn = UART_DMA_DISABLE;
	uartInitStruct.autoFlowCtrl= UART_AUTO_FLOW_CTRL_DIS;
	uartInitStruct.rxTriggerLevel= UART_RX_FIFO_TRIGGER_LEVEL_14BYTE;

	/*add for Initialize and Deinitialize function test*/
	ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_DATA_UART, &REG_PERI_uart_Params[4], &REG_PERI_uart_Params[5]);

	/* System clock configuration */
	RCC_PeriphClockCmd(APBPeriph_UART, APBPeriph_UART_CLOCK, ENABLE);

	/* data uart init */
	
	UART_Init(UART, &uartInitStruct);

	//enable rx interrupt and line status interrupt
	UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, ENABLE);

    ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_DATA_UART, &REG_PERI_uart_Params[6], &REG_PERI_uart_Params[7]);

}

void AutoTestUartLoopBackHandle(uint8_t cmd, uint8_t copmsk, uint8_t* pOpt,uint16_t lenPara, uint8_t* pPara)
{
	uint8_t* p_send = NULL;
	uint8_t* p_send_index = NULL;
	uint8_t* pOpt_index = NULL;
	/*length of P1, P2, P3*/
	uint8_t P_length = 4;
	uint8_t i = 0;
	
	pOpt_index = pOpt;
	uint8_t LoopBackBuffer[256];
	p_send_index = p_send = LoopBackBuffer;
	*p_send_index = cmd;
	p_send_index++;
	*p_send_index = copmsk;
	p_send_index++;		
	*p_send_index = (lenPara+9)/256;
	p_send_index++;
	*p_send_index = (lenPara+9)%256;
	p_send_index++;

    while(P_length)
	{
		*p_send_index = *pOpt_index++;
		p_send_index++;
		P_length--;
	}
	*p_send_index = *(pPara - 1);
	p_send_index++;
	
	memcpy(p_send_index, pPara,lenPara);
	for(i = 0; i < lenPara + 9; i++)
   {
     	while(UART_GetFlagState(UART, UART_FLAG_THR_EMPTY)==RESET);
		UART_SendData(UART, p_send++, 1);
   }

}


uint8_t AutoTest_ReadPeriFunRegister(uint32_t base, uint32_t addr, uint32_t BIT_PERI_EN)
{	
	uint32_t IOModule_ENValue = 0;
	uint8_t BIT_PERI_Value = 0;
	
	IOModule_ENValue = HAL_READ32(base,addr);
	if(IOModule_ENValue & BIT_PERI_EN)
	{
		BIT_PERI_Value = 1;
	}
	return BIT_PERI_Value;
}
void ReadPeriFunRegisterByPeripheralType(InitOrDeinitPeripherialType periType, uint8_t *FUNC_param, uint8_t *CLK_param)
{
	 switch(periType)
    {
    	case AutoTest_PeripherialType_PWM:
            {
				break;
        	}
		case AutoTest_PeripherialType_DATA_UART:
            {
				*FUNC_param = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, REG_SOC_PERI_FUNC0_EN, BIT_PERI_UART0_EN); 
				*CLK_param = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, REG_PESOC_PERI_CLK_CTRL0, BIT_SOC_ACTCK_UART0_EN);
           		break;
        	}
		case AutoTest_PeripherialType_GPIO:
            {
				*FUNC_param = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, REG_SOC_PERI_FUNC1_EN, BIT_PERI_GPIO_EN);
				*CLK_param = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, REG_PESOC_CLK_CTRL, BIT_SOC_ACTCK_GPIO_EN);
           		break;
        	}
		case AutoTest_PeripherialType_Timer:
            {
				*FUNC_param = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, REG_PESOC_CLK_CTRL, BIT_SOC_ACTCK_TIMER_EN);
				break;
        	}
		case AutoTest_PeripherialType_I2C0:
            {
				*FUNC_param = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, REG_SOC_PERI_FUNC0_EN, BIT_PERI_I2C0_EN);
				*CLK_param = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, REG_PESOC_PERI_CLK_CTRL1, BIT_SOC_ACTCK_I2C0_EN);
           		break;
        	}
		case AutoTest_PeripherialType_I2C1:
            {
				*FUNC_param = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, REG_SOC_PERI_FUNC0_EN, BIT_PERI_I2C1_EN);
				*CLK_param = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, REG_PESOC_PERI_CLK_CTRL1, BIT_SOC_ACTCK_I2C1_EN);
           		break;
        	}
        case AutoTest_PeripherialType_SPI0:
            {
				*FUNC_param = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, REG_SOC_PERI_FUNC0_EN, BIT_PERI_SPI0_EN);
				*CLK_param = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, REG_PESOC_PERI_CLK_CTRL0, BIT_SOC_ACTCK_SPI0_EN);
           		break;
        	}
		case AutoTest_PeripherialType_SPI1:
            {
				*FUNC_param = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, REG_SOC_PERI_FUNC0_EN, BIT_PERI_SPI1_EN);
				*CLK_param = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, REG_PESOC_PERI_CLK_CTRL0, BIT_SOC_ACTCK_SPI1_EN);
           		break;
        	}
		case AutoTest_PeripherialType_Keyscan:
            {
				*FUNC_param = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, REG_SOC_PERI_FUNC0_EN, BIT_PERI_KEYSCAN_EN);
				*CLK_param = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, REG_PESOC_PERI_CLK_CTRL1, BIT_SOC_ACTCK_KEYSCAN_EN);
           		break;
        	}
		default:
			{
				break;
			}
	}
}

void AutoTestGPIOParamHandle(uint8_t* pPara, GPIO_InitTypeDef *pAutoTest_GPIO_param)
{
	pAutoTest_GPIO_param->GPIO_Pin= GPIO_GetPin(*pPara++);
	pAutoTest_GPIO_param->GPIO_Mode = (GPIOMode_TypeDef)*pPara++;
	pAutoTest_GPIO_param->GPIO_ITCmd = (FunctionalState)*pPara++;	
	pAutoTest_GPIO_param->GPIO_ITTrigger = (GPIOIT_LevelType)*pPara++;
	pAutoTest_GPIO_param->GPIO_ITPolarity= (GPIOIT_PolarityType)*pPara++;
	pAutoTest_GPIO_param->GPIO_ITDebounce = (GPIOIT_DebounceType)*pPara++;
	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->AutoTestGPIOParamHandle->GPIO_Pin value: %x\n", 1, pAutoTest_GPIO_param->GPIO_Pin);
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->AutoTestGPIOParamHandle->GPIOMode value: %x\n", 1, pAutoTest_GPIO_param->GPIO_Mode);
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->AutoTestGPIOParamHandle->INT_Enabler value: %x\n", 1, pAutoTest_GPIO_param->GPIO_ITCmd);
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->AutoTestGPIOParamHandle->INT_Level: %x\n", 1, pAutoTest_GPIO_param->GPIO_ITTrigger);
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->AutoTestGPIOParamHandle->INT_Polarity value: %x\n", 1, pAutoTest_GPIO_param->GPIO_ITPolarity);
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->AutoTestGPIOParamHandle->INT_Debounce value: %x\n", 1, pAutoTest_GPIO_param->GPIO_ITDebounce);
#endif
}

void AutoTestGPIOHandle(AutoTest_CmdTypeDef *pAutoTest_cmd )
{	
	uint8_t send_data[10];	
	switch((pAutoTest_cmd->HeaderTypeDef.P2_l & 0x0f))
	{
		case 0:
		{

			/*add for Deinit all pin*/
			#if 0
			for (periType = PeripherialType_HCI_UART; periType < PeripherialType_MAX; periType++)
			{
				if ((periType != PeripherialType_DATA_UART)&&(periType != PeripherialType_SWD))
				
				{
					HalDumpOrDeinitPinByPeripheralType(periType, FALSE, TRUE);
				}
			}
			//DumpPinStatus(); 
			#endif
			AutoTestSendData(0x30, NULL, 0);
			break;
		}
		case 1:
		{
			GPIO_MaskINTConfig(pAutoTest_cmd->InitTypeDef.GPIO_params.GPIO_Pin,ENABLE);
			AutoTestSendData(0x31, send_data, 0);
			break;
		}
		case 2:
		{		
			UINT8 pin_num=0x0;
			ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_GPIO,&send_data[0], &send_data[1]);
			for(UINT32 i=0;i<32;i++)
				if(pAutoTest_cmd->InitTypeDef.GPIO_params.GPIO_Pin==BIT(i))
					pin_num=i;
			if((28<=pin_num)&&(pin_num<=31))
					pin_num=pin_num+4;
			RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
			Pinmux_Config(pin_num,GPIO_FUN);
			Pad_Config(pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
			GPIO_Init(&pAutoTest_cmd->InitTypeDef.GPIO_params);
			
			ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_GPIO,&send_data[2], &send_data[3]);
			/*read pinmux status*/
			send_data[4] = AutoTest_ReadPinStatus(pin_num);
			AutoTestSendData(0x32, send_data, 5);
			break;
		}
		case 3:
		{
			UINT8 pin_num=0x0;
			ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_GPIO,&send_data[0], &send_data[1]);
			GPIO_DeInit();
			for(UINT32 i=0;i<32;i++)
				if(pAutoTest_cmd->InitTypeDef.GPIO_params.GPIO_Pin==BIT(i))
					pin_num=i;
			if((28<=pin_num)&&(pin_num<=31))
					pin_num=pin_num+4;
			Pinmux_Deinit(pin_num);
			ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_GPIO,&send_data[2], &send_data[3]);
			/*read pinmux status*/
			send_data[4] = AutoTest_ReadPinStatus(pin_num);
			AutoTestSendData(0x33, send_data, 5);
			break;
		}
		case 4:
		{	
			GPIO_GetINTStatus(pAutoTest_cmd->InitTypeDef.GPIO_params.GPIO_Pin);
			AutoTestSendData(0x34, send_data, 0); 
			break;
		}
		case 5:
		{
			GPIO_WriteBit(pAutoTest_cmd->InitTypeDef.GPIO_params.GPIO_Pin,(BitAction) (pAutoTest_cmd->DataTypeDef.AutoTest_GPIO_Data.GPIO_voltage_level));
			send_data[0] = pAutoTest_cmd->DataTypeDef.AutoTest_GPIO_Data.GPIO_voltage_level;
			AutoTestSendData(0x35, send_data, 1);
			break;
		}
		case 6:
		{
			//send_data[0] = GPIO_Write_V2(&pAutoTest_cmd->InitTypeDef.GPIO_param, pAutoTest_cmd->DataTypeDef.AutoTest_GPIO_Data.GPIO_voltage_level);
			//AutoTestSendData(0x36, send_data, 1);
			break;
		}
		case 7:
		{
			GPIO_Write(pAutoTest_cmd->DataTypeDef.AutoTest_GPIO_Data.port_value);
			AutoTestSendData(0x37, send_data, 0);			
#if AUTOTEST_DBG_EN	
			DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO write port value: %x\n", 1, pAutoTest_cmd->DataTypeDef.AutoTest_GPIO_Data.port_value);
#endif			
			break;
		}
		case 8:
		{
			GPIO_MaskINTConfig(pAutoTest_cmd->InitTypeDef.GPIO_params.GPIO_Pin,DISABLE);
			AutoTestSendData(0x38, send_data, 0);
			break;
		}
		case 9:
		{
			uint32_t ReadInputData = 0;
			ReadInputData=GPIO_ReadInputData();
			send_data[3]=(ReadInputData&0xff000000)>>24;
			send_data[2]=(ReadInputData&0x00ff0000)>>16;
			send_data[1]=(ReadInputData&0x0000ff00)>>8;
			send_data[0]=ReadInputData&0x0000000ff;
			AutoTestSendData(0x39, send_data, 4);
			break;
		}
		case 0x0a:
		{
			send_data[0]=GPIO_ReadInputDataBit(pAutoTest_cmd->InitTypeDef.GPIO_params.GPIO_Pin);
			AutoTestSendData(0x3a, send_data, 1);
			break;
		}
		case 0x0b:
		{
			NVIC_InitTypeDef NVIC_InitStruct;
			if(pAutoTest_cmd->InitTypeDef.GPIO_params.GPIO_Pin==GPIO_Pin_0)
				NVIC_InitStruct.NVIC_IRQChannel = GPIO0_IRQ;
			else if(pAutoTest_cmd->InitTypeDef.GPIO_params.GPIO_Pin==GPIO_Pin_1)
				NVIC_InitStruct.NVIC_IRQChannel = GPIO1_IRQ;
			else if(pAutoTest_cmd->InitTypeDef.GPIO_params.GPIO_Pin==GPIO_Pin_2)
				NVIC_InitStruct.NVIC_IRQChannel = GPIO2_IRQ;
			else if(pAutoTest_cmd->InitTypeDef.GPIO_params.GPIO_Pin==GPIO_Pin_3)
				NVIC_InitStruct.NVIC_IRQChannel = GPIO3_IRQ;
			else if(pAutoTest_cmd->InitTypeDef.GPIO_params.GPIO_Pin==GPIO_Pin_4)
				NVIC_InitStruct.NVIC_IRQChannel = GPIO4_IRQ;
			else if(pAutoTest_cmd->InitTypeDef.GPIO_params.GPIO_Pin==GPIO_Pin_5)
				NVIC_InitStruct.NVIC_IRQChannel = GPIO5_IRQ;
			else
			NVIC_InitStruct.NVIC_IRQChannel = GPIO6To31_IRQ;
			NVIC_InitStruct.NVIC_IRQChannelPriority = 2;
			NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
			NVIC_Init(&NVIC_InitStruct);
			
			GPIO_INTConfig(pAutoTest_cmd->InitTypeDef.GPIO_params.GPIO_Pin,ENABLE);
			
			AutoTestSendData(0x3b, send_data, 0);
			break;
		}
		case 0x0c:
		{
			GPIO_INTConfig(pAutoTest_cmd->InitTypeDef.GPIO_params.GPIO_Pin,DISABLE);
			AutoTestSendData(0x3c, send_data, 0);
			break;
		}
		case 0x0d:
		{
			GPIO_INTConfig(pAutoTest_cmd->InitTypeDef.GPIO_params.GPIO_Pin,ENABLE);
			AutoTestSendData(0x3d, send_data, 0);
			break;
		}
		case 0x0e:
		{
			GPIO_ClearINTPendingBit(pAutoTest_cmd->InitTypeDef.GPIO_params.GPIO_Pin);
			AutoTestSendData(0x3e, send_data, 0);
			break;
		}
		
		case 0x0f:
		{
			AutoTestSendData(0x3f, send_data, 0);
			vTaskDelay(200 / portTICK_RATE_MS);
			NVIC_SystemReset();
			break;
		}
		default:
		{
			break;
		}
	}
}

void Gpio0IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio1IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio2IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}

void Gpio3IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio4IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio5IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio6IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio7IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio8IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio9IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio10IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio11IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio12IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio13IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio14IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio15IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}

void Gpio16IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}

void Gpio17IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio18IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio19IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio20IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio21IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio22IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio23IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio24IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio25IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio26IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio27IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio28IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio29IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio30IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}
void Gpio31IntrHandler(void)
{
	uint32_t GPIO_GetINTStatus_Vaule = 0;
	
	GPIO_GetINTStatus_Vaule = GPIO->INTSTATUS;
	GPIO->INTMASK |= GPIO_GetINTStatus_Vaule;	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->GPIO_ISR_HANDLER-->GPIO_GetINTStatus_Vaule:%x!\n", 1, GPIO_GetINTStatus_Vaule);
#endif

    AutosendInt32(GPIO_GetINTStatus_Vaule);	
	GPIO_ClearINTPendingBit(GPIO_GetINTStatus_Vaule);
	GPIO->INTMASK &= ~(GPIO_GetINTStatus_Vaule);
}

uint8_t AutoTest_ReadPinStatus(uint8_t Pin_Num)
{
	UINT32 reg_addr  = 0x0;
    UINT32 reg_value = 0x0;
    UINT8 pin_status = 0x0;
	uint8_t GPIOGroup=	Pin_Num/8;
	uint8_t GPIOIndex= Pin_Num%8;
    reg_addr =  GPIOGroup * 8 + (GPIOIndex/4)*4;
    reg_value = HAL_READ32(PINMUX_REG_BASE, reg_addr);
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest_ReadPinStatus->GPIOGroup = %d, reg_addr = 0x%x, reg_value = 0x%x\n", 3, GPIOGroup + 10, reg_addr, reg_value);
	pin_status = (reg_value>>(8*(GPIOIndex%4)))&0x7f;
	return pin_status;
}


void AutoTestTimerParamHandle(uint8_t* pPara, AutoTest_Tim_Params *pAutoTest_TimerAdap)
{
	pAutoTest_TimerAdap->TimerId= *pPara++;
	pAutoTest_TimerAdap->TIM_InitStruct.TIM_Period= *pPara++;
	pAutoTest_TimerAdap->TIM_InitStruct.TIM_Period = (pAutoTest_TimerAdap->TIM_InitStruct.TIM_Period << 8) + *pPara++;
	pAutoTest_TimerAdap->TIM_InitStruct.TIM_Period = (pAutoTest_TimerAdap->TIM_InitStruct.TIM_Period << 8) + *pPara++;
	pAutoTest_TimerAdap->TIM_InitStruct.TIM_Period = (pAutoTest_TimerAdap->TIM_InitStruct.TIM_Period << 8) + *pPara++;
	pAutoTest_TimerAdap->TIM_InitStruct.TIM_ClockSrc= *pPara++;	
	pAutoTest_TimerAdap->TIM_InitStruct.TIM_Mode= *pPara++;
	pAutoTest_TimerAdap->TIM_InitStruct.TIM_EventIndex= *pPara++;	
	pAutoTest_TimerAdap->TIM_InitStruct.TIM_EventMode= *pPara++;
	pAutoTest_TimerAdap->TIM_InitStruct.TIM_EventDuration= *pPara;
	
	DBG_DIRECT("Bee-->Timer-->TimerId value: %x\n",pAutoTest_TimerAdap->TimerId);
	DBG_DIRECT("Bee-->Timer-->TIM_Period value: %x\n", pAutoTest_TimerAdap->TIM_InitStruct.TIM_Period);
	DBG_DIRECT("Bee-->Timer-->TimerClkSrc value: %x\n", pAutoTest_TimerAdap->TIM_InitStruct.TIM_ClockSrc);
	DBG_DIRECT("Bee-->Timer-->TimerMode value: %x\n", pAutoTest_TimerAdap->TIM_InitStruct.TIM_Mode);
	DBG_DIRECT("Bee-->Timer-->TIM_EventIndex value: %x\n", pAutoTest_TimerAdap->TIM_InitStruct.TIM_EventIndex);
	DBG_DIRECT("Bee-->Timer-->TIM_EventMode value: %x\n", pAutoTest_TimerAdap->TIM_InitStruct.TIM_EventMode);
	DBG_DIRECT("Bee-->Timer-->TIM_EventDuration value: %x\n", pAutoTest_TimerAdap->TIM_InitStruct.TIM_EventDuration);

}



void AutoTestTimerHandle(AutoTest_CmdTypeDef *pAutoTest_cmd )
{	

	uint8_t send_data[10];
	switch((pAutoTest_cmd->HeaderTypeDef.P2_l & 0x0f))
	{
		case 1:
		{
			RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
			Pinmux_Config(P1_2, GPIO_FUN);
			Pad_Config(P1_2, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
			GPIO_InitTypeDef GPIO_InitStruct;
		    GPIO_InitStruct.GPIO_Pin  = GPIO_GetPin(P1_2);
			GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
			GPIO_InitStruct.GPIO_ITCmd = DISABLE;
			GPIO_InitStruct.GPIO_ITTrigger = GPIO_INT_Trigger_LEVEL;
			GPIO_InitStruct.GPIO_ITPolarity = GPIO_INT_POLARITY_ACTIVE_LOW;
			GPIO_InitStruct.GPIO_ITDebounce = GPIO_INT_DEBOUNCE_DISABLE;
			GPIO_Init(&GPIO_InitStruct);
			GPIO_SetBits(GPIO_GetPin(P1_2));
			
			ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_Timer, &send_data[0], NULL);
			RCC_PeriphClockCmd(APBPeriph_TIMER, APBPeriph_TIMER_CLOCK, ENABLE);
			UINT8 offset=0x14* (pAutoTest_cmd->InitTypeDef.TIM_params.TimerId);
			TIM_TimeBaseInit((TIM_TypeDef*)(TIM0_REG_BASE+offset), &pAutoTest_cmd->InitTypeDef.TIM_params.TIM_InitStruct); 
			ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_Timer, &send_data[1], NULL);
			AutoTestSendData(0x41, send_data, 2);
			break;
		}
		case 2:
		{
			AutoTestSendData(0x42, send_data, 0);
			vTaskDelay(200 / portTICK_RATE_MS);
			NVIC_SystemReset();
			break;
		}
		case 3:
		{
			NVIC_InitTypeDef NVIC_InitStruct;
			if(pAutoTest_cmd->InitTypeDef.TIM_params.TimerId==1)
				NVIC_InitStruct.NVIC_IRQChannel = TIMER1_IRQ;
			else if(pAutoTest_cmd->InitTypeDef.TIM_params.TimerId==2)
				NVIC_InitStruct.NVIC_IRQChannel = TIMER2_IRQ;
			else if(pAutoTest_cmd->InitTypeDef.TIM_params.TimerId==3)
				NVIC_InitStruct.NVIC_IRQChannel = TIMER3_IRQ;
			else if(pAutoTest_cmd->InitTypeDef.TIM_params.TimerId==4)
				NVIC_InitStruct.NVIC_IRQChannel = TIMER4_IRQ;
			else if(pAutoTest_cmd->InitTypeDef.TIM_params.TimerId==5)
				NVIC_InitStruct.NVIC_IRQChannel = TIMER5_IRQ;
			else if(pAutoTest_cmd->InitTypeDef.TIM_params.TimerId==6)
				NVIC_InitStruct.NVIC_IRQChannel = TIMER6_IRQ;
			else if(pAutoTest_cmd->InitTypeDef.TIM_params.TimerId==7)
				NVIC_InitStruct.NVIC_IRQChannel = TIMER7_IRQ;
			else
				DBG_DIRECT("Bee Timer Configure error!");
			NVIC_InitStruct.NVIC_IRQChannelPriority = 2;
			NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
			NVIC_Init(&NVIC_InitStruct);
			UINT8 offset=0x14* (pAutoTest_cmd->InitTypeDef.TIM_params.TimerId);
			TIM_ClearINT((TIM_TypeDef*) (TIM0_REG_BASE+offset));
			TIM_INTConfig((TIM_TypeDef*) (TIM0_REG_BASE+offset),ENABLE);
			TIM_Cmd((TIM_TypeDef*) (TIM0_REG_BASE+offset),ENABLE);
			
			send_data[0] = pAutoTest_cmd->InitTypeDef.TIM_params.TimerId; 
			AutoTestSendData(0x43, send_data, 1);
			break;
		}
		case 4:
		{
			uint32_t offset=0x14* (pAutoTest_cmd->InitTypeDef.TIM_params.TimerId);
			TIM_Cmd((TIM_TypeDef*) (TIM0_REG_BASE+offset),DISABLE);
			Pinmux_Deinit(P1_2);
			send_data[0] = pAutoTest_cmd->InitTypeDef.TIM_params.TimerId; 
			AutoTestSendData(0x44, send_data, 1);
			break;
		}
		case 5:
		{
			send_data[0] = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, REG_PESOC_CLK_CTRL, BIT_SOC_ACTCK_TIMER_EN);
			TIM_DeInit();
			send_data[1] = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, REG_PESOC_CLK_CTRL, BIT_SOC_ACTCK_TIMER_EN);
			AutoTestSendData(0x45, send_data, 2);
			break;
		}
		case 6:
		{
		#if 0
			TimerCountValue = HalTimerReadCount(pAutoTest_cmd->InitTypeDef.TimerAdap.TimerId);
#if AUTOTEST_DBG_EN	
			DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->AutoTestTimerHandle->HalTimerReadCount value: %x\n", 1, TimerCountValue);
#endif
			send_data[0] = (TimerCountValue>>16)/256;
			send_data[1] = (TimerCountValue>>16)%256;
			send_data[2] = (TimerCountValue & 0x0000ffff)/256;
			send_data[3] = (TimerCountValue & 0x0000ffff)%256;
			AutoTestSendData(0x46, send_data, 4);
		#endif
			break;
		}
		case 7:
		{
			UINT8 offset=0x14* (pAutoTest_cmd->InitTypeDef.TIM_params.TimerId);
			TIM_ClearINT((TIM_TypeDef*) (TIM0_REG_BASE+offset));
			send_data[0] = pAutoTest_cmd->InitTypeDef.TIM_params.TimerId;
			AutoTestSendData(0x47, send_data, 1);
			break;
		}
		#if 0
		case 8:
		{
			HalTimerEnterDLPS();
			send_data[0] = pAutoTest_cmd->InitTypeDef.TimerAdap.TimerId;
			AutoTestSendData(0x48, send_data, 1);
			break;
		}
		case 9:
		{
			HalTimerExitDLPS();
			send_data[0] = pAutoTest_cmd->InitTypeDef.TimerAdap.TimerId;
			AutoTestSendData(0x49, send_data, 1);
			break;
		}
		#endif
		default:
		{
			break;
		}
	}
}


void Timer1IntrHandler(void)
{
	uint32_t GPIO_value = 0;
	GPIO_value = GPIO_ReadOutputDataBit(GPIO_GetPin(P1_2));
    GPIO_WriteBit(GPIO_GetPin(P1_2),!GPIO_value);
	Autosendchar(0x66);
	TIM_ClearINT(TIM1);    
}

void Timer2IntrHandler(void)
{
	uint32_t GPIO_value = 0;
	GPIO_value = GPIO_ReadOutputDataBit(GPIO_GetPin(P1_2));
    GPIO_WriteBit(GPIO_GetPin(P1_2),!GPIO_value);
	Autosendchar(0x66);
	TIM_ClearINT(TIM2);    
}

void Timer3IntrHandler(void)
{
	uint32_t GPIO_value = 0;
	GPIO_value = GPIO_ReadOutputDataBit(GPIO_GetPin(P1_2));
    GPIO_WriteBit(GPIO_GetPin(P1_2),!GPIO_value);
	Autosendchar(0x66);
	TIM_ClearINT(TIM3);    
}

void Timer4IntrHandler(void)
{
	uint32_t GPIO_value = 0;
	GPIO_value = GPIO_ReadOutputDataBit(GPIO_GetPin(P1_2));
    GPIO_WriteBit(GPIO_GetPin(P1_2),!GPIO_value);
	Autosendchar(0x66);
	TIM_ClearINT(TIM4);    
}

void Timer5IntrHandler(void)
{
	uint32_t GPIO_value = 0;
	GPIO_value = GPIO_ReadOutputDataBit(GPIO_GetPin(P1_2));
    GPIO_WriteBit(GPIO_GetPin(P1_2),!GPIO_value);
	Autosendchar(0x66);
	TIM_ClearINT(TIM5);    
}

void Timer6IntrHandler(void)
{
	uint32_t GPIO_value = 0;
	GPIO_value = GPIO_ReadOutputDataBit(GPIO_GetPin(P1_2));
    GPIO_WriteBit(GPIO_GetPin(P1_2),!GPIO_value);
	Autosendchar(0x66);
	TIM_ClearINT(TIM6);    
}

void Timer7IntrHandler(void)
{
	uint32_t GPIO_value = 0;
	GPIO_value = GPIO_ReadOutputDataBit(GPIO_GetPin(P1_2));
    GPIO_WriteBit(GPIO_GetPin(P1_2),!GPIO_value);
	Autosendchar(0x66);
	TIM_ClearINT(TIM7);    
}

void AutoTestPWMParameterHandle(uint8_t* pPara, AutoTest_pwm_Params *pAutoTest_PWMAdap)
{
	/* timerid */	
	pAutoTest_PWMAdap->PWM_InitStruct.PWM_TIMIndex= *pPara++;
	/* PWMTimerClkSrc */
	pAutoTest_PWMAdap->TIM_ClockSrc= *pPara++;
	/* pwm_period_length */
	pAutoTest_PWMAdap->PWM_InitStruct.PWM_Period= *pPara++;
	pAutoTest_PWMAdap->PWM_InitStruct.PWM_Period = (pAutoTest_PWMAdap->PWM_InitStruct.PWM_Period << 8) + *pPara++;
	pAutoTest_PWMAdap->PWM_InitStruct.PWM_Period = (pAutoTest_PWMAdap->PWM_InitStruct.PWM_Period << 8) + *pPara++;
	pAutoTest_PWMAdap->PWM_InitStruct.PWM_Period = (pAutoTest_PWMAdap->PWM_InitStruct.PWM_Period << 8) + *pPara++;
	/* pwm_duty_cycle_length */
	pAutoTest_PWMAdap->PWM_InitStruct.PWM_Duty= *pPara++;
	pAutoTest_PWMAdap->PWM_InitStruct.PWM_Duty = (pAutoTest_PWMAdap->PWM_InitStruct.PWM_Duty << 8) + *pPara++;
	pAutoTest_PWMAdap->PWM_InitStruct.PWM_Duty = (pAutoTest_PWMAdap->PWM_InitStruct.PWM_Duty << 8) + *pPara++;
	pAutoTest_PWMAdap->PWM_InitStruct.PWM_Duty = (pAutoTest_PWMAdap->PWM_InitStruct.PWM_Duty << 8) + *pPara++;
	/* pwm_selection */
	pAutoTest_PWMAdap->pwm_selection=*pPara++;
	/* gpio_pin */
	pAutoTest_PWMAdap->Pin_Num= *pPara++;
	/*timer_period*/
	pAutoTest_PWMAdap->TIM_Period=*pPara++;
	pAutoTest_PWMAdap->TIM_Period = (pAutoTest_PWMAdap->TIM_Period << 8) + *pPara++;
	pAutoTest_PWMAdap->TIM_Period = (pAutoTest_PWMAdap->TIM_Period << 8) + *pPara++;
	pAutoTest_PWMAdap->TIM_Period = (pAutoTest_PWMAdap->TIM_Period << 8) + *pPara;
	
#if AUTOTEST_DBG_EN	
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->PWM timerId parameter: %x\n", 1, pAutoTest_PWMAdap->PWM_InitStruct.PWM_TIMIndex);
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->PWMTimerClkSrc parameter: %x\n", 1, pAutoTest_PWMAdap->TIM_ClockSrc);
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->PWM pwm_period_length parameter: %x\n", 1, pAutoTest_PWMAdap->PWM_InitStruct.PWM_Period);
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->PWM pwm_duty_length parameter: %x\n", 1, pAutoTest_PWMAdap->PWM_InitStruct.PWM_Duty);
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->PWM pwm_selection parameter: %x\n", 1, pAutoTest_PWMAdap->pwm_selection);
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->PWM GPIO_Pin parameter: %x\n", 1, pAutoTest_PWMAdap->Pin_Num);
	DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->PWM timer_period_length parameter: %x\n", 1, pAutoTest_PWMAdap->TIM_Period);
#endif
}

void AutoTestPWMHandle(AutoTest_CmdTypeDef *pAutoTest_cmd )
{
//	uint32_t PWM_test = 0;
	uint8_t send_data[10];
	
	switch((pAutoTest_cmd->HeaderTypeDef.P2_l & 0x0f))
	{
		
		case 1:
		{
			//Hal_GPIO_Initialize_OPs();
			//Autosendchar('g');
			break;
		}
		case 2:
		{
			//Hal_Timer_Initialize_OPs();
			//Autosendchar('t');
			break;
		}
		case 3:
		{
			//Hal_PWM_Initialize_OPs();
			//Autosendchar('p');
			break;
		}
		
		case 4:
		{
			if(pAutoTest_cmd->InitTypeDef.pwm_params.pwm_selection==0)
				Pinmux_Config(pAutoTest_cmd->InitTypeDef.pwm_params.Pin_Num, timer_pwm0);
			else if(pAutoTest_cmd->InitTypeDef.pwm_params.pwm_selection==1)
				Pinmux_Config(pAutoTest_cmd->InitTypeDef.pwm_params.Pin_Num, timer_pwm1);
			else if(pAutoTest_cmd->InitTypeDef.pwm_params.pwm_selection==2)
				Pinmux_Config(pAutoTest_cmd->InitTypeDef.pwm_params.Pin_Num, timer_pwm2);
			else if(pAutoTest_cmd->InitTypeDef.pwm_params.pwm_selection==3)
				Pinmux_Config(pAutoTest_cmd->InitTypeDef.pwm_params.Pin_Num, timer_pwm3);
			else
				DBG_DIRECT("Bee PWM Configure error!");
			
			Pad_Config(pAutoTest_cmd->InitTypeDef.pwm_params.Pin_Num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_HIGH);
			RCC_PeriphClockCmd(APBPeriph_TIMER, APBPeriph_TIMER_CLOCK, ENABLE); 
			TIM_TimeBaseInitTypeDef TIM_InitStruct;
		    TIM_StructInit(&TIM_InitStruct);
			TIM_InitStruct.TIM_ClockSrc = pAutoTest_cmd->InitTypeDef.pwm_params.TIM_ClockSrc;
			TIM_InitStruct.TIM_Period =pAutoTest_cmd->InitTypeDef.pwm_params.TIM_Period;
			UINT8 timer_offset=0x14* (pAutoTest_cmd->InitTypeDef.pwm_params.PWM_InitStruct.PWM_TIMIndex);
			TIM_TimeBaseInit((TIM_TypeDef*) (TIM0_REG_BASE+timer_offset), &TIM_InitStruct);
			TIM_Cmd((TIM_TypeDef*) (TIM0_REG_BASE+timer_offset), ENABLE);
			UINT8 pwm_offset=0x08*(pAutoTest_cmd->InitTypeDef.pwm_params.pwm_selection);
			PWM_Init((PWM_TypeDef*) (PWM0_REG_BASE+pwm_offset), &pAutoTest_cmd->InitTypeDef.pwm_params.PWM_InitStruct);
			AutoTestSendData(0x14, send_data, 0);
			break;
		}
		case 5:
		{
			
			send_data[0] = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, 0x364 + (pAutoTest_cmd->InitTypeDef.pwm_params.pwm_selection)*8,BIT(0));  		
			UINT8 pwm_offset=0x08*(pAutoTest_cmd->InitTypeDef.pwm_params.pwm_selection);
			PWM_Cmd((PWM_TypeDef*) (PWM0_REG_BASE+pwm_offset), ENABLE);
			send_data[1] = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, 0x364 + (pAutoTest_cmd->InitTypeDef.pwm_params.pwm_selection)*8,BIT(0));  
			/*read pinmux status*/
			send_data[2] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.pwm_params.Pin_Num);
			AutoTestSendData(0x15, send_data, 3);
			break;
		}
		case 6:
		{
			
			send_data[0] = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, 0x364 + (pAutoTest_cmd->InitTypeDef.pwm_params.pwm_selection)*8,BIT(0));  
			
			UINT32 pwm_offset=0x08*(pAutoTest_cmd->InitTypeDef.pwm_params.pwm_selection);
			PWM_Cmd((PWM_TypeDef*) (PWM0_REG_BASE+pwm_offset), DISABLE);
			UINT32 timer_offset=0x14* (pAutoTest_cmd->InitTypeDef.pwm_params.PWM_InitStruct.PWM_TIMIndex);
			TIM_Cmd((TIM_TypeDef*) (TIM0_REG_BASE+timer_offset),DISABLE);
			TIM_DeInit();
			Pinmux_Deinit(pAutoTest_cmd->InitTypeDef.pwm_params.Pin_Num);
			send_data[1] = AutoTest_ReadPeriFunRegister(PERIPH_REG_BASE, 0x364 + (pAutoTest_cmd->InitTypeDef.pwm_params.pwm_selection)*8,BIT(0)); 
			/*read pinmux status*/
			send_data[2] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.pwm_params.Pin_Num);	
			AutoTestSendData(0x16, send_data, 3);
			break;
		}
		case 7:
		{			
			AutoTestSendData(0x17, send_data, 0);
			vTaskDelay(200 / portTICK_RATE_MS);
//#if AUTOTEST_BY_LTP_EN
			/* system reset */
			NVIC_SystemReset();
//#endif
			break;
		}
		#if 0
		case 8:
		{
			send_data[0] = PWMParamModifyHandle(&pAutoTest_cmd->InitTypeDef.PWMAdap);
			AutoTestSendData(0x18, send_data, 1);
			break;
		}
		/*add for PWM duty change test (tempority)*/
		case 9:
		{
			for(PWM_test=200 ; PWM_test<pAutoTest_cmd->InitTypeDef.PWMAdap.pwm_period_length-200; )
			{
				pAutoTest_cmd->InitTypeDef.PWMAdap.pwm_duty_cycle_length  = PWM_test;
				HalPWMChangParameter(&pAutoTest_cmd->InitTypeDef.PWMAdap);
				PWM_test = PWM_test+200;
				vTaskDelay(20 / portTICK_RATE_MS);
			}
			break;
		}
		case 0x0a:
		{
			for(PWM_test=pAutoTest_cmd->InitTypeDef.PWMAdap.pwm_period_length-200; PWM_test>=200; )
			{
				pAutoTest_cmd->InitTypeDef.PWMAdap.pwm_duty_cycle_length  = PWM_test;
				HalPWMChangParameter(&pAutoTest_cmd->InitTypeDef.PWMAdap);
				PWM_test = PWM_test - 200;
				vTaskDelay(20 / portTICK_RATE_MS);
			}
			break;
		}
		#endif
		default:
		{
			break;
		}
	}
}


void AutoTestI2CParamHandle(uint8_t* pPara, AutoTest_i2c_Params *pAutoTest_I2C_Params)
{
	pAutoTest_I2C_Params->I2C_InitStructure.I2C_DeviveMode= *pPara++;
	pAutoTest_I2C_Params->I2C_InitStructure.I2C_DeviveMode= (pAutoTest_I2C_Params->I2C_InitStructure.I2C_DeviveMode << 8) + *pPara++;
	pAutoTest_I2C_Params->i2c_index = *pPara++;
	pAutoTest_I2C_Params->I2C_InitStructure.I2C_ClockSpeed= *pPara++;
	pAutoTest_I2C_Params->I2C_InitStructure.I2C_ClockSpeed = (pAutoTest_I2C_Params->I2C_InitStructure.I2C_ClockSpeed << 8) + *pPara++;
	pAutoTest_I2C_Params->I2C_InitStructure.I2C_ClockSpeed = (pAutoTest_I2C_Params->I2C_InitStructure.I2C_ClockSpeed << 8) + *pPara++;
	pAutoTest_I2C_Params->I2C_InitStructure.I2C_ClockSpeed = (pAutoTest_I2C_Params->I2C_InitStructure.I2C_ClockSpeed << 8) + *pPara++;
	pAutoTest_I2C_Params->I2C_InitStructure.I2C_AddressMode= *pPara++;
	pAutoTest_I2C_Params->I2C_InitStructure.I2C_SlaveAddress= *pPara++;
	pAutoTest_I2C_Params->I2C_InitStructure.I2C_SlaveAddress= (pAutoTest_I2C_Params->I2C_InitStructure.I2C_AddressMode << 8) + *pPara++;
	pAutoTest_I2C_Params->i2c_scl_pin_num= *pPara++;
	pAutoTest_I2C_Params->i2c_sda_pin_num= *pPara++;
	pAutoTest_I2C_Params->I2C_InitStructure.I2C_Ack=I2C_Ack_Enable;
	
	
	DBG_DIRECT(" Bee---> I2C devicemode value: %x\n", pAutoTest_I2C_Params->I2C_InitStructure.I2C_DeviveMode);
	DBG_DIRECT(" Bee---> I2C i2C_index value: %x\n", pAutoTest_I2C_Params->i2c_index);
	DBG_DIRECT(" Bee---> I2C i2c_speed value: %x\n", pAutoTest_I2C_Params->I2C_InitStructure.I2C_ClockSpeed);
	DBG_DIRECT(" Bee---> I2C i2c_address_mode value: %x\n", pAutoTest_I2C_Params->I2C_InitStructure.I2C_AddressMode);
	DBG_DIRECT(" Bee---> I2C i2c_slave_address value: %x\n", pAutoTest_I2C_Params->I2C_InitStructure.I2C_SlaveAddress);
	DBG_DIRECT(" Bee---> I2C i2c_scl_pin.I2C gpio_pin value: %x\n", pAutoTest_I2C_Params->i2c_scl_pin_num);
	DBG_DIRECT(" Bee---> I2C i2c_sda_pin.gpio_pin value: %x\n", pAutoTest_I2C_Params->i2c_sda_pin_num);

}


void AutoTestI2CHandle(AutoTest_CmdTypeDef *pAutoTest_cmd )
{	
	uint8_t send_data[50];
	UINT32 interruptMask = 0x0;
	
	switch((pAutoTest_cmd->HeaderTypeDef.P2_l & 0x0f))
	{
		case 0x0:
		{
			if(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_index == 0)
			{
				ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_I2C0, &send_data[0], &send_data[1]);
				I2C_DeInit(I2C0);
			}
			else
			{
				ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_I2C1, &send_data[0], &send_data[1]);
				I2C_DeInit(I2C1);
			}
			Pinmux_Deinit(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_scl_pin_num);
			Pinmux_Deinit(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_sda_pin_num);
						
			if(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_index == 0)
			{
				ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_I2C0, &send_data[2], &send_data[3]);
			}
			else
			{
				ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_I2C1, &send_data[2], &send_data[3]);
			}

			/*read pinmux status*/
			send_data[4] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_scl_pin_num);
			send_data[5] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_sda_pin_num);
			AutoTestSendData(0x50, send_data, 6);
			break;
		}
		case 0x1:
		{	
			Pinmux_Deinit(P2_4);
			Pinmux_Deinit(P2_5);
			if(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_index == 0)
			{
				ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_I2C0, &send_data[0], &send_data[1]);
				RCC_PeriphClockCmd(APBPeriph_I2C0, APBPeriph_I2C0_CLOCK, ENABLE);
				Pinmux_Config(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_scl_pin_num, I2C0_CLK);
				Pinmux_Config(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_sda_pin_num, I2C0_DAT);
				Pad_Config(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_scl_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
				Pad_Config(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_sda_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);	
				I2C_Init(I2C0, &pAutoTest_cmd->InitTypeDef.I2C_Params.I2C_InitStructure);
  				I2C_Cmd(I2C0, ENABLE); 
				ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_I2C0, &send_data[2], &send_data[3]);
			}
			else
			{
				ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_I2C1, &send_data[0], &send_data[1]);
				RCC_PeriphClockCmd(APBPeriph_I2C1, APBPeriph_I2C1_CLOCK, ENABLE);
				Pinmux_Config(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_scl_pin_num, I2C1_CLK);
				Pinmux_Config(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_sda_pin_num, I2C1_DAT);
				Pad_Config(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_scl_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
				Pad_Config(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_sda_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);	
				I2C_Init(I2C1, &pAutoTest_cmd->InitTypeDef.I2C_Params.I2C_InitStructure);
  				I2C_Cmd(I2C1, ENABLE); 	
				ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_I2C1, &send_data[2], &send_data[3]);
			}

			/*read pinmux status*/
			send_data[4] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_scl_pin_num);
			send_data[5] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_sda_pin_num);
			
			AutoTestSendData(0x51, send_data, 6);
			break;
		}
		case 0x2:
		{
			//send_data[0] = Fun_Status =  I2C_Initialize_Master(&pAutoTest_cmd->InitTypeDef.I2C_Params);
			//AutoTestSendData(0x52, send_data, 1);
			break;
		}
		case 0x3:
		{
			//send_data[0] = Fun_Status =  I2C_Initialize_Slave(&pAutoTest_cmd->InitTypeDef.I2C_Params);
			//AutoTestSendData(0x53, send_data, 1);
			break;
		}
		case 0x4:
		{		
			if(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_index == 0)
				I2C_MasterWrite(I2C0,pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.i2c_write_buffer,pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.i2c_data_length);
			else
			{
				I2C_MasterWrite(I2C1,pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.i2c_write_buffer,pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.i2c_data_length);
			}
			AutoTestSendData(0x54, send_data, 0);	
			break;
		}
		case 0x5:
		{
			interruptMask = I2C_INT_RD_REQ|I2C_INT_RX_DONE| I2C_INT_STOP_DET|I2C_INT_TX_ABRT;
			NVIC_InitTypeDef NVIC_InitStruct;
			if(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_index == 0)
			{
				I2C_ClearAllINT(I2C0);
				NVIC_InitStruct.NVIC_IRQChannel = I2C0_IRQ;
			}
			else
			{
				I2C_ClearAllINT(I2C1);
				NVIC_InitStruct.NVIC_IRQChannel = I2C1_IRQ;
			}
			NVIC_InitStruct.NVIC_IRQChannelPriority = 1;
			NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
			NVIC_Init(&NVIC_InitStruct);
			if(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_index == 0)
			{
				I2C_INTConfig(I2C0,interruptMask,ENABLE);
			}
			else
			{
				I2C_INTConfig(I2C1,interruptMask,ENABLE);
			}
			AutoTestSendData(0x55, send_data, 0);
			break;
		}
		case 0x6:
		{
			/*read data in master mode*/
			if(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_index == 0)
			{
				I2C_MasterRead(I2C0,send_data,pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.ReadDataCount);
			}
			else
			{
				I2C_MasterRead(I2C1,send_data,pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.ReadDataCount);
			}
			

#if AUTOTEST_DBG_EN	
			DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->AutoTestI2CHandle->I2C_Write_Data_Adapter->i2c_index : %x\n", 1, pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_index);
			DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->AutoTestI2CHandle->I2C_Write_Data_Adapter->i2c_address_mode : %x\n", 1, pAutoTest_cmd->InitTypeDef.I2C_Params.I2C_InitStructure.I2C_AddressMode);
			DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->AutoTestI2CHandle->I2C_Write_Data_Adapter->i2c_slave_address : %x\n", 1, pAutoTest_cmd->InitTypeDef.I2C_Params.I2C_InitStructure.I2C_SlaveAddress);
			DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->AutoTestI2CHandle->I2C_Write_Data_Adapter->i2c_read_data_length : %x\n", 1, pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.ReadDataCount);
			DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->AutoTestI2CHandle->I2C_Write_Data_Adapter->i2c_read_data_buffer : %x\n", 1, send_data);
#endif

			AutoTestSendData(0x56, send_data, pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.ReadDataCount);
			break;
		}
		#if 0
		case 0x0d:
		{
			Fun_Status = I2C_Read_Status(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_index);
			send_data[0] = (Fun_Status >> 16)/256;
			send_data[1] = (Fun_Status >> 16)%256;
			send_data[2] = (Fun_Status & 0x0000ffff)/256;
			send_data[3] = (Fun_Status & 0x0000ffff)%256;
			AutoTestSendData(0x5d, send_data, 4);
		
			break;
		}
		#endif
		case 0x0e:
		{	
			if(pAutoTest_cmd->InitTypeDef.I2C_Params.i2c_index == 0)
			{
				I2C_RepeatRead(I2C0,pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.i2c_write_buffer,pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.i2c_data_length,send_data,pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.ReadDataCount);
			}
			else
			{
				I2C_RepeatRead(I2C1,pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.i2c_write_buffer,pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.i2c_data_length,send_data,pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.ReadDataCount);
			}
			AutoTestSendData(0x5e, send_data, pAutoTest_cmd->DataTypeDef.AutoTest_I2C_Data.ReadDataCount);
			break;
		}
		
		case 0x0f:
		{
			AutoTestSendData(0x5f, send_data, 0);
			vTaskDelay(200 / portTICK_RATE_MS);
			NVIC_SystemReset();
		}
		default:
		{
			break;
		}
	}
}


void I2C0IntrHandler(void)
{	  
	uint8_t receive_data = 0 ;
	/*Test data buffer for slave mode */
	uint8_t send_data[25];
	uint8_t idx = 0;
	
	for(idx = 0; idx < 25; idx++)
	{
		send_data[idx] = idx+1;
	}
	
    if (I2C_GetINTStatus(I2C0,I2C_INT_RD_REQ)==SET)
    {
    	/*slave mode request for send I2C data*/
		for(uint8_t i=0;i<25;i++)
		{
			I2C_SendData(I2C0,send_data[i],DISABLE);
		}
#if AUTOTEST_DBG_EN	
		DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->AutoTest_I2C_ISR_HANDLER->I2C_INT_Status->I2C_INT_RD_REQ\n", 0);
#endif

		I2C_ClearINTPendingBit(I2C0,I2C_INT_RD_REQ);
    }
	else if (I2C_GetINTStatus(I2C0,I2C_INT_TX_ABRT)==SET)
	{
		DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "ERROR", 0);
	}
	else 
	{
		if (I2C_GetINTStatus(I2C0,I2C_INT_STOP_DET)==SET)
		{
			/*read I2C data*/
			receive_data = I2C_ReceiveData(I2C0);
			I2C_ClearINTPendingBit(I2C0,I2C_INT_STOP_DET);
			AutoTestSendData(0xff, &receive_data, 1);
		}
	}
    
}

void I2C1IntrHandler(void)
{	  
	uint8_t receive_data = 0 ;
	/*Test data buffer for slave mode */
	uint8_t send_data[25];
	uint8_t idx = 0;
	
	for(idx = 0; idx < 25; idx++)
	{
		send_data[idx] = idx+1;
	}
	
    if (I2C_GetINTStatus(I2C1,I2C_INT_RD_REQ)==SET)
    {
    	/*slave mode request for send I2C data*/
		for(uint8_t i=0;i<25;i++)
		{
			I2C_SendData(I2C1,send_data[i],DISABLE);
		}
#if AUTOTEST_DBG_EN	
		DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "AutoTest-->AutoTest_I2C_ISR_HANDLER->I2C_INT_Status->I2C_INT_RD_REQ\n", 0);
#endif

		I2C_ClearINTPendingBit(I2C1,I2C_INT_RD_REQ);
    }
	else if (I2C_GetINTStatus(I2C1,I2C_INT_TX_ABRT)==SET)
	{
		DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "ERROR", 0);
	}
	else 
	{
		if (I2C_GetINTStatus(I2C1,I2C_INT_STOP_DET)==SET)
		{
			/*read I2C data*/
			receive_data = I2C_ReceiveData(I2C1);
			I2C_ClearINTPendingBit(I2C1,I2C_INT_STOP_DET);
			AutoTestSendData(0xff, &receive_data, 1);
		}
	}
    
}


void AutoTestSPIParamHandle(uint8_t* pSPIPara, AutoTest_spi_Params *pAutoTest_SPI_Params)
{
	pAutoTest_SPI_Params->spi_index = *pSPIPara++;
	pAutoTest_SPI_Params->SPI_InitStructure.SPI_Mode= *pSPIPara++;
	pAutoTest_SPI_Params->SPI_InitStructure.SPI_Mode= (pAutoTest_SPI_Params->SPI_InitStructure.SPI_Mode << 8) + *pSPIPara++;
	pAutoTest_SPI_Params->SPI_InitStructure.SPI_DataSize= *pSPIPara++;
	pAutoTest_SPI_Params->SPI_InitStructure.SPI_FrameFormat= *pSPIPara++;
	pAutoTest_SPI_Params->SPI_InitStructure.SPI_Direction= *pSPIPara++;
	pAutoTest_SPI_Params->SPI_InitStructure.SPI_CPOL= *pSPIPara++;
	pAutoTest_SPI_Params->SPI_InitStructure.SPI_CPHA= *pSPIPara++;

	pAutoTest_SPI_Params->SPI_InitStructure.SPI_ClockSpeed= *pSPIPara++;
	pAutoTest_SPI_Params->SPI_InitStructure.SPI_ClockSpeed = ((pAutoTest_SPI_Params->SPI_InitStructure.SPI_ClockSpeed)<<8) + *pSPIPara++;
	pAutoTest_SPI_Params->SPI_InitStructure.SPI_ClockSpeed = ((pAutoTest_SPI_Params->SPI_InitStructure.SPI_ClockSpeed<<8)) + *pSPIPara++;
	pAutoTest_SPI_Params->SPI_InitStructure.SPI_ClockSpeed = ((pAutoTest_SPI_Params->SPI_InitStructure.SPI_ClockSpeed<<8)) + *pSPIPara++;
	pAutoTest_SPI_Params->SPI_InitStructure.SPI_RxThresholdLevel=1;
	pAutoTest_SPI_Params->SPI_InitStructure.SPI_TxThresholdLevel=1;
	pAutoTest_SPI_Params->SPI_InitStructure.SPI_NDF=1;
	
	pAutoTest_SPI_Params->spi_clk_pin_num= *pSPIPara++;
	pAutoTest_SPI_Params->spi_mosi_pin_num= *pSPIPara++;
	pAutoTest_SPI_Params->spi_miso_pin_num= *pSPIPara++;
	pAutoTest_SPI_Params->spi_cs0_pin_num= *pSPIPara++;

	/*DBG_DIRECT(" Bee---> DriverModule_SPI_Params--> spi_index value: %x\n", pAutoTest_SPI_Params->spi_index);
	DBG_DIRECT(" Bee---> DriverModule_SPI_Params--> devicerole value: %x\n", pAutoTest_SPI_Params->SPI_InitStructure.SPI_Mode);
	DBG_DIRECT(" Bee---> DriverModule_SPI_Params--> data_frame_size value: %x\n", pAutoTest_SPI_Params->SPI_InitStructure.SPI_DataSize);
	DBG_DIRECT(" Bee---> DriverModule_SPI_Params--> data_frame_format value: %x\n", pAutoTest_SPI_Params->SPI_InitStructure.SPI_FrameFormat);
	DBG_DIRECT(" Bee---> DriverModule_SPI_Params--> data_transfermode value: %x\n", pAutoTest_SPI_Params->SPI_InitStructure.SPI_Direction);
	DBG_DIRECT(" Bee---> DriverModule_SPI_Params--> sclk_pol value: %x\n", pAutoTest_SPI_Params->SPI_InitStructure.SPI_CPOL);
	DBG_DIRECT(" Bee---> DriverModule_SPI_Params--> sclk_phase value: %x\n", pAutoTest_SPI_Params->SPI_InitStructure.SPI_CPHA);
	DBG_DIRECT(" Bee---> DriverModule_SPI_Params--> spi_speed value: %d\n", pAutoTest_SPI_Params->SPI_InitStructure.SPI_ClockSpeed);	
	DBG_DIRECT(" Bee---> DriverModule_SPI_Params--> spi_clk_gpio_pin value: %x\n", pAutoTest_SPI_Params->spi_clk_pin_num);
	DBG_DIRECT(" Bee---> DriverModule_SPI_Params--> spi_mosi_gpio_pin value: %x\n", pAutoTest_SPI_Params->spi_mosi_pin_num);	
	DBG_DIRECT(" Bee---> DriverModule_SPI_Params--> spi_miso_gpio_pin value: %x\n", pAutoTest_SPI_Params->spi_miso_pin_num);	
	DBG_DIRECT(" Bee---> DriverModule_SPI_Params--> spi_cs0_gpio_pin value: %x\n", pAutoTest_SPI_Params->spi_cs0_pin_num);
	*/
}


void AutoTestSPIHandle(AutoTest_CmdTypeDef *pAutoTest_cmd )
{	
	uint8_t send_data[50] = {0};
	uint8_t SPI_receivedata_index = 0;
	uint8_t SPI_receivedata_length = 0;
	uint32_t SPI_writedata_length = 0;
	uint8_t spi_index = pAutoTest_cmd->InitTypeDef.SPI_Params.spi_index;
	
	switch((pAutoTest_cmd->HeaderTypeDef.P2_l & 0x0f))
	{
		case 0:
		{
			Pinmux_Deinit(P4_0);
			Pinmux_Deinit(P4_1);
			Pinmux_Deinit(P4_2);
			Pinmux_Deinit(P4_3);

			if(spi_index == 0)
			{				
				ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_SPI0, &send_data[0], &send_data[1]);
				RCC_PeriphClockCmd(APBPeriph_SPI0, APBPeriph_SPI0_CLOCK, ENABLE);
				
				if(pAutoTest_cmd->InitTypeDef.SPI_Params.SPI_InitStructure.SPI_Mode==SPI_Mode_Master)
				{
					Pinmux_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_clk_pin_num, SPI0_CLK_Master);
					Pinmux_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_mosi_pin_num, SPI0_MO_Master);
					Pinmux_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_miso_pin_num, SPI0_MI_Master);
					Pinmux_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_cs0_pin_num, SPI0_SS_N_0_Master);
				}
				else
				{
					Pinmux_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_clk_pin_num, SPI0_CLK_0_Slave);
					Pinmux_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_mosi_pin_num, SPI0_SI_0_Slave);
					Pinmux_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_miso_pin_num, SPI0_SO_0_Slave);
					Pinmux_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_cs0_pin_num, SPI0_SS_N_0_Slave);
				}
				
				Pad_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_clk_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
				Pad_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_mosi_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
				Pad_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_miso_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
				Pad_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_cs0_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
				
				SPI_Init(SPI0,&pAutoTest_cmd->InitTypeDef.SPI_Params.SPI_InitStructure);
				SPI_Cmd(SPI0,ENABLE);
				ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_SPI0, &send_data[2], &send_data[3]);
			}
			else
			{
				 ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_SPI1, &send_data[0], &send_data[1]);
				 RCC_PeriphClockCmd(APBPeriph_SPI1, APBPeriph_SPI1_CLOCK, ENABLE);
				 Pinmux_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_clk_pin_num, SPI1_CLK_Master);
				 Pinmux_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_mosi_pin_num, SPI1_MO_Master);
				 Pinmux_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_miso_pin_num, SPI1_MI_Master);
				 Pinmux_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_cs0_pin_num, SPI1_SS_N_0_Master);

				 Pad_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_clk_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
				 Pad_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_mosi_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
				 Pad_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_miso_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
				 Pad_Config(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_cs0_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
				 
				 SPI_Init(SPI1,&pAutoTest_cmd->InitTypeDef.SPI_Params.SPI_InitStructure);
				 SPI_Cmd(SPI1,ENABLE);
				 ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_SPI1, &send_data[2], &send_data[3]);
			}
			/*read pinmux status*/
			send_data[4] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_clk_pin_num);
			send_data[5] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_mosi_pin_num);
			send_data[6] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_miso_pin_num);
			send_data[7] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_cs0_pin_num);
			
			AutoTestSendData(0x60, send_data, 8);
			break;
		}
		case 1:
		{
			/*SPI wirte*/
			for (SPI_writedata_length=0; SPI_writedata_length < pAutoTest_cmd->DataTypeDef.AutoTest_SPI_Data.spi_data_length; SPI_writedata_length++)
			{
				if(spi_index == 0)
				{
					SPI_SendData(SPI0, pAutoTest_cmd->DataTypeDef.AutoTest_SPI_Data.spi_write_buffer[SPI_writedata_length]);
				}
				else
				{
					SPI_SendData(SPI1, pAutoTest_cmd->DataTypeDef.AutoTest_SPI_Data.spi_write_buffer[SPI_writedata_length]);
				}
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, " AutoTest-->AutoTestSPIHandle->SPI_Write_V2 value: %x\n", 1, pAutoTest_cmd->DataTypeDef.AutoTest_SPI_Data.spi_write_buffer[SPI_writedata_length]);
			}
			AutoTestSendData(0x61, send_data, 0);
			break;
		}
		case 2:
		{
			#if 0
			Fun_Status = SPI_GetStatus_V2(spi_index);
			send_data[0] = (Fun_Status >> 16)/256;
			send_data[1] = (Fun_Status >> 16)%256;
			send_data[2] = (Fun_Status & 0x0000ffff)/256;
			send_data[3] = (Fun_Status & 0x0000ffff)%256;
			AutoTestSendData(0x62, send_data, 4);
			#endif
			break;
		}
		case 3:
		{
			if(spi_index==0)
			{
				/*Waiting for SPI data transfer to end*/
   		    	while(SPI_GetFlagState(SPI0, SPI_FLAG_BUSY));
				SPI_receivedata_length = SPI_GetRxFIFOLen(SPI0);
				while(SPI_receivedata_length--)
				{
					send_data[SPI_receivedata_index++] = SPI_ReceiveData(SPI0);
				}
			}
			else
			{
				/*Waiting for SPI data transfer to end*/
   		    	while(SPI_GetFlagState(SPI1, SPI_FLAG_BUSY));
				SPI_receivedata_length = SPI_GetRxFIFOLen(SPI1);
				while(SPI_receivedata_length--)
				{
					send_data[SPI_receivedata_index++] = SPI_ReceiveData(SPI1);
				}
			}
			AutoTestSendData(0x63, send_data, SPI_receivedata_index);
			break;
		}

		case 0x04:
		{
			/*read register*/
			if(spi_index == 0)
			{
				ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_SPI0, &send_data[0], &send_data[1]);
				SPI_DeInit(SPI0);
			}
			else
			{
				ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_SPI1, &send_data[0], &send_data[1]);
				SPI_DeInit(SPI1);
			}
			
			Pinmux_Deinit(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_clk_pin_num);
			Pinmux_Deinit(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_mosi_pin_num);
			Pinmux_Deinit(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_miso_pin_num);
			Pinmux_Deinit(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_cs0_pin_num);
			
			/*read register*/
			if(spi_index == 0)
			{
				ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_SPI0, &send_data[2], &send_data[3]);
			}
			else
			{
				ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_SPI1, &send_data[2], &send_data[3]);
			}
			/*read pinmux status*/
			send_data[4] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_clk_pin_num);
			send_data[5] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_mosi_pin_num);
			send_data[6] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_miso_pin_num);
			send_data[7] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.SPI_Params.spi_cs0_pin_num);

			AutoTestSendData(0x64, send_data, 8);
			break;
		}
		case 0x05:
		{
			#if 0
			//send_data[0] = SPI_Write_WithDMA(spi_index, 8, pAutoTest_cmd->DataTypeDef.pAutoTest_SPI_Data->spi_data_length, (UINT32*)&(pAutoTest_cmd->DataTypeDef.pAutoTest_SPI_Data->spi_write_buffer[0]),SPI_WRITE_DMA_CB);
			//send_data[0] = SPI_Write_WithDMA(spi_index, 8, pAutoTest_cmd->DataTypeDef.pAutoTest_SPI_Data->spi_data_length, &(pAutoTest_cmd->DataTypeDef.pAutoTest_SPI_Data->spi_write_buffer[0]), SPI_WRITE_DMA_CB);
			for (i = 4; i < 220; i++)
			{
				AutoTest_SPI_WriteBuffer[i] = i + 0x5;
			}
			send_data[0] = SPI_Write_WithDMA(spi_index, 8, 200, AutoTest_SPI_WriteBuffer, SPI_WRITE_DMA_CB);
			send_data[1] = pAutoTest_cmd->DataTypeDef.AutoTest_SPI_Data.spi_write_buffer[0];
			AutoTestSendData(0x65, send_data, 2);
			#endif
			break;
		}
		case 0x06:
		{
			#if 0
			send_data[0] = SPI_Write_WithDMA(spi_index, 16, pAutoTest_cmd->DataTypeDef.AutoTest_SPI_Data.spi_data_length/2, (UINT32*)&(pAutoTest_cmd->DataTypeDef.AutoTest_SPI_Data.spi_write_buffer[0]),SPI_WRITE_DMA_CB);
			send_data[1] = pAutoTest_cmd->DataTypeDef.AutoTest_SPI_Data.spi_write_buffer[0];
			AutoTestSendData(0x66, send_data, 2);
			#endif
			break;
		}
		case 0x07:
		{
			#if 0
			//AutoTest_SPI_Receive_Length = pAutoTest_cmd->DataTypeDef.pAutoTest_SPI_Data->spi_read_length;
			/* malloc memory for stor*/
			//pAutoTest_cmd->DataTypeDef.pAutoTest_SPI_Data = pvPortMalloc(sizeof(uint32_t*800),RAM_TYPE_DATA_OFF);
			//memset(pAutoTest_cmd->DataTypeDef.pAutoTest_SPI_Data, 0, sizeof(AutoTest_SPI_TestData));

			send_data[0] = SPI_Read_WithDMA(spi_index, 8, pAutoTest_cmd->DataTypeDef.AutoTest_SPI_Data.spi_read_length, AutoTest_SPI_Buffer, SPI_READ_DMA_CB);
			AutoTestSendData(0x67, send_data, 1);
			#endif
			break;
		}
		case 0x08:
		{
			#if 0
			SPI_Read_WithDMA(spi_index, 16, pAutoTest_cmd->DataTypeDef.AutoTest_SPI_Data.spi_read_length/2, (UINT16*)send_data, SPI_READ_DMA_CB);
			AutoTestSendData(0x68, send_data, pAutoTest_cmd->DataTypeDef.AutoTest_SPI_Data.spi_read_length);
			#endif
			break;
		}
		case 0x09:
		{
			#if 0
			/* Common Interrupt Configurations */
			if(spi_index == 0)
			{
				AutoTest_SPI_IrqHandle_Slave.IrqNum = SPI0_IRQ;
			}
			else
			{
			 AutoTest_SPI_IrqHandle_Slave.IrqNum = SPI1_IRQ;
			}
			
		    AutoTest_SPI_IrqHandle_Slave.IrqFun = (IRQ_FUN) AutoTest_SPI_ISR_HANDLER;
		    AutoTest_SPI_IrqHandle_Slave.Priority = 2;
			InterruptUnRegister(&AutoTest_SPI_IrqHandle_Slave);
			SPI_Set_INT_Mask_V2(spi_index, pAutoTest_cmd->InitTypeDef.SPI_Params.InterruptMask);	
		    InterruptRegister(&AutoTest_SPI_IrqHandle_Slave);
		    InterruptEn(&AutoTest_SPI_IrqHandle_Slave);
			AutoTestSendData(0x69, send_data, 1);
			#endif
			break;
		}
		case 0x0a:
		{
			#if 0
			send_data[0] = SPI_BurstWrite_V2(spi_index, &(pAutoTest_cmd->DataTypeDef.AutoTest_SPI_Data.spi_write_buffer[0]), pAutoTest_cmd->DataTypeDef.AutoTest_SPI_Data.spi_data_length);
			send_data[1] = pAutoTest_cmd->DataTypeDef.AutoTest_SPI_Data.spi_data_length;
			AutoTestSendData(0x6a, send_data, 2);
			#endif
			break;
		}
		case 0x0f:
		{
			AutoTestSendData(0x6f, send_data, 0);
			vTaskDelay(200 / portTICK_RATE_MS);
			NVIC_SystemReset();
			break;
		}
		default:
		{
			break;
		}
	}
}


void AutoTestKeyScanParamHandle(uint8_t* pParam, AutoTest_keyscan_Params *pkeypad_param)
{
	pkeypad_param->keyScanInitStruct.rowSize= *pParam++;
	pkeypad_param->keyScanInitStruct.colSize= *pParam++;
	pkeypad_param->keyScanInitStruct.detectPeriod= *pParam++;
	pkeypad_param->keyScanInitStruct.detectPeriod= (pkeypad_param->keyScanInitStruct.detectPeriod << 8) + *pParam++;
	pkeypad_param->keyScanInitStruct.timeout= *pParam++;
	pkeypad_param->keyScanInitStruct.scanInterval= *pParam++;
	pkeypad_param->keyScanInitStruct.debounceEn= *pParam++;
	pkeypad_param->keyScanInitStruct.debounceTime= *pParam++;
	pkeypad_param->keyScanInitStruct.debounceTime= (pkeypad_param->keyScanInitStruct.debounceTime<<8)+ *pParam++;
	pkeypad_param->keyScanInitStruct.detectMode= *pParam++;
	pkeypad_param->keyScanInitStruct.fifoOvrCtrl= *pParam++;
	pkeypad_param->keyScanInitStruct.maxScanData= *pParam++;
	pkeypad_param->keyScanInitStruct.maxScanData= (pkeypad_param->keyScanInitStruct.maxScanData<<8)+ *pParam++;
	pkeypad_param->keyscan_column1_pin_num= *pParam++;
	pkeypad_param->keyscan_column2_pin_num= *pParam++;
	pkeypad_param->keyscan_column3_pin_num= *pParam++;
	pkeypad_param->keyscan_column4_pin_num= *pParam++;
	pkeypad_param->keyscan_row1_pin_num= *pParam++;
	pkeypad_param->keyscan_row2_pin_num= *pParam++;
	pkeypad_param->keyscan_row3_pin_num= *pParam++;
	pkeypad_param->keyscan_row4_pin_num= *pParam;
	
}


void AutoTestKeyScanHandle(AutoTest_CmdTypeDef *pAutoTest_cmd)
{
	uint8_t send_data[50] = {0};
	
	switch((pAutoTest_cmd->HeaderTypeDef.P2_l & 0x0f))
	{
		case 0:
		{
			ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_Keyscan, &send_data[0], &send_data[1]);
			/* turn on Keyscan clock */
    		RCC_PeriphClockCmd(APBPeriph_KEYSCAN, APBPeriph_KEYSCAN_CLOCK, ENABLE);
			/* keypad pinmux config */
    		Pinmux_Config(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row1_pin_num, KEY_ROW_0);
    		Pinmux_Config(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row2_pin_num, KEY_ROW_1);
			Pinmux_Config(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row3_pin_num, KEY_ROW_2);
			Pinmux_Config(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row4_pin_num, KEY_ROW_3);
    		Pinmux_Config(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column1_pin_num, KEY_COL_0);
    		Pinmux_Config(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column2_pin_num, KEY_COL_1);
			Pinmux_Config(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column3_pin_num, KEY_COL_2);
			Pinmux_Config(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column4_pin_num, KEY_COL_3);
			/* Keypad pad config */
		    Pad_Config(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row1_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);
		    Pad_Config(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row2_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);
			Pad_Config(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row3_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);
			Pad_Config(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row4_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);
		    Pad_Config(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column1_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_LOW);
		    Pad_Config(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column2_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_LOW);
			Pad_Config(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column3_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_LOW);
			Pad_Config(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column4_pin_num, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_LOW);

			KeyScan_Init(KEYSCAN,&pAutoTest_cmd->InitTypeDef.keypad_param.keyScanInitStruct);
			KeyScan_Cmd(KEYSCAN,ENABLE);
			ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_Keyscan, &send_data[2], &send_data[3]);

			/*read pinmux status*/
			send_data[4] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row1_pin_num);
			send_data[5] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row2_pin_num);
			send_data[6] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row3_pin_num);
			send_data[7] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row4_pin_num);
			send_data[8] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column1_pin_num);
			send_data[9] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column2_pin_num);
			send_data[10] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column3_pin_num);
			send_data[11] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column4_pin_num);
			AutoTestSendData(0x90, send_data, 12);
			break;
		}
		case 0x01:
		{
			ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_Keyscan, &send_data[0], &send_data[1]);
			KeyScan_DeInit(KEYSCAN);
			
			Pinmux_Deinit(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row1_pin_num);
			Pinmux_Deinit(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row2_pin_num);
			Pinmux_Deinit(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row3_pin_num);
			Pinmux_Deinit(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row4_pin_num);
			Pinmux_Deinit(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column1_pin_num);
			Pinmux_Deinit(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column2_pin_num);
			Pinmux_Deinit(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column3_pin_num);
			Pinmux_Deinit(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column4_pin_num);
			
			ReadPeriFunRegisterByPeripheralType(AutoTest_PeripherialType_Keyscan, &send_data[2], &send_data[3]);
			
			/*read pinmux status*/
			send_data[4] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row1_pin_num);
			send_data[5] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row2_pin_num);
			send_data[6] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row3_pin_num);
			send_data[7] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_row4_pin_num);
			send_data[8] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column1_pin_num);
			send_data[9] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column2_pin_num);
			send_data[10] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column3_pin_num);
			send_data[11] = AutoTest_ReadPinStatus(pAutoTest_cmd->InitTypeDef.keypad_param.keyscan_column4_pin_num);
			AutoTestSendData(0x90, send_data, 12);
			break;
		}
		case 0x04:
		{
			NVIC_InitTypeDef NVIC_InitStruct;
    
		    /* Keyscan IRQ */  
		    NVIC_InitStruct.NVIC_IRQChannel = KEYSCAN_IRQ;
		    NVIC_InitStruct.NVIC_IRQChannelPriority = 1;
		    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;    
		    NVIC_Init(&NVIC_InitStruct);	
			KeyScan_INTConfig(KEYSCAN, KEYSCAN_INT_SCAN_END, ENABLE);
			AutoTestSendData(0x94, send_data, 0);
			break;
		}
		case 0x05:
		{
			//send_data[0]=CurKeyData.key[0].row;
			//send_data[1]=CurKeyData.key[0].column;
			AutoTestSendData(0x95, send_data, 0);
			break;
		}
		case 0x0f:
		{
			AutoTestSendData(0x9f, send_data, 0);
			vTaskDelay(200 / portTICK_RATE_MS);
			NVIC_SystemReset();
			break;
		}
		default:
		{
			break;
		}
	}
}

void KeyscanIntrHandler(void)
{   
    uint32_t fifoLength;  
    PKEYSCAN_DATA_STRUCT pKeyData = &CurKeyData;
    
    /* Read current keyscan interrupt status and mask interrupt */
    KeyScan_INTMask(KEYSCAN, ENABLE);
    KeyScan_ClearINTPendingBit(KEYSCAN, KEYSCAN_INT_SCAN_END);

    memset(pKeyData, 0, sizeof(KEYSCAN_DATA_STRUCT));

    fifoLength = (uint32_t)KeyScan_GetFifoDataNum(KEYSCAN);
    pKeyData->length = fifoLength;

    /* If more than one data in FIFO */
    if (fifoLength > 0)
    {
        if (fifoLength > (sizeof(pKeyData->key) / sizeof(uint16_t)))
        {
            fifoLength = sizeof(pKeyData->key) / sizeof(uint16_t);
        }

        /* Read out all FIFO data */
        KeyScan_Read(KEYSCAN, (uint8_t*)(&pKeyData->key[0]), fifoLength);
		Autosendchar(pKeyData->key[0].row);
		Autosendchar(pKeyData->key[0].column);
		pKeyData=0;
		KeyScan_INTMask(KEYSCAN, DISABLE);  
    }

}


BYTE AutoTestCRC8(LPBYTE pStart, WORD length)
{
    BYTE fcs = 0xff;

    while (length--)
    {
        fcs = crc8EtsTable[fcs ^ *pStart++];
    }
    return 0xff - fcs;
}

int AutosendInt32(uint32_t ch)
{
	while(1)
	{
		if(UART_GetFlagState(UART, UART_FLAG_THR_TSR_EMPTY)==SET)
		{
			break;
		}
	}
	UART_SendData(UART,(UINT8*)&ch, 4);
	return (ch);
}

int Autosendchar(int ch)
{
	while(1)
	{
		if(UART_GetFlagState(UART, UART_FLAG_THR_TSR_EMPTY)==SET)
		{
			break;
		}
	}
	UART_SendData(UART, (UINT8*)&ch, 1);	
	return (ch);
}

