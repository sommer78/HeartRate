enum { __FILE_NUM__= 0 };


#include "symboltable_uuid.h"
#include "freeRTOS.h"
#include "task.h"
#include "trace.h"
#include "gatttest.h"

void Board_Init(void)
{

}

int main(void) 
{  	
    DBG_DIRECT("User code entry\n");
//    LPS_MODE_Pause();
	  //APP init
    gattTestInit();
    vTaskStartScheduler();
	  return 0;
}
