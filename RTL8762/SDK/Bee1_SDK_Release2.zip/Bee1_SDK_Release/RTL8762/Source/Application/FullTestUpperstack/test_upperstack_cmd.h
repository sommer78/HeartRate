#ifndef _TEST_UPPERSTACK_CMD_H_
#define _TEST_UPPERSTACK_CMD_H_


void test_upperstack_CmdInit(void);

TTestResult test_upperstack_CmdExecute( PGATTTest pGattTest,
        TTestParseResult * pParseResult );


#endif
