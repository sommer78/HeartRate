#include "test_transport_uart.h"

#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>

/* for bee uart io driver interface */
#include "rtl_types.h"
#include "board.h"
#include "rtl876x_uart.h"
#include "rtl876x_pinmux.h"
#include "rtl876x_io_dlps.h"


extern xQueueHandle test_upperstack_QueueHandleTransportRx;
extern xQueueHandle test_upperstack_QueueHandleEvent;

int transport_uart_sendchar(int ch)
{
    while (UART_GetFlagState(UART, UART_FLAG_THR_EMPTY) != SET);
    UART_SendData(UART, (uint8_t*)&ch, 1);
    return (ch);
}

int transport_uart_VSprintf(char *buf, const char *fmt, const int *dp)
{
    char *p, *s;

    s = buf;
    for ( ; *fmt != '\0'; ++fmt)
    {
        if (*fmt != '%')
        {
            buf ? *s++ = *fmt : transport_uart_sendchar(*fmt);
            continue;
        }
        if (*++fmt == 's')
        {
            for (p = (char *)*dp++; *p != '\0'; p++)
                buf ? *s++ = *p : transport_uart_sendchar(*p);
        }
        else    /* Length of item is bounded */
        {
            char tmp[20], *q = tmp;
            int alt = 0;
            int shift = 28;

#if 1   //wei patch for %02x
            if ((*fmt  >= '0') && (*fmt  <= '9'))
            {
                int width;
                unsigned char fch = *fmt;
                for (width = 0; (fch >= '0') && (fch <= '9'); fch = *++fmt)
                {
                    width = width * 10 + fch - '0';
                }
                shift = (width - 1) * 4;
            }
#endif

            /*
             * Before each format q points to tmp buffer
             * After each format q points past end of item
             */

            if ((*fmt == 'x') || (*fmt == 'X') || (*fmt == 'p') || (*fmt == 'P'))
            {
                /* With x86 gcc, sizeof(long) == sizeof(int) */
                const long *lp = (const long *)dp;
                long h = *lp++;
                int ncase = (*fmt & 0x20);
                dp = (const int *)lp;
                if ((*fmt == 'p') || (*fmt == 'P'))
                    alt = 1;
                if (alt)
                {
                    *q++ = '0';
                    *q++ = 'X' | ncase;
                }
                for ( ; shift >= 0; shift -= 4)
                    * q++ = "0123456789ABCDEF"[(h >> shift) & 0xF] | ncase;
            }
            else if (*fmt == 'd')
            {
                int i = *dp++;
                char *r;
                if (i < 0)
                {
                    *q++ = '-';
                    i = -i;
                }
                p = q;      /* save beginning of digits */
                do
                {
                    *q++ = '0' + (i % 10);
                    i /= 10;
                }
                while (i);
                /* reverse digits, stop in middle */
                r = q;      /* don't alter q */
                while (--r > p)
                {
                    i = *r;
                    *r = *p;
                    *p++ = i;
                }
            }
            else if (*fmt == 'c')
                *q++ = *dp++;
            else
                *q++ = *fmt;
            /* now output the saved string */
            for (p = tmp; p < q; ++p)
                buf ? *s++ = *p : transport_uart_sendchar(*p);
        }
    }
    if (buf)
        *s = '\0';
    return (s - buf);
}




int
transport_uart_print(
    IN  char *fmt, ...
)
{
    (void)transport_uart_VSprintf(0, fmt, ((const int *)&fmt) + 1);
    return 0;
}

/****************************************************************************/
/* UART interrupt                                                           */
/****************************************************************************/
void TestUpperStackDataUartIrqHandle(void)
{
    uint8_t rx_data = 0;
    portBASE_TYPE TaskWoken = pdFALSE;
    uint8_t event  = DEMO_EVENT_UART_RX;
    uint32_t int_status = 0;

    /* read interrupt id */
    int_status = UART_GetIID(UART);
    /* disable interrupt */
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, DISABLE);

    switch (int_status)
    {
    /* tx fifo empty */
    case UART_INT_ID_TX_EMPTY:
        /* do nothing */
        break;

    /* rx data valiable */
    case UART_INT_ID_RX_LEVEL_REACH:
    case UART_INT_ID_RX_TMEOUT:
        while (UART_GetFlagState(UART, UART_FLAG_RX_DATA_RDY) == SET)
        {
            UART_ReceiveData(UART, &rx_data, 1);
        }

        xQueueSendFromISR(test_upperstack_QueueHandleTransportRx, &rx_data, &TaskWoken);
        xQueueSendFromISR(test_upperstack_QueueHandleEvent, &event, &TaskWoken);

        break;

    /* receive line status interrupt */
    case UART_INT_ID_LINE_STATUS:
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "Line status error!!!!\n", 0);
        break;

    default:
        break;
    }

    /* enable interrupt again */
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, ENABLE);
    portEND_SWITCHING_ISR(TaskWoken);
    return;
}

/****************************************************************************/
/* UART init                                                                */
/****************************************************************************/
void test_upperstack_UARTInit(void)
{
    DLPS_IO_Register();
    test_upperstack_QueueHandleTransportRx = xQueueCreate(UART_RX_QUEUE_LENGTH, sizeof(char));
    //pinmux config
    Pinmux_Config(UART_TX_PIN, DATA_UART_TX);
    Pinmux_Config(UART_RX_PIN, DATA_UART_RX);

    //pad config
    Pad_Config(UART_TX_PIN, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
    Pad_Config(UART_RX_PIN, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);


    //uart init
    UART_InitTypeDef uartInitStruct;
    UART_StructInit(&uartInitStruct);

    uartInitStruct.rxTriggerLevel = UART_RX_FIFO_TRIGGER_LEVEL_1BYTE;
    UART_Init(UART, &uartInitStruct);
    //enable line status interrupt and rx data avaliable interrupt
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, ENABLE);

    /*  Enable UART IRQ  */
    NVIC_ClearPendingIRQ(UART_IRQ);
    NVIC_SetPriority(UART_IRQ, 0);
    NVIC_EnableIRQ(UART_IRQ);
    System_WakeUp_Pin_Enable(UART_RX_PIN, 0);
    return;
}
