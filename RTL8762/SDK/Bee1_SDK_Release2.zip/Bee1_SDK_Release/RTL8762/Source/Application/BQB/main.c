enum { __FILE_NUM__= 0 };

#include "section_config.h"
#include "flash_ota.h"
#include "trace.h"
#include "symboltable_uuid.h"
#include "bqb_demo.h"

int main(void) 
{   
    DBG_DIRECT("Bee stack BQB\n");
    
     BQB_Init();
     vTaskStartScheduler();
    
     return 0;
}

void io_assert_failed(uint8_t* file, uint32_t line)
{
    DBG_DIRECT("io driver parameters error! file_name: %s, line: %d", file, line);
    
    for(;;);
}
