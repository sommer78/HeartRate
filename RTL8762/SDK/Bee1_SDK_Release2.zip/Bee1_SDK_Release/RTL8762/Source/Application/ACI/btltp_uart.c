#include "board.h"
#include "rtl876x_rcc.h"
#include "rtl876x_uart.h"
#include "rtl876x_pinmux.h"
#include "rtl876x_gpio.h"
#include "btltp.h"
#include "aci_low_power.h"

BYTE RxTriggerLevel = 14;

/****************************************************************************/
/**
 * @brief send to ltp task to release tx buffer space.
 *
 * @param p_tx_buf, pointer to the tx bufer to be released.
 * @return void.
*/
portBASE_TYPE ltpSendTxBufReleaseMsg(TLTPData *p_tx_buf)
{
    portBASE_TYPE ReturnValue;

    ReturnValue = xQueueSend(P_BtLtp->p_aci_tcb->QueueHandleTxRel, p_tx_buf, 0);

    return (ReturnValue);
}

/**
 * @brief send event to ltp task in isr.
 *
 * @param pEvent, pointer to the event to b sent.
 * @return send result.
 * @retval pdPASS--send successfully.
 *         errQUEUE_FULL-- queue is full.
*/
portBASE_TYPE ltpSendEventFromISR(const unsigned char *pEvent)
{
    portBASE_TYPE ReturnValue;
    portBASE_TYPE TaskWoken = pdFALSE;

    ReturnValue = xQueueSendFromISR(P_BtLtp->p_aci_tcb->QueueHandleEvent, pEvent, &TaskWoken);
    portYIELD_FROM_ISR(TaskWoken);

    return (ReturnValue);
}

portBASE_TYPE ltpSendEventMsg(const unsigned char *pEvent)
{
    portBASE_TYPE ReturnValue;

    ReturnValue = xQueueSend(P_BtLtp->p_aci_tcb->QueueHandleEvent, pEvent, 0);
    return (ReturnValue);
}

/**
 * @brief tx task, tx bytes in polling mode.
 *
 * @param pParameters, not used.
 * @return void.
*/
void TxAssistTask(void *pParameters)
{
    DWORD i = 0;
    BYTE *pBuffer = NULL;
    BYTE event = 0;
    WORD blk_count = 0;
    TLTPData data = {NULL, 0};

    while (TRUE)
    {
        if (xQueueReceive(P_BtLtp->p_aci_tcb->QueueHandleTxData, &data, portMAX_DELAY) == pdPASS)
        {
            pBuffer = data.pBuffer;
            blk_count = data.Length / 16;

            for (i = 0; i < blk_count; i++)
            {
                while (UART_GetFlagState(UART, UART_FLAG_THR_EMPTY) != SET);
                UART_SendData(UART, pBuffer, 16);
                pBuffer += 16;
            }

            //the ramain data
            blk_count = data.Length % 16;

            if (blk_count)
            {
                while (UART_GetFlagState(UART, UART_FLAG_THR_EMPTY) != SET);
                UART_SendData(UART, pBuffer, blk_count);
            }

            if (pdFALSE == ltpSendTxBufReleaseMsg(&data))
            {
                if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
                {
                    DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "ltpSendTxBufReleaseMsg fail", 0);
                }
            }
            event = LTP_EVENT_UART_TX_COMPLETED;
            if (pdFALSE == ltpSendEventMsg(&event))
            {
                if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
                {
                    DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "ltpSendEvent fail", 0);
                }
            }

            /* reset moniter timer */
            if (MoniterTimer)
            {
                xTimerReset(MoniterTimer, 5);
                MonitorTimeout = 0;
            }
        }
        else
        {
            if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
            {
                DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "TxAssistTask: xQueueReceive fail", 0);
            }
        }
    }

}

/**
 * @brief update rx data length when received data from uart or spi.
 *
 * @param none.
 * @return none.
 * @retval void.
*/
void LtpRxDataLengthUpdate(void)
{
    WORD RxOffset;
    WORD Length;

    RxOffset = P_BtLtp->p_aci_tcb->P_RxBuffer - &P_BtLtp->p_aci_tcb->p_rx_buf[0]; /* tifnan: num of char received */

    /* will not occur in our uart framework!!! */
    if (P_BtLtp->p_aci_tcb->RxOffset == RxOffset)
    {
        if (P_BtLtp->p_aci_tcb->RxDataLength == RX_BUFFER_SIZE)  /* overrun */
        {
            if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
            {
                DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "!!!LtpRxDataLengthUpdate: Rx overrun", 0);
            }
            P_BtLtp->p_aci_tcb->RxDataLength = 0;
            Length = RX_BUFFER_SIZE;
        }
        else
        {
            return;       /* no data */
        }
    }
    else
    {
        /* [p_aci_tcb->RxOffset----RxBufferSize-1] + [P_BtLtp->p_aci_tcb->p_rx_buf[0]----RxOffset] */
        if (P_BtLtp->p_aci_tcb->RxOffset > RxOffset)
        {
            Length = RX_BUFFER_SIZE - P_BtLtp->p_aci_tcb->RxOffset + RxOffset;
        }
        /* [p_aci_tcb->RxOffset ---- RxOffset] */
        else
        {
            Length = RxOffset - P_BtLtp->p_aci_tcb->RxOffset;
        }

        /* update new P_BtLtp->p_aci_tcb->RxOffset */
        P_BtLtp->p_aci_tcb->RxOffset = RxOffset;
    }

    if ((Length + P_BtLtp->p_aci_tcb->RxDataLength) > RX_BUFFER_SIZE)   /* Rx overrun */
    {
        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
        {
            DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "!!!LtpRxDataLengthUpdate: Rx overrun (%d)", 1, \
                   Length + P_BtLtp->p_aci_tcb->RxDataLength);
        }

        P_BtLtp->p_aci_tcb->RxDataLength  = RX_BUFFER_SIZE;
        P_BtLtp->p_aci_tcb->RxWriteIndex += Length;
        P_BtLtp->p_aci_tcb->RxWriteIndex &= (RX_BUFFER_SIZE - 1);
        P_BtLtp->p_aci_tcb->RxReadIndex   = P_BtLtp->p_aci_tcb->RxWriteIndex;
    }
    else
    {
        P_BtLtp->p_aci_tcb->RxDataLength += Length;         /* update length */
        P_BtLtp->p_aci_tcb->RxWriteIndex += Length;
        P_BtLtp->p_aci_tcb->RxWriteIndex &= (RX_BUFFER_SIZE - 1);
    }
}

/**
 * @brief uart interrupt handle ISR.
 *
 * @param none.
 * @return none.
 * @retval void.
*/
void LtpDataUartIrqHandle(void)
{
    /* read interrupt status */
    UINT32 int_status;
    WORD len = 0;
    BYTE event = LTP_EVENT_UART_RX;
    /* read interrupt id */
    int_status = UART_GetIID(UART);
    /* disable interrupt */
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, DISABLE);

    switch (int_status)
    {
    /* tx fifo empty */
    case UART_INT_ID_TX_EMPTY:
        break;

    /* rx data valiable */
    case UART_INT_ID_RX_LEVEL_REACH:
        if ((P_BtLtp->p_aci_tcb->P_RxBuffer - &P_BtLtp->p_aci_tcb->p_rx_buf[0] + RxTriggerLevel)\
                <= RX_BUFFER_SIZE)
        {
            UART_ReceiveData(UART, P_BtLtp->p_aci_tcb->P_RxBuffer, RxTriggerLevel);
            P_BtLtp->p_aci_tcb->P_RxBuffer += RxTriggerLevel;
        }
        else
        {
            len = RX_BUFFER_SIZE - (P_BtLtp->p_aci_tcb->P_RxBuffer - &P_BtLtp->p_aci_tcb->p_rx_buf[0]);
            UART_ReceiveData(UART, P_BtLtp->p_aci_tcb->P_RxBuffer, len);
            P_BtLtp->p_aci_tcb->P_RxBuffer = &P_BtLtp->p_aci_tcb->p_rx_buf[0];
            UART_ReceiveData(UART, P_BtLtp->p_aci_tcb->P_RxBuffer, RxTriggerLevel - len);
            P_BtLtp->p_aci_tcb->P_RxBuffer += (RxTriggerLevel - len);
        }

        /* update rx data length */
        LtpRxDataLengthUpdate();
        /* notify ltp task */
        if (pdFALSE == ltpSendEventFromISR(&event))
        {
            if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
            {
                DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "ltpSendEventFromISR fail", 0);
            }
        }

        break;

    /* rx time out */
    case UART_INT_ID_RX_TMEOUT:
        /* read out all bytes in fifo */
        while (UART_GetFlagState(UART, UART_FLAG_RX_DATA_RDY) == SET)
        {
            if (P_BtLtp->p_aci_tcb->P_RxBuffer - &P_BtLtp->p_aci_tcb->p_rx_buf[0] == RX_BUFFER_SIZE)
            {
                P_BtLtp->p_aci_tcb->P_RxBuffer = &P_BtLtp->p_aci_tcb->p_rx_buf[0];
            }
            UART_ReceiveData(UART, P_BtLtp->p_aci_tcb->P_RxBuffer, 1);
            P_BtLtp->p_aci_tcb->P_RxBuffer++;
        }

        /* update rx data length */
        LtpRxDataLengthUpdate();
        /* notify ltp task */
        if (pdFALSE == ltpSendEventFromISR(&event))
        {
            if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
            {
                DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "ltpSendEventFromISR fail", 0);
            }
        }

        break;

    /* receive line status interrupt */
    case UART_INT_ID_LINE_STATUS:
        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
        {
            DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "Line status error!!!!\n", 0);
        }
        break;

    default:
        break;
    }

    /* enable interrupt again */
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, ENABLE);
}

void UARTChangeBaudrate(UART_InitTypeDef* UART_InitStruct)
{
    //uart init 
    switch (P_AciConfig->uart_baudrate)
    {
        case 38400:
            UART_InitStruct->div = 85;
            UART_InitStruct->ovsr = 7;
            UART_InitStruct->ovsr_adj = 0x222;
            break;
        case 115200:
            UART_InitStruct->div = 20;
            UART_InitStruct->ovsr = 12;
            UART_InitStruct->ovsr_adj = 0x252;
            break;
        case 230400:
            UART_InitStruct->div = 10;
            UART_InitStruct->ovsr = 12;
            UART_InitStruct->ovsr_adj = 0x252;
            break;
        default:
            UART_InitStruct->div = 20;
            UART_InitStruct->ovsr = 12;
            UART_InitStruct->ovsr_adj = 0x252;
            break;
    }
    return;
}

void ltpPeripheralInit(void)
{

    //pinmux and pad config
    Pinmux_Config(P_AciConfig->uart_tx_pin_index, DATA_UART_TX);
    Pinmux_Config(P_AciConfig->uart_rx_pin_index, DATA_UART_RX);

    Pad_Config(P_AciConfig->uart_tx_pin_index, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
    Pad_Config(P_AciConfig->uart_rx_pin_index, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
#if ACI_EN
    if(P_AciConfig->uart_flow_control_en)
    {
        Pinmux_Config(P_AciConfig->uart_cts_pin_index, DATA_UART_CTS);
        Pinmux_Config(P_AciConfig->uart_rts_pin_index, DATA_UART_RTS);

        Pad_Config(P_AciConfig->uart_cts_pin_index, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
        Pad_Config(P_AciConfig->uart_rts_pin_index, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);   
     }
#endif
    RCC_PeriphClockCmd(APBPeriph_UART, APBPeriph_UART_CLOCK, ENABLE);
    //uart init
    UART_InitTypeDef uartInitStruct;
    UART_StructInit(&uartInitStruct);

    uartInitStruct.rxTriggerLevel = UART_RX_FIFO_TRIGGER_LEVEL_14BYTE;
#if ACI_EN
    if(P_AciConfig->uart_flow_control_en)
    {
        uartInitStruct.autoFlowCtrl= UART_AUTO_FLOW_CTRL_EN;
    }
    if(P_AciConfig->uart_baudrate != 115200)
    {
        UARTChangeBaudrate(&uartInitStruct);
    }
    if(P_AciConfig->uart_parity == 1)
    {
       uartInitStruct.parity = UART_PARITY_ODD;
    }
    else if(P_AciConfig->uart_parity == 2)
    {
       uartInitStruct.parity = UART_PARITY_EVEN;
    }
    else
    {
        uartInitStruct.parity = UART_PARITY_NO_PARTY;
    }
    if(P_AciConfig->uart_word_len != 0)
    {
        uartInitStruct.wordLen = UART_WROD_LENGTH_7BIT;
    }
#endif
    UART_Init(UART, &uartInitStruct);
    //enable line status interrupt and rx data avaliable interrupt
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, ENABLE);

    /*  Enable UART IRQ  */
    NVIC_ClearPendingIRQ(UART_IRQ);
    NVIC_SetPriority(UART_IRQ, 0);
    NVIC_EnableIRQ(UART_IRQ);
}

