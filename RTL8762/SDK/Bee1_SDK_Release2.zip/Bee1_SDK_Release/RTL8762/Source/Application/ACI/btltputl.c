enum { __FILE_NUM__ = 0 };


#include <blueapi_types.h>
#include "btltp.h"
#include "trace.h"


PBTLtpMDLContext BTLTPAllocateMDLContext(PBTLtp pBTLtp, BYTE local_MDL_ID, BYTE local_MDEP_ID)
{
    WORD loop;
    PBTLtpMDLContext pUnusedContext = NULL;

    for (loop = 0; loop < BLUE_API_MDL_COUNT; loop++)
    {
        PBTLtpMDLContext pContext = &pBTLtp->MDLContextPool[loop];
        if (pContext->flags & LTP_MDL_ALLOCATED)
        {
            if ((pContext->flags & LTP_MDL_GATT) &&
                    (pContext->local_MDL_ID == 0x00) &&
                    (pContext->local_MDEP_ID == local_MDEP_ID)
               )
            {
                pContext->local_MDL_ID = local_MDL_ID;
                return pContext;
            }
            else if (pContext->local_MDL_ID == local_MDL_ID)
            {
                return pContext;
            }
        }
        else if (pUnusedContext == NULL)
        {
            pUnusedContext = pContext;
        }
    }

    if (pUnusedContext != NULL)
    {
        memset(pUnusedContext, 0, sizeof(TBTLtpMDLContext));
        pUnusedContext->flags           = LTP_MDL_ALLOCATED;
        pUnusedContext->local_MDL_ID    = local_MDL_ID;
        pUnusedContext->local_MDEP_ID   = local_MDEP_ID;

        pUnusedContext->flags        |= LTP_MDL_GATT;

        return pUnusedContext;
    }
    if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
    {
        DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "!!!LTP: out of MDL context elements", 0);
    }
    return NULL;
}


PBTLtpMDLContext BTLTPFindMDLContext(PBTLtp pBTLtp, BYTE local_MDL_ID)
{
    WORD loop;

    for (loop = 0; loop < BLUE_API_MDL_COUNT; loop++)
    {
        PBTLtpMDLContext pContext = &pBTLtp->MDLContextPool[loop];
        if ((pContext->flags & LTP_MDL_ALLOCATED) &&
                (pContext->local_MDL_ID == local_MDL_ID)
           )
        {
            return pContext;
        }
    }
    if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
    {
        DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "!!!LTP: no MDL context found for MDL %d", 1, local_MDL_ID);
    }
    return NULL;
}


BYTE BTLTPCountMDLConnected(PBTLtp pBTLtp)
{
    WORD loop;
    BYTE count = 0;

    for (loop = 0; loop < BLUE_API_MDL_COUNT; loop++)
    {
        PBTLtpMDLContext pContext = &pBTLtp->MDLContextPool[loop];

        if ((pContext->flags & (LTP_MDL_ALLOCATED | LTP_MDL_CONNECTED)) == (LTP_MDL_ALLOCATED | LTP_MDL_CONNECTED))
        {
            count++;
        }
    }

    return count;
}

PBTLtpMDLContext BTLTPFindAMDLConnected(PBTLtp pBTLtp)
{
    WORD loop;

    for (loop = 0; loop < BLUE_API_MDL_COUNT; loop++)
    {
        PBTLtpMDLContext pContext = &pBTLtp->MDLContextPool[loop];

        if ((pContext->flags & (LTP_MDL_ALLOCATED | LTP_MDL_CONNECTED)) == (LTP_MDL_ALLOCATED | LTP_MDL_CONNECTED))
        {
            return pContext;
        }
    }

    return NULL;
}

BOOL BTLTPCheckAMDLConnected(PBTLtp pBTLtp, BYTE* remote_BD, BYTE  remote_BD_type)
{
    WORD loop;

    for (loop = 0; loop < BLUE_API_MDL_COUNT; loop++)
    {
        PBTLtpMDLContext pContext = &pBTLtp->MDLContextPool[loop];
     
        if((memcmp(pContext->remote_BD, remote_BD, 6) == 0) &&
                (pContext->remote_BD_type == remote_BD_type))
        {
            if ((pContext->flags & (LTP_MDL_ALLOCATED | LTP_MDL_CONNECTED)) == (LTP_MDL_ALLOCATED | LTP_MDL_CONNECTED))
            {
                return true;
            }
        }
    }

    return false;
}

PBTLtpAction BTLTPAllocateAction(PBTLtp pBTLtp)
{
    WORD loop;

    for (loop = 0; loop < BTLTP_ACTION_POOL_SIZE; loop++)
    {
        if (pBTLtp->ActionPool[loop].Action == btltpActionNotUsed)
        {
            return &pBTLtp->ActionPool[loop];
        }
    }
    if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
    {
        DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "!!!LTP: out of action queue elements", 0);
    }
    return NULL;
}

BYTE BTLTPConvertCOMtoLTPcause(TBlueAPI_Cause cause)
{
    switch (cause)
    {
    case blueAPI_CauseUnspecified:
        return LTP_CAUSE_UNSPECIFIED;
    default:
        return (BYTE) cause;
    }
}

TBlueAPI_Cause BTLTPConvertLTPtoCOMcause(BYTE cause)
{
    switch (cause)
    {
    case LTP_CAUSE_NOT_SUPPORTED:
        return blueAPI_CauseNotSupported;
    default:
        return (TBlueAPI_Cause)cause;
    }
}

void BTLTPCheckForActInfo(PBTLtp pBTLtp)
{
    BYTE pOpt[4];
    WORD pos = 0;


    if (pBTLtp->ActInfoFlags == LTP_ACT_INFO_FLAG_ALL)
    {
        NETSHORT2CHAR(&pOpt[pos], pBTLtp->LTPLib.ReceiveMaxLength);
        pos += 2;
        NETSHORT2CHAR(&pOpt[pos], pBTLtp->LTPLib.ReceiveMaxLength);
        pos += 2;

        LTPLibSendActInfo(&pBTLtp->LTPLib,
                          BTLTP_DEFAULT_COPMSK | \
                          LTP_ACT_INFO_OPT_MASK_MAX_RX_MESSAGE_LENGTH | \
                          LTP_ACT_INFO_OPT_MASK_MAX_TX_MESSAGE_LENGTH,
                          pOpt,
                          pBTLtp->ActInfoCause,
                          LTP_VERSION,
                          pBTLtp->ownBDAddress,
                          pBTLtp->ActInfoVersionString
                         );
    }
}

