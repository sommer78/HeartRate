/**
*********************************************************************************************************
*               Copyright(c) 2014, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      aci_low_power.c
* @brief     low power handle when using ACI.
* @details   none.
* @author    Tifnan
* @date      2014-11-19
* @version   v0.1
* *********************************************************************************************************
*/

#include "aci_low_power.h"
#include "btltp.h"
#include "dlps_platform.h"
#include "blueapi.h"
#include "rtl876x_gpio.h"
#include "rtl876x_nvic.h"
#include "rtl876x_rcc.h"
#include "rtl876x_io_dlps.h"
#include "rtl876x.h"
#include "freeRTOS.h"
#include "timers.h"
#include "board.h"
#include "trace.h"
#include "aci_low_power_utils.h"

/* default input wakeup pin and output notify pin */
DWORD AciIn_WakeupPin;
DWORD AciOut_NotifyPin;

/** @brief the current power state of bee */
BYTE LtpPowerState = LTPLL_STATE_PRE_WAKE;
/** @brief Host power mode */
BYTE HostPwrMode = LTPLL_LPWR_OFF;
/** @brief Bee power mode */
BYTE BeePwrMode = LTPLL_LPWR_OFF;
/** @brief monitor timer flag */
BYTE MonitorTimeout  = 0;
/** @brief monitor timer*/
xTimerHandle MoniterTimer = NULL;

/* monitor timer timeout handler */
void MonitorTimerHandler(xTimerHandle handle)
{
    if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
    {
        DBG_BUFFER(MODULE_LTP, LEVEL_INFO, "<<<<<<<<<<<Moniter timer timeout", 0);
    }

    MonitorTimeout = 1;

    return;
}

BYTE LTPLL_GetPowerStatus(void)
{
    return LtpPowerState;
}
void LTPLL_SetPowerStatus(BYTE power_state)
{
    if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ALL)
    {
        DBG_BUFFER(MODULE_LTP, LEVEL_INFO,  "--->power status:0x%x-->0x%x", 2,LtpPowerState, power_state);
    }
    LtpPowerState = power_state;
}
/**
 * @brief send the data in queue save when bee is waiting for host ack.
 *
 * @param p_buf pointer to the buffer start address.
 * @param buf_len the length of the buffer.
 * @return none.
 * @retal   void.
*/
static void LtpLowPowerQueueSend(void)
{
    WORD i = 0;
    PLTPLL_BufMsg p_buf_msg = NULL;
    TLTPData tx_data = {NULL, 0};
    WORD queue_size = LTPLL_GetQueueSize();

    if(P_AciConfig->ltp_trace_level >= LTP_TRACE_INFO)
    {
        DBG_BUFFER(MODULE_LTP, LEVEL_INFO, "LtpLowPowerQueueSend--Queue size: %d", 1, queue_size);
    }

    /* send all message in tx buffer */
    for (i = 0; i < queue_size; i++)
    {
        p_buf_msg = LTPLL_QueueOut();
        tx_data.pBuffer = p_buf_msg->buf_addr;
        tx_data.Length = p_buf_msg->size;
        if (NULL != p_buf_msg)
        {
            /* take care that exceed the size of QueueHandleTxData!!! */
            if (pdFALSE == xQueueSend(P_BtLtp->p_aci_tcb->QueueHandleTxData, &tx_data, 0))
            {
                if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
                {
                    DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "LtpLowPowerQueueSend:xQueueSend fail", 0);
                }
            }

            /* free buffer */
            vPortFree(p_buf_msg, RAM_TYPE_DATA_ON);
        }
    }
}


/**
 * @brief goio interrupt handle ISR.
 * @param none.
 * @return none.
 * @retval void.
*/
void LTPLL_HostGpioIsr(void)
{
    portBASE_TYPE TaskWoken = pdFALSE;

    GPIO_MaskINTConfig(AciIn_WakeupPin, ENABLE);

    if(P_AciConfig->ltp_trace_level >= LTP_TRACE_INFO)
    {
        DBG_BUFFER(MODULE_LTP, LEVEL_INFO, "<<<<<<<<<<<ACI GPIO ISR", 0);
    }

    /* host wake up bee */
    if (LTPLL_STATE_PRE_WAKE == LTPLL_GetPowerStatus())
    {
        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_INFO)
        {
            DBG_BUFFER(MODULE_LTP, LEVEL_INFO, "--->GPIO ISR:host wakeup bee", 0);
        }

        /* sene ack to host */
        GPIO_SetBits(AciOut_NotifyPin);
        LTPLL_SetPowerStatus(LTPLL_STATE_BE_WAKED);

    }
    /* host ack */
    else if (LTPLL_STATE_W4ACK == LTPLL_GetPowerStatus())
    {
        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_INFO)
        {
            DBG_BUFFER(MODULE_LTP, LEVEL_INFO, "--->GPIO ISR:host ack bee", 0);
        }

        LTPLL_SetPowerStatus(LTPLL_STATE_OWN_WAKE);

        /* if have stack message in queue, handle it */
        LtpLowPowerQueueSend();
    }
    /* wrong interrupt sig */
    else
    {
        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
        {
            DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "LTPLL_HostGpioIsr:wrong interrupt:0x%x", 1, LTPLL_GetPowerStatus());
        }
    }

    GPIO_ClearINTPendingBit(AciIn_WakeupPin);

    /* if do not use low power mode, do not unmask interrupt */
    if (BeePwrMode == LTPLL_LPWR_OFF)
    {
        GPIO_MaskINTConfig(AciIn_WakeupPin, DISABLE);
    }

    /* reset timer */
    if (MoniterTimer)
    {
        xTimerResetFromISR(MoniterTimer, &TaskWoken);
        MonitorTimeout = 0;
    }

    portYIELD_FROM_ISR(TaskWoken);

    return;
}

void Gpio16IntrHandler(void)
{
    LTPLL_HostGpioIsr();
}

void Gpio17IntrHandler(void)
{
    LTPLL_HostGpioIsr();
}

void Gpio20IntrHandler(void)
{
    LTPLL_HostGpioIsr();
}

void Gpio21IntrHandler(void)
{
    LTPLL_HostGpioIsr();
}

void Gpio24IntrHandler(void)
{
    LTPLL_HostGpioIsr();
}

void Gpio25IntrHandler(void)
{
    LTPLL_HostGpioIsr();
}

void Gpio26IntrHandler(void)
{
    LTPLL_HostGpioIsr();
}

void Gpio28IntrHandler(void)
{
    LTPLL_HostGpioIsr();
}

void Gpio29IntrHandler(void)
{
    LTPLL_HostGpioIsr();
}

void Gpio30IntrHandler(void)
{
    LTPLL_HostGpioIsr();
}

void Gpio31IntrHandler(void)
{
    LTPLL_HostGpioIsr();
}
BOOL LTPLL_IsHostSleep(void)
{
    return !GPIO_ReadInputDataBit(AciIn_WakeupPin);
}

void LTPLL_WakeUpHost(void)
{
    uint32_t i = 0;
    
    //host LPS on, bee LPS off
    if(BeePwrMode == LTPLL_LPWR_OFF
         && HostPwrMode == LTPLL_LPWR_ON)
    {
        GPIO_ResetBits(AciOut_NotifyPin);
        //delay some time, about 25us@40M
        for(i = 1000; i > 0; i--);
        GPIO_SetBits(AciOut_NotifyPin);
    }
    else
    {
        GPIO_SetBits(AciOut_NotifyPin);
    }
}

/**
 * @brief when bee exit dlps, this function will be called.
 * @param none.
 * @return none.
 * @retval void.
*/
void LTPLL_ExitDlpsRoutin(void)
{
    unsigned long io_level = 0;

    Pad_Config(P_AciConfig->uart_tx_pin_index, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
    Pad_Config(P_AciConfig->uart_rx_pin_index, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);
    Pad_Config(P_AciConfig->gpio_h_pin_index, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_DOWN, PAD_OUT_DISABLE, PAD_OUT_LOW);
    Pad_Config(P_AciConfig->gpio_b_pin_index, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_DOWN, PAD_OUT_ENABLE, PAD_OUT_LOW);

#if ACI_EN
    if(P_AciConfig->uart_flow_control_en)
    {
        Pad_Config(P_AciConfig->uart_cts_pin_index, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
        Pad_Config(P_AciConfig->uart_rts_pin_index, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);   
     }
#endif
    io_level = GPIO_ReadInputDataBit(AciIn_WakeupPin);

    /* host wakeup Bee */
    if (1 == io_level)
    {
        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_INFO)
        {
            DBG_BUFFER(MODULE_LTP, LEVEL_INFO, "--->host wakeup bee", 0);
        }
    }
    else /* Bee wake up itself */
    {
        //DBG_BUFFER(MODULE_LTP, LEVEL_INFO, "<---bee wakeup itself", 0);
    }

    LTPLL_SetPowerStatus(LTPLL_STATE_PRE_WAKE);

    return;
}

void LTPLL_EnterDlpsRoutin(void)
{
    //DBG_BUFFER(MODULE_LTP, LEVEL_INFO,  "-->Bee send sleep indication to host\n", 0);
    /* pad settings */
    Pad_Config(P_AciConfig->uart_tx_pin_index, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_HIGH);
    Pad_Config(P_AciConfig->uart_rx_pin_index, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);
    Pad_Config(P_AciConfig->gpio_h_pin_index, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_DOWN, PAD_OUT_DISABLE, PAD_OUT_LOW);
    Pad_Config(P_AciConfig->gpio_b_pin_index, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_DOWN, PAD_OUT_ENABLE, PAD_OUT_LOW);
#if ACI_EN
    if(P_AciConfig->uart_flow_control_en)
    {
        Pad_Config(P_AciConfig->uart_cts_pin_index, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
        Pad_Config(P_AciConfig->uart_rts_pin_index, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);   
     }
#endif
    /* unmask gpio interrupt again */
    GPIO_MaskINTConfig(AciIn_WakeupPin, DISABLE);
    LTPLL_SetPowerStatus(LTPLL_STATE_DLPS);

    return;
}

BOOL LTPLL_EnterDlpsCheck(void)
{
    if (LtpDlpsEnterCheck() == FALSE)
    {
        return FALSE;
    }
    /* timeout */
    if (MonitorTimeout)
    {
        if( LTPLL_GetPowerStatus() == LTPLL_STATE_OWN_WAKE
            || LTPLL_GetPowerStatus() == LTPLL_STATE_BE_WAKED)
        {
            /* pull gpio low */
            GPIO_ResetBits(AciOut_NotifyPin);
            LTPLL_SetPowerStatus(LTPLL_STATE_PRE_SLEEP);
        }

        /* wait host gpio low */
        if (!GPIO_ReadInputDataBit(AciIn_WakeupPin))
        {
            //there is data in queue
            if(LTPLL_GetQueueSize())
            {
                /* unmask gpio interrupt again */
                GPIO_MaskINTConfig(AciIn_WakeupPin, DISABLE);
                GPIO_SetBits(AciOut_NotifyPin);
                LTPLL_SetPowerStatus(LTPLL_STATE_W4ACK);
                xTimerReset(MoniterTimer, 5);
                MonitorTimeout = 0;
                return FALSE;
            }
            else
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    else
    {
        return FALSE;
    }
}

/******************************************  aci export function ************************************/

void LTPLL_HandleHwInitReq(BYTE hostPwrMode, BYTE beePwrMode)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    /* if host and Bee both do not use low power mode, no need to init GPIO */
    if (hostPwrMode == LTPLL_LPWR_OFF
            && beePwrMode == LTPLL_LPWR_OFF)
    {
        return;
    }

    /* turn on gpio clock */
    RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);

    /* pad config */
    Pad_Config(P_AciConfig->gpio_h_pin_index, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_DOWN, PAD_OUT_DISABLE, PAD_OUT_LOW);
    Pad_Config(P_AciConfig->gpio_b_pin_index, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_DOWN, PAD_OUT_ENABLE, PAD_OUT_LOW);

    /* pinmux confguration */
    Pinmux_Config(P_AciConfig->gpio_h_pin_index, GPIO_FUN);
    Pinmux_Config(P_AciConfig->gpio_b_pin_index, GPIO_FUN);

    AciOut_NotifyPin = GPIO_GetPin(P_AciConfig->gpio_b_pin_index);
    AciIn_WakeupPin  = GPIO_GetPin(P_AciConfig->gpio_h_pin_index);

    /* struct init */
    GPIO_StructInit(&GPIO_InitStruct);

    /* output pin init */
    GPIO_InitStruct.GPIO_Pin    = AciOut_NotifyPin;
    GPIO_InitStruct.GPIO_Mode   = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_ITCmd  = DISABLE;
    GPIO_Init(&GPIO_InitStruct);
    GPIO_SetBits(AciOut_NotifyPin);     //pull high

    /* input pin init */
    GPIO_InitStruct.GPIO_Pin          = AciIn_WakeupPin;
    GPIO_InitStruct.GPIO_Mode         = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_ITCmd        = ENABLE;
    GPIO_InitStruct.GPIO_ITTrigger    = GPIO_INT_Trigger_LEVEL;
    GPIO_InitStruct.GPIO_ITPolarity   = GPIO_INT_POLARITY_ACTIVE_HIGH;
    GPIO_InitStruct.GPIO_ITDebounce   = GPIO_INT_DEBOUNCE_DISABLE;

    GPIO_Init(&GPIO_InitStruct);

    /* if not enable bee low power mode, no need to enable wakeu pin and gpio interrupt */
    if (beePwrMode == LTPLL_LPWR_ON)
    {
        /* enable input pin wakeup function, default p3_2 */
        System_WakeUp_Pin_Enable(P_AciConfig->gpio_h_pin_index, 1);

        /* GPIO NVIC */
        NVIC_InitTypeDef NVIC_InitStruct;

        NVIC_InitStruct.NVIC_IRQChannel = GPIO6To31_IRQ;
        NVIC_InitStruct.NVIC_IRQChannelPriority = 1;
        NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;

        NVIC_Init(&NVIC_InitStruct);
    }

    return;
}

void LTPLL_HandleDlpsConfig(void)
{
    if(P_AciConfig->ltp_trace_level >= LTP_TRACE_INFO)
    {
        DBG_BUFFER(MODULE_LTP, LEVEL_INFO,  "------LTPLL_DlpsEnable------", 0);
    }

    /* if Bee does not use low power mode, do nothing */
    if (BeePwrMode == LTPLL_LPWR_OFF)
    {
        return;
    }

    DLPS_INTERRUPT_CONTROL_CB_REG(LTPLL_EnterDlpsRoutin, DLPS_ENTER);
    DLPS_IO_Register();

    DLPS_ENTER_CHECK_CB_REG(LTPLL_EnterDlpsCheck);
    DLPS_IO_RegUserDlpsExitCb(LTPLL_ExitDlpsRoutin);

    return;
}
#if 0
void LTPLL_HandleDlpsCtrlReq(void* param)
{
    if(P_AciConfig->ltp_trace_level >= LTP_TRACE_INFO)
    {
        DBG_BUFFER(MODULE_LTP, LEVEL_INFO,  "------LTPLL_PwrCtrl: 0x%x------", 1, *(BYTE*)param);
    }

    BYTE* p = NULL;

    /* dlps on */
    if (0x01 == *(BYTE*)param)
    {
        LPS_MODE_Set(LPM_DLPS_MODE);
    }

    /* dlps off */
    if (0x02 == *(BYTE*)param)
    {
        LPS_MODE_Set(LPM_ACTIVE_MODE);
    }

    /* power mode pause */
    if (0x03 == *(BYTE*)param)
    {
        LPS_MODE_Pause();
    }

    /* power mode resume */
    if (0x04 == *(BYTE*)param)
    {
        LPS_MODE_Resume();
    }

    /* sned dlps_ctrl_rsp */
    p = BTLTPTgtSendBufferAlloc(P_BtLtp, 6);
    *p = 0xFC;
    *(p + 1) = 0x01;
    *(p + 2) = 0x00;
    *(p + 3) = 0x06;
    *(p + 4) = 0x04;
    *(p + 5) = *(BYTE*)param;
    BTLTPTgtSendLTPMessage(P_BtLtp, p, 0, 6);

    return;
}
#endif
/* host power mode config */
void LTPLL_HandlePwrCfgReq(PBTLtp pBTLtp, void* param)
{
    BYTE* p = (BYTE*)param;
    BYTE cause = LTP_CAUSE_SUCCESS;
    WORD moniter_time = 0;
    if(P_AciConfig->ltp_wake_up_pin_en)
    {
        p++;
        /* host support low power mode */
        if (0x01 == *p++)
        {
            HostPwrMode = LTPLL_LPWR_ON;
        }

        /* Bee support low power mode */
        if (0x01 == *p++)
        {
            BeePwrMode = LTPLL_LPWR_ON;
        }
        moniter_time = NETCHAR2SHORT(p);
        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
        {
            DBG_BUFFER(MODULE_LTP, LEVEL_ERROR,  "PwrCfgReq:host_power_mode:0x%x, bee_power_mode:0x%x time %d", 3, \
                   HostPwrMode, BeePwrMode, moniter_time);
        }

        /* hardware init */
        LTPLL_HandleHwInitReq(HostPwrMode, BeePwrMode);

        /* if not enable low power mode, no need to register dlps callback and moniter timer */
        if (BeePwrMode == LTPLL_LPWR_ON)
        {
            /* create monitor timer, (200 * x) ms */
            MoniterTimer = xTimerCreate((const char*)"Moniter_Timer", \
                                        (moniter_time * 10) / portTICK_RATE_MS, pdFALSE, NULL, MonitorTimerHandler);

            /* dlps config */
            LTPLL_HandleDlpsConfig();

            xTimerStart(MoniterTimer, 10);

            LPS_MODE_Set(LPM_DLPS_MODE);
        }
    }
    else
    {
        cause = LTP_CAUSE_REJECT;
    }

    LTPLibSendLowPowerConfigRsp(&pBTLtp->LTPLib, cause, HostPwrMode, BeePwrMode);

    return;
}

