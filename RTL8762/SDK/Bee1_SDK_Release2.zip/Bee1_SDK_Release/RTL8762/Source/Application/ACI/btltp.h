#ifndef  _BTLTP_H_
#define  _BTLTP_H_

#include <string.h>
#include <blueapi_types.h>
#include <ltplib.h>
#include "aci_if.h"
#include "gatt.h"

#define LTP_VERSION                           0x10          /* LTP V1.0 */
#define ACI_EN                                1
#define ACI_CONFIG_EN                         0

/* buffer size */
#define RX_BUFFER_SIZE                        0x400
#define TX_BUFFER_SIZE                        0x200
#define RX_HANDLE_BUFFER_SIZE                 0x400

#define BTLTP_DEFAULT_COPMSK                  0x80          /* enable CRC  */

#define BTLTP_ACTION_POOL_SIZE                (2)  /* enough */
#define BT_GATT_SERVER_MAX_SERVICES_COUNT     8
#define BLUE_API_MDL_COUNT 4

#define LTP_ACT_INFO_FLAG_ACT_INFO            0x01
#define LTP_ACT_INFO_FLAG_ALL                 (LTP_ACT_INFO_FLAG_ACT_INFO)


#define BT_MAX_MTU_SIZE                       244
#define BTLTP_US_BUFFER_SIZE                  (BT_MAX_MTU_SIZE + 32)
#define BTLTP_MAX_MSG_SIZE                    270

#define BTLTP_QUEUE_ELEMENT_COUNT             10

#define LTP_TRACE_NONE                        0
#define LTP_TRACE_ERROR                       1
#define LTP_TRACE_INFO                        2
#define LTP_TRACE_DEBUG                       3
#define LTP_TRACE_ALL                         4


/******************************** the define of events ltp used **********************************/

#define LTP_EVENT_UART_RX               0x01      /* data available */
#define LTP_EVENT_UART_TX               0x02      /* transmit request */
#define LTP_EVENT_UART_TX_COMPLETED     0x03      /* transmit completed */
#define LTP_EVENT_BLUEAPI_MESSAGE       0x04      /* BlueAPI message */

/****************************************************************************/
/* state                                                                    */
/****************************************************************************/
typedef enum _TBTLtpState
{
    btltpStateInit,
    btltpStateRegistering,
    btltpStateIdle,
    btltpStateReleasing,
    btltpStateCount
} TBTLtpState;

/****************************************************************************/
/* Tx Buffer callback handling                                              */
/****************************************************************************/

typedef enum
{
    btltpActionNotUsed,
    btltpActionExit,
    btltpActionReset,
    btltpActionSendDataConf,
    btltpActionReleaseBuffer
} TBTLtpActionCommand;

typedef struct
{
    LPVOID pBuffer;
    DWORD  serviceHandle;
} TBTLtpServiceAction;

typedef union
{
    LPBYTE              pReleaseBuffer;
    WORD                MDL_ID;
    TBTLtpServiceAction serviceAction;
} TBTLtpActionData;

typedef struct
{
    TBTLtpActionCommand Action;
    TBTLtpActionData    p;
} TBTLtpAction;
typedef TBTLtpAction FAR* PBTLtpAction;

#define LTP_MDL_UNUSED           0x00
#define LTP_MDL_ALLOCATED        0x01  /* MDL and MDEP valid/set */
#define LTP_MDL_CONNECTED        0x02  /* ConnectMDLInfo .. DisconnectMDLInd */
#define LTP_MDL_DATARSP_ERROR    0x04  /* got DataRsp with cause != success */
#define LTP_MDL_GATT             0x08  /* GATT context, reply with ConnectGATTMDLRsp */

typedef struct
{
    WORD             dsDataOffset;
    WORD             dsPoolID;
    BYTE             flags;                  /* LTP_MDL_* */
    BYTE             local_MDL_ID;           /* local MDL ID */
    BYTE             local_MDEP_ID;          /* local MDEP ID */
    BYTE             maxUsCredits;           /* max us credits (from ConnectMDLInfo) */
    BYTE             collectedUsCredits;     /* credits need to be sent US */
    BYTE             pendingDataConfs;       /* DataConf need to be sent DS */
    BYTE             remote_BD[BLUE_API_BD_SIZE];  /**<  @brief Bluetooth device address of remote device. */
    BYTE             remote_BD_type;  
} TBTLtpMDLContext;
typedef TBTLtpMDLContext FAR* PBTLtpMDLContext;

/****************************************************************************/
/* Instance data                                                            */
/****************************************************************************/

typedef struct
{
    void *  serviceHandle;
    void * pService;
    BOOL isUsed;
    BYTE self_idx;
    WORD nbrOfAttrib;
    WORD database_length;
    WORD receive_length;
    DWORD   host_service;
} TGattServiceTable;
typedef TGattServiceTable FAR* PGattServiceTable;

typedef struct _TBTLtp
{
    LPBYTE              p_send_buffer;    /* for saving the address of tx buffer */
    LTP_QUEUE_T         FreeElementQueue;

    TBTLtpState         State;

    TBTLtpMDLContext    MDLContextPool[BLUE_API_MDL_COUNT];

    /* Buffer callback Action Handling                                       */
    TBTLtpAction        ActionPool[BTLTP_ACTION_POOL_SIZE];
    PBTLtpAction        pBufferAction;
    /* LTP re-assemble                                                       */
    WORD                LTP_US_OfflinePoolID;
    LPBYTE              pMsgBuffer;
    TLTPLib             LTPLib;
    TLTPElement         ElementPool[BTLTP_QUEUE_ELEMENT_COUNT];
    /* COM interface                                                         */
    BYTE                ActInfoFlags;
    BYTE                ownBDAddress[6];
    BYTE                ActInfoCause;
    BYTE                ActInfoVersionString[BLUE_API_VERSION_LENGTH];

    BOOL                ltp_key_store_en;

    BYTE                service_register_idx;
    TGattServiceTable   gattServiceTable[BT_GATT_SERVER_MAX_SERVICES_COUNT]; //use for ACI
    void *              gattServiceHandle[BT_GATT_SERVER_MAX_SERVICES_COUNT];//use for LTP

    P_ACI_TCB           p_aci_tcb;
} TBTLtp;
typedef TBTLtp FAR* PBTLtp;

typedef struct _TAciConfig
{
    UINT8 ltp_interface :2;
    UINT8 ltp_wake_up_pin_en :1; 
    UINT8 ltp_trace_level:3;
    UINT8 reserved:2;
    
    UINT8 uart_flow_control_en:1;
    UINT8 uart_word_len:1;
    UINT8 uart_parity:2;
    UINT8 reserved2:4;

	/* ltp uart pin configuration */
    UINT8 uart_tx_pin_index;
    UINT8 uart_rx_pin_index;
    UINT8 uart_cts_pin_index;
    UINT8 uart_rts_pin_index;
    UINT8 gpio_h_pin_index;
    UINT8 gpio_b_pin_index;

    UINT32 uart_baudrate;

    /* ltp spi pin configuration */
	UINT8 spi_mosi_pin_index;
	UINT8 spi_miso_pin_index;
	UINT8 spi_cs_pin_index;
	UINT8 spi_clk_pin_index;
	UINT8 spi_int_pin_index; /* used to notify master to read data drom bee */

    UINT8 reserved3[7];

}TAciConfig;
typedef TAciConfig FAR* PAciConfig;
/* for ltp, will change later */

extern const TAttribAppl GattdFindMeProfile[];
extern const int GattdFindMeProfileSize;
extern PBTLtp  P_BtLtp;
extern PAciConfig P_AciConfig;

/****************************************************************************/
/* Prototypes                                                               */
/****************************************************************************/

/* btltpcom.c */
void BTLTPHandleBLUE_API_MSG(PBTLtp pBTLtp, LPBYTE pBuffer, WORD offset);

/* btltpltp.c */
void BTLTPHandleResetReq                    (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleDisconnectMDLReq            (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleDisconnectMDLConf           (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleCreateMDLConf               (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleExitReq                     (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, LPBYTE pPara);
void BTLTPHandlePasskeyRequestCnf           (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleOOBRequestCnf               (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleAuthResultExtCnf            (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleAuthResultRequestExtCnf     (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandlePairableModeSetReq          (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandlePasskeyReqReplyReq          (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleGATTServiceRegisterReq      (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleGATTAttributeUpdateReq      (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleGATTAttributeUpdateStatusCnf(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleGATTAttributeReadCnf        (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleGATTAttributeWriteCnf       (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleGATTServerStoreCnf          (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleConnectGATTMDLReq           (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleGATTDiscoveryReq            (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleGATTDiscoveryCnf            (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleGATTAttributeReadReq        (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleGATTAttributeWriteReq       (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleGATTAttributeCnf            (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleGATTSecurityReq             (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleLEAdvertiseReq              (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleLEAdvertiseParameterSetReq  (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleLEAdvertiseDataSetReq       (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleLEScanReq                   (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleLEModifyWhitelistReq        (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleLEConnectionUpdateReq       (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleLEConnectionUpdateCnf       (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);

void BTLTPHandleSetRandomAddressReq         (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleDeviceNameReq               (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleDeviceConfigSecuritySetReq  (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleDeviceConfigAppearanceSetReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleDeviceConfigStoreSetReq     (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleDeviceConfigPerPrefConnParamSetReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleSetLETxPowerReq             (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleSetDataLengthReq            (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleDownloadServiceDatabaseReq  (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleClearServiceDatabaseReq     (PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleGATTAttributePrepareWriteReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleGATTAttributeExecuteWriteReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleGATTAttributePrepareWriteCnf(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleGATTAttributeExecuteWriteCnf(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);
void BTLTPHandleAuthDeleteReq               (PBTLtp pBTLtp,BYTE copmsk, LPBYTE pOpt,WORD lenPara,LPBYTE pPara);
void BTLTPHandleAuthListReq                 (PBTLtp pBTLtp,BYTE copmsk, LPBYTE pOpt,WORD lenPara,LPBYTE pPara);
/* btltputil.c */
PBTLtpMDLContext     BTLTPAllocateMDLContext(PBTLtp pBTLtp, BYTE local_MDL_ID, BYTE local_MDEP_ID);
PBTLtpMDLContext     BTLTPFindMDLContext        (PBTLtp pBTLtp, BYTE local_MDL_ID);
PBTLtpMDLContext     BTLTPFindAMDLConnected(PBTLtp pBTLtp);
BYTE                 BTLTPCountMDLConnected     (PBTLtp pBTLtp);
BOOL                 BTLTPCheckAMDLConnected(PBTLtp pBTLtp, BYTE* remote_BD, BYTE  remote_BD_type);
BYTE                 BTLTPConvertCOMtoLTPcause  (TBlueAPI_Cause cause);
TBlueAPI_Cause       BTLTPConvertLTPtoCOMcause  (BYTE cause);
PBTLtpAction         BTLTPAllocateAction        (PBTLtp pBTLtp);
void                 BTLTPCheckForActInfo       (PBTLtp pBTLtp);

/* btltp_FreeRTOS.c  */
extern void LtpBufferRelease(void *pBuffer);
extern void LtpWrite(BYTE *p_buf, DWORD buf_len);
extern void ltpBlueAPICallback(PBlueAPI_UsMessage pMsg);
extern BOOL LtpDlpsEnterCheck(void);

#endif
