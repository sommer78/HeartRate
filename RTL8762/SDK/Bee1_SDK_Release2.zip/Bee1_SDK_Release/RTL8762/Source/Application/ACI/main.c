enum { __FILE_NUM__ = 0 };

#include "symboltable_uuid.h"
#include "freeRTOS.h"
#include "aci_if.h"
#include "board.h"
#include "rtl876x_pinmux.h"

extern void  stSetTraceLevel(uint32_t traceLevel);

int main(void)
{
    All_Pad_Config_Default();
    ltpInit();
    ltpTaskInit();
    vTaskStartScheduler();

    return 0;
}
