enum { __FILE_NUM__ = 0 };
/**
*********************************************************************************************************
*               Copyright(c) 2014, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      btltp_FreeRTOS.c
* @brief     aci iterface implementation.
* @details   none.
* @author    Tifnan
* @date      2014-10-17
* @version   v0.1
* *********************************************************************************************************
*/

#include <blueapi_types.h>
#include <blueapi.h>
#include "aci_if.h"
#include "btltp.h"
#include "dlps_platform.h"
#include "aci_low_power.h"
#include "aci_low_power_utils.h"
#include "rtl876x_pinmux.h"
#include "aci_service_handle.h"
#include "aci_key_storage.h"
#include "btltp_uart.h"
#include "board.h"
#if ACI_CONFIG_EN
#include "otp.h"
#endif
/* task  */
#define LTP_PRIORITY                    (tskIDLE_PRIORITY + 2)   /* Task priorities. */
#define LTP_TASK_STACK_SIZE             0x600
#define TX_TASK_STACK_SIZE              0x200

#define MAX_NUMBER_OF_RX_EVENT          0x20
#define MAX_NUMBER_OF_MESSAGE           0x20
#define MAX_NUMBER_OF_TX_DATA           12
#define MAX_NUMBER_OF_TX_REL            MAX_NUMBER_OF_TX_DATA
#define MAX_NUMBER_OF_RX_DATA           12

ACI_TCB AciTcb;
TBTLtp  BtLtp;
PBTLtp  P_BtLtp = NULL;
TAciConfig AciConfig;
PAciConfig P_AciConfig = &AciConfig;

SRAM_OFF_BD_DATA_SECTION
BYTE RxBuffer[RX_BUFFER_SIZE];
SRAM_OFF_BD_DATA_SECTION
BYTE TXBuffer[TX_BUFFER_SIZE];
SRAM_OFF_BD_DATA_SECTION
BYTE RXHandleBuffer[RX_HANDLE_BUFFER_SIZE];

xTaskHandle LTPTaskHandle = NULL;
xTaskHandle LTPTxAssistHandle = NULL;
extern uint32_t g_eflash_dbg;
void ltpTask(void *pParameters);
#if ACI_CONFIG_EN
extern OTP_STRUCT otp_str_data;
#endif

/**
 * @brief send event to ltp task.
 *
 * @param pEvent, pointer to the event to be sent.
 * @return send result.
 * @retval pdPASS--send successfully.
 *         errQUEUE_FULL-- queue is full.
*/
portBASE_TYPE ltpSendEvent(const unsigned char *pEvent)
{
    portBASE_TYPE ReturnValue;

    ReturnValue = xQueueSend(P_BtLtp->p_aci_tcb->QueueHandleEvent, pEvent, 0);
    return (ReturnValue);
}

/**
 * @brief handle message from upper stack.
 *
 * @param pMsg --message pointer from upper stack.
 * @return none.
 * @retal void
*/
void ltpHandleBlueAPIMessage(PBlueAPI_UsMessage pMsg)
{
    switch (pMsg->Command)
    {
    case blueAPI_EventActInfo: /*-------------------------------------------*/
        P_BtLtp->LTP_US_OfflinePoolID = pMsg->p.ActInfo.systemPoolID;
        break;

    default: /*-------------------------------------------------------------*/
        break;
    }

    BTLTPHandleBLUE_API_MSG(P_BtLtp, (LPBYTE)pMsg, 0);

    blueAPI_BufferRelease(pMsg);

}


/**
 * @brief callback function, upper stack will call it to send message to ltp.
 *
 * @param pMsg --message pointer from upper stack.
 * @return none.
 * @retal void
*/
void ltpBlueAPICallback(PBlueAPI_UsMessage pMsg)
{
    unsigned char Event = LTP_EVENT_BLUEAPI_MESSAGE;

    if (xQueueSend(P_BtLtp->p_aci_tcb->QueueHandleMessage, &pMsg, 0) == errQUEUE_FULL)
    {
        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
        {
            DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "!!!ltpBlueAPICallback: MessageQueue full", 0);
        }

        blueAPI_BufferRelease(pMsg);
    }
    else
    {
        if (ltpSendEvent(&Event) == errQUEUE_FULL)     /* signal event to GATTDEMO task */
        {
            if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
            {
                DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "!!!ltpBlueAPICallback: EventQueue full", 0);
            }
        }
    }
}


/**
 * @brief time out routine, not used now .
 *
 * @param xTimer --time handle.
 * @return none.
 * @retal void
*/
#if F_LTPLIB_ASYNC_ASSEMBLY_SUPPORT
void ltpTimeoutRoutine(xTimerHandle xTimer)
{
    P_BtLtp->p_aci_tcb->ltpTimerMS = 0;
    LTPLibHandleTimeout(&P_BtLtp->LTPLib, (TLTPTimerID)P_BtLtp->p_aci_tcb->ltpTimerID);
}

/**
 * @brief start lp timer, not used in ltp now.
 *
 * @param TimerID time id.
 * @param TimerMS the time setting of this timer.
 * @return none.
 * @retal   void.
*/
void ltpTimerStart(TLTPTimerID TimerID, int TimerMS)        /* tifnan:not used now */
{
    if (P_BtLtp->p_aci_tcb->ltpTimerMS != 0)     /* timer started */
    {
        xTimerStop(P_BtLtp->p_aci_tcb->ltpTimerHandle, 0);
    }
    P_BtLtp->p_aci_tcb->ltpTimerID = TimerID;
    P_BtLtp->p_aci_tcb->ltpTimerMS = TimerMS;
    xTimerChangePeriod(P_BtLtp->p_aci_tcb->ltpTimerHandle, (TimerMS / portTICK_RATE_MS), 0);
    xTimerStart(P_BtLtp->p_aci_tcb->ltpTimerHandle, 0);

    return;
}
#endif

/**
 * @brief dlps callback function, used when bee is to enter dlps .
 *
 * @param none.
 * @return the check result.
 * @retal  TRUE -- can enter dlps.
            FALSE --can not enter dlps.
*/

BOOL LtpDlpsEnterCheck(void)
{
    /* check all queues are all empty */
    if (MAX_NUMBER_OF_RX_EVENT != uxQueueSpacesAvailable(P_BtLtp->p_aci_tcb->QueueHandleEvent)
            && MAX_NUMBER_OF_TX_DATA != uxQueueSpacesAvailable(P_BtLtp->p_aci_tcb->QueueHandleTxData)
            && MAX_NUMBER_OF_RX_DATA != uxQueueSpacesAvailable(P_BtLtp->p_aci_tcb->QueueHandleRxData)
            && MAX_NUMBER_OF_TX_REL != uxQueueSpacesAvailable(P_BtLtp->p_aci_tcb->QueueHandleTxRel)
            && MAX_NUMBER_OF_MESSAGE != uxQueueSpacesAvailable(P_BtLtp->p_aci_tcb->QueueHandleMessage))
    {
        //DBG_BUFFER(MODULE_LTP, LEVEL_INFO, "Ltp queue is not empty!", 0);
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

/**
 * @brief call this fucntion will start to send data through ltp.
 * @param p_buf pointer to the buffer start address.
 * @param buf_len the length of the buffer.
 * @return none.
 * @retal   void.
*/
void LtpWrite(BYTE *p_buf, DWORD buf_len)
{
    TLTPData tx_data;
    tx_data.pBuffer       = p_buf;
    tx_data.Length        = buf_len;

    /* host support low power mode & host in low power mode */
    if (HostPwrMode == LTPLL_LPWR_ON)
    {
        if(LTPLL_IsHostSleep())
        {
            if(P_AciConfig->ltp_trace_level >= LTP_TRACE_INFO)
            {
                DBG_BUFFER(MODULE_LTP, LEVEL_INFO, "LtpWrite: host in lps, store buffer: 0x%x, length: %d", \
                       2, p_buf, buf_len);
            }
            /* save data */
            LTPLL_QueueSave(p_buf, buf_len);
            /* wake up host firstly */
            LTPLL_WakeUpHost();
            /* stop moniter timer, can not enter dlps when wait for ack from host */
            if (MoniterTimer)
            {
                xTimerStop(MoniterTimer, 5);
                MonitorTimeout = 0;
            }
            LTPLL_SetPowerStatus(LTPLL_STATE_W4ACK); 
        }
        else if(LTPLL_GetPowerStatus() == LTPLL_STATE_PRE_SLEEP)
        {
            /* bee is wait host goio low!!!! just save data */
            LTPLL_QueueSave(p_buf, buf_len);
        }
        else
        {
            //send directly
            if (pdFALSE == xQueueSend(P_BtLtp->p_aci_tcb->QueueHandleTxData, &tx_data, 0))
            {
                if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
                {
                    DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "!!!LtpWrite:xQueueSend fail", 0);
                }
            }
        }
    }
    else    /* host not support low power mode, or host in wake status, send directly */
    {
        if (pdFALSE == xQueueSend(P_BtLtp->p_aci_tcb->QueueHandleTxData, &tx_data, 0))
        {
            if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
            {
                DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "!!!LtpWrite:xQueueSend fail", 0);
            }
        }

    }

    return;
}


/**
 * @brief release ltp buffer when ltp command has executed completely.
 *
 * @param p_buf the buffer start address to release, not used now!!
 * @return none.
 * @retal   void.
*/
void LtpBufferRelease(void* p_buf)
{
    TLTPData RxData;

    if (xQueueReceive(P_BtLtp->p_aci_tcb->QueueHandleRxData, &RxData, 0) == pdPASS)
    {
        if (RxData.pBuffer == &P_BtLtp->p_aci_tcb->p_rx_buf[P_BtLtp->p_aci_tcb->RxReadIndex])
        {
            DWORD RxDataLength;

            taskDISABLE_INTERRUPTS();
            P_BtLtp->p_aci_tcb->RxDataLength -= RxData.Length;
            RxDataLength           = P_BtLtp->p_aci_tcb->RxDataLength;
            taskENABLE_INTERRUPTS();

            P_BtLtp->p_aci_tcb->RxReadIndex += RxData.Length;
            P_BtLtp->p_aci_tcb->RxReadIndex &= (RX_BUFFER_SIZE - 1);

            if (P_BtLtp->p_aci_tcb->RxDataIndication)   /* waiting for response */
            {
                P_BtLtp->p_aci_tcb->RxDataIndication -= RxData.Length;
            }

            if (P_BtLtp->p_aci_tcb->RxDataIndication == 0 &&   /* no response pending and */
                    RxDataLength != 0)                         /* still data available */
            {
                BYTE event = LTP_EVENT_UART_RX;
                if ( errQUEUE_FULL == ltpSendEvent(&event) )
                {
                    if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
                    {
                        DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "!!!LtpBufferRelease:ltpSendEvent fail", 0);
                    }
                }
            }

        }
        else
        {
            if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
            {
                DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "!!!LtpBufferRelease: Wrong buffer", 0);
            }
        }
    }
    else
    {
        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_INFO)
        {
            DBG_BUFFER(MODULE_LTP, LEVEL_INFO, "LtpBufferRelease: No RxData", 0);
        }
    }

    return;
}

void aciConfigDefault(void)
{
    P_AciConfig->ltp_interface = 0;
#if ACI_EN
    P_AciConfig->ltp_wake_up_pin_en = 1;
#else
    P_AciConfig->ltp_wake_up_pin_en = 0;
#endif
    P_AciConfig->ltp_trace_level = LTP_TRACE_INFO;
    P_AciConfig->uart_flow_control_en = 0;
    P_AciConfig->uart_baudrate = 115200;
    P_AciConfig->uart_parity = 0;
    P_AciConfig->uart_word_len = 0;
    P_AciConfig->uart_tx_pin_index = UART_TX_PIN;
    P_AciConfig->uart_rx_pin_index = UART_RX_PIN;
    P_AciConfig->gpio_b_pin_index = DLPS_BEE_PIN;
    P_AciConfig->gpio_h_pin_index = DLPS_HOST_PIN;

}
/**
 * @brief init ltp module, call this function before calling other ltp functions .
 *
 * @param none.
 * @return the init result.
 * @retal  0 -- init ltp failed.
            1 -- init ltp successfully.
*/
BYTE ltpInit(void)
{
    g_eflash_dbg = 0;
    P_BtLtp = &BtLtp;
    /* memset */
    memset(P_BtLtp, 0, sizeof(TBTLtp));
    P_BtLtp->p_aci_tcb = & AciTcb;
    memset(P_BtLtp->p_aci_tcb, 0, sizeof(ACI_TCB));
    P_BtLtp->p_aci_tcb->p_rx_buf = RxBuffer;
    memset(P_BtLtp->p_aci_tcb->p_rx_buf, 0, RX_BUFFER_SIZE);
    P_BtLtp->p_aci_tcb->p_tx_buf = TXBuffer;
    memset(P_BtLtp->p_aci_tcb->p_tx_buf, 0, TX_BUFFER_SIZE);
    P_BtLtp->p_aci_tcb->p_rx_handle_buf = RXHandleBuffer;
    memset(P_BtLtp->p_aci_tcb->p_rx_handle_buf, 0, RX_HANDLE_BUFFER_SIZE);

    /* allocate failed */
    if (NULL == P_BtLtp
            || NULL == P_BtLtp->p_aci_tcb
            || NULL == P_BtLtp->p_aci_tcb->p_rx_buf
            || NULL == P_BtLtp->p_aci_tcb->p_tx_buf
            || NULL == P_BtLtp->p_aci_tcb->p_rx_handle_buf)
    {
        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
        {
            DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "!!!Ltp ram allocated failed!", 0);
        }
        return 0;
    }
    if(P_AciConfig->ltp_trace_level >= LTP_TRACE_INFO)
    {
        DBG_BUFFER(MODULE_LTP, LEVEL_INFO, "Ltp ram allocated successfully!", 0);
    }
    memset(&(P_BtLtp->p_aci_tcb->tx_mem_tcb), 0, sizeof(TxMemTCB));
    P_BtLtp->p_aci_tcb->tx_mem_tcb.free_size = TX_BUFFER_SIZE;

    /* tasks and queues */
    P_BtLtp->p_aci_tcb->Handle = LTPTaskHandle;
    P_BtLtp->p_aci_tcb->P_RxBuffer = &P_BtLtp->p_aci_tcb->p_rx_buf[0];
    P_BtLtp->p_aci_tcb->QueueHandleEvent   = xQueueCreate(MAX_NUMBER_OF_RX_EVENT, sizeof(unsigned char));
    P_BtLtp->p_aci_tcb->QueueHandleTxData  = xQueueCreate(MAX_NUMBER_OF_TX_DATA, sizeof(TLTPData));
    P_BtLtp->p_aci_tcb->QueueHandleRxData  = xQueueCreate(MAX_NUMBER_OF_RX_DATA, sizeof(TLTPData));
    P_BtLtp->p_aci_tcb->QueueHandleTxRel  = xQueueCreate(MAX_NUMBER_OF_TX_REL, sizeof(TLTPData)); /* tx release */
    P_BtLtp->p_aci_tcb->QueueHandleMessage = xQueueCreate(MAX_NUMBER_OF_MESSAGE, sizeof(PBlueAPI_DsMessage));
#if F_LTPLIB_ASYNC_ASSEMBLY_SUPPORT
    P_BtLtp->p_aci_tcb->ltpTimerHandle = xTimerCreate("TIM_LTP", (10 / portTICK_RATE_MS), pdFALSE, 0, ltpTimeoutRoutine);
#endif


    for (WORD i = 0; i < BT_GATT_SERVER_MAX_SERVICES_COUNT; i++)
    {
        P_BtLtp->gattServiceTable[i].self_idx = i;
    }
    fs_init(P_BtLtp);

    aciConfigDefault();
#if ACI_CONFIG_EN
    P_BtLtp->ltp_key_store_en = TRUE;
    fs_key_storage_init(P_BtLtp);
    if(otp_str_data.reserved_1[0] != 0xFF)
    {
        memcpy(P_AciConfig, otp_str_data.reserved_1, 24);
        //if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
        //{
            DBG_BUFFER(MODULE_LTP, LEVEL_INFO, "Ltp Aci Config:mtu %d trace level: %d interface %d wakeup %d flow control %d data %d parity %d baudrate %d", 8,
                                otp_str_data.gEfuse_UpperStack_s.att_max_mtu_size,
                                P_AciConfig->ltp_trace_level,
                                P_AciConfig->ltp_interface,
                                P_AciConfig->ltp_wake_up_pin_en, 
                                P_AciConfig->uart_flow_control_en,
                                P_AciConfig->uart_word_len,
                                P_AciConfig->uart_parity,
                                P_AciConfig->uart_baudrate);
            DBG_BUFFER(MODULE_LTP, LEVEL_INFO, "Ltp Aci Config: tx pin %d rx pin %d cts %d rts %d gpio_h %d gpio_b %d", 6,
                                P_AciConfig->uart_tx_pin_index,
                                P_AciConfig->uart_rx_pin_index,
                                P_AciConfig->uart_cts_pin_index,
                                P_AciConfig->uart_rts_pin_index,
                                P_AciConfig->gpio_h_pin_index,
                                P_AciConfig->gpio_b_pin_index);
        //}
    }
#endif
    return 1;
}

BYTE ltpTaskInit(void)
{
    xTaskCreate(ltpTask, "BTLTP", LTP_TASK_STACK_SIZE / sizeof(portSTACK_TYPE), NULL, LTP_PRIORITY, &LTPTaskHandle);

    xTaskCreate(TxAssistTask, "TxAssist", TX_TASK_STACK_SIZE / sizeof(portSTACK_TYPE), NULL, LTP_PRIORITY - 1, &LTPTxAssistHandle);
    return 1;
}

/**
 * @brief ltp task implementation .
 *
 * @param pParameters --task parameters, no used in ltp task.
 * @return none.
 * @retal void
*/
void ltpTask(void *pParameters)
{
    int  loop;
    char Event;

    /* init uart or spi */
    ltpPeripheralInit();
    P_BtLtp->State = btltpStateInit;

    for (loop = 0; loop < BTLTP_QUEUE_ELEMENT_COUNT; loop++)
    {
        ltpQueueIn(&P_BtLtp->FreeElementQueue, &P_BtLtp->ElementPool[loop]);
    }

    for (loop = 0; loop < BTLTP_ACTION_POOL_SIZE; loop++)
    {
        P_BtLtp->ActionPool[loop].Action = btltpActionNotUsed;
    }
    P_BtLtp->pBufferAction = NULL; /* no action pending */
    LTPLibInitialize(&P_BtLtp->LTPLib,
                     (LTP_TGT_APPHANDLE)P_BtLtp,
                     0,
                     BTLTP_MAX_MSG_SIZE,
                     0
                    );

    blueAPI_RegisterReq(P_BtLtp, (void *)ltpBlueAPICallback);

    P_BtLtp->State = btltpStateIdle; /* not use !!*/

    while (TRUE)
    {
        if (xQueueReceive(P_BtLtp->p_aci_tcb->QueueHandleEvent, &Event, portMAX_DELAY) == pdPASS)
        {
            switch (Event)
            {
            case LTP_EVENT_UART_RX:          /* RxData available */
                {
                    DWORD RxDataLength;
                    WORD RxReadIndex;

                    taskENTER_CRITICAL();
                    /* skip data filed in handling */
                    RxDataLength = P_BtLtp->p_aci_tcb->RxDataLength - P_BtLtp->p_aci_tcb->RxDataIndication;
                    taskEXIT_CRITICAL();
                    RxReadIndex  = P_BtLtp->p_aci_tcb->RxReadIndex + P_BtLtp->p_aci_tcb->RxDataIndication;
                    RxReadIndex &= (RX_BUFFER_SIZE - 1);

                    while (RxDataLength)
                    {
                        TLTPData RxData;

                        /* exceed rx buffer tail */
                        if ((RxReadIndex + RxDataLength) > RX_BUFFER_SIZE)
                        {
                            RxData.Length = RX_BUFFER_SIZE - RxReadIndex;
                        }
                        else
                        {
                            RxData.Length = RxDataLength;
                        }
                        RxData.pBuffer = &P_BtLtp->p_aci_tcb->p_rx_buf[RxReadIndex];

                        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ALL)
                        {
                            DBG_BUFFER(MODULE_LTP, LEVEL_TRACE, "LTP_EVENT_UART_RX: RxReadIndex = 0x%x, RxData.Length= 0x%x\t",\
                            2, RxReadIndex, RxData.Length);
                        }

                        if (xQueueSend(P_BtLtp->p_aci_tcb->QueueHandleRxData, &RxData, 0) == pdPASS)
                        {
                            P_BtLtp->p_aci_tcb->RxDataIndication += RxData.Length;
                            /* LTPLibHandleReceiveData return when all data in RxData has been copied */
                            if (!LTPLibHandleReceiveData(&P_BtLtp->LTPLib, RxData.pBuffer, RxData.Length, 0))
                            {
                                LtpBufferRelease(RxData.pBuffer);
                            }

                            RxDataLength -= RxData.Length;
                            RxReadIndex  += RxData.Length;
                            RxReadIndex  &= (RX_BUFFER_SIZE - 1);
                        }
                        else
                        {
                            if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
                            {
                                DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "LTP_EVENT_UART_RX, xQueueSend fail", 0);
                            }
                            break;
                        }
                    }
                    break;
                }

            case LTP_EVENT_UART_TX_COMPLETED:          /* transmit completed */
                {
                    THandle Handle;
                    TLTPData data;

                    if (xQueueReceive(P_BtLtp->p_aci_tcb->QueueHandleTxRel, &data, 0) == pdPASS)
                    {
                        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ALL)
                        {
                            DBG_BUFFER(MODULE_LTP, LEVEL_INFO, "QueueHandleTxRel cmd:0x%x", 1, \
                                   P_BtLtp->p_aci_tcb->p_tx_buf[P_BtLtp->p_aci_tcb->tx_mem_tcb.tx_blk_idx]);
                        }
                        P_BtLtp->p_aci_tcb->tx_mem_tcb.tx_blk_idx += data.Length;
                        P_BtLtp->p_aci_tcb->tx_mem_tcb.free_size += data.Length;

                        if (P_BtLtp->p_aci_tcb->tx_mem_tcb.tx_blk_idx > TX_BUFFER_SIZE)
                        {
                            P_BtLtp->p_aci_tcb->tx_mem_tcb.tx_blk_idx = data.Length;
                            P_BtLtp->p_aci_tcb->tx_mem_tcb.tx_un_used_size = 0;
                        }
                        else if (P_BtLtp->p_aci_tcb->tx_mem_tcb.tx_blk_idx == TX_BUFFER_SIZE)
                        {
                            P_BtLtp->p_aci_tcb->tx_mem_tcb.tx_blk_idx = 0;
                            P_BtLtp->p_aci_tcb->tx_mem_tcb.tx_un_used_size = 0;
                        }
                        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_DEBUG)
                        {
                            DBG_BUFFER(MODULE_LTP, LEVEL_INFO, "Free2:tx idx = 0x%x, free idx = 0x%x\t, tx_un_used_size = 0x%x\t", 3, \
                                   P_BtLtp->p_aci_tcb->tx_mem_tcb.tx_blk_idx, \
                                   P_BtLtp->p_aci_tcb->tx_mem_tcb.tx_free_blk_idx, \
                                   P_BtLtp->p_aci_tcb->tx_mem_tcb.tx_un_used_size);
                        }
                    }
                    else
                    {
                        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_INFO)
                        {
                            DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "!!!QueueHandleTxRel recieve fail: ", 0);
                        }
                    }

                    /* reset */
                    if (P_BtLtp->pBufferAction->Action == btltpActionReset)
                    {
                        Handle.lpHandle       = (LPVOID)P_BtLtp->pBufferAction;
                        BTLTPBufferCallback(Handle);
                        P_BtLtp->pBufferAction->Action = btltpActionNotUsed;
                        P_BtLtp->pBufferAction = NULL;
                    }

                    break;
                }
            case LTP_EVENT_BLUEAPI_MESSAGE:            /* BlueAPI */
                {
                    PBlueAPI_UsMessage pMsg;

                    while (xQueueReceive(P_BtLtp->p_aci_tcb->QueueHandleMessage, &pMsg, 0) == pdPASS)
                    {
                        ltpHandleBlueAPIMessage(pMsg);
                    }
                    break;
                }

            default:
                if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
                {
                    DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "ltpTask: Unknown event (%d)", 1, Event);
                }
                break;
            }
        }
        else
        {
            if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
            {
                DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "ltpTask: xQueueReceive fail", 0);
            }
        }
    }
}

