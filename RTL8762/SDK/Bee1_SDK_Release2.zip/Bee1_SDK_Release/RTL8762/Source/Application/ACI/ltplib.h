#ifndef     _LTPLIB_H_
#define     _LTPLIB_H_

//#include "btltp.h"
#define  FAR

#if !defined (FALSE)
#define FALSE  0
#define TRUE   1
#endif

#ifndef NULL
#define NULL            (void *)0
#endif

typedef        unsigned char    BOOL, * PBOOL;
typedef        int              INT, *PINT;
typedef        unsigned char    UCHAR, BYTE, * PUCHAR, * PBYTE;
typedef        const BYTE       * PCBYTE;
typedef        unsigned char    * LPBYTE;
typedef        const BYTE       * LPCBYTE;
typedef        char             *  PCHAR;
typedef        char             * LPSTR;
typedef        unsigned int     UINT, * PUINT;
typedef        long             LONG, * PLONG;
typedef        long             * LPLONG;
typedef        unsigned long    ULONG, DWORD, * PULONG, * PDWORD;
typedef        unsigned long    * LPDWORD;
typedef        const unsigned long  * LPCDWORD;
typedef        unsigned short   WORD, USHORT, * PUSHORT, * PWORD;
typedef        unsigned short    * LPWORD;
typedef        short            SHORT;
typedef        PCHAR          * PPCHAR;
typedef  const char        * LPCSTR;
typedef        DWORD            LARGE_INTEGER;
typedef  unsigned int           HANDLE;

typedef  void  VOID, * PVOID, ** PPVOID;
typedef  const void * PCVOID;
typedef  void   * LPVOID;
typedef  const void   * LPCVOID;


typedef union _handle
{
    BYTE   bHandle;
    WORD   wHandle;
    DWORD  dwHandle;
    PVOID  pHandle;
    LPVOID lpHandle;
} THandle, *PHandle;
typedef THandle FAR *LPHandle;

/****************************************************************************/
/* target specific application context to be handed over to the application */
/* this constand is used by the BTLTPTgtxxx function calls of this library  */
#define LTP_TGT_APPHANDLE   LPVOID

#define F_LTPLIB_ASYNC_ASSEMBLY_SUPPORT 0  /*LTP library includes asynchronous LTP_RESET_REQ detection*/

/* definition of valid LTP response causes                                  */
#define LTP_CAUSE_SUCCESS                                                 0x00
#define LTP_CAUSE_ACCEPT                                                  0x01
#define LTP_CAUSE_REJECT                                                  0x02
#define LTP_CAUSE_RESOURCE_ERROR                                          0x03
#define LTP_CAUSE_INVALID_PARAMETER                                       0x04
#define LTP_CAUSE_INVALID_STATE                                           0x05
#define LTP_CAUSE_CONNECTION_DISCONNECT                                   0x06
#define LTP_CAUSE_CONNECTION_LOST                                         0x07
#define LTP_CAUSE_AUTHENTICATION_FAILED                                   0x08
#define LTP_CAUSE_INIT_TIMEOUT                                            0x09
#define LTP_CAUSE_INIT_OUT_OF_SYNC                                        0x0A
#define LTP_CAUSE_INIT_HARDWARE_fAILURE                                   0x0B
#define LTP_CAUSE_UNSPECIFIED                                             0xFD
#define LTP_CAUSE_NOT_SUPPORTED                                           0xFE

/* definitions of Link key Types                                             */
#define LTP_LINK_KEY_TYPE_COMBINATION                                     0x00
#define LTP_LINK_KEY_TYPE_LOCAL_UNIT                                      0x01
#define LTP_LINK_KEY_TYPE_REMOTE_UNIT                                     0x02
/* 0x03 reserved                                                            */
#define LTP_LINK_KEY_TYPE_UNAUTHENTICATED                                 0x04
#define LTP_LINK_KEY_TYPE_AUTHENTICATED                                   0x05
#define LTP_LINK_KEY_TYPE_CHANGED                                         0x06
#define LTP_LINK_KEY_TYPE_DELETED                                         0xFF

/* definition of locally generated internal Event types                     */
#define LTP_INTERNAL_EVENT_COMMUNICATION_OUT_OF_SYNC                      0x40
#define LTP_INTERNAL_EVENT_MALFORMED_MSG_RECEIVED                         0x41
#define LTP_INTERNAL_EVENT_INVALID_DATA_RECEIVED                          0x42


/* definition of IOCapabilities                                             */
#define LTP_IO_CAPABILITIES_DISPLAY_ONLY                                  0x00
#define LTP_IO_CAPABILITIES_DISPLAY_YES_NO                                0x01
#define LTP_IO_CAPABILITIES_KEYBOARD_ONLY                                 0x02
#define LTP_IO_CAPABILITIES_NO_IO_CAPABILITIES                            0x03

/* definitions for MCL Status                                               */
#define LTP_MCL_STATUS_IDLE                                               0x01
#define LTP_MCL_STATUS_CONTROL_CONNECTING                                 0x02
#define LTP_MCL_STATUS_CONTROL_CONNECTED                                  0x03
#define LTP_MCL_STATUS_CONTROL_DISCONNECTING                              0x04
#define LTP_MCL_STATUS_CONTROL_LISTENING                                  0x05
#define LTP_MCL_STATUS_DATA_CONNECTING                                    0x06
#define LTP_MCL_STATUS_DATA_CONNECTED                                     0x07
#define LTP_MCL_STATUS_DATA_DISCONNECTING                                 0x08
#define LTP_MCL_STATUS_DATA_LISTENING                                     0x09
#define LTP_MCL_STATUS_CONTROL_WAIT_FOR_RESPONSE                          0x0A
#define LTP_MCL_STATUS_WAIT_FOR_RESPONSE                                  0x0B
#define LTP_MCL_STATUS_RELEASED                                           0x0C

/* definitions for ACL Status                                               */
#define LTP_ACL_STATUS_CONNECTED_ACTIVE                                   0x01
#define LTP_ACL_STATUS_CONNECTED_SNIFF                                    0x02
#define LTP_ACL_STATUS_AUTHENTICATION_STARTED                             0x03
#define LTP_ACL_STATUS_AUTHENTICATION_SUCCESS                             0x04
#define LTP_ACL_STATUS_AUTHENTICATION_FAILURE                             0x05
#define LTP_ACL_STATUS_CONNECTION_ENCRYPTED                               0x06
#define LTP_ACL_STATUS_CONNECTION_DISCONNECTED                            0x07
#define LTP_ACL_STATUS_CONNECTION_NOT_ENCRYPTED                           0x08

/* definition of AuthRequirements                                           */
#define LTP_AUTH_REQUIREMENTS_NO_MITM_REQUIRED_NO_STORE                   0x00
#define LTP_AUTH_REQUIREMENTS_MITM_REQUIRED_NO_STORE                      0x01
#define LTP_AUTH_REQUIREMENTS_NO_MITM_REQUIRED_BONDING                    0x02
#define LTP_AUTH_REQUIREMENTS_MITM_REQUIRED_BONDING                       0x03

/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/**                                                                        **/
/** 3) Internal functionality used by the LTP-Lib                          **/
/**                                                                        **/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/

/* macro definition for read/write WORD from/to BYTE memory                 */
#define NETSHORT2CHAR(p,w)                 \
    *((p)+1) = (BYTE)((w) & 0xff);         \
    *(p)     = /*lint -e(572,778)*/ (BYTE)(((w)>>8) & 0xff)

#define NETCHAR2SHORT(p) ((*((p)+1)) & 0xff) + ((*(p)) << 8)

#define NETCHAR2LONG(p) ((DWORD)(*((p)+3)) & 0xff) + ((DWORD)(*((p)+2)) << 8) \
    + ((DWORD)(*((p)+1)) << 16)  + ((DWORD)(*((p)+0)) << 24)

#define NET24BIT2CHAR(p,w)                  \
    *((p)+2) = (BYTE)((w) & 0xff);          \
    *((p)+1) = /*lint -e(572,778)*/ (BYTE)(((w)>>8) & 0xff);     \
    *((p)+0) = /*lint -e(572,778)*/ (BYTE)(((w)>>16) & 0xff);    \
     
#define NETLONG2CHAR(p,w)                   \
    *((p)+3) = (BYTE)((w) & 0xff);          \
    *((p)+2) = /*lint -e(572,778)*/ (BYTE)(((w)>>8) & 0xff);     \
    *((p)+1) = /*lint -e(572,778)*/ (BYTE)(((w)>>16) & 0xff);    \
    *((p)+0) = /*lint -e(572,778)*/ (BYTE)(((w)>>24) & 0xff)


/* macro definition to identity internal event location                     */
#define LTP_GENERATE_EVENT_ID  ((0x00)<<24 | (((LTP_SOURCE_FILE_ID) & 0xFF)<<16) | ((__LINE__) & 0xFFFF))

/* message definitions                                                      */
#define LTP_DATA_MIN_HEADER_LENGTH                                           4
#define LTP_OPT_MASK_HEADER_CRC8                                          0x80

#define LTP_OPCODE_RESERVED                                               0x00

/* definitions of message properties                                        */
#define LTP_MDC_MSG         0x01
#define LTP_MDH_MSG         0x02
#define LTP_VAR_LEN_MSG     0x04
#define LTP_CNF_MSG         0x08

/*--------------------------------------------------------------------------*/
/* CONNECT_MDL_INFO                                                         */
#define LTP_CONNECT_MDL_INFO                                              0x04
#define LTP_CONNECT_MDL_INFO_LENGTH                                          9
#define LTP_CONNECT_MDL_INFO_FLAGS                               (LTP_MDC_MSG)

#define LTP_CONNECT_MDL_INFO_OPT_MASK_LINK_TYPE                           0x01
#define LTP_CONNECT_MDL_INFO_OPT_MASK_MAX_TPDU_US_CREDITS                 0x02
#define LTP_CONNECT_MDL_INFO_OPT_MASK_MAX_TPDU_DS_CREDITS                 0x04

/*--------------------------------------------------------------------------*/
/* CREATE_MDL_CNF                                                           */
#define LTP_CREATE_MDL_CNF                                                0x05
#define LTP_CREATE_MDL_CNF_LENGTH                                            6
#define LTP_CREATE_MDL_CNF_FLAGS                     (LTP_CNF_MSG|LTP_MDH_MSG)

#define LTP_CREATE_MDL_CNF_OPT_MASK_MAX_TPDU_US_CREDITS                   0x01

/*--------------------------------------------------------------------------*/
/* DELETE_MDL_INFO                                                          */
#define LTP_DELETE_MDL_INFO                                               0x06
#define LTP_DELETE_MDL_INFO_LENGTH                                           5
#define LTP_DELETE_MDL_INFO_FLAGS                                (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* DISCONNECT_MDL_RSP                                                       */
#define LTP_DISCONNECT_MDL_RSP                                            0x07
#define LTP_DISCONNECT_MDL_RSP_LENGTH                                        6
#define LTP_DISCONNECT_MDL_RSP_FLAGS                             (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* DISCONNECT_MDL_CNF                                                       */
#define LTP_DISCONNECT_MDL_CNF                                            0x08
#define LTP_DISCONNECT_MDL_CNF_LENGTH                                        5
#define LTP_DISCONNECT_MDL_CNF_FLAGS                 (LTP_CNF_MSG|LTP_MDH_MSG)

#define LTP_DISCONNECT_MDL_CNF_OPT_MASK_LOC_MDL_ID                        0x01


/*--------------------------------------------------------------------------*/
/* EXIT_RSP                                                                 */
#define LTP_EXIT_RSP                                                      0x09
#define LTP_EXIT_RSP_LENGTH                                                  5
#define LTP_EXIT_RSP_FLAGS                                       (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* ACT_INFO                                                                 */
#define LTP_ACT_INFO                                                      0x0A
#define LTP_ACT_INFO_LENGTH                                                 12
#define LTP_ACT_INFO_FLAGS                       (LTP_VAR_LEN_MSG|LTP_MDC_MSG)

#define LTP_ACT_INFO_OPT_MASK_MAX_RX_MESSAGE_LENGTH                       0x03
#define LTP_ACT_INFO_OPT_MASK_MAX_TX_MESSAGE_LENGTH                       0x0C

/*--------------------------------------------------------------------------*/
/* LTP_ACL_STATUS_INFO                                                      */
#define LTP_ACL_STATUS_INFO                                               0x0B
#define LTP_ACL_STATUS_INFO_LENGTH                                          11
#define LTP_ACL_STATUS_INFO_FLAGS                                (LTP_MDC_MSG)

#define LTP_ACL_STATUS_INFO_OPT_MASK_BD_TYPE                              0x01
#define LTP_ACL_STATUS_INFO_OPT_MASK_KEY_TYPE                             0x02
#define LTP_ACL_STATUS_INFO_OPT_MASK_KEY_SIZE                             0x04
#define LTP_ACL_STATUS_INFO_OPT_MASK_SNIFF_INTERVAL                       0x18

/*--------------------------------------------------------------------------*/
/* RESET_RSP                                                                */
#define LTP_RESET_RSP                                                     0x0C
#define LTP_RESET_RSP_LENGTH                                                 5
#define LTP_RESET_RSP_FLAGS                                      (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_INTERNAL_EVENT_INFO                                                  */
#define LTP_INTERNAL_EVENT_INFO                                           0x0D
#define LTP_INTERNAL_EVENT_INFO_LENGTH                                      10
#define LTP_INTERNAL_EVENT_INFO_FLAGS                            (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_PASSKEY_REQUEST_CNF                                                  */
#define LTP_PASSKEY_REQUEST_CNF                                           0x0E
#define LTP_PASSKEY_REQUEST_CNF_LENGTH                                      11
#define LTP_PASSKEY_REQUEST_CNF_FLAGS                (LTP_CNF_MSG|LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_REMOTE_OOB_REQUEST_CNF                                               */
#define LTP_REMOTE_OOB_REQUEST_CNF                                        0x0F
#define LTP_REMOTE_OOB_REQUEST_CNF_LENGTH                                   27
#define LTP_REMOTE_OOB_REQUEST_CNF_FLAGS             (LTP_CNF_MSG|LTP_MDH_MSG)


/*--------------------------------------------------------------------------*/
/* LTP_MCL_STATUS_INFO                                                      */
#define LTP_MCL_STATUS_INFO                                               0x10
#define LTP_MCL_STATUS_INFO_LENGTH                                          12
#define LTP_MCL_STATUS_INFO_FLAGS                                (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_PAIRABLE_MODE_SET_RSP                                                */
#define LTP_PAIRABLE_MODE_SET_RSP                                         0x11
#define LTP_PAIRABLE_MODE_SET_RSP_LENGTH                                     5
#define LTP_PAIRABLE_MODE_SET_RSP_FLAGS                          (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_PASSKEY_REQ_REPLY_RSP                                                */
#define LTP_PASSKEY_REQ_REPLY_RSP                                         0x12
#define LTP_PASSKEY_REQ_REPLY_RSP_LENGTH                                     5
#define LTP_PASSKEY_REQ_REPLY_RSP_FLAGS                          (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_PASSKEY_NOTIFICATION_INFO                                            */
#define LTP_PASSKEY_NOTIFICATION_INFO                                     0x13
#define LTP_PASSKEY_NOTIFICATION_INFO_LENGTH                                14
#define LTP_PASSKEY_NOTIFICATION_INFO_FLAGS                      (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* CONNECT_GATT_MDL_RSP                                                     */
#define LTP_CONNECT_GATT_MDL_RSP                                          0x14
#define LTP_CONNECT_GATT_MDL_RSP_LENGTH                                     13
#define LTP_CONNECT_GATT_MDL_RSP_FLAGS                           (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_SERVICE_REGISTER_RSP */
#define LTP_GATT_SERVICE_REGISTER_RSP                                     0x15
#define LTP_GATT_SERVICE_REGISTER_RSP_LENGTH                                 8
#define LTP_GATT_SERVICE_REGISTER_RSP_FLAGS                      (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_ATTRIBUTE_UPDATE_RSP */
#define LTP_GATT_ATTRIBUTE_UPDATE_RSP                                     0x16
#define LTP_GATT_ATTRIBUTE_UPDATE_RSP_LENGTH                                14
#define LTP_GATT_ATTRIBUTE_UPDATE_RSP_FLAGS      (LTP_VAR_LEN_MSG|LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_ATTRIBUTE_UPDATE_STATUS_CNF */
#define LTP_GATT_ATTRIBUTE_UPDATE_STATUS_CNF                              0x17
#define LTP_GATT_ATTRIBUTE_UPDATE_STATUS_CNF_LENGTH                         12
#define LTP_GATT_ATTRIBUTE_UPDATE_STATUS_CNF_FLAGS   (LTP_CNF_MSG|LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_ATTRIBUTE_READ_CNF */
#define LTP_GATT_ATTRIBUTE_READ_CNF                                       0x18
#define LTP_GATT_ATTRIBUTE_READ_CNF_LENGTH                                  11
#define LTP_GATT_ATTRIBUTE_READ_CNF_FLAGS        (LTP_VAR_LEN_MSG|LTP_CNF_MSG|LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_ATTRIBUTE_WRITE_CNF */
#define LTP_GATT_ATTRIBUTE_WRITE_CNF                                      0x19
#define LTP_GATT_ATTRIBUTE_WRITE_CNF_LENGTH                                 11
#define LTP_GATT_ATTRIBUTE_WRITE_CNF_FLAGS           (LTP_CNF_MSG|LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_CCCD_INFO */
#define LTP_GATT_CCCD_INFO                                                0x1A
#define LTP_GATT_CCCD_INFO_LENGTH                                            6
#define LTP_GATT_CCCD_INFO_FLAGS                 (LTP_VAR_LEN_MSG|LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_DISCOVERY_RSP */
#define LTP_GATT_DISCOVERY_RSP                                            0x1B
#define LTP_GATT_DISCOVERY_RSP_LENGTH                                        9
#define LTP_GATT_DISCOVERY_RSP_FLAGS                             (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_DISCOVERY_CNF */
#define LTP_GATT_DISCOVERY_CNF                                            0x1C
#define LTP_GATT_DISCOVERY_CNF_LENGTH                                       11
#define LTP_GATT_DISCOVERY_CNF_FLAGS                 (LTP_CNF_MSG|LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_ATTRIBUTE_READ_RSP */
#define LTP_GATT_ATTRIBUTE_READ_RSP                                       0x1D
#define LTP_GATT_ATTRIBUTE_READ_RSP_LENGTH                                  14
#define LTP_GATT_ATTRIBUTE_READ_RSP_FLAGS        (LTP_VAR_LEN_MSG|LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_ATTRIBUTE_WRITE_RSP */
#define LTP_GATT_ATTRIBUTE_WRITE_RSP                                      0x1E
#define LTP_GATT_ATTRIBUTE_WRITE_RSP_LENGTH                                  9
#define LTP_GATT_ATTRIBUTE_WRITE_RSP_FLAGS                       (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_ATTRIBUTE_CNF */
#define LTP_GATT_ATTRIBUTE_CNF                                            0x1F
#define LTP_GATT_ATTRIBUTE_CNF_LENGTH                                        6
#define LTP_GATT_ATTRIBUTE_CNF_FLAGS                 (LTP_CNF_MSG|LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_ATTRIBUTE_NOTIFICATION_INFO */
#define LTP_GATT_ATTRIBUTE_NOTIFICATION_INFO                              0x20
#define LTP_GATT_ATTRIBUTE_NOTIFICATION_INFO_LENGTH                          7
#define LTP_GATT_ATTRIBUTE_NOTIFICATION_INFO_FLAGS           (LTP_VAR_LEN_MSG|LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LE_ADVERTISE_RSP */
#define LTP_LE_ADVERTISE_RSP                                              0x21
#define LTP_LE_ADVERTISE_RSP_LENGTH                                          6
#define LTP_LE_ADVERTISE_RSP_FLAGS                               (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LE_ADVERTISE_PARAMETER_SET_RSP */
#define LTP_LE_ADVERTISE_PARAMETER_SET_RSP                                0x22
#define LTP_LE_ADVERTISE_PARAMETER_SET_RSP_LENGTH                            5
#define LTP_LE_ADVERTISE_PARAMETER_SET_RSP_FLAGS                 (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LE_ADVERTISE_DATA_SET_RSP */
#define LTP_LE_ADVERTISE_DATA_SET_RSP                                     0x23
#define LTP_LE_ADVERTISE_DATA_SET_RSP_LENGTH                                 6
#define LTP_LE_ADVERTISE_DATA_SET_RSP_FLAGS                      (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LE_SCAN_RSP */
#define LTP_LE_SCAN_RSP                                                   0x24
#define LTP_LE_SCAN_RSP_LENGTH                                               5
#define LTP_LE_SCAN_RSP_FLAGS                                    (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LE_SCAN_INFO */
#define LTP_LE_SCAN_INFO                                                  0x25
#define LTP_LE_SCAN_INFO_LENGTH                                             13
#define LTP_LE_SCAN_INFO_FLAGS                   (LTP_VAR_LEN_MSG|LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LE_MODIFY_WHITELIST_RSP */
#define LTP_LE_MODIFY_WHITELIST_RSP                                       0x26
#define LTP_LE_MODIFY_WHITELIST_RSP_LENGTH                                   6
#define LTP_LE_MODIFY_WHITELIST_RSP_FLAGS                        (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LE_CONNECTION_UPDATE_RSP */
#define LTP_LE_CONNECTION_UPDATE_RSP                                      0x27
#define LTP_LE_CONNECTION_UPDATE_RSP_LENGTH                                  6
#define LTP_LE_CONNECTION_UPDATE_RSP_FLAGS                       (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LE_CONNECTION_UPDATE_CNF */
#define LTP_LE_CONNECTION_UPDATE_CNF                                      0x28
#define LTP_LE_CONNECTION_UPDATE_CNF_LENGTH                                  6
#define LTP_LE_CONNECTION_UPDATE_CNF_FLAGS           (LTP_CNF_MSG|LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LE_CONNECTION_PARAMETER_INFO */
#define LTP_LE_CONNECTION_PARAMETER_INFO                                  0x29
#define LTP_LE_CONNECTION_PARAMETER_INFO_LENGTH                             11
#define LTP_LE_CONNECTION_PARAMETER_INFO_FLAGS                   (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_SERVER_STORE_CNF */
#define LTP_GATT_SERVER_STORE_CNF                                         0x2A
#define LTP_GATT_SERVER_STORE_CNF_LENGTH                                    15
#define LTP_GATT_SERVER_STORE_CNF_FLAGS          (LTP_VAR_LEN_MSG|LTP_CNF_MSG|LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* AUTH_RESULT_EXT_CNF */
#define LTP_AUTH_RESULT_EXT_CNF                                           0x2B
#define LTP_AUTH_RESULT_EXT_CNF_LENGTH                                      12
#define LTP_AUTH_RESULT_EXT_CNF_FLAGS                (LTP_CNF_MSG|LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* AUTH_RESULT_REQUEST_EXT_CNF */
#define LTP_AUTH_RESULT_REQUEST_EXT_CNF                                   0x2C
#define LTP_AUTH_RESULT_REQUEST_EXT_CNF_LENGTH                              13
#define LTP_AUTH_RESULT_REQUEST_EXT_CNF_FLAGS    (LTP_VAR_LEN_MSG|LTP_CNF_MSG|LTP_MDH_MSG)

#define LTP_AUTH_RESULT_REQUEST_EXT_CNF_OPT_MASK_RESTART_HANDLE           0x03

/*--------------------------------------------------------------------------*/
/* GATT_SECURITY_RSP */
#define LTP_GATT_SECURITY_RSP                                             0x2D
#define LTP_GATT_SECURITY_RSP_LENGTH                                         8
#define LTP_GATT_SECURITY_RSP_FLAGS                              (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_MTU_INFO */
#define LTP_GATT_MTU_INFO                                                 0x2E
#define LTP_GATT_MTU_INFO_LENGTH                                             7
#define LTP_GATT_MTU_INFO_FLAGS                                  (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_ATTRIBUTE_WRITE_COMMAND_INFO */
#define LTP_GATT_ATTRIBUTE_WRITE_COMMAND_INFO                             0x2F
#define LTP_GATT_ATTRIBUTE_WRITE_COMMAND_INFO_LENGTH                        12
#define LTP_GATT_ATTRIBUTE_WRITE_COMMAND_INFO_FLAGS          (LTP_VAR_LEN_MSG|LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_ACL_BD_RESOLVED_INFO */
#define LTP_ACL_BD_RESOLVED_INFO                                          0x40
#define LTP_ACL_BD_RESOLVED_INFO_LENGTH                                     18
#define LTP_ACL_BD_RESOLVED_INFO_FLAGS                           (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_AUTH_DELETE_RSP                                                      */
#define LTP_AUTH_DELETE_RSP                                               0x41
#define LTP_AUTH_DELETE_RSP_LENGTH                                          11
#define LTP_AUTH_DELETE_RSP_FLAGS                                (LTP_MDC_MSG)

#define LTP_AUTH_DELETE_RSP_OPT_MASK_BD_TYPE                              0x01

/*--------------------------------------------------------------------------*/
/* LTP_AUTH_LIST_RSP                                                        */
#define LTP_AUTH_LIST_RSP                                                 0x42
#define LTP_AUTH_LIST_RSP_LENGTH                                            11
#define LTP_AUTH_LIST_RSP_FLAGS                                  (LTP_MDC_MSG)

#define LTP_AUTH_LIST_RSP_OPT_MASK_BD_TYPE                                0x01
#define LTP_AUTH_LIST_RSP_OPT_MASK_GET_LATEST                             0x02

/*--------------------------------------------------------------------------*/
/* LTP_AUTH_LIST_INFO                                                       */
#define LTP_AUTH_LIST_INFO                                                0x43
#define LTP_AUTH_LIST_INFO_LENGTH                                           11
#define LTP_AUTH_LIST_INFO_FLAGS                                 (LTP_MDC_MSG)

#define LTP_AUTH_LIST_INFO_OPT_MASK_BD_TYPE                               0x01

/*--------------------------------------------------------------------------*/
/* 0x7D reserved (LTP_EXTEND_COMMAND)*/


/*--------------------------------------------------------------------------*/
/* 0x84 reserved (LTP_CONNECT_MDL_INFO)*/


/* CREATE_MDL_IND                                                           */
#define LTP_CREATE_MDL_IND                                                0x85
#define LTP_CREATE_MDL_IND_LENGTH                                           11
#define LTP_CREATE_MDL_IND_FLAGS                                 (LTP_MDC_MSG)

#define LTP_CREATE_MDL_IND_OPT_MASK_BD_TYPE                               0x01

/*--------------------------------------------------------------------------*/
/* 0x86 reserved (DeleteMDLInfo)                                            */

/*--------------------------------------------------------------------------*/
/* DISCONNECT_MDL_REQ                                                       */
#define LTP_DISCONNECT_MDL_REQ                                            0x87
#define LTP_DISCONNECT_MDL_REQ_LENGTH                                        6
#define LTP_DISCONNECT_MDL_REQ_FLAGS                             (LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* DISCONNECT_MDL_IND                                                       */
#define LTP_DISCONNECT_MDL_IND                                            0x88
#define LTP_DISCONNECT_MDL_IND_LENGTH                                        6
#define LTP_DISCONNECT_MDL_IND_FLAGS                             (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* EXIT_REQ                                                                 */
#define LTP_EXIT_REQ                                                      0x89
#define LTP_EXIT_REQ_LENGTH                                                  5
#define LTP_EXIT_REQ_FLAGS                                       (LTP_MDH_MSG)

#define LTP_EXIT_REQ_OPT_MASK_STATUS                                      0x01

/*--------------------------------------------------------------------------*/
/* 0x8A - 0x8B reserved (ActInfo, ACLStatusInfo)                  */

/*--------------------------------------------------------------------------*/
/* RESET_REQ                                                                */
#define LTP_RESET_REQ                                                     0x8C
#define LTP_RESET_REQ_LENGTH                                                 4
#define LTP_RESET_REQ_FLAGS                                      (LTP_MDH_MSG)
#define LTP_RESET_REQ_HEADER_CRC                                          0x04

/*--------------------------------------------------------------------------*/
/* 0x8D reserved (LTP_INTERNAL_EVENT_INFO)                  */

/*--------------------------------------------------------------------------*/
/* LTP_PASSKEY_REQUEST_IND                                                  */
#define LTP_PASSKEY_REQUEST_IND                                           0x8E
#define LTP_PASSKEY_REQUEST_IND_LENGTH                                      10
#define LTP_PASSKEY_REQUEST_IND_FLAGS                            (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_REMOTE_OOB_REQUEST_IND                                               */
#define LTP_REMOTE_OOB_REQUEST_IND                                        0x8F
#define LTP_REMOTE_OOB_REQUEST_IND_LENGTH                                   10
#define LTP_REMOTE_OOB_REQUEST_IND_FLAGS                         (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* 0x90 reserved (MCLStatusInfo)                                            */

/*--------------------------------------------------------------------------*/
/* LTP_PAIRABLE_MODE_SET_REQ                                                */
#define LTP_PAIRABLE_MODE_SET_REQ                                         0x91
#define LTP_PAIRABLE_MODE_SET_REQ_LENGTH                                     8
#define LTP_PAIRABLE_MODE_SET_REQ_FLAGS                          (LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_PASSKEY_REQ_REPLY_REQ                                                */
#define LTP_PASSKEY_REQ_REPLY_REQ                                         0x92
#define LTP_PASSKEY_REQ_REPLY_REQ_LENGTH                                    15
#define LTP_PASSKEY_REQ_REPLY_REQ_FLAGS                          (LTP_MDH_MSG)


/*--------------------------------------------------------------------------*/
/* 0x93 reserved (KeypressNotificationInfo)                                 */


/*--------------------------------------------------------------------------*/
/* CONNECT_GATT_MDL_REQ */
#define LTP_CONNECT_GATT_MDL_REQ                                          0x94
#define LTP_CONNECT_GATT_MDL_REQ_LENGTH                                     29
#define LTP_CONNECT_GATT_MDL_REQ_FLAGS                           (LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_SERVICE_REGISTER_REQ */
#define LTP_GATT_SERVICE_REGISTER_REQ                                     0x95
#define LTP_GATT_SERVICE_REGISTER_REQ_LENGTH                                10
#define LTP_GATT_SERVICE_REGISTER_REQ_FLAGS                      (LTP_MDH_MSG)


/*--------------------------------------------------------------------------*/
/* GATT_ATTRIBUTE_UPDATE_REQ */
#define LTP_GATT_ATTRIBUTE_UPDATE_REQ                                     0x96
#define LTP_GATT_ATTRIBUTE_UPDATE_REQ_LENGTH                                11
#define LTP_GATT_ATTRIBUTE_UPDATE_REQ_FLAGS      (LTP_VAR_LEN_MSG|LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_ATTRIBUTE_UPDATE_STATUS_IND */
#define LTP_GATT_ATTRIBUTE_UPDATE_STATUS_IND                              0x97
#define LTP_GATT_ATTRIBUTE_UPDATE_STATUS_IND_LENGTH                         21
#define LTP_GATT_ATTRIBUTE_UPDATE_STATUS_IND_FLAGS               (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_ATTRIBUTE_READ_IND */
#define LTP_GATT_ATTRIBUTE_READ_IND                                       0x98
#define LTP_GATT_ATTRIBUTE_READ_IND_LENGTH                                  10
#define LTP_GATT_ATTRIBUTE_READ_IND_FLAGS                        (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_ATTRIBUTE_WRITE_IND */
#define LTP_GATT_ATTRIBUTE_WRITE_IND                                      0x99
#define LTP_GATT_ATTRIBUTE_WRITE_IND_LENGTH                                 12
#define LTP_GATT_ATTRIBUTE_WRITE_IND_FLAGS       (LTP_VAR_LEN_MSG|LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* 0x9A reserved (LTP_GATT_CCCD_INFO) */

/*--------------------------------------------------------------------------*/
/* GATT_DISCOVERY_REQ */
#define LTP_GATT_DISCOVERY_REQ                                            0x9B
#define LTP_GATT_DISCOVERY_REQ_LENGTH                                       12
#define LTP_GATT_DISCOVERY_REQ_FLAGS             (LTP_VAR_LEN_MSG|LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_DISCOVERY_IND */
#define LTP_GATT_DISCOVERY_IND                                            0x9C
#define LTP_GATT_DISCOVERY_IND_LENGTH                                       10
#define LTP_GATT_DISCOVERY_IND_FLAGS             (LTP_VAR_LEN_MSG|LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_ATTRIBUTE_READ_REQ */
#define LTP_GATT_ATTRIBUTE_READ_REQ                                       0x9D
#define LTP_GATT_ATTRIBUTE_READ_REQ_LENGTH                                  14
#define LTP_GATT_ATTRIBUTE_READ_REQ_FLAGS        (LTP_VAR_LEN_MSG|LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_ATTRIBUTE_WRITE_REQ */
#define LTP_GATT_ATTRIBUTE_WRITE_REQ                                      0x9E
#define LTP_GATT_ATTRIBUTE_WRITE_REQ_LENGTH                                 8
#define LTP_GATT_ATTRIBUTE_WRITE_REQ_FLAGS       (LTP_VAR_LEN_MSG|LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* GATT_ATTRIBUTE_IND */
#define LTP_GATT_ATTRIBUTE_IND                                            0x9F
#define LTP_GATT_ATTRIBUTE_IND_LENGTH                                        7
#define LTP_GATT_ATTRIBUTE_IND_FLAGS             (LTP_VAR_LEN_MSG|LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* 0xA0 reserved (LTP_GATT_ATTRIBUTE_NOTIFICATION_INFO) */


/*--------------------------------------------------------------------------*/
/* LE_ADVERTISE_REQ */
#define LTP_LE_ADVERTISE_REQ                                              0xA1
#define LTP_LE_ADVERTISE_REQ_LENGTH                                         5
#define LTP_LE_ADVERTISE_REQ_FLAGS                               (LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LE_ADVERTISE_PARAMETER_SET_REQ */
#define LTP_LE_ADVERTISE_PARAMETER_SET_REQ                                0xA2
#define LTP_LE_ADVERTISE_PARAMETER_SET_REQ_LENGTH                           19
#define LTP_LE_ADVERTISE_PARAMETER_SET_REQ_FLAGS                 (LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LE_ADVERTISE_DATA_SET_REQ */
#define LTP_LE_ADVERTISE_DATA_SET_REQ                                     0xA3
#define LTP_LE_ADVERTISE_DATA_SET_REQ_LENGTH                                 5
#define LTP_LE_ADVERTISE_DATA_SET_REQ_FLAGS      (LTP_VAR_LEN_MSG|LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LE_SCAN_REQ */
#define LTP_LE_SCAN_REQ                                                   0xA4
#define LTP_LE_SCAN_REQ_LENGTH                                              12
#define LTP_LE_SCAN_REQ_FLAGS                                    (LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* 0xA5 reserved (LTP_LE_SCAN_INFO) */

/*--------------------------------------------------------------------------*/
/* LE_MODIFY_WHITELIST_REQ */
#define LTP_LE_MODIFY_WHITELIST_REQ                                       0xA6
#define LTP_LE_MODIFY_WHITELIST_REQ_LENGTH                                  12
#define LTP_LE_MODIFY_WHITELIST_REQ_FLAGS                        (LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LE_CONNECTION_UPDATE_REQ */
#define LTP_LE_CONNECTION_UPDATE_REQ                                      0xA7
#define LTP_LE_CONNECTION_UPDATE_REQ_LENGTH                                 13
#define LTP_LE_CONNECTION_UPDATE_REQ_FLAGS                       (LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LE_CONNECTION_UPDATE_IND */
#define LTP_LE_CONNECTION_UPDATE_IND                                      0xA8
#define LTP_LE_CONNECTION_UPDATE_IND_LENGTH                                 13
#define LTP_LE_CONNECTION_UPDATE_IND_FLAGS                       (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* 0xA9 reserved (LTP_LE_CONNECTION_UPDATE_INFO) */

/*--------------------------------------------------------------------------*/
/* GATT_SERVER_STORE_IND */
#define LTP_GATT_SERVER_STORE_IND                                         0xAA
#define LTP_GATT_SERVER_STORE_IND_LENGTH                                    14
#define LTP_GATT_SERVER_STORE_IND_FLAGS          (LTP_VAR_LEN_MSG|LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* AUTH_RESULT_EXT_IND */
#define LTP_AUTH_RESULT_EXT_IND                                           0xAB
#define LTP_AUTH_RESULT_EXT_IND_LENGTH                                      13
#define LTP_AUTH_RESULT_EXT_IND_FLAGS            (LTP_VAR_LEN_MSG|LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* AUTH_RESULT_REQUEST_EXT_IND */
#define LTP_AUTH_RESULT_REQUEST_EXT_IND                                   0xAC
#define LTP_AUTH_RESULT_REQUEST_EXT_IND_LENGTH                              12
#define LTP_AUTH_RESULT_REQUEST_EXT_IND_FLAGS                    (LTP_MDC_MSG)

#define LTP_AUTH_RESULT_REQUEST_EXT_IND_OPT_MASK_RESTART_HANDLE           0x03

/*--------------------------------------------------------------------------*/
/* GATT_SECURITY_REQ */
#define LTP_GATT_SECURITY_REQ                                             0xAD
#define LTP_GATT_SECURITY_REQ_LENGTH                                         8
#define LTP_GATT_SECURITY_REQ_FLAGS                              (LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* 0xAE reserved (LTP_GATT_MTU_INFO) */

/*--------------------------------------------------------------------------*/
/* 0xAF reserved (LTP_GATT_ATTRIBUTE_WRITE_COMMAND_INFO) */


/*--------------------------------------------------------------------------*/
/* LTP_AUTH_DELETE_REQ                                                      */
#define LTP_AUTH_DELETE_REQ                                               0xC1
#define LTP_AUTH_DELETE_REQ_LENGTH                                          10
#define LTP_AUTH_DELETE_REQ_FLAGS                                (LTP_MDH_MSG)

#define LTP_AUTH_DELETE_REQ_OPT_MASK_BD_TYPE                              0x01

/*--------------------------------------------------------------------------*/
/* LTP_AUTH_LIST_REQ                                                        */
#define LTP_AUTH_LIST_REQ                                                 0xC2
#define LTP_AUTH_LIST_REQ_LENGTH                                            10
#define LTP_AUTH_LIST_REQ_FLAGS                                  (LTP_MDH_MSG)

#define LTP_AUTH_LIST_REQ_OPT_MASK_BD_TYPE                                0x01
#define LTP_AUTH_LIST_REQ_OPT_MASK_GET_LATEST                             0x02

/*--------------------------------------------------------------------------*/
/* LTP_EXTEND_COMMAND */
#define LTP_EXTEND_COMMAND                                               0xFA
#define LTP_EXTEND_COMMAND_LENGTH                                           5
#define LTP_EXTEND_COMMAND_FLAGS                            (LTP_VAR_LEN_MSG|LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_SUB_SET_RANDOM_ADDRESS_RSP */
#define LTP_SUB_SET_RANDOM_ADDRESS_RSP                                   0x01
#define LTP_SUB_SET_RANDOM_ADDRESS_RSP_LENGTH                               8
#define LTP_SUB_SET_RANDOM_ADDRESS_RSP_FLAGS                    (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_DEVICE_CONFIG_DEVICE_NAME_SET_RSP */
#define LTP_SUB_DEVICE_CONFIG_DEVICE_NAME_SET_RSP                        0x02
#define LTP_SUB_DEVICE_CONFIG_DEVICE_NAME_SET_RSP_LENGTH                    6
#define LTP_SUB_DEVICE_CONFIG_DEVICE_NAME_SET_RSP_FLAGS         (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_DEVICE_CONFIG_SECURITY_SET_RSP*/
#define LTP_SUB_DEVICE_CONFIG_SECURITY_SET_RSP                           0x03
#define LTP_SUB_DEVICE_CONFIG_SECURITY_SET_RSP_LENGTH                       6
#define LTP_SUB_DEVICE_CONFIG_SECURITY_SET_RSP_FLAGS            (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_DEVICE_CONFIG_STORE_SET_RSP */
#define LTP_SUB_DEVICE_CONFIG_STORE_SET_RSP                              0x04
#define LTP_SUB_DEVICE_CONFIG_STORE_SET_RSP_LENGTH                          6
#define LTP_SUB_DEVICE_CONFIG_STORE_SET_RSP_FLAGS                (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_DEVICE_CONFIG_APPEARANCE_SET_RSP */
#define LTP_SUB_DEVICE_CONFIG_APPEARANCE_SET_RSP                         0x05
#define LTP_SUB_DEVICE_CONFIG_APPEARANCE_SET_RSP_LENGTH                     6
#define LTP_SUB_DEVICE_CONFIG_APPEARANCE_SET_RSP_FLAGS           (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_DEVICE_CONFIG_PER_PREF_CONN_PARAM_SET_RSP */
#define LTP_SUB_DEVICE_CONFIG_PER_PREF_CONN_PARAM_SET_RSP                0x06
#define LTP_SUB_DEVICE_CONFIG_PER_PREF_CONN_PARAM_SET_RSP_LENGTH            6
#define LTP_SUB_DEVICE_CONFIG_PER_PREF_CONN_PARAM_SET_RSP_FLAGS (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_SET_LE_TX_POWER_RSP */
#define LTP_SUB_SET_LE_TX_POWER_RSP                                      0x07
#define LTP_SUB_SET_LE_TX_POWER_RSP_LENGTH                                  9
#define LTP_SUB_SET_LE_TX_POWER_RSP_FLAGS                       (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_SET_DATA_LENGTH_RSP */
#define LTP_SUB_SET_DATA_LENGTH_RSP                                      0x08
#define LTP_SUB_SET_DATA_LENGTH_RSP_LENGTH                                  7
#define LTP_SUB_SET_DATA_LENGTH_RSP_FLAGS                       (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_DATA_LENGTH_CHANGE_INFO */
#define LTP_SUB_DATA_LENGTH_CHANGE_INFO                                  0x09
#define LTP_SUB_DATA_LENGTH_CHANGE_INFO_LENGTH                             14
#define LTP_SUB_DATA_LENGTH_CHANGE_INFO_FLAGS                   (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_DOWNLOAD_SERVICE_DATABASE_RSP */
#define LTP_SUB_DOWNLOAD_SERVICE_DATABASE_RSP                            0x0A
#define LTP_SUB_DOWNLOAD_SERVICE_DATABASE_RSP_LENGTH                        6
#define LTP_SUB_DOWNLOAD_SERVICE_DATABASE_RSP_FLAGS             (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_SUB_CLEAR_SERVICE_DATABASE_RSP */
#define LTP_SUB_CLEAR_SERVICE_DATABASE_RSP                               0x0B
#define LTP_SUB_CLEAR_SERVICE_DATABASE_RSP_LENGTH                           6
#define LTP_SUB_CLEAR_SERVICE_DATABASE_RSP_FLAGS                (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_SUB_GATT_ATTRIBUTE_PREPARE_WRITE_CNF */
#define LTP_SUB_GATT_ATTRIBUTE_PREPARE_WRITE_CNF                         0x0D
#define LTP_SUB_GATT_ATTRIBUTE_PREPARE_WRITE_CNF_LENGTH                    12
#define LTP_SUB_GATT_ATTRIBUTE_PREPARE_WRITE_CNF_FLAGS          (LTP_VAR_LEN_MSG|LTP_CNF_MSG|LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_SUB_GATT_ATTRIBUTE_PREPARE_WRITE_RSP */
#define LTP_SUB_GATT_ATTRIBUTE_PREPARE_WRITE_RSP                         0x0E
#define LTP_SUB_GATT_ATTRIBUTE_PREPARE_WRITE_RSP_LENGTH                    11
#define LTP_SUB_GATT_ATTRIBUTE_PREPARE_WRITE_RSP_FLAGS          (LTP_VAR_LEN_MSG|LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_SUB_GATT_ATTRIBUTE_EXECUTE_WRITE_CNF */
#define LTP_SUB_GATT_ATTRIBUTE_EXECUTE_WRITE_CNF                         0x0F
#define LTP_SUB_GATT_ATTRIBUTE_EXECUTE_WRITE_CNF_LENGTH                    11
#define LTP_SUB_GATT_ATTRIBUTE_EXECUTE_WRITE_CNF_FLAGS          (LTP_CNF_MSG|LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_SUB_GATT_ATTRIBUTE_EXECUTE_WRITE_RSP */
#define LTP_SUB_GATT_ATTRIBUTE_EXECUTE_WRITE_RSP                         0x10
#define LTP_SUB_GATT_ATTRIBUTE_EXECUTE_WRITE_RSP_LENGTH                     9
#define LTP_SUB_GATT_ATTRIBUTE_EXECUTE_WRITE_RSP_FLAGS          (LTP_MDC_MSG)


/*--------------------------------------------------------------------------*/
/* LTP_SUB_LOW_POWER_CONFIG_RSP */
#define LTP_SUB_LOW_POWER_CONFIG_RSP                                     0x11
#define LTP_SUB_LOW_POWER_CONFIG_RSP_LENGTH                                 8
#define LTP_SUB_LOW_POWER_CONFIG_RSP_FLAGS                       (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_SET_RANDOM_ADDRESS_REQ */
#define LTP_SUB_SET_RANDOM_ADDRESS_REQ                                   0x81
#define LTP_SUB_SET_RANDOM_ADDRESS_LENGTH                                  11
#define LTP_SUB_SET_RANDOM_ADDRESS_FLAGS                        (LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_DEVICE_CONFIG_DEVICE_NAME_SET_REQ */
#define LTP_SUB_DEVICE_CONFIG_DEVICE_NAME_SET_REQ                        0x82
#define LTP_SUB_DEVICE_CONFIG_DEVICE_NAME_SET_REQ_LENGTH                    1
#define LTP_SUB_DEVICE_CONFIG_DEVICE_NAME_SET_REQ_FLAGS     (LTP_VAR_LEN_MSG|LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_DEVICE_CONFIG_SECURITY_SET_REQ */
#define LTP_SUB_DEVICE_CONFIG_SECURITY_SET_REQ                           0x83
#define LTP_SUB_DEVICE_CONFIG_SECURITY_SET_REQ_LENGTH                       9
#define LTP_SUB_DEVICE_CONFIG_SECURITY_SET_REQ_FLAGS            (LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_DEVICE_CONFIG_STORE_SET_REQ */
#define LTP_SUB_DEVICE_CONFIG_STORE_SET_REQ                              0x84
#define LTP_SUB_DEVICE_CONFIG_STORE_SET_REQ_LENGTH                          7
#define LTP_SUB_DEVICE_CONFIG_STORE_SET_REQ_FLAGS               (LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_DEVICE_CONFIG_APPEARANCE_SET_REQ */
#define LTP_SUB_DEVICE_CONFIG_APPEARANCE_SET_REQ                         0x85
#define LTP_SUB_DEVICE_CONFIG_APPEARANCE_SET_REQ_LENGTH                     7
#define LTP_SUB_DEVICE_CONFIG_APPEARANCE_SET_REQ_FLAGS          (LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_DEVICE_CONFIG_PER_PREF_CONN_PARAM_SET_REQ */
#define LTP_SUB_DEVICE_CONFIG_PER_PREF_CONN_PARAM_SET_REQ                0x86
#define LTP_SUB_DEVICE_CONFIG_PER_PREF_CONN_PARAM_SET_REQ_LENGTH           13
#define LTP_SUB_DEVICE_CONFIG_PER_PREF_CONN_PARAM_SET_REQ_FLAGS (LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_SET_LE_TX_POWER_REQ */
#define LTP_SUB_SET_LE_TX_POWER_REQ                                      0x87
#define LTP_SUB_SET_LE_TX_POWER_REQ_LENGTH                                  6
#define LTP_SUB_SET_LE_TX_POWER_REQ_FLAGS                       (LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_SET_DATA_LENGTH_REQ */
#define LTP_SUB_SET_DATA_LENGTH_REQ                                      0x88
#define LTP_SUB_SET_DATA_LENGTH_REQ_LENGTH                                 10
#define LTP_SUB_SET_DATA_LENGTH_REQ_FLAGS                       (LTP_MDH_MSG)
/*--------------------------------------------------------------------------*/
/* 0x89 reserved (LTP_SUB_DATA_LENGTH_CHANGE_INFO) */

/*--------------------------------------------------------------------------*/
/* LTP_DOWNLOAD_SERVICE_DATABASE_REQ */
#define LTP_SUB_DOWNLOAD_SERVICE_DATABASE_REQ                            0x8A
#define LTP_SUB_DOWNLOAD_SERVICE_DATABASE_REQ_LENGTH                       10
#define LTP_SUB_DOWNLOAD_SERVICE_DATABASE_REQ_FLAGS         (LTP_VAR_LEN_MSG|LTP_MDH_MSG)

#define LTP_SUB_DOWNLOAD_SERVICE_DATABASE_REQ_OPT_MASK_SRV_LEN           0x03
/*--------------------------------------------------------------------------*/
/* LTP_SUB_CLEAR_SERVICE_DATABASE_REQ */
#define LTP_SUB_CLEAR_SERVICE_DATABASE_REQ                               0x8B
#define LTP_SUB_CLEAR_SERVICE_DATABASE_REQ_LENGTH                           5
#define LTP_SUB_CLEAR_SERVICE_DATABASE_REQ_FLAGS                (LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_SUB_GATT_ATTRIBUTE_PREPARE_WRITE_IND */
#define LTP_SUB_GATT_ATTRIBUTE_PREPARE_WRITE_IND                         0x8D
#define LTP_SUB_GATT_ATTRIBUTE_PREPARE_WRITE_IND_LENGTH                    13
#define LTP_SUB_GATT_ATTRIBUTE_PREPARE_WRITE_IND_FLAGS       (LTP_VAR_LEN_MSG|LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_SUB_GATT_ATTRIBUTE_PREPARE_WRITE_REQ */
#define LTP_SUB_GATT_ATTRIBUTE_PREPARE_WRITE_REQ                         0x8E
#define LTP_SUB_GATT_ATTRIBUTE_PREPARE_WRITE_REQ_LENGTH                    10
#define LTP_SUB_GATT_ATTRIBUTE_PREPARE_WRITE_REQ_FLAGS       (LTP_VAR_LEN_MSG|LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_SUB_GATT_ATTRIBUTE_EXECUTE_WRITE_IND */
#define LTP_SUB_GATT_ATTRIBUTE_EXECUTE_WRITE_IND                         0x8F
#define LTP_SUB_GATT_ATTRIBUTE_EXECUTE_WRITE_IND_LENGTH                    7
#define LTP_SUB_GATT_ATTRIBUTE_EXECUTE_WRITE_IND_FLAGS          (LTP_MDC_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_SUB_GATT_ATTRIBUTE_EXECUTE_WRITE_REQ */
#define LTP_SUB_GATT_ATTRIBUTE_EXECUTE_WRITE_REQ                         0x90
#define LTP_SUB_GATT_ATTRIBUTE_EXECUTE_WRITE_REQ_LENGTH                     7
#define LTP_SUB_GATT_ATTRIBUTE_EXECUTE_WRITE_REQ_FLAGS          (LTP_MDH_MSG)

/*--------------------------------------------------------------------------*/
/* LTP_SUB_LOW_POWER_CONFIG_REQ */
#define LTP_SUB_LOW_POWER_CONFIG_REQ                                     0x91
#define LTP_SUB_LOW_POWER_CONFIG_REQ_LENGTH                                 9
#define LTP_SUB_LOW_POWER_CONFIG_REQ_FLAGS                       (LTP_MDH_MSG)

#ifdef __cplusplus
extern "C" {
#endif

/* needed message structures                                                */

/* data structure to describe message properties                            */
typedef struct
{
    BYTE opcode;
    BYTE length;
    BYTE properties;
} LTPCmdInfo;
typedef LTPCmdInfo FAR* PLTPCmdInfo;

/* internal Status definition for LTP-Lib                                   */
typedef enum
{
    LTPLibStatusIdle,             /* ready to be called with 'LTPLibxxx' call*/
    LTPLibStatusResync,           /* Lib is ready for re-sync                */
    LTPLibStatusBusy,             /* busy with 'LTPLibxxx' call (re-entrant) */
    LTPLibStatusOffSync           /* Lib detected sync loss in receive data  */
} TLTPStatus;

/* internal data container definition for LTP-Lib                           */
typedef struct
{
    WORD   Offset;                 /* offset to data in data buffer           */
    WORD   Length;                 /* length of data                          */
    LPBYTE BufferAddress;          /* buffer address                          */
} LTP_DATA_CB_T;
typedef LTP_DATA_CB_T FAR * LTP_DATA_CB_P;

/* internal data container definition for queue elements                    */
struct ltpQueueElement                                /* dummy definition      */
{
    struct ltpQueueElement  *Next;                      /* point to next element */
    BYTE                    data[2];                    /* user data             */
};
typedef struct ltpQueueElement LTP_ELEMENT_T;
typedef LTP_ELEMENT_T *LTP_ELEMENT_P;

/* internal data container definition for queue elements                    */
typedef struct
{
    LTP_ELEMENT_P First;                                 /* first element         */
    LTP_ELEMENT_P Last;                                  /* last element          */
    WORD          ElementCount;                          /* element count         */
} LTP_QUEUE_T, *LTP_QUEUE_P;

void  ltpQueueIn(LTP_QUEUE_P QueuePtr, void *pQueueElement);
void *ltpQueueOut(LTP_QUEUE_P QueuePtr);

/* internal queue-element for LTP-Lib for data container                    */
typedef struct
{
    /* This MUST be the FIRST structure element ! */
    LTP_ELEMENT_T  QueueElement;
    /* the 'real' data...                         */
    LTP_DATA_CB_T  DataCB;
} TLTPElement;
typedef TLTPElement FAR* PLTPElement;

#if F_LTPLIB_ASYNC_ASSEMBLY_SUPPORT
/* internal Async assemply Status definition for LTP-Lib                    */
typedef enum
{
    LTPLibAsyncStatusIgnore,           /* waiting for precede idle time      */
    LTPLibAsyncStatusWaitCMD,          /* wait for command Byte              */
    LTPLibAsyncStatusWaitCopMsk,       /* wait for CopMsk Byte               */
    LTPLibAsyncStatusWaitLen1,         /* wait for first length Byte         */
    LTPLibAsyncStatusWaitLen1HeaderCRC,/* wait for first length Byte and CRC */
    LTPLibAsyncStatusWaitLen2,         /* wait for second length Byte        */
    LTPLibAsyncStatusWaitLen2HeaderCRC,/* wait for second length Byte and CRC*/
    LTPLibAsyncStatusWaitHeaderCRC,    /* wait for header CRC byte           */
    LTPLibAsyncStatusWaitTimeout       /* wait for consecutive idle time     */
} TLTPAsyncStatus;

/* ID to identify addressed timer for timer/timeout functions               */
typedef enum
{
    LTPLibTimerID_AsyncTimeout
} TLTPTimerID;
typedef TLTPTimerID FAR * PLTPTimerID;
#endif /* F_LTPLIB_ASYNC_ASSEMBLY_SUPPORT */

/* internal context definition for LTP-Lib. When ever a LTP-Lib function is */
/*  called, a pointer to this context must be provided                      */
typedef struct
{
    LTP_TGT_APPHANDLE   AppHandle;
    TLTPStatus          Status;
    WORD                ReceiveOffset;
    WORD                ReceiveMaxLength;
    WORD                SendOffset;
    WORD                LTPMsgStart;
    PLTPElement         pActiveElement;
    LPBYTE              pLTPMsg;
    WORD                LTPMsgPos;
    WORD                LTPMsgLength;
#if F_LTPLIB_ASYNC_ASSEMBLY_SUPPORT
    TLTPAsyncStatus     AsyncState;
#endif
    LTP_QUEUE_T         UsedElementQueue;
    WORD                LTPDataCollected;
} TLTPLib;
typedef TLTPLib * PLTPLib;

/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/**                                                                        **/
/** 4) Target specifics that must be implemented by the user of the LTP-Lib**/
/**                                                                        **/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/

/****************************************************************************/
/* LPBYTE BTLTPTgtSendBufferAlloc                                           */
/* (                                                                        */
/*    LTP_TGT_APPHANDLE AppHandle : Handle to identify application context  */
/*    WORD              len       : size of buffer to be allocated (bytes)  */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* pointer to allocated memory in case of success                           */
/* NULL pointer in case of an error                                         */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This target specific function is used to allocate buffers for LTP        */
/* messages that are send to an application with the BT_LTP_Sendxxx         */
/* functions of this library.                                               */
/*                                                                          */
/* TODO: please implement this function for your target                     */
/*                                                                          */
/****************************************************************************/
LPBYTE BTLTPTgtSendBufferAlloc(LTP_TGT_APPHANDLE AppHandle, WORD len);

/****************************************************************************/
/* LPBYTE BTLTPTgtAssemblyBfferAlloc                                        */
/* (                                                                        */
/*    LTP_TGT_APPHANDLE AppHandle : Handle to identify application context  */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* pointer to allocated memory in case of success                           */
/* NULL pointer in case of no buffer available (this is no error condition) */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This target specific function is used to allocate buffers for LTP-       */
/* message assembly that is processed by functions of this library.         */
/*                                                                          */
/* TODO: please implement this function for your target                     */
/*                                                                          */
/****************************************************************************/
LPBYTE BTLTPTgtAssemblyBufferAlloc(LTP_TGT_APPHANDLE AppHandle);
void BTLTPBufferCallback(THandle Handle);
/****************************************************************************/
/* void BTLTPTgtReceiveBufferRelease                                        */
/* (                                                                        */
/*    LTP_TGT_APPHANDLE AppHandle : Handle to identify application context  */
/*    LPBYTE            pBuffer   : pointer to receive buffer to be released*/
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* non                                                                      */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This target specific function is used to released buffers for LTP        */
/* messages that are received and consumed by the 'LTPLibHandleReceiveData' */
/* function of this library.                                                */
/*                                                                          */
/* TODO: please implement this function for your target                     */
/*                                                                          */
/****************************************************************************/
void BTLTPTgtReceiveBufferRelease(LTP_TGT_APPHANDLE AppHandle, LPBYTE pBuffer);

/****************************************************************************/
/* BOOL BTLTPTgtSendLTPMessage                                              */
/* (                                                                        */
/*    LTP_TGT_APPHANDLE AppHandle : Handle to identify application context  */
/*    LPBYTE            pMsg      : pointer to of LTP msg buffer to be send */
/*    WORD              offset                                              */
/*    WORD              dataLen                                             */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message could be send successfully,                     */
/* FALSE in case the message could not be send but was dumped               */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function is used to send an LTP message to an application with the  */
/* BT_LTP_Sendxxx functions of this library                                 */
/*                                                                          */
/* TODO: please implement this function for your target                     */
/*                                                                          */
/****************************************************************************/
BOOL BTLTPTgtSendLTPMessage(LTP_TGT_APPHANDLE AppHandle, LPBYTE pMsg, WORD offset, WORD dataLen);

/****************************************************************************/
/* BOOL BTLTPTgtHandleLTPMessage                                            */
/* (                                                                        */
/*    LTP_TGT_APPHANDLE AppHandle : Handle to identify application context  */
/*    LPBYTE            pMsgBuffer: pointer to message buffer               */
/*    BYTE              cmd       : identifier for LTP-command to be handled*/
/*    BYTE              copmsk    : copmsk of LPT-command to be handled     */
/*    LPBYTE            pOpt      : pointer to optional parameters of LTP-  */
/*                                  command to be handled, or NULL in case  */
/*                                  of no optional parameters included      */
/*    WORD              lenPara   : length of mandatory parameters of LTP-  */
/*                                  command to be handled                   */
/*    LPBYTE            pPara     : pointer to mandatory parameters of LTP- */
/*                                  command to be handled, or NULL in case  */
/*                                  of no mandatory parameters included     */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* FALSE in case the message buffer shall not be re-used for LTP-msg        */
/* assembly by the LTP-Lib, otherwise TRUE                                  */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function is called by the LTP-Lib if a complete LTP message is      */
/* assembled and is ready to be consumed by the application                 */
/*                                                                          */
/* TODO: please implement this function for your target                     */
/*                                                                          */
/****************************************************************************/
BOOL BTLTPTgtHandleLTPMessage(LTP_TGT_APPHANDLE AppHandle, LPBYTE pMsgBuffer, BYTE cmd,
                              BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara);

/****************************************************************************/
/* PLTPElement BTLTPTgtQueueElementAlloc                                    */
/* (                                                                        */
/*    LTP_TGT_APPHANDLE AppHandle : Handle to identify application context  */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* pointer to allocated queue element in case of success                    */
/* NULL pointer in case of no queue element available (this is no error     */
/* condition)                                                               */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This target specific function is used to allocate queue elements for LTP-*/
/* message assembly that is processed by functions of this library.         */
/*                                                                          */
/* TODO: please implement this function for your target                     */
/*                                                                          */
/****************************************************************************/
PLTPElement BTLTPTgtQueueElementAlloc(LTP_TGT_APPHANDLE AppHandle);

/****************************************************************************/
/* void BTLTPTgtQueueElementRelease                                         */
/* (                                                                        */
/*    LTP_TGT_APPHANDLE AppHandle : Handle to identify application context  */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* non                                                                      */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This target specific function is used to release queue elements for LTP- */
/* message assembly that is processed by functions of this library.         */
/*                                                                          */
/* TODO: please implement this function for your target                     */
/*                                                                          */
/****************************************************************************/
void BTLTPTgtQueueElementRelease(LTP_TGT_APPHANDLE AppHandle, PLTPElement pLTPElement);

#if F_LTPLIB_ASYNC_ASSEMBLY_SUPPORT
/****************************************************************************/
/* void BTLTPTgtTriggerTimer                                                */
/* (                                                                        */
/*    LTP_TGT_APPHANDLE AppHandle : Handle to identify application context  */
/*    TLTPTimerID       timerID   : ID to identify addressed timer          */
/*    WORD              timeout_ms: new timeout for addressed timer in ms   */
/* )                                                                        */
/****************************************************************************/
void BTLTPTgtTriggerTimer(LTP_TGT_APPHANDLE AppHandle, TLTPTimerID timerID, WORD timeout_ms);

/****************************************************************************/
/* void BTLTPTgtHandleAsyncLTP_RESET_REQ                                    */
/* (                                                                        */
/*    LTP_TGT_APPHANDLE AppHandle : Handle to identify application context  */
/* )                                                                        */
/****************************************************************************/
void BTLTPTgtHandleAsyncLTP_RESET_REQ(LTP_TGT_APPHANDLE AppHandle);
#endif /* F_LTPLIB_ASYNC_ASSEMBLY_SUPPORT */

/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/**                                                                        **/
/** 5) Utility fuctions that have to be integrated for using the LTP-Lib   **/
/**                                                                        **/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/

/****************************************************************************/
/* BOOL LTPLibInitialize                                                    */
/* (                                                                        */
/*    PLTPLib      pLTPLib        : pointer to LTP context to be initialized*/
/*    LTP_TGT_APPHANDLE AppHandle : Handle to identify application context  */
/*    WORD              receiveOffset : offset for assembled LTP-messages   */
/*    WORD              receiveMaxLen : max len for assembled LTP-messages  */
/*    WORD              sendOffset    : offset for LTP-messages to be send  */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/*  FALSE if an internal error occured and the lib is not functional,       */
/*  TRUE otherwise (in case of success)                                     */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function has to be called to initialize the LTP-Lib at system       */
/* startup and/or reset                                                     */
/*                                                                          */
/* TODO: please integrate this function into the target implementation      */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibInitialize(PLTPLib pLTPLib, LTP_TGT_APPHANDLE AppHandle, WORD receiveOffset,
                      WORD receiveMaxLen, WORD sendOffset);

/****************************************************************************/
/* BOOL LTPLibShutdown                                                      */
/* (                                                                        */
/*    PLTPLib      pLTPLib        : pointer to LTP context to be initialized*/
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/*  FALSE if an internal error occured and the lib is not functional,       */
/*  TRUE otherwise (in case of success)                                     */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function may be called to free all resources used by LTP-Lib        */
/*                                                                          */
/* TODO: please integrate this function into the target implementation      */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibShutdown(PLTPLib pLTPLib);

#if F_LTPLIB_ASYNC_ASSEMBLY_SUPPORT
/****************************************************************************/
/* void LTPLibHandleTimeout                                                 */
/* (                                                                        */
/*    PLTPLib     pLTPLib  : pointer to LTP context to be used              */
/*    TLTPTimerID timerID  : timer that timed out                           */
/* )                                                                        */
/****************************************************************************/
void LTPLibHandleTimeout(PLTPLib pLTPLib, TLTPTimerID timerID);
#endif

/****************************************************************************/
/* BOOL LTPLibHandleReceiveData                                             */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    LPBYTE  pRxBuffer    : pointer to buffer that contains new data       */
/*    WORD    rxLength     : length of new data received                    */
/*    WORD    rxOffset     : offset of new data in buffer                   */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/*  FALSE data could NOT be handled properly,                               */
/*  TRUE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function has to be called to introduce new rx data received into    */
/* the LTP-Lib statemachine when ever new data is received                  */
/*                                                                          */
/* TODO: please integrate this function into the target implementation      */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibHandleReceiveData(PLTPLib pLTPLib, LPBYTE pRxBuffer, WORD rxLength, WORD rxOffset);

/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/**                                                                        **/
/** 6) Utility functions that can be used by the user of the LTP-Lib       **/
/**                                                                        **/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/



/****************************************************************************/
/* WORD LTPLibInsertHeader                                                  */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    LPBYTE  pBuffer      : pointer to data buffer containing payload      */
/*    LPWORD  offset       : pointer to the offset of the payload           */
/*                           after call: offset of the message in buffer    */
/*    WORD    dataLen      : payload length in buffer                       */
/*    BYTE    cmd          : ltp command                                    */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    LPWORD  posParam     : after call: offset of the first parameter      */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* length of the ltp message in pBuffer beginning from *offset              */
/* if length is 0, the header could not be inserted                         */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to insert a LTP message header with optional   */
/* parameters infront of a given message buffer with payload                */
/*                                                                          */
/****************************************************************************/
WORD LTPLibInsertHeader(PLTPLib pLTPLib, LPBYTE pBuffer, LPWORD offset, WORD dataLen, BYTE cmd, BYTE copmsk, LPBYTE pOpt, LPWORD posParam);
WORD LTPLibInsertExtendHeader(PLTPLib pLTPLib, LPBYTE pBuffer, LPWORD offset, WORD dataLen, BYTE subCmd, BYTE copmsk, LPBYTE pOpt, LPWORD posParam);
/****************************************************************************/
/* BOOL LTPLibSendDeviceConfigDeviceSetRsp                                   */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result cause for this message                  */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/* Porting to BlueAPI+:-----------------------------------------------------*/
/* The corresponding function in the Stollmann system internal software API */
/* BlueAPI+ for using LTP functionality without serial link interface is    */
/* blueAPI_SendDeviceConfigSetReq(...)                                      */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendDeviceConfigDeviceNameSetRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause);
BOOL LTPLibSendDeviceConfigAppearanceSetRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause);
BOOL LTPLibSendDeviceConfigStoreSetRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause);
BOOL LTPLibSendDeviceConfigPerPrefConnParamSetRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause);

/****************************************************************************/
/* BOOL LTPLibSendDeviceConfigSecuritySetRsp                                */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result cause for this message                  */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/* Porting to BlueAPI+:-----------------------------------------------------*/
/* The corresponding function in the Stollmann system internal software API */
/* BlueAPI+ for using LTP functionality without serial link interface is    */
/* blueAPI_SendDeviceConfigSetReq(...)                                      */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendDeviceConfigSecuritySetRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause);


/****************************************************************************/
/* BOOL LTPLibSendPairableModeSetRsp                                        */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result code for this message                   */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendPairableModeSetRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause);

/****************************************************************************/
/* BOOL LTPLibSendPasskeyReqReplyRsp                                        */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result code for this message                   */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendPasskeyReqReplyRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause);

/****************************************************************************/
/* BOOL LTPLibSendActInfo                                                   */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result code for this message                   */
/*    BYTE    version      : version of supported LTP protocol              */
/*    LPBYTE  local_BD     : Bluetooth device address of local device       */
/*    LPBYTE  FW_VersionString : human readable version string for FW vers. */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send successfully                           */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendActInfo(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause, BYTE version, LPBYTE local_BD, LPBYTE FW_VersionString);

/****************************************************************************/
/* BOOL LTPLibSendPasskeyNotificationInfo                                   */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    LPBYTE  rem_BD       : Bluetooth device address of remote device      */
/*    DWORD   displayValue : value to be displayed                          */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send successfully                           */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendPasskeyNotificationInfo(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, LPBYTE rem_BD, DWORD displayValue);

/****************************************************************************/
/* BOOL LTPLibSendMCLStatusInfo                                             */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    LPBYTE  rem_BD       : Bluetooth device address of remote device      */
/*    BYTE    loc_MCL_ID   : Identifier to referenced MCL                   */
/*    BYTE    loc_MCL_Status : status of referenced MCL                     */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send successfully                           */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendMCLStatusInfo(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, LPBYTE rem_BD, BYTE loc_MCL_ID, BYTE loc_MCL_Status);

/****************************************************************************/
/* BOOL LTPLibSendACLStatusInfo                                             */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    LPBYTE  rem_BD       : Bluetooth device address of remote device      */
/*    BYTE    loc_MCL_Status : status of referenced MCL                     */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send successfully                           */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendACLStatusInfo(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, LPBYTE rem_BD,
                             BYTE loc_MCL_Status);


/****************************************************************************/
/* BOOL LTPLibSendPasskeyRequestInd                                         */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP-Context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to potional parameter structure        */
/*    LPBYTE  rem_BD       : Bluetooth device address of remote device      */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the was send send successfully                              */
/* FALSE otherwhise                                                         */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendPasskeyRequestInd(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, LPBYTE rem_BD);

/****************************************************************************/
/* BOOL LTPLibSendRemoteOOBRequestInd                                       */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP-Context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to potional parameter structure        */
/*    LPBYTE  rem_BD       : Bluetooth device address of remote device      */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the was send send successfully                              */
/* FALSE otherwhise                                                         */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendRemoteOOBRequestInd(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, LPBYTE rem_BD);


/****************************************************************************/
/* BOOL LTPLibSendResultInd                                                 */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP-Context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to potional parameter structure        */
/*    BYTE    cause        : result of authentication                       */
/*    LPBYTE  rem_BD       : Bluetooth device address of remote device      */
/*    BYTE    rem_BD_Type  : Type of Bluetooth address                      */
/*    BYTE    keyType      : type of the generated linkkey                  */
/*    DWORD   appData      : Application specific data                      */
/*    LPBYTE  linkKey      : Bluetooth Linkkey                              */
/*    WORD    linkKeyLength: Length of Linkkey data                         */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the was send send successfully                              */
/* FALSE otherwhise                                                         */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendAuthResultExtInd(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause,
                                LPBYTE rem_BD, BYTE rem_BD_Type, BYTE keyType,
                                LPBYTE linkKey, WORD linkKeyLength);

/****************************************************************************/
/* BOOL LTPLibSendAuthResultRequestExtInd                                   */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP-Context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to potional parameter structure        */
/*    LPBYTE  rem_BD       : Bluetooth device address of remote device      */
/*    BYTE    rem_BD_Type  : Type of Bluetooth address                      */
/*    BYTE    keyType      : type of the generated linkkey                  */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the was send send successfully                              */
/* FALSE otherwhise                                                         */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendAuthResultRequestExtInd(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, LPBYTE rem_BD, BYTE rem_BD_Type, BYTE keyType);


/****************************************************************************/
/* BOOL LTPLibSendInternalEventInfo                                         */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP-Context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to potional parameter structure        */
/*    BYTE    cause        : result code for this message                   */
/*    BYTE    eventType    : indicates the result of an transaction         */
/*    DWORD   eventInfo    : additional information for this event          */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the was send send successfully                              */
/* FALSE otherwhise                                                         */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendInternalEventInfo(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt,
                                 BYTE cause, BYTE eventType, DWORD eventInfo);

/****************************************************************************/
/* BOOL LTPLibSendCreateMDLInd                                              */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    LPBYTE  rem_BD       : Bluetooth device address of remote device      */
/*    BYTE    loc_MDL_ID   : reference to local MDL identifier              */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendCreateMDLInd(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, LPBYTE rem_BD, BYTE loc_MDL_ID);


/****************************************************************************/
/* BOOL LTPLibSendConnectMDLInfo                                            */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    loc_MDL_ID   : reference to local MDL identifier              */
/*    WORD    maxLTPSize   : max LTP message size for this MDL              */
/*    WORD    maxAPDUSize  : max APDU size for this MDL                     */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendConnectMDLInfo(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE loc_MDL_ID,
                              WORD maxLTPSize, WORD maxAPDUSize);

/****************************************************************************/
/* BOOL LTPLibSendDisconnectMDLInd                                          */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result code for this message                   */
/*    BYTE    loc_MDL_ID   : reference to local MDL identifier              */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendDisconnectMDLInd(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause, BYTE loc_MDL_ID);

/****************************************************************************/
/* BOOL LTPLibSendDeleteMDLInfo                                             */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    loc_MDL_ID   : reference to local MDL identifier              */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendDeleteMDLInfo(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE loc_MDL_ID);

/****************************************************************************/
/* BOOL LTPLibSendDisconnectMDLRsp                                          */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result code for this message                   */
/*    BYTE    loc_MDL_ID   : reference to local MDL identifier              */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendDisconnectMDLRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause, BYTE loc_MDL_ID);


/****************************************************************************/
/* BOOL LTPLibSendResetRsp                                                  */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result code for this message                   */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendResetRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause);


/****************************************************************************/
/* BOOL LTPLibSendGATTServiceRegisterRsp                                    */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result code for this message                   */
/*    WORD    subcause     : detailed result information from lower layers  */
/*    BYTE    serviceHandle: handle used for service related transactions   */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendGATTServiceRegisterRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause, WORD subCause, BYTE serviceHandle);



/****************************************************************************/
/* BOOL LTPLibSendGATTAttributeUpdateStatusInd                              */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result code for this message                   */
/*    WORD    subcause     : detailed result information from lower layers  */
/*    BYTE    serviceHandle: handle of service that contains the attribute  */
/*    BYTE    requestHandle: request handle from attribute update request   */
/*    WORD    attribIndex  : index of attribute in service descriptor array */
/*    LPBYTE  rem_BD       : Bluetooth device address of remote device      */
/*    BYTE    rem_BD_Type  : Type of Bluetooth address                      */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendGATTAttributeUpdateStatusInd(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause, WORD subCause, BYTE serviceHandle, void * requestHandle, WORD attribIndex, LPBYTE rem_BD, BYTE rem_BD_Type);

/****************************************************************************/
/* BOOL LTPLibSendGATTAttributeReadInd                                      */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    loc_MDL_ID   : reference to local MDL identifier              */
/*    BYTE    serviceHandle: handle of service that contains the attribute  */
/*    WORD    attribIndex  : index of attribute in service descriptor array */
/*    WORD    readOffset   : offset in attribute                            */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendGATTAttributeReadInd(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE loc_MDL_ID, BYTE serviceHandle, WORD attribIndex, WORD readOffset);

/****************************************************************************/
/* BOOL LTPLibSendGATTServerStoreInd                                        */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    opCode       : requested operation                            */
/*    LPBYTE  rem_BD       : Bluetooth device address of remote device      */
/*    BYTE    rem_BD_Type  : Type of Bluetooth address                      */
/*    WORD    restartHandle: used for multiple data message                 */
/*    LPBYTE  data         : up to 32byte of data                           */
/*    WORD    dataLength   : length of data parameter                       */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendGATTServerStoreInd(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE opCode, LPBYTE rem_BD, BYTE rem_BD_Type, WORD restartHandle, LPBYTE data, WORD dataLength);

/****************************************************************************/
/* BOOL LTPLibSendConnectGATTMDLRsp                                         */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result code for this message                   */
/*    LPBYTE  rem_BD       : Bluetooth device address of remote device      */
/*    BYTE    rem_BD_Type  : Type of Bluetooth address                      */
/*    BYTE    loc_MDL_ID   : reference to local MDL identifier              */
/*    BYTE    loc_MDEP_ID  : local MDEP ID from connect request             */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendConnectGATTMDLRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause, LPBYTE rem_BD, BYTE rem_BD_Type, BYTE loc_MDL_ID, BYTE loc_MDEP_ID);

/****************************************************************************/
/* BOOL LTPLibSendGATTDiscoveryRsp                                          */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result code for this message                   */
/*    WORD    subcause     : detailed result information from lower layers  */
/*    BYTE    loc_MDL_ID   : reference to local MDL identifier              */
/*    BYTE    discoveryType: type of discovery                              */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendGATTDiscoveryRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause, WORD subCause, BYTE loc_MDL_ID, BYTE discoveryType);

/****************************************************************************/
/* BOOL LTPLibSendGATTAttributeWriteRsp                                     */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result code for this message                   */
/*    WORD    subcause     : detailed result information from lower layers  */
/*    BYTE    loc_MDL_ID   : reference to local MDL identifier              */
/*    BYTE    writeType    : type of write                                  */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendGATTAttributeWriteRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause, WORD subCause, BYTE loc_MDL_ID, BYTE writeType);

/****************************************************************************/
/* BOOL LTPLibSendGATTAttributeNotificationInfo                             */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    loc_MDL_ID   : reference to local MDL identifier              */
/*    WORD    attribHandle : handle of attribute                            */
/*    LPBYTE  data         : attribute data                                 */
/*    WORD    dataLength   : length of attribute data                       */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendGATTAttributeNotificationInfo(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE loc_MDL_ID, WORD attribHandle, LPBYTE data, WORD dataLength);

/****************************************************************************/
/* BOOL LTPLibSendGATTSecurityRsp                                           */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result code for this message                   */
/*    BYTE    loc_MDL_ID   : reference to local MDL identifier              */
/*    BYTE    keyType      : generated linkkey type                         */
/*    BYTE    keySize      : size of generated linkkey                      */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendGATTSecurityRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause, BYTE loc_MDL_ID, BYTE keyType, BYTE keySize);


/****************************************************************************/
/* BOOL LTPLibSendGATTMtuSizeInfo                                           */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    loc_MDL_ID   : reference to local MDL identifier              */
/*    WORD    mtuSize      : MTU size used for this link                    */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendGATTMtuSizeInfo(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE loc_MDL_ID, WORD mtuSize);

/****************************************************************************/
/* BOOL LTPLibSendLEAdvertiseRsp                                            */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result code for this message                   */
/*    BYTE    advMode      : advertising mode from Advertise request        */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendLEAdvertiseRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause, BYTE advMode);
BOOL LTPLibSendSetRandomAddressRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause, WORD subCause);


/****************************************************************************/
/* BOOL LTPLibSendLEAdvertiseParameterSetRsp                                */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result code for this message                   */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendLEAdvertiseParameterSetRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause);

/****************************************************************************/
/* BOOL LTPLibSendLEAdvertiseDataSetRsp                                     */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result code for this message                   */
/*    BYTE    dataType     : data type from Advertise Data Set Request      */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendLEAdvertiseDataSetRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause, BYTE dataType);

/****************************************************************************/
/* BOOL LTPLibSendLEScanRsp                                                 */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result code for this message                   */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendLEScanRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause);

/****************************************************************************/
/* BOOL LTPLibSendLEScanInfo                                                */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    LPBYTE  rem_BD       : Bluetooth device address of remote device      */
/*    BYTE    rem_BD_Type  : Type of Bluetooth address                      */
/*    BYTE    advType      : Type of advertising event                      */
/*    BYTE    rssi         : remote signal strength indication              */
/*    BYTE    data         : advertising data / scan response data          */
/*    WORD    dataLength   : length of data part                            */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendLEScanInfo(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, LPBYTE rem_BD, BYTE rem_BD_Type, BYTE advType, BYTE rssi, LPBYTE data, WORD dataLength);

/****************************************************************************/
/* BOOL LTPLibSendLEModifyWhitelistRsp                                      */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result code for this message                   */
/*    BYTE    whitelistOp  : whitelist operation from request               */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendLEModifyWhitelistRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause, BYTE whitelistOp);

/****************************************************************************/
/* BOOL LTPLibSendLEConnectionUpdateRsp                                     */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    cause        : result code for this message                   */
/*    BYTE    loc_MDL_ID   : reference to local MDL identifier              */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendLEConnectionUpdateRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause, BYTE loc_MDL_ID);

/****************************************************************************/
/* BOOL LTPLibSendLEConnectionUpdateInd                                     */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    loc_MDL_ID   : reference to local MDL identifier              */
/*    WORD    connIntervalMin   : minimum connection interval               */
/*    WORD    connIntervalMax   : maximum connection interval               */
/*    WORD    connLatency       : connection latency                        */
/*    WORD    supervisionTimeout: supervision timeout                       */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendLEConnectionUpdateInd(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE loc_MDL_ID, WORD connIntervalMin, WORD connIntervalMax, WORD connLatency, WORD supervisionTimeout);

/****************************************************************************/
/* BOOL LTPLibSendLEConnectionParameterInfo                                 */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    copmsk       : bitmask defining content of optional parameter */
/*    LPBYTE  pOpt         : pointer to optional parameter structure        */
/*    BYTE    loc_MDL_ID   : reference to local MDL identifier              */
/*    WORD    connInterval : current connection interval                    */
/*    WORD    connLatency  : current connection latency                     */
/*    WORD    supervisionTimeout: current supervision timeout               */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendLEConnectionParameterInfo(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE loc_MDL_ID, WORD connInterval, WORD connLatency, WORD supervisionTimeout);
BOOL LTPLibSendSetBleTxPowerRsp(PLTPLib pLTPLib, BYTE tx_power_index, BYTE cause, WORD subCause);
BOOL LTPLibSendSetDataLengthRsp(PLTPLib pLTPLib, BYTE loc_MDL_ID, BYTE cause);
BOOL LTPLibSendDataLengthChangeInfo(PLTPLib pLTPLib, BYTE loc_MDL_ID, WORD MaxTxOctets, WORD MaxTxTime, WORD MaxRxOctets, WORD MaxRxTime);
BOOL LTPLibSendDownloadServiceDatabaseRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause);
BOOL LTPLibSendClearServiceDatabaseRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause);
BOOL LTPLibSendGATTAttributeExecuteWriteRsp(PLTPLib pLTPLib, BYTE loc_MDL_ID, BYTE cause, WORD subCause);
BOOL LTPLibSendGATTAttributeExecuteWriteInd(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE loc_MDL_ID, BYTE flags);
BOOL LTPLibSendLowPowerConfigRsp(PLTPLib pLTPLib, BYTE cause, BYTE hostPwrMode, BYTE beePwrMode);
BOOL LTPLibSendAuthDeleteRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause, LPBYTE rem_BD);
BOOL LTPLibSendAuthListRsp(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, BYTE cause, LPBYTE rem_BD);
BOOL LTPLibSendAuthListInfo(PLTPLib pLTPLib, BYTE copmsk, LPBYTE pOpt, LPBYTE rem_BD, BYTE keyType);
/****************************************************************************/
/* BOOL LTPLibSendPairableModeSetReq                                        */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    enablePairableMode   : TRUE if pairable mode is enabled       */
/*    BYTE    BluetoothMode        : supported Bluetooth mode if pairable   */
/*    BYTE    AuthRequirements     : authentication requirements if pairable*/
/*    BYTE    IOCapabilities       : capabilities for auhtentication        */
/*    BYTE    remoteOOBDataPresent : TRUE if remote OOB data present        */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/* Porting to BlueAPI+:-----------------------------------------------------*/
/* The corresponding function in the Stollmann system internal software API */
/* BlueAPI+ for using LTP functionality without serial link interface is    */
/* blueAPI_PairableModeSetReq(...)                                          */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendPairableModeSetReq(PLTPLib pLTPLib, BYTE enablePairableMode, BYTE AuthRequirements, BYTE IOCapabilities, BYTE remoteOOBDataPresent);

/****************************************************************************/
/* BOOL LTPLibSendPasskeyReqReplyReq                                        */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    LPBYTE  rem_BD       : Bluetooth device address of remote device      */
/*    DWORD   passKey      : result of Keyboard input                       */
/*    BYTE    cause        : result code for this message                   */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/* Porting to BlueAPI+:-----------------------------------------------------*/
/* The corresponding function in the Stollmann system internal software API */
/* BlueAPI+ for using LTP functionality without serial link interface is    */
/* blueAPI_UserPasskeyReqReplyReq(...)                                      */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendPasskeyReqReplyReq(PLTPLib pLTPLib, LPBYTE rem_BD, DWORD passKey, BYTE cause );


/****************************************************************************/
/* BOOL LTPLibSendPasskeyRequestCnf                                         */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    LPBYTE  rem_BD       : Bluetooth device address of remote device      */
/*    BYTE    cause        : result code for this message                   */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/* Porting to BlueAPI+:-----------------------------------------------------*/
/* The corresponding function in the Stollmann system internal software API */
/* BlueAPI+ for using LTP functionality without serial link interface is    */
/* blueAPI_UserPasskeyReqConf(...)                                          */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendPasskeyRequestCnf(PLTPLib pLTPLib, LPBYTE rem_BD, BYTE cause);

/****************************************************************************/
/* BOOL LTPLibSendRemoteOOBReqCnf                                           */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    LPBYTE  rem_BD       : Bluetooth device address of remote device      */
/*    LPBYTE  C            : 16 byte long hash C value                      */
/*    LPBYTE  R            : 16 byte long Randomizer R value                */
/*    BYTE    cause        : result code for this message                   */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/* Porting to BlueAPI+:-----------------------------------------------------*/
/* The corresponding function in the Stollmann system internal software API */
/* BlueAPI+ for using LTP functionality without serial link interface is    */
/* blueAPI_RemoteOOBDataReqConf(...)                                        */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendRemoteOOBReqCnf(PLTPLib pLTPLib, LPBYTE rem_BD, LPBYTE C, LPBYTE R, BYTE cause);

/****************************************************************************/
/* BOOL LTPLibSendAuthResultExtCnf                                          */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    cause        : result code for this message                   */
/*    LPBYTE  rem_BD       : pointer to remote device address (6 bytes)     */
/*    BYTE    rem_BD_Type  : Type of Bluetooth address                      */
/*    DWORD   AppData      : MDH specific data to a given bond table entry  */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/* Porting to BlueAPI+:-----------------------------------------------------*/
/* The corresponding function in the Stollmann system internal software API */
/* BlueAPI+ for using LTP functionality without serial link interface is    */
/* blueAPI_AuthResultConf(...)                                              */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendAuthResultExtCnf(PLTPLib pLTPLib, BYTE cause, LPBYTE rem_BD,
                                BYTE rem_BD_Type, DWORD AppData);


/****************************************************************************/
/* BOOL LTPLibSendAuthResultRequestExtCnf                                   */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    cause        : result code for this message                   */
/*    LPBYTE  rem_BD       : pointer to remote device address (6 bytes)     */
/*    BYTE    rem_BD_Type  : Type of Bluetooth address                      */
/*    BYTE    keyType      : type of the generated linkkey                  */
/*    LPBYTE  linkKey      : Bluetooth Linkkey                              */
/*    WORD    linkKeyLength: Length of Linkkey data                         */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/* Porting to BlueAPI+:-----------------------------------------------------*/
/* The corresponding function in the Stollmann system internal software API */
/* BlueAPI+ for using LTP functionality without serial link interface is    */
/* blueAPI_AuthResultRequestConf(...)                                       */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendAuthResultRequestExtCnf(PLTPLib pLTPLib, BYTE cause, LPBYTE rem_BD,
                                       BYTE rem_BD_Type, BYTE keyType,
                                       LPBYTE linkKey, WORD linkKeyLength);


/****************************************************************************/
/* BOOL LTPLibSendCreateMDLCnf                                              */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    loc_MDL_ID   : reference to local MDL identifier              */
/*    BYTE    LinkConfigType   : requested QoS-configuration for this link  */
/*                               Default = LTP_LINK_CONFIG_RELIABLE         */
/*    BYTE    maxTPDUusCredits : maximum num of usCredits allowed for MDL   */
/*                               Default = 0x00                             */
/*    BYTE    cause        : result code for this message                   */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/* Porting to BlueAPI+:-----------------------------------------------------*/
/* The corresponding function in the Stollmann system internal software API */
/* BlueAPI+ for using LTP functionality without serial link interface is    */
/* blueAPI_CreateMDLConf(...)                                               */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendCreateMDLCnf(PLTPLib pLTPLib, BYTE loc_MDL_ID, BYTE LinkConfigType, BYTE maxTPDUusCredits, BYTE cause);

/****************************************************************************/
/* BOOL LTPLibSendDisconnectMDLReq                                          */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    loc_MDL_ID   : reference to local MDL identifier              */
/*    BYTE    cause        : result code for this message                   */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/* Porting to BlueAPI+:-----------------------------------------------------*/
/* The corresponding function in the Stollmann system internal software API */
/* BlueAPI+ for using LTP functionality without serial link interface is    */
/* blueAPI_DisconnectMDLReq(...)                                            */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendDisconnectMDLReq(PLTPLib pLTPLib, BYTE loc_MDL_ID, BYTE cause);

/****************************************************************************/
/* BOOL LTPLibSendDisconnectMDLCnf                                          */
/* (                                                                        */
/*    PLTPLib pLTPLib      : pointer to LTP context to be used              */
/*    BYTE    loc_MDL_ID   : reference to local MDL identifier              */
/* )                                                                        */
/* return:------------------------------------------------------------------*/
/* TRUE in case the message was send send successfully                      */
/* FALSE otherwise                                                          */
/*                                                                          */
/* Description:-------------------------------------------------------------*/
/* This function can be used to send the LTP message in the function name   */
/*                                                                          */
/* Porting to BlueAPI+:-----------------------------------------------------*/
/* The corresponding function in the Stollmann system internal software API */
/* BlueAPI+ for using LTP functionality without serial link interface is    */
/* blueAPI_DisconnectMDLConf(...)                                           */
/*                                                                          */
/****************************************************************************/
BOOL LTPLibSendDisconnectMDLCnf(PLTPLib pLTPLib, BYTE loc_MDL_ID);
const char *LTPLIB_Message(BYTE opcode);
const char *LTPLIB_SubMessage(BYTE opcode);
#ifdef __cplusplus
}
#endif

#endif /* LTPLIB_H */
