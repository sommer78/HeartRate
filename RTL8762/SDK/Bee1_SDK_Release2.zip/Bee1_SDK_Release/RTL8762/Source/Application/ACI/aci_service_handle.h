/**
*********************************************************************************************************
*               Copyright(c) 2014, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      aci_service_handle.h
* @brief     low power handle when using ACI.
* @details   none.
* @author    tifnan
* @date      2014-11-19
* @version   v0.1
* *********************************************************************************************************
*/

#ifndef     _ACI_SERVICE_HANDLE_H_
#define     _ACI_SERVICE_HANDLE_H_

#define ACI_SERVICE_DATABASE_START    1
#define ACI_SERVICE_DATABASE_CONTINUE 2
#define ACI_SERVICE_DATABASE_END      3

#define ACI_SERVICE_TABLE_START_OFFSET     8
#define ACI_SERVICE_DATABASE_START_OFFSET  104
#define ACI_SERVICE_DATABASE_END_OFFSET   2048
#define ACI_SERVICE_DATABASE_MAX_SIZE  (ACI_SERVICE_DATABASE_END_OFFSET - ACI_SERVICE_DATABASE_START_OFFSET)

typedef struct
{
    WORD service_offset;
    WORD database_offset;
    BYTE service_num;
    BYTE padding[3];
} ServiceTcb;

typedef struct
{
    DWORD host_service;
    WORD database_length;
    WORD start_offset;
} ServiceTable;
typedef ServiceTable FAR* PServiceTable;

typedef enum
{
    Load_CauseSuccess,
    Load_CauseServiceExist,
    Load_CauseServiceNotExist,
    Load_CauseServiceTooMuch,
    Load_CauseServiceNoResource,
    Load_CauseLengthError,
    Load_CauseInvalidPDU,
} LoadDatabaseCause;

void * ACI_GetBuffer(WORD length);
BOOL ACI_FreeBuffer(void * pBuffer, WORD length);
void fs_init(PBTLtp pBTLtp);
BOOL fs_save_New_ServiceTable(PGattServiceTable pdata);
BOOL fs_clear_all_ServiceTable(PBTLtp pBTLtp);
BYTE BTACIGetServiceNum(void);
PGattServiceTable    BTACIAllocateGATTServiceHandle(PBTLtp pBTLtp);
BYTE                 BTACIFindGATTServiceHandle(PBTLtp pBTLtp, void *serviceHandle);
PGattServiceTable    BTACILookupGATTServiceTableByHostService(PBTLtp pBTLtp, DWORD hostServiceHandle);
void *               BTLTPLookupGATTServiceHandle(PBTLtp pBTLtp, BYTE shortServiceHandle);
BYTE                 BTLTPAllocateFindGATTServiceHandle(PBTLtp pBTLtp, void *serviceHandle);

#endif
