/**
*********************************************************************************************************
*               Copyright(c) 2014, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      aci_if.h
* @brief     some macro/struct/functions declaration of aci interface
* @details   none.
* @author    tifnan
* @date      2014-10-17
* @version   v0.1
* *********************************************************************************************************
*/

#ifndef     _ACI_IF_H_
#define     _ACI_IF_H_

/****************************************************************************
 * includes
 ****************************************************************************/
#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>
#include <timers.h>

#include <ltplib.h>

/* Ltp data struct */
typedef struct _TData
{
    BYTE *pBuffer;
    DWORD Length;
} TLTPData;


/** @brief tcb to manage tx buffer */
typedef struct
{
    WORD    tx_blk_idx;          /* sending block index [0 -- TX_BUFFER_SIZE_MASK](block is sending now ) */
    WORD    tx_free_blk_idx;     /* free tx block index [0----TX_BUFFER_SIZE_MASK] */
    WORD    tx_un_used_size;     /* size of block which is discarded */
    WORD    free_size;           /* bytes can be used */
} TxMemTCB, *PTxMemTCB;

/** @brief aci control struct */
typedef struct _ACI_TCB
{
    TLTPData                  TxData;
    xTaskHandle               Handle;              /* task handle */
    xQueueHandle              QueueHandleEvent;    /* task queue */
    xQueueHandle              QueueHandleMessage;  /* message queue */
    xQueueHandle              QueueHandleTxData;   /* Tx queue */
    xQueueHandle              QueueHandleRxData;   /* Rx queue */
    xQueueHandle              QueueHandleTxRel;    /* tx buffer release queue */
    DWORD                     RxDataIndication;    /* pending responses */
    DWORD                     RxDataLength;
    DWORD                     RxOffset;
    WORD                      RxReadIndex;
    WORD                      RxWriteIndex;
    // for F_LTPLIB_ASYNC_ASSEMBLY_SUPPORT
#if F_LTPLIB_ASYNC_ASSEMBLY_SUPPORT
    xTimerHandle              ltpTimerHandle;
    int                       ltpTimerMS;
    TLTPTimerID               ltpTimerID;         /* only one timer */
#endif
    PBYTE                     p_rx_buf;           /* pointer to the rx buffer allocated dynamically */
    PBYTE                     p_tx_buf;           /* pointer to the tx buffer allocated dynamically */
    PBYTE                     p_rx_handle_buf;    /* buffer address, handle uart rx data */
    PBYTE                     P_RxBuffer;         /* for rx */
    TxMemTCB                  tx_mem_tcb;         /* manage tx bufer */
} ACI_TCB, *P_ACI_TCB;

/* export functions */
BYTE ltpInit(void);
BYTE ltpTaskInit(void);
#endif

