/**
*********************************************************************************************************
*               Copyright(c) 2014, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      aci_key_storage.h
* @brief     key storage function.
* @details   none.
* @author    tifnan
* @date      2014-11-19
* @version   v0.1
* *********************************************************************************************************
*/

#ifndef     _ACI_KEY_STORAGE_H_
#define     _ACI_KEY_STORAGE_H_

#include "rtl876x_flash_storage.h"

#define ACI_KEY_TABLE_START_OFFSET     300
#define GATTDSTORE_ENTRY_COUNT         8

typedef struct _GATTDStoreEntrySEC
{
    TBlueAPI_LinkKeyType    keyType;
    uint8_t                 dataLen;
    uint8_t                 data[28];
} TGATTDStoreEntrySEC;

typedef struct _GATTDStoreEntryGATT
{
    uint8_t                 dataLen;
    uint8_t                 data[32];
} TGATTDStoreEntryGATT;

#define GATTDSTORE_FREE_ENTRY    0
#define GATTDSTORE_SEC_ENTRY     1
#define GATTDSTORE_CCC_ENTRY     2

typedef struct _GATTDStoreEntry
{
    uint8_t                 used;
    uint8_t                 bd[6];
    TBlueAPI_RemoteBDType   bdType;
    union
    {
        TGATTDStoreEntrySEC   sec;
        TGATTDStoreEntryGATT  gatt;
    } p;
    uint8_t reserved[3];
} TGATTDStoreEntry, * PGATTDStoreEntry;

extern TGATTDStoreEntry  gapBond_extStore[GATTDSTORE_ENTRY_COUNT];
DWORD fs_save_TGATTDStoreEntry_struct(TGATTDStoreEntry *pdata, BYTE index);
bool fs_check_BD_key(BYTE *bd, TBlueAPI_RemoteBDType   bdType);
bool fs_delete_unused_TGATTDStoreEntry(PBTLtp pBTLtp);
void fs_key_storage_init(PBTLtp pBTLtp);
void fs_save_latest_bond(BYTE *bd, TBlueAPI_RemoteBDType   bdType);
void fs_del_latest_bond(BYTE *bd, TBlueAPI_RemoteBDType   bdType);
bool fs_get_latest_bond(remote_BD_struct *pBondedDevice);

#endif
