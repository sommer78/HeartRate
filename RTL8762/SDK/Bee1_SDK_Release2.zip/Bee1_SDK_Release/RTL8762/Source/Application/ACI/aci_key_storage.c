enum { __FILE_NUM__ = 0 };
/**
*********************************************************************************************************
*               Copyright(c) 2014, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      aci_service_handle.c
* @brief     low power handle when using ACI.
* @details   none.
* @author    Tifnan
* @date      2014-11-19
* @version   v0.1
* *********************************************************************************************************
*/
#include "btltp.h"
#include <ltplib.h>
#include "aci_key_storage.h"
#include "flash_translation_layer.h"


TGATTDStoreEntry  gapBond_extStore[GATTDSTORE_ENTRY_COUNT];

DWORD fs_save_TGATTDStoreEntry_struct(TGATTDStoreEntry *pdata, BYTE index)
{
    uint16_t data_size;
    uint16_t addr_offset;

    data_size = sizeof(TGATTDStoreEntry);
    addr_offset = ACI_KEY_TABLE_START_OFFSET + index*data_size;
    
    if( (data_size&0x3) || (addr_offset&0x3))
    {
        return 2; // not 4byte align
    }

    if ( 4<= (addr_offset+data_size) && (addr_offset+data_size) <=1024 )
    {
        return Save_To_Storage(pdata, addr_offset, data_size);
    }
    
    return 1; // out of range
}

DWORD fs_load_TGATTDStoreEntry_struct(TGATTDStoreEntry *pdata, BYTE index)
{
    uint16_t data_size;
    uint16_t addr_offset;

    data_size = sizeof(TGATTDStoreEntry);
    addr_offset = ACI_KEY_TABLE_START_OFFSET + index*data_size;
    
    if( (data_size&0x3) || (addr_offset&0x3))
    {
        return 2;
    }

    if ( 4<= (addr_offset+data_size) && (addr_offset+data_size) <=1024 )
    {
        return Load_From_Storage(pdata, addr_offset, data_size);
    }
    
    return 1; // out of range
}

void fs_clear_BD_key(BYTE *bd, TBlueAPI_RemoteBDType   bdType)
{
    uint16_t          i;

    for (i = 0; i < GATTDSTORE_ENTRY_COUNT; i++)
    {
        PGATTDStoreEntry pSearch = &gapBond_extStore[i];

        if ((pSearch->used != GATTDSTORE_FREE_ENTRY) &&
                (memcmp(pSearch->bd, bd, 6) == 0) &&
                (pSearch->bdType == bdType)
           )
        {
            pSearch->used = GATTDSTORE_FREE_ENTRY;
            fs_save_TGATTDStoreEntry_struct(pSearch, i);
        }
    }
}

bool fs_check_BD_key(BYTE *bd, TBlueAPI_RemoteBDType   bdType)
{
    uint16_t          i;

    for (i = 0; i < GATTDSTORE_ENTRY_COUNT; i++)
    {
        PGATTDStoreEntry pSearch = &gapBond_extStore[i];

        if ((pSearch->used == GATTDSTORE_SEC_ENTRY) &&
                (memcmp(pSearch->bd, bd, 6) == 0) &&
                (pSearch->bdType == bdType)
           )
        {
            return true;
        }
    }
    return false;
}

bool fs_delete_unused_TGATTDStoreEntry(PBTLtp pBTLtp)
{
    uint16_t          i;
    bool              isConnect = true;

    for (i = 0; i < GATTDSTORE_ENTRY_COUNT; i++)
    {
        PGATTDStoreEntry pSearch = &gapBond_extStore[i];

        if (pSearch->used == GATTDSTORE_SEC_ENTRY)
        {
            isConnect = BTLTPCheckAMDLConnected(pBTLtp, pSearch->bd, pSearch->bdType);
            if(!isConnect)
            {
                fs_clear_BD_key(pSearch->bd, pSearch->bdType);
                return true;
            }
        }
    }
    return false;
}

void fs_del_latest_bond(BYTE *bd, TBlueAPI_RemoteBDType   bdType)
{
    BYTE           BD0[6]        = { 0, 0, 0, 0, 0, 0 };
    bool              nullBD;
    remote_BD_struct s_remote_BD;
    remote_BD_struct invalid_remotebd;
    fs_load_remote_BD_struct(&s_remote_BD);
    nullBD = (memcmp(bd, BD0, BLUE_API_BD_SIZE) == 0);
    
    if (((nullBD) || (memcmp(s_remote_BD.addr, bd, 6) == 0)) &&
            ((bdType == blueAPI_RemoteBDTypeAny) || (s_remote_BD.remote_bd_type == bdType))
       )
    {
        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_INFO)
        {
            DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "fs_del_latest_bond",0);
        }
        memset(&invalid_remotebd, 0xFF, sizeof(invalid_remotebd));
        fs_save_remote_BD_struct(&invalid_remotebd); 
    }
    
}

void fs_save_latest_bond(BYTE *bd, TBlueAPI_RemoteBDType   bdType)
{
    remote_BD_struct s_remote_BD;
    s_remote_BD.addr[0] = bd[0];
    s_remote_BD.addr[1] = bd[1];
    s_remote_BD.addr[2] = bd[2];
    s_remote_BD.addr[3] = bd[3];
    s_remote_BD.addr[4] = bd[4];
    s_remote_BD.addr[5] = bd[5];
    s_remote_BD.remote_bd_type = bdType;
    fs_save_remote_BD_struct(&s_remote_BD);
    if(P_AciConfig->ltp_trace_level >= LTP_TRACE_INFO)
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "fs_save_latest_bond",0);
    }
}

bool fs_get_latest_bond(remote_BD_struct *pBondedDevice)
{
    bool bRet= false;
    int remote_BD_equal;
    remote_BD_struct remotebd;
    remote_BD_struct invalid_remotebd;
    uint32_t result;
    memset(&invalid_remotebd, 0xFF, sizeof(invalid_remotebd));

    result = fs_load_remote_BD_struct(&remotebd);
    if(result != 0)
    {
        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
        {
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "fs_get_latest_bond No Bond Device, result(%d)",1, result);
        }
        return false;
    }
    
    remote_BD_equal = memcmp(&remotebd, &invalid_remotebd, sizeof(invalid_remotebd));

    if (remote_BD_equal != 0)
    {
        if(fs_check_BD_key(remotebd.addr, (TBlueAPI_RemoteBDType)remotebd.remote_bd_type))
        {
            memcpy(pBondedDevice, &remotebd, sizeof(remotebd));
            bRet=  true;
        }
        else
        {
            if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
            {
                DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "fs_get_latest_bond No Bond Device, no entry",0);
            }
            fs_save_remote_BD_struct(&invalid_remotebd);
            bRet = false;
        }
        
    }
    else
    {
        bRet= false;
    }
    
    return bRet;
}

void fs_clear_all_key(void)
{
    WORD i;
    remote_BD_struct invalid_remotebd;
    memset(gapBond_extStore, 0x00, sizeof(gapBond_extStore));
    for (i = 0; i < GATTDSTORE_ENTRY_COUNT; i++)
    {
        PGATTDStoreEntry pSearch = &gapBond_extStore[i];
        fs_save_TGATTDStoreEntry_struct(pSearch, i);
    }
    memset(&invalid_remotebd, 0xFF, sizeof(invalid_remotebd));
    fs_save_remote_BD_struct(&invalid_remotebd);
}

void fs_key_storage_init(PBTLtp pBTLtp)
{
    WORD i;
    WORD err;
    memset(gapBond_extStore, 0x00, sizeof(gapBond_extStore));
    for (i = 0; i < GATTDSTORE_ENTRY_COUNT; i++)
    {
        PGATTDStoreEntry pSearch = &gapBond_extStore[i];
        err = fs_load_TGATTDStoreEntry_struct(pSearch, i);
        if(err != 0)
        {
            pSearch->used = GATTDSTORE_FREE_ENTRY;
        }
    }
}
