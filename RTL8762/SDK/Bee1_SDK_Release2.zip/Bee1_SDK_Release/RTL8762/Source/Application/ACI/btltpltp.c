enum { __FILE_NUM__ = 0 };

#include <blueapi_types.h>
#include <blueapi.h>
#include "btltp.h"
#include "gatt.h"
#include "trace.h"
#include "aci_service_handle.h"
#include "aci_key_storage.h"

#define LTP_SOURCE_FILE_ID 0x82
extern void  stSetTraceLevel(uint32_t traceLevel);
extern uint32_t g_eflash_dbg;
void BTLTPHandleExitReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, LPBYTE pPara)
{
    LPBYTE       pInsert = pBTLtp->pMsgBuffer;
    WORD         pos     = 0;

    //DBG_BUFFER(MODULE_LTP, LEVEL_INFO,  "LTP: >>ExitReq", 0);

    /* prepare confirmation                                                 */
    pInsert[pos++] = LTP_EXIT_RSP;
    pInsert[pos++] = 0x00;                                    /* copmsk     */
    NETSHORT2CHAR(&pInsert[pos], LTP_EXIT_RSP_LENGTH);
    pos += 2; /* msg length */
    pInsert[pos++] = LTP_CAUSE_NOT_SUPPORTED;

    /* send LTP messages                                                    */
    BTLTPTgtSendLTPMessage(pBTLtp, pBTLtp->pMsgBuffer, 0, pos);
}

void BTLTPHandleCreateMDLConf(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    WORD                 pos              = 0;
    BYTE                 local_MDL_ID     = 0;
    BYTE                 maxTPDUusCredits = 0;
    BYTE                 cause;


    /* read mandatory parameters                                             */
    cause        = pPara[pos++];

    if (cause != LTP_CAUSE_NOT_SUPPORTED)
    {
        local_MDL_ID = pPara[pos++];
    }

    /* read optional parameters                                              */
    pos = 0;
    if (copmsk & LTP_CREATE_MDL_CNF_OPT_MASK_MAX_TPDU_US_CREDITS)
    {
        maxTPDUusCredits = pOpt[pos++];
    }

    blueAPI_CreateMDLConf(local_MDL_ID,
                          maxTPDUusCredits,
                          BTLTPConvertLTPtoCOMcause(cause)
                         );
}

void BTLTPHandleDisconnectMDLConf(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    BYTE          local_MDL_ID;
    WORD          pos          = 0;


    /* read mandatory parameters                                             */
    local_MDL_ID = pPara[pos++];


    /* read optional parameters                                              */
    /* non */

    blueAPI_DisconnectMDLConf(
        local_MDL_ID
    );
}

void BTLTPHandleDisconnectMDLReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    BYTE          local_MDL_ID = 0;                             /* mandatory */
    WORD          pos          = 0;
    BYTE          cause;


    /* read mandatory parameters                                             */
    cause        = pPara[pos++];

    if (cause != LTP_CAUSE_NOT_SUPPORTED)
    {
        local_MDL_ID = pPara[pos++];
    }

    /* read optional parameters                                              */
    /* non */

    blueAPI_DisconnectMDLReq(
        local_MDL_ID,
        BTLTPConvertLTPtoCOMcause(cause)
    );
}

void BTLTPHandleResetReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    BOOL result = FALSE;
    if(P_AciConfig->ltp_trace_level >= LTP_TRACE_INFO)
    {
        DBG_BUFFER(MODULE_LTP, LEVEL_INFO, "LTP: >>ResetReq", 0);
    }

    pBTLtp->pBufferAction = BTLTPAllocateAction(pBTLtp);
    if (pBTLtp->pBufferAction)
    {
        pBTLtp->pBufferAction->Action = btltpActionReset;

        result = LTPLibSendResetRsp(&pBTLtp->LTPLib, BTLTP_DEFAULT_COPMSK, NULL, LTP_CAUSE_SUCCESS);

        if (!result)
        {
            pBTLtp->pBufferAction->Action = btltpActionNotUsed;
            pBTLtp->pBufferAction         = NULL;
        }
    }

    if (!result)
    {
        THandle      handle;
        TBTLtpAction directAction;
        directAction.Action = btltpActionReset;

        handle.lpHandle = (LPVOID)&directAction;
        BTLTPBufferCallback(handle);
    }
}

void BTLTPHandlePasskeyRequestCnf(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    WORD   pos = 0;
    BYTE   cause;                                               /* mandatory */
    LPBYTE rem_BD = NULL;                                       /* mandatory */


    /* read mandatory parameters                                             */
    cause = pPara[pos++];

    if (cause != LTP_CAUSE_NOT_SUPPORTED)
    {
        rem_BD = &pPara[pos];
        pos += 6;
    }

    /* read optional parameters                                              */
    /* non */

    blueAPI_UserPasskeyReqConf(
        rem_BD,
        BTLTPConvertLTPtoCOMcause(cause)
    );
}

void BTLTPHandleOOBRequestCnf(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    WORD   pos = 0;
    LPBYTE rem_BD = NULL;                                       /* mandatory */
    LPBYTE C      = NULL;                                       /* mandatory */
    BYTE   cause;                                               /* mandatory */


    /* read mandatory parameters                                             */
    cause = pPara[pos++];

    if (cause != LTP_CAUSE_NOT_SUPPORTED)
    {
        rem_BD = &pPara[pos];
        pos += 6;
        C      = &pPara[pos];
        pos += 16;
    }
    /* read optional parameters                                              */
    /* non */

    blueAPI_RemoteOOBDataReqConf(
        rem_BD,
        C,
        BTLTPConvertLTPtoCOMcause(cause)
    );
}

void BTLTPHandleAuthResultExtCnf(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    WORD   pos = 0;
    BYTE   cause;
    LPBYTE rem_BD      = NULL;
    BYTE   rem_BD_Type = blueAPI_RemoteBDTypeClassic;


    /* read mandatory parameters                                             */
    cause = pPara[pos++];

    if (cause != LTP_CAUSE_NOT_SUPPORTED)
    {
        rem_BD      = &pPara[pos];
        pos += 6;
        rem_BD_Type = pPara[pos++];
    }

    /* read optional parameters                                              */
    /* non */

    blueAPI_AuthResultConf(
        rem_BD,
        (TBlueAPI_RemoteBDType)rem_BD_Type,
        BTLTPConvertLTPtoCOMcause(cause)
    );
}

void BTLTPHandleAuthResultRequestExtCnf(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    WORD          pos            = 0;
    LPBYTE        rem_BD         = NULL;
    BYTE          rem_BD_Type    = blueAPI_RemoteBDTypeClassic;
    LPBYTE        linkKey        = NULL;
    BYTE          linkKeyLength  = 0;
    BYTE          keyType        = 0;
    BYTE          cause;
    WORD          restartHandle  = 0x0000;                      /* optional  */


    /* read mandatory parameters                                             */
    cause = pPara[pos++];

    if (cause != LTP_CAUSE_NOT_SUPPORTED)
    {
        rem_BD        = &pPara[pos];
        pos += 6;
        rem_BD_Type   = pPara[pos++];
        keyType       = pPara[pos++];
        linkKeyLength = lenPara - pos;
        linkKey       = &pPara[pos];
        pos += linkKeyLength;
    }

    /* read optional parameters                                              */
    pos = 0;

    if (copmsk & LTP_AUTH_RESULT_REQUEST_EXT_CNF_OPT_MASK_RESTART_HANDLE)
    {
        restartHandle = NETCHAR2SHORT(&pOpt[pos]);
        pos += 2;
    }

    blueAPI_AuthResultRequestConf(
        rem_BD,
        (TBlueAPI_RemoteBDType)rem_BD_Type,
        linkKeyLength,
        linkKey,
        (TBlueAPI_LinkKeyType)keyType,
        restartHandle,
        BTLTPConvertLTPtoCOMcause(cause)
    );
}

void BTLTPHandlePairableModeSetReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    BOOL                   enablePairableMode;
    TBlueAPI_AuthRequirements AuthRequirements;
    TBlueAPI_IOCapabilities   IOCapabilities;
    BOOL                   remoteOOBDataPresent;


    /* read mandatory parameters                                             */
    enablePairableMode   = (BOOL)pPara[pos++];
    AuthRequirements     = (TBlueAPI_AuthRequirements)pPara[pos++];
    IOCapabilities       = (TBlueAPI_IOCapabilities)pPara[pos++];
    remoteOOBDataPresent = (BOOL)pPara[pos++];

    /* read optional parameters                                              */
    /* non */

    blueAPI_PairableModeSetReq(
        enablePairableMode,
        AuthRequirements,
        IOCapabilities,
        remoteOOBDataPresent
    );
}

void BTLTPHandlePasskeyReqReplyReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    WORD              pos       = 0;
    TBlueAPI_Cause    cause;
    LPBYTE            rem_BD;
    DWORD             passKey;


    /* read mandatory parameters                                             */
    cause    = (TBlueAPI_Cause)pPara[pos++];
    rem_BD   = &pPara[pos];
    pos += 6;
    passKey  = NETCHAR2LONG(&pPara[pos]);
    pos += 4;

    /* read optional parameters                                              */
    /* non */

    blueAPI_UserPasskeyReqReplyReq(
        rem_BD,
        passKey,
        cause
    );
}
#define LTP_CauseServiceDatabaseNotExist 0xF1
#define LTP_CauseServiceDatabaseError 0xF2
#define LTP_CauseServiceDatabaseEmpty 0xF3

void BTLTPHandleGATTServiceRegisterReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
                                       WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    DWORD pService;
    WORD nbrOfAttrib;
    PGattServiceTable pServiceTable;
    BYTE cause;

    /* read mandatory parameters                                             */
    pService     = NETCHAR2LONG(&pPara[pos]);
    pos += 4;
    nbrOfAttrib = NETCHAR2SHORT(&pPara[pos]);

#if ACI_EN
    pServiceTable = BTACILookupGATTServiceTableByHostService(pBTLtp, pService);
    if (pServiceTable == NULL)
    {
        BYTE service_num = BTACIGetServiceNum();
        if(service_num)

        {
            cause = LTP_CauseServiceDatabaseNotExist;
        }
        else
        {
            cause = LTP_CauseServiceDatabaseEmpty;
        }
        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
        {
            DBG_BUFFER(MODULE_LTP, LEVEL_INFO, "BTLTPHandleGATTServiceRegisterReq service 0x%x not exist! service num %d", 2, pService, service_num);
        }
        LTPLibSendGATTServiceRegisterRsp(&pBTLtp->LTPLib,
                                         BTLTP_DEFAULT_COPMSK,
                                         NULL,
                                         cause,
                                         0,
                                         0
                                        );
    }
    else
    {
        BYTE data = *(BYTE*)pServiceTable->pService;
        if ((nbrOfAttrib == pServiceTable->nbrOfAttrib) && (pServiceTable->pService != NULL) && (data != 0xFF))
        {
            pBTLtp->service_register_idx = pServiceTable->self_idx;
            blueAPI_GATTServiceRegisterReq(
                nbrOfAttrib,
                pServiceTable->pService
            );
        }
        else
        {
            cause = LTP_CauseServiceDatabaseError;
            LTPLibSendGATTServiceRegisterRsp(&pBTLtp->LTPLib,
                                             BTLTP_DEFAULT_COPMSK,
                                             NULL,
                                             cause,
                                             0,
                                             0
                                            );
        }
    }
#else
    nbrOfAttrib = GattdFindMeProfileSize / sizeof(TAttribAppl);
    blueAPI_GATTServiceRegisterReq(
        nbrOfAttrib,
        (void*)GattdFindMeProfile
    );
#endif
}

void BTLTPHandleGATTAttributeUpdateReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
                                       WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    BYTE serviceHandle;
    WORD attribIndex;
    union
    {
        DWORD   d;
        void   *p;
    } requestHandle;

    WORD wOffset = 0;
    WORD ds_pool_id = 0;
    BYTE* pBuffer = NULL;

    /* read mandatory parameters                                             */
    serviceHandle   = pPara[pos++];
    requestHandle.d = NETCHAR2LONG(&pPara[pos]);
    pos += 4;
    attribIndex     = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;

    /* read optional parameters                                              */
    /* none */
    PBTLtpMDLContext p_mdl_context = BTLTPFindAMDLConnected(pBTLtp);

    if (p_mdl_context)
    {
        wOffset = p_mdl_context->dsDataOffset + 3;
        ds_pool_id = p_mdl_context->dsPoolID;
    }

    if (blueAPI_CauseSuccess == blueAPI_BufferGet(ds_pool_id,  lenPara - pos, wOffset, (void**)&pBuffer))
    {
        memcpy(pBuffer + wOffset, pPara + pos, lenPara - pos);
        if (!blueAPI_GATTAttributeUpdateReq(pBuffer,
                                            BTLTPLookupGATTServiceHandle(pBTLtp, serviceHandle),
                                            requestHandle.p,
                                            attribIndex,
                                            (lenPara - pos),
                                            wOffset
                                           ))
        {
            blueAPI_BufferRelease(pBuffer);
        }
    }
    else
    {
        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
        {
            DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "!!!LTP:BTLTPHandleGATTAttributeUpdateReq blueAPI_BufferGet failed!", 0);
        }
    }

    return;
}

void BTLTPHandleGATTAttributeUpdateStatusCnf(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
        WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    BYTE cause;
    BYTE serviceHandle = 0x00;
    WORD attribIndex   = 0x00;
    union
    {
        DWORD   d;
        void   *p;
    } requestHandle;

    requestHandle.d = 0;

    /* read mandatory parameters                                             */
    cause           = pPara[pos++];
    if (cause != LTP_CAUSE_NOT_SUPPORTED)
    {
        serviceHandle   = pPara[pos++];
        requestHandle.d = NETCHAR2LONG(&pPara[pos]);
        pos += 4;
        attribIndex     = NETCHAR2SHORT(&pPara[pos]);
        pos += 2;
    }

    /* read optional parameters                                              */
    /* none */

    blueAPI_GATTAttributeUpdateStatusConf(
        BTLTPLookupGATTServiceHandle(pBTLtp, serviceHandle),
        requestHandle.p,
        attribIndex
    );
}

void BTLTPHandleGATTAttributeReadCnf(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
                                     WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    BYTE cause;
    WORD subCause       = 0x0000;
    BYTE loc_MDL_ID     = 0x00;
    BYTE serviceHandle  = 0x00;
    WORD attribIndex    = 0x00;

    PBTLtpMDLContext pMDLContext = NULL;
    WORD wOffset = 0;
    void* pBuffer = NULL;
    WORD ds_pool_id = 0;

    /* read mandatory parameters                                             */
    cause           = pPara[pos++];
    if (cause != LTP_CAUSE_NOT_SUPPORTED)
    {
        subCause      = NETCHAR2SHORT(&pPara[pos]);
        pos += 2;
        loc_MDL_ID    = pPara[pos++];
        serviceHandle = pPara[pos++];
        attribIndex   = NETCHAR2SHORT(&pPara[pos]);
        pos += 2;
    }

    /* read optional parameters                                              */
    /* none */
    pMDLContext = BTLTPFindMDLContext(pBTLtp, loc_MDL_ID);


    if (NULL != pMDLContext)
    {
        wOffset = pMDLContext->dsDataOffset;
        ds_pool_id = pMDLContext->dsPoolID;
    }

    /* none */
    if (blueAPI_CauseSuccess == blueAPI_BufferGet(ds_pool_id,  lenPara - pos, wOffset, (void**)&pBuffer))
    {
        memcpy(((BYTE *)pBuffer) + wOffset, pPara + pos, lenPara - pos);
        if (!blueAPI_GATTAttributeReadConf(pBuffer,
                                           loc_MDL_ID,
                                           BTLTPLookupGATTServiceHandle(pBTLtp, serviceHandle),
                                           (TBlueAPI_Cause)cause,
                                           subCause,
                                           attribIndex,
                                           (lenPara - pos),
                                           wOffset
                                          ))
        {
            blueAPI_BufferRelease(pBuffer);
        }
    }
    else
    {
        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
        {
            DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "BTLTPHandleGATTAttributeReadCnf blueAPI_BufferGet failed!", 0);
        }
    }

    return;
}

void BTLTPHandleGATTAttributeWriteCnf(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
                                      WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    BYTE cause;
    WORD subCause       = 0x0000;
    BYTE loc_MDL_ID     = 0x00;
    BYTE serviceHandle  = 0x00;
    WORD attribIndex    = 0x0000;

    /* read mandatory parameters                                             */
    cause           = pPara[pos++];
    if (cause != LTP_CAUSE_NOT_SUPPORTED)
    {
        subCause      = NETCHAR2SHORT(&pPara[pos]);
        pos += 2;
        loc_MDL_ID    = pPara[pos++];
        serviceHandle = pPara[pos++];
        attribIndex   = NETCHAR2SHORT(&pPara[pos]);
        pos += 2;
    }

    /* read optional parameters                                              */
    /* none */

    blueAPI_GATTAttributeWriteConf(
        loc_MDL_ID,
        BTLTPLookupGATTServiceHandle(pBTLtp, serviceHandle),
        (TBlueAPI_Cause)cause,
        subCause,
        attribIndex
    );
}

void BTLTPHandleGATTServerStoreCnf(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
                                   WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    BYTE cause;
    BYTE opCode         = 0x00;
    LPBYTE rem_BD       = NULL;
    BYTE rem_BD_Type    = 0x00;
    WORD restartHandle  = 0x0000;

    /* read mandatory parameters                                             */
    cause           = pPara[pos++];
    if (cause != LTP_CAUSE_NOT_SUPPORTED)
    {
        opCode        = pPara[pos++];
        rem_BD        = &pPara[pos];
        pos += 6;
        rem_BD_Type   = pPara[pos++];
        restartHandle = NETCHAR2SHORT(&pPara[pos]);
        pos += 2;
    }

    /* read optional parameters                                              */
    /* none */

    blueAPI_GATTServerStoreConf(
        (TBlueAPI_GATTStoreOpCode)opCode,
        rem_BD,
        (TBlueAPI_RemoteBDType)rem_BD_Type,
        restartHandle,
        (lenPara - pos),
        (pPara + pos),
        (TBlueAPI_Cause)cause
    );
}

void BTLTPHandleConnectGATTMDLReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
                                  WORD lenPara, LPBYTE pPara)
{
    PBTLtpMDLContext pMdlContext = NULL;
    WORD pos = 0;
    LPBYTE rem_BD;
    BYTE rem_BD_Type;
    WORD scanInterval;
    WORD scanWindow;
    WORD scanTimeout;
    WORD connIntervalMin;
    WORD connIntervalMax;
    WORD connLatency;
    WORD supervisionTimeout;
    BYTE local_BD_Type;
    WORD CE_Length;

    /* read mandatory parameters                                             */
    rem_BD              = &pPara[pos];
    pos += 6;
    rem_BD_Type         = pPara[pos++];
    //loc_MDEP_ID         = pPara[pos++];
    pos++;
    scanInterval        = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    scanWindow          = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    scanTimeout         = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    connIntervalMin     = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    connIntervalMax     = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    connLatency         = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    supervisionTimeout  = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    local_BD_Type       = pPara[pos++];
    CE_Length           = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;

    /* read optional parameters                                              */
    /* none */

    /* Allocate Context for this loc_MDEP_ID */
    pMdlContext = BTLTPAllocateMDLContext(pBTLtp, 0x00, 0x01);
    if(pMdlContext != NULL)
    {
        memcpy(pMdlContext->remote_BD, rem_BD, 6);
        pMdlContext->remote_BD_type = rem_BD_Type;
    }

    blueAPI_ConnectGATTMDLReq(
        rem_BD,
        (TBlueAPI_RemoteBDType)rem_BD_Type,
        (TBlueAPI_LocalBDType)local_BD_Type,
        scanInterval,
        scanWindow,
        scanTimeout,
        connIntervalMin,
        connIntervalMax,
        connLatency,
        supervisionTimeout,
        CE_Length
    );
}

void BTLTPHandleGATTDiscoveryReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
                                 WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    BYTE loc_MDL_ID;
    BYTE discoveryType;
    WORD startHandle;
    WORD endHandle;
    WORD uuid16 = 0;
    LPBYTE pUUID128 = NULL;

    /* read mandatory parameters                                             */
    loc_MDL_ID    = pPara[pos++];
    discoveryType = pPara[pos++];
    startHandle   = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    endHandle     = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;

    if (lenPara == (pos + 2))
    {
        uuid16      = NETCHAR2SHORT(&pPara[pos]);
        pos += 2;
    }
    else
    {
        pUUID128    = &pPara[pos];
    }

    /* read optional parameters                                              */
    /* none */

    blueAPI_GATTDiscoveryReq(
        loc_MDL_ID,
        (TBlueAPI_GATTDiscoveryType)discoveryType,
        startHandle,
        endHandle,
        uuid16,
        pUUID128
    );
}

void BTLTPHandleGATTDiscoveryCnf(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
                                 WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    BYTE cause;
    BYTE loc_MDL_ID     = 0x00;
    BYTE discoveryType  = 0x00;
    WORD startHandle    = 0x0000;
    WORD endHandle      = 0x0000;

    /* read mandatory parameters                                             */
    cause           = pPara[pos++];
    if (cause != LTP_CAUSE_NOT_SUPPORTED)
    {
        loc_MDL_ID    = pPara[pos++];
        discoveryType = pPara[pos++];
        startHandle   = NETCHAR2SHORT(&pPara[pos]);
        pos += 2;
        endHandle     = NETCHAR2SHORT(&pPara[pos]);
        pos += 2;
    }

    /* read optional parameters                                              */
    /* none */

    blueAPI_GATTDiscoveryConf(
        loc_MDL_ID,
        (TBlueAPI_GATTDiscoveryType)discoveryType,
        startHandle,
        endHandle
    );
}

void BTLTPHandleGATTAttributeReadReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
                                     WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    BYTE loc_MDL_ID;
    BYTE readType;
    WORD readOffset;
    WORD startHandle;
    WORD endHandle;
    WORD uuid16 = 0;
    LPBYTE pUUID128 = NULL;

    /* read mandatory parameters                                             */
    loc_MDL_ID  = pPara[pos++];
    readType    = pPara[pos++];
    readOffset  = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    startHandle = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    endHandle   = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;

    if (lenPara == (pos + 2))
    {
        uuid16    = NETCHAR2SHORT(&pPara[pos]);
        pos += 2;
    }
    else
    {
        pUUID128  = &pPara[pos];
    }

    /* read optional parameters                                              */
    /* none */

    blueAPI_GATTAttributeReadReq(
        loc_MDL_ID,
        (TBlueAPI_GATTReadType)readType,
        readOffset,
        startHandle,
        endHandle,
        uuid16,
        pUUID128
    );
}

void BTLTPHandleGATTAttributeWriteReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
                                      WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    BYTE loc_MDL_ID;
    BYTE writeType;
    WORD attribHandle;

    PBTLtpMDLContext pMDLContext = NULL;
    WORD wOffset = 0;
    void* pBuffer = NULL;
    WORD ds_pool_id = 0;

    /* read mandatory parameters                                             */
    loc_MDL_ID    = pPara[pos++];
    writeType     = pPara[pos++];
    attribHandle  = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;

    /* read optional parameters */
    pMDLContext = BTLTPFindMDLContext(pBTLtp, loc_MDL_ID);

    if (NULL != pMDLContext)
    {
        wOffset = pMDLContext->dsDataOffset + 3;
        ds_pool_id = pMDLContext->dsPoolID;
    }

    if (blueAPI_CauseSuccess == blueAPI_BufferGet(ds_pool_id,  lenPara - pos, wOffset, (void**)&pBuffer))
    {
        memcpy(((BYTE *)pBuffer) + wOffset, pPara + pos, lenPara - pos);
        if (!blueAPI_GATTAttributeWriteReq(pBuffer,
                                           loc_MDL_ID,
                                           (TBlueAPI_GATTWriteType)writeType,
                                           attribHandle,
                                           (lenPara - pos),
                                           wOffset
                                          ))
        {
            blueAPI_BufferRelease(pBuffer);
        }
    }
    else
    {
        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
        {
            DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "!!!LTP:BTLTPHandleGATTAttributeWriteReq blueAPI_BufferGet failed!", 0);
        }
    }

    return;
}

void BTLTPHandleGATTAttributeCnf(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
                                 WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    BYTE cause;
    BYTE loc_MDL_ID = 0x00;

    /* read mandatory parameters                                             */
    cause         = pPara[pos++];
    if (cause != LTP_CAUSE_NOT_SUPPORTED)
    {
        loc_MDL_ID  = pPara[pos++];
    }

    /* read optional parameters                                              */
    /* none */

    blueAPI_GATTAttributeConf(
        loc_MDL_ID
    );
}

void BTLTPHandleGATTSecurityReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
                                WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    BYTE loc_MDL_ID;
    WORD requirements;
    BYTE minKeySize;

    /* read mandatory parameters                                             */
    loc_MDL_ID    = pPara[pos++];
    requirements  = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    minKeySize    = pPara[pos++];

    /* read optional parameters                                              */
    /* none */

    blueAPI_GATTSecurityReq(
        loc_MDL_ID,
        requirements,
        minKeySize
    );
}

void BTLTPHandleLEAdvertiseReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
                               WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    BYTE advMode;


    /* read mandatory parameters                                             */
    advMode     = pPara[pos++];

    /* read optional parameters                                              */
    /* none */

    blueAPI_LEAdvertiseReq(
        (TBlueAPI_LEAdvMode)advMode);

}

void BTLTPHandleSetRandomAddressReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
                                    WORD lenPara, LPBYTE pPara)
{
    WORD pos = 1;
    LPBYTE rem_BD;

    /* read mandatory parameters                                             */
    rem_BD      = &pPara[pos];
    pos += 6;

    /* read optional parameters                                              */
    /* none */

    blueAPI_SetRandomAddressReq(rem_BD);

}

void BTLTPHandleLEAdvertiseParameterSetReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
        WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    BYTE advType;
    BYTE filterScanReq;
    BYTE filterConnectReq;
    WORD minAdvInterval;
    WORD maxAdvInterval;
    BYTE local_BD_Type;
    LPBYTE rem_BD;
    BYTE rem_BD_Type;

    /* read mandatory parameters                                             */
    advType           = pPara[pos++];
    filterScanReq     = pPara[pos++];
    filterConnectReq  = pPara[pos++];
    minAdvInterval    = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    maxAdvInterval    = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    local_BD_Type     = pPara[pos++];
    rem_BD            = &pPara[pos];
    pos += 6;
    rem_BD_Type = pPara[pos++];

    /* read optional parameters                                              */
    /* none */

    blueAPI_LEAdvertiseParameterSetReq(
        (TBlueAPI_LEAdvType)advType,
        (TBlueAPI_LEFilterPolicy)filterScanReq,
        (TBlueAPI_LEFilterPolicy)filterConnectReq,
        minAdvInterval,
        maxAdvInterval,
        (TBlueAPI_LocalBDType)local_BD_Type,
        rem_BD,
        (TBlueAPI_RemoteBDType)rem_BD_Type
    );
}

void BTLTPHandleLEAdvertiseDataSetReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
                                      WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    BYTE dataType = 0;

    /* read mandatory parameters                                             */
    dataType = pPara[pos++];

    /* read optional parameters                                              */
    /* none */

    blueAPI_LEAdvertiseDataSetReq(
        (TBlueAPI_LEDataType)dataType,
        (lenPara - pos),
        (pPara + pos)
    );

}

void BTLTPHandleLEScanReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
                          WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    BYTE scanMode;
    WORD scanInterval;
    WORD scanWindow;
    BYTE filterPolicy;
    BYTE filterDuplicates;
    BYTE localBDType;

    /* read mandatory parameters                                             */
    scanMode          = pPara[pos++];
    scanInterval      = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    scanWindow        = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    filterPolicy      = pPara[pos++];
    filterDuplicates  = pPara[pos++];
    localBDType  = pPara[pos++];

    /* read optional parameters                                              */
    /* none */

    blueAPI_LEScanReq(
        (TBlueAPI_LEScanMode)scanMode,
        scanInterval,
        scanWindow,
        (TBlueAPI_LEFilterPolicy)filterPolicy,
        (TBlueAPI_LocalBDType)localBDType,
        filterDuplicates
    );
} /* BTLTPHandleLEScanReq */

void BTLTPHandleLEModifyWhitelistReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
                                     WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    BYTE whitelistOp;
    LPBYTE rem_BD;
    BYTE rem_BD_Type;

    /* read mandatory parameters                                             */
    whitelistOp = pPara[pos++];
    rem_BD      = &pPara[pos];
    pos += 6;
    rem_BD_Type = pPara[pos++];

    /* read optional parameters                                              */
    /* none */

    blueAPI_LEModifyWhitelistReq(
        (TBlueAPI_LEWhitelistOp)whitelistOp,
        rem_BD,
        (TBlueAPI_RemoteBDType)rem_BD_Type
    );
}

void BTLTPHandleLEConnectionUpdateReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
                                      WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    BYTE loc_MDL_ID;
    WORD connIntervalMin;
    WORD connIntervalMax;
    WORD connLatency;
    WORD supervisionTimeout;

    /* read mandatory parameters                                             */
    loc_MDL_ID          = pPara[pos++];
    connIntervalMin     = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    connIntervalMax     = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    connLatency         = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    supervisionTimeout  = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;

    /* read optional parameters                                              */
    /* none */

    blueAPI_LEConnectionUpdateReq(
        loc_MDL_ID,
        connIntervalMin,
        connIntervalMax,
        connLatency,
        supervisionTimeout
    );
}

void BTLTPHandleLEConnectionUpdateCnf(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt,
                                      WORD lenPara, LPBYTE pPara)
{
    WORD pos = 0;
    BYTE cause;
    BYTE loc_MDL_ID = 0x00;

    /* read mandatory parameters                                             */
    cause         = pPara[pos++];
    if (cause != LTP_CAUSE_NOT_SUPPORTED)
    {
        loc_MDL_ID  = pPara[pos++];
    }

    /* read optional parameters                                              */
    /* none */

    blueAPI_LEConnectionUpdateConf(
        loc_MDL_ID,
        (TBlueAPI_Cause)cause
    );
}

void BTLTPHandleDeviceNameReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    BYTE dev_name[40];
    WORD pos = 1;
    memcpy(dev_name, pPara + pos, lenPara - pos);
    blueAPI_DeviceConfigDeviceNameSetReq( dev_name);
}

void BTLTPHandleDeviceConfigSecuritySetReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    WORD                    pos = 1;
    DWORD                   leFixedDisplayValue;


    leFixedDisplayValue = NETCHAR2LONG(&pPara[pos]);


    blueAPI_DeviceConfigSecuritySetReq(leFixedDisplayValue);
}

void BTLTPHandleDeviceConfigStoreSetReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    WORD                    pos = 1;
    TBlueAPI_StoreBondModes storeBondMode;
    BYTE                    storeBondSize;

    /* read mandatory parameters                                             */
    storeBondMode       = (TBlueAPI_StoreBondModes)pPara[pos++];
    storeBondSize       = pPara[pos++];

    blueAPI_DeviceConfigStoreSetReq(storeBondMode, storeBondSize);
}

void BTLTPHandleDeviceConfigAppearanceSetReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    WORD                    pos = 1;
    WORD                    appearance;

    /* read mandatory parameters                                             */
    appearance     = NETCHAR2SHORT(&pPara[pos]);

    blueAPI_DeviceConfigAppearanceSetReq(appearance);
}

void BTLTPHandleDeviceConfigPerPrefConnParamSetReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    WORD                    pos = 1;
    WORD connIntervalMin;
    WORD connIntervalMax;
    WORD slaveLatency;
    WORD supervisionTimeout;

    /* read mandatory parameters                                             */
    connIntervalMin     = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    connIntervalMax     = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    slaveLatency         = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    supervisionTimeout  = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;

    blueAPI_DeviceConfigPerPrefConnParamSetReq(connIntervalMin, connIntervalMax, slaveLatency, supervisionTimeout);
}

void BTLTPHandleSetLETxPowerReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    WORD                    pos = 1;
    BYTE                    tx_power;

    /* read mandatory parameters                                             */
    tx_power       = pPara[pos];

    blueAPI_SetBleTxPowerReq(tx_power);
}

void BTLTPHandleSetDataLengthReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    WORD                    pos = 1;
    WORD                    txOctets;
    WORD                    txTime;
    BYTE                    loc_MDL_ID = 0x00;

    /* read mandatory parameters                                             */
    loc_MDL_ID       = pPara[pos++];
    txOctets     = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    txTime       = NETCHAR2SHORT(&pPara[pos]);

    blueAPI_SetDataLengthReq(loc_MDL_ID, txOctets, txTime);
}


void BTLTPHandleDownloadServiceDatabaseReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    WORD    pos = 1;
    BYTE    cmd;
    DWORD host_service = 0;
    PGattServiceTable pServiceTable = NULL;
    LoadDatabaseCause    cause = Load_CauseSuccess;
    WORD    receive_pos;

    cmd = pPara[pos++];
    host_service = NETCHAR2LONG(&pPara[pos]);
    pos += 4;
    if(P_AciConfig->ltp_trace_level >= LTP_TRACE_INFO)
    {
        DBG_BUFFER(MODULE_LTP, LEVEL_INFO,  "BTLTPHandleDownloadServiceDatabaseReq cmd %d 0x%x\n", 2, cmd,host_service);
    }
    switch (cmd)
    {
    case ACI_SERVICE_DATABASE_START:
        {
            WORD  database_len;
            if(copmsk & LTP_SUB_DOWNLOAD_SERVICE_DATABASE_REQ_OPT_MASK_SRV_LEN)
            {
                database_len = NETCHAR2SHORT(&pOpt[0]);
                if(P_AciConfig->ltp_trace_level >= LTP_TRACE_INFO)
                {
				    DBG_BUFFER(MODULE_LTP, LEVEL_ERROR,  "service len %d\n", 1,database_len);
                }
            }
            else
            {
                if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
                {
                    DBG_BUFFER(MODULE_LTP, LEVEL_ERROR,  "!!!LTP:ACI_SERVICE_DATABASE_START no option param\n", 0);
                }
                cause = Load_CauseInvalidPDU;
                break;
            }
            pServiceTable = BTACILookupGATTServiceTableByHostService(pBTLtp, host_service);
            if (pServiceTable == NULL)
            {
                pServiceTable = BTACIAllocateGATTServiceHandle(pBTLtp);
                if (pServiceTable == NULL)
                {
                    if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
                    {
                        DBG_BUFFER(MODULE_LTP, LEVEL_ERROR,  "!!LTP:BTLTPHandleDownloadServiceDatabaseReq too much\n", 0);
                    }
                    cause = Load_CauseServiceTooMuch;
                }
                else
                {

                    pServiceTable->pService = ACI_GetBuffer(database_len);
                    if (pServiceTable->pService == NULL)
                    {
                        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
                        {
                            DBG_BUFFER(MODULE_LTP, LEVEL_ERROR,  "!!!LTP:BTLTPHandleDownloadServiceDatabaseReq allocate failed\n", 0);
                        }
                        fs_clear_all_ServiceTable(pBTLtp);
                        cause = Load_CauseServiceNoResource;
                    }
                    else
                    {
                        pServiceTable->isUsed = TRUE;
                        pServiceTable->host_service = host_service;
                        pServiceTable->database_length = database_len;
                        pServiceTable->receive_length = lenPara - pos;
                        memcpy(pServiceTable->pService, pPara + pos, pServiceTable->receive_length);
                        if (pServiceTable->receive_length == pServiceTable->database_length)
                        {
                            pServiceTable->nbrOfAttrib = pServiceTable->database_length / sizeof(TAttribAppl);
                            fs_save_New_ServiceTable(pServiceTable);
                        }
                    }
                }
            }
            else
            {
                if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
                {
                    DBG_BUFFER(MODULE_LTP, LEVEL_ERROR,  "!!!LTP:BTLTPHandleDownloadServiceDatabaseReq service exist\n", 0);
                }
                cause = Load_CauseServiceExist;
            }
        }
        break;
    case ACI_SERVICE_DATABASE_CONTINUE:
        {
            pServiceTable = BTACILookupGATTServiceTableByHostService(pBTLtp, host_service);
            if (pServiceTable == NULL)
            {
                if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
                {
                    DBG_BUFFER(MODULE_LTP, LEVEL_ERROR,  "!!!LTP:BTLTPHandleDownloadServiceDatabaseReq not exist\n", 0);
                }
                cause = Load_CauseServiceNotExist;
            }
            else
            {
                receive_pos = pServiceTable->receive_length;
                memcpy(((BYTE *)pServiceTable->pService + receive_pos), pPara + pos, lenPara - pos);
                pServiceTable->receive_length += (lenPara - pos);
            }
        }
        break;
    case ACI_SERVICE_DATABASE_END:
        {
            pServiceTable = BTACILookupGATTServiceTableByHostService(pBTLtp, host_service);
            if (pServiceTable == NULL)
            {
                if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
                {
                    DBG_BUFFER(MODULE_LTP, LEVEL_ERROR,  "!!!LTP:BTLTPHandleDownloadServiceDatabaseReq not exist\n", 0);
                }
                cause = Load_CauseServiceNotExist;
            }
            else
            {
                receive_pos = pServiceTable->receive_length;
                memcpy(((BYTE *)pServiceTable->pService + receive_pos), pPara + pos, lenPara - pos);
                pServiceTable->receive_length += (lenPara - pos);
                if (pServiceTable->receive_length != pServiceTable->database_length)
                {
                    ACI_FreeBuffer(pServiceTable->pService, pServiceTable->database_length);
                    pServiceTable->isUsed = FALSE;
                    pServiceTable->host_service = 0;
                    pServiceTable->database_length = 0;
                    pServiceTable->receive_length = 0;
                    pServiceTable->pService = NULL;
                    cause = Load_CauseLengthError;
                    if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
                    {
                        DBG_BUFFER(MODULE_LTP, LEVEL_ERROR,  "!!!LTP:BTLTPHandleDownloadServiceDatabaseReq len check failed\n", 0);
                    }

                }
                else
                {
                    pServiceTable->nbrOfAttrib = pServiceTable->database_length / sizeof(TAttribAppl);
                    if(P_AciConfig->ltp_trace_level >= LTP_TRACE_INFO)
                    {
                        DBG_BUFFER(MODULE_LTP, LEVEL_INFO,  "Download OK 0x%x\n", 1, pServiceTable->host_service);
                    }
                    fs_save_New_ServiceTable(pServiceTable);
                }
            }
        }
        break;
    default:
        cause = Load_CauseInvalidPDU;
        break;
    }

    LTPLibSendDownloadServiceDatabaseRsp(&pBTLtp->LTPLib, BTLTP_DEFAULT_COPMSK, NULL, cause);
}


void BTLTPHandleClearServiceDatabaseReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    TBlueAPI_Cause cause = blueAPI_CauseSuccess;
    if(P_AciConfig->ltp_trace_level >= LTP_TRACE_INFO)
    {
        DBG_BUFFER(MODULE_LTP, LEVEL_INFO, "BTLTPHandleClearServiceDatabaseReq !", 0);
    }
    fs_clear_all_ServiceTable(pBTLtp);
    LTPLibSendClearServiceDatabaseRsp(&pBTLtp->LTPLib, BTLTP_DEFAULT_COPMSK, NULL, cause);
}

void BTLTPHandleGATTAttributePrepareWriteReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    WORD pos = 1;
    BYTE loc_MDL_ID;
    WORD attribHandle;
    WORD writeOffset;

    PBTLtpMDLContext pMDLContext = NULL;
    WORD wOffset = 0;
    void* pBuffer = NULL;
    WORD ds_pool_id = 0;

    /* read mandatory parameters                                             */
    loc_MDL_ID    = pPara[pos++];
    attribHandle  = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    writeOffset   = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;

    /* read optional parameters */
    pMDLContext = BTLTPFindMDLContext(pBTLtp, loc_MDL_ID);

    if (NULL != pMDLContext)
    {
        wOffset = pMDLContext->dsDataOffset + 3;
        ds_pool_id = pMDLContext->dsPoolID;
    }
    else
    {
        return;
    }

    if (blueAPI_CauseSuccess == blueAPI_BufferGet(ds_pool_id,  lenPara - pos, wOffset, (void**)&pBuffer))
    {
        memcpy(((BYTE *)pBuffer) + wOffset, pPara + pos, lenPara - pos);
        if (!blueAPI_GATTAttributePrepareWriteReq(pBuffer,
                                           loc_MDL_ID,
                                           attribHandle,
                                           (lenPara - pos),
                                           writeOffset,
                                           wOffset
                                          ))
        {
            blueAPI_BufferRelease(pBuffer);
        }
    }
    else
    {
        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
        {
            DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "!!!LTP:blueAPI_GATTAttributePrepareWriteReq blueAPI_BufferGet failed!", 0);
        }
    }

    return;
}

void BTLTPHandleGATTAttributeExecuteWriteReq(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    WORD pos = 1;
    BYTE loc_MDL_ID;
    BYTE flags;

    loc_MDL_ID    = pPara[pos++];
    flags    = pPara[pos++];
    blueAPI_GATTAttributeExecuteWriteReq(loc_MDL_ID, flags);
}

void BTLTPHandleGATTAttributePrepareWriteCnf(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    WORD pos = 1;
    BYTE cause;
    WORD subCause       = 0x0000;
    BYTE loc_MDL_ID     = 0x00;
    BYTE serviceHandle  = 0x00;
    WORD attribIndex    = 0x0000;

    PBTLtpMDLContext pMDLContext = NULL;
    WORD wOffset = 0;
    void* pBuffer = NULL;
    WORD ds_pool_id = 0;

    /* read mandatory parameters                                             */
    cause           = pPara[pos++];
    subCause      = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    loc_MDL_ID    = pPara[pos++];
    serviceHandle = pPara[pos++];
    attribIndex   = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;

    /* read optional parameters */
    pMDLContext = BTLTPFindMDLContext(pBTLtp, loc_MDL_ID);

    if (NULL != pMDLContext)
    {
        wOffset = pMDLContext->dsDataOffset;
        ds_pool_id = pMDLContext->dsPoolID;
    }

    if (blueAPI_CauseSuccess == blueAPI_BufferGet(ds_pool_id,  lenPara - pos, wOffset, (void**)&pBuffer))
    {
        memcpy(((BYTE *)pBuffer) + wOffset, pPara + pos, lenPara - pos);
        if (!blueAPI_GATTAttributePrepareWriteConf(pBuffer,
                                           loc_MDL_ID,
                                           BTLTPLookupGATTServiceHandle(pBTLtp, serviceHandle),
                                           (TBlueAPI_Cause)cause,
                                           subCause,
                                           attribIndex,
                                           (lenPara - pos),
                                           wOffset
                                          ))
        {
            blueAPI_BufferRelease(pBuffer);
        }
    }
    else
    {
        if(P_AciConfig->ltp_trace_level >= LTP_TRACE_ERROR)
        {
            DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "!!!LTP:BTLTPHandleGATTAttributePrepareWriteCnf blueAPI_BufferGet failed!", 0);
        }
    }
  
    return;
}

void BTLTPHandleGATTAttributeExecuteWriteCnf(PBTLtp pBTLtp, BYTE copmsk, LPBYTE pOpt, WORD lenPara, LPBYTE pPara)
{
    WORD pos = 1;
    BYTE loc_MDL_ID;
    BYTE cause;
    WORD subCause;
    WORD handle;

    loc_MDL_ID    = pPara[pos++];
    cause    = pPara[pos++];
    subCause = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    handle = NETCHAR2SHORT(&pPara[pos]);
    pos += 2;
    blueAPI_GATTAttributeExecuteWriteConf(loc_MDL_ID, (TBlueAPI_Cause)cause, subCause, handle);
}

void BTLTPHandleAuthDeleteReq(PBTLtp pBTLtp,BYTE copmsk, LPBYTE pOpt,WORD lenPara,LPBYTE pPara)
{
    WORD   pos = 0;
    LPBYTE rem_BD;                                              /* mandatory */
    TBlueAPI_RemoteBDType rem_BD_Type = blueAPI_RemoteBDTypeAny;
    TBlueAPI_Cause cause= blueAPI_CauseInvalidParameter;

    /* read mandatory parameters                                             */
    rem_BD = &pPara[pos]; pos+=6;

    /* read optional parameters                                              */
    pos = 0;
    if (copmsk & LTP_AUTH_DELETE_REQ_OPT_MASK_BD_TYPE)
    {
        rem_BD_Type = (TBlueAPI_RemoteBDType)pOpt[pos++];
    }

    if(pBTLtp->ltp_key_store_en) 
    {
        WORD          i;
        BYTE           BD0[6]        = { 0, 0, 0, 0, 0, 0 };
        bool              nullBD;
        nullBD = (memcmp(rem_BD, BD0, BLUE_API_BD_SIZE) == 0);
        
        for (i = 0; i < GATTDSTORE_ENTRY_COUNT; i++)
        {
            PGATTDStoreEntry pSearch = &gapBond_extStore[i];

            if (((pSearch->used == GATTDSTORE_SEC_ENTRY) || (pSearch->used == GATTDSTORE_CCC_ENTRY)) &&
                    ((nullBD) || (memcmp(pSearch->bd, rem_BD, 6) == 0)) &&
                    ((rem_BD_Type == blueAPI_RemoteBDTypeAny) || (pSearch->bdType == rem_BD_Type))
               )
            {
                pSearch->used = GATTDSTORE_FREE_ENTRY;
                fs_save_TGATTDStoreEntry_struct(pSearch, i);
                cause = blueAPI_CauseSuccess;
                
            }
        }
        fs_del_latest_bond(rem_BD, rem_BD_Type);
    }

    {
      BYTE opt[1];

      opt[0] = rem_BD_Type;

      LTPLibSendAuthDeleteRsp(&pBTLtp->LTPLib,
                              (BTLTP_DEFAULT_COPMSK |
                               LTP_AUTH_DELETE_RSP_OPT_MASK_BD_TYPE
                              ),
                              opt,
                              cause,
                              rem_BD
                              );
    }
}

void BTLTPHandleAuthListReq(PBTLtp pBTLtp,BYTE copmsk, LPBYTE pOpt,WORD lenPara,LPBYTE pPara)
{
    WORD   pos = 0;
    LPBYTE rem_BD;
    TBlueAPI_RemoteBDType rem_BD_Type = blueAPI_RemoteBDTypeAny;
    BYTE opt[2];
    BOOL found = false;
    BOOL get_latest = false;
    
    /* read mandatory parameters                                             */
    rem_BD = &pPara[pos]; pos+=6;

    /* read optional parameters                                              */
    pos = 0;
    if (copmsk & LTP_AUTH_LIST_REQ_OPT_MASK_BD_TYPE)
    {
        rem_BD_Type = (TBlueAPI_RemoteBDType)pOpt[pos++];
    }
    if (copmsk & LTP_AUTH_LIST_REQ_OPT_MASK_GET_LATEST)
    {
        get_latest = pOpt[pos++];
    }
    opt[0] = rem_BD_Type;

    if(get_latest)
    {
        remote_BD_struct remotebd;
        found = fs_get_latest_bond(&remotebd);
        opt[0] = remotebd.remote_bd_type;
        opt[1] = get_latest;
        LTPLibSendAuthListRsp(&pBTLtp->LTPLib,
                    (BTLTP_DEFAULT_COPMSK |
                     LTP_AUTH_LIST_RSP_OPT_MASK_BD_TYPE|
                     LTP_AUTH_LIST_RSP_OPT_MASK_GET_LATEST
                    ),
                    opt,
                    found ? blueAPI_CauseSuccess
                              : blueAPI_CauseReject,
                    remotebd.addr
                    );
        return;
        
    }
    
   /* non */
    if(pBTLtp->ltp_key_store_en) 
    {
        WORD          i;
        BYTE          BD0[6]        = { 0, 0, 0, 0, 0, 0 };
        bool          nullBD;
 
        nullBD = (memcmp(rem_BD, BD0, BLUE_API_BD_SIZE) == 0);
        
        for (i = 0; i < GATTDSTORE_ENTRY_COUNT; i++)
        {
            PGATTDStoreEntry pSearch = &gapBond_extStore[i];

            if ((pSearch->used == GATTDSTORE_SEC_ENTRY) &&
                    ((nullBD) || (memcmp(pSearch->bd, rem_BD, 6) == 0)) &&
                    ((rem_BD_Type == blueAPI_RemoteBDTypeAny) || (pSearch->bdType == rem_BD_Type))
               )
            {
                opt[0] = pSearch->bdType;
                LTPLibSendAuthListInfo(&pBTLtp->LTPLib,
                         (BTLTP_DEFAULT_COPMSK |
                          LTP_AUTH_LIST_INFO_OPT_MASK_BD_TYPE
                         ),
                         opt,
                         pSearch->bd,
                         pSearch->p.sec.keyType
                         );
                found = true;
                
            }
        }
    }
   
    LTPLibSendAuthListRsp(&pBTLtp->LTPLib,
                        (BTLTP_DEFAULT_COPMSK |
                         LTP_AUTH_LIST_RSP_OPT_MASK_BD_TYPE
                        ),
                        opt,
                        found ? blueAPI_CauseSuccess
                                  : blueAPI_CauseInvalidParameter,
                        rem_BD
                        );
}

