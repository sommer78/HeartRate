#include "rtl876x_uart.h"
#include "trace.h"
#include "GPS_cmd.h"
#include <string.h>
#include "GPS_application.h"

static const uint16_t ccitt_table[256] = {
    0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50A5, 0x60C6, 0x70E7,
    0x8108, 0x9129, 0xA14A, 0xB16B, 0xC18C, 0xD1AD, 0xE1CE, 0xF1EF,
    0x1231, 0x0210, 0x3273, 0x2252, 0x52B5, 0x4294, 0x72F7, 0x62D6,
    0x9339, 0x8318, 0xB37B, 0xA35A, 0xD3BD, 0xC39C, 0xF3FF, 0xE3DE,
    0x2462, 0x3443, 0x0420, 0x1401, 0x64E6, 0x74C7, 0x44A4, 0x5485,
    0xA56A, 0xB54B, 0x8528, 0x9509, 0xE5EE, 0xF5CF, 0xC5AC, 0xD58D,
    0x3653, 0x2672, 0x1611, 0x0630, 0x76D7, 0x66F6, 0x5695, 0x46B4,
    0xB75B, 0xA77A, 0x9719, 0x8738, 0xF7DF, 0xE7FE, 0xD79D, 0xC7BC,
    0x48C4, 0x58E5, 0x6886, 0x78A7, 0x0840, 0x1861, 0x2802, 0x3823,
    0xC9CC, 0xD9ED, 0xE98E, 0xF9AF, 0x8948, 0x9969, 0xA90A, 0xB92B,
    0x5AF5, 0x4AD4, 0x7AB7, 0x6A96, 0x1A71, 0x0A50, 0x3A33, 0x2A12,
    0xDBFD, 0xCBDC, 0xFBBF, 0xEB9E, 0x9B79, 0x8B58, 0xBB3B, 0xAB1A,
    0x6CA6, 0x7C87, 0x4CE4, 0x5CC5, 0x2C22, 0x3C03, 0x0C60, 0x1C41,
    0xEDAE, 0xFD8F, 0xCDEC, 0xDDCD, 0xAD2A, 0xBD0B, 0x8D68, 0x9D49,
    0x7E97, 0x6EB6, 0x5ED5, 0x4EF4, 0x3E13, 0x2E32, 0x1E51, 0x0E70,
    0xFF9F, 0xEFBE, 0xDFDD, 0xCFFC, 0xBF1B, 0xAF3A, 0x9F59, 0x8F78,
    0x9188, 0x81A9, 0xB1CA, 0xA1EB, 0xD10C, 0xC12D, 0xF14E, 0xE16F,
    0x1080, 0x00A1, 0x30C2, 0x20E3, 0x5004, 0x4025, 0x7046, 0x6067,
    0x83B9, 0x9398, 0xA3FB, 0xB3DA, 0xC33D, 0xD31C, 0xE37F, 0xF35E,
    0x02B1, 0x1290, 0x22F3, 0x32D2, 0x4235, 0x5214, 0x6277, 0x7256,
    0xB5EA, 0xA5CB, 0x95A8, 0x8589, 0xF56E, 0xE54F, 0xD52C, 0xC50D,
    0x34E2, 0x24C3, 0x14A0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
    0xA7DB, 0xB7FA, 0x8799, 0x97B8, 0xE75F, 0xF77E, 0xC71D, 0xD73C,
    0x26D3, 0x36F2, 0x0691, 0x16B0, 0x6657, 0x7676, 0x4615, 0x5634,
    0xD94C, 0xC96D, 0xF90E, 0xE92F, 0x99C8, 0x89E9, 0xB98A, 0xA9AB,
    0x5844, 0x4865, 0x7806, 0x6827, 0x18C0, 0x08E1, 0x3882, 0x28A3,
    0xCB7D, 0xDB5C, 0xEB3F, 0xFB1E, 0x8BF9, 0x9BD8, 0xABBB, 0xBB9A,
    0x4A75, 0x5A54, 0x6A37, 0x7A16, 0x0AF1, 0x1AD0, 0x2AB3, 0x3A92,
    0xFD2E, 0xED0F, 0xDD6C, 0xCD4D, 0xBDAA, 0xAD8B, 0x9DE8, 0x8DC9,
    0x7C26, 0x6C07, 0x5C64, 0x4C45, 0x3CA2, 0x2C83, 0x1CE0, 0x0CC1,
    0xEF1F, 0xFF3E, 0xCF5D, 0xDF7C, 0xAF9B, 0xBFBA, 0x8FD9, 0x9FF8,
    0x6E17, 0x7E36, 0x4E55, 0x5E74, 0x2E93, 0x3EB2, 0x0ED1, 0x1EF0
};


static uint16_t crc16(uint8_t *q, uint16_t len)
{
    uint16_t crc = 0;

    while (len-- > 0)
        crc = ccitt_table[(crc >> 8 ^ *q++) & 0xff] ^ (crc << 8);

    return crc;
}

bool Send(uint8_t *pBuf, uint32_t Len)
{
    for (; Len != 0; )
    {
        while (1)
        {
            if (UART_GetFlagState(UART, UART_FLAG_THR_EMPTY) == SET)
            {
                break;
            }
        }

        if (Len < 16)
        {
            UART_SendData(UART, pBuf, Len);
            break;
        }
        else
        {
            UART_SendData(UART, pBuf, 16);
            pBuf += 16;
            Len -= 16;
        }
    }
    return true;
}

static bool Recv(uint8_t *pBuf, uint32_t Len, uint32_t *pRetLen)
{

    uint32_t TotalNumberOfBytesRead = 0;
    uint8_t have_checksum;
    uint16_t msg_len;
    uint32_t  EventLen = 0;

    PRxGpsData pData = NULL;
    int i = 0;
    for (; i < 7; i++)
    {
        if (xQueueReceive(g_AppCB->QueueHandleGpsEvent, &pData, 4) == pdPASS)
        {
            if (TotalNumberOfBytesRead == 0)
            {
                if (pData->rx_buffer[0] != 0xA5)
                {
                    //DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "rec:start byte is 0x%02x discard\n", 1, pData->rx_buffer[0]);
                }
                else
                {
                    memcpy(pBuf, pData->rx_buffer, pData->length);
                    TotalNumberOfBytesRead += pData->length;
                    if (TotalNumberOfBytesRead < LEN_6_BYTE)
                    {
                        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "TotalNumberOfBytesRead < LEN_6_BYTE\n", 0);
                        AppQueueIn(&g_AppCB->rxGPSEventQueueFree, pData);
                        *pRetLen = 0;
                        return FALSE;
                    }
                    msg_len = ((pBuf[1] & 0x0f) << 8) + pBuf[2];
                    have_checksum = pBuf[1] & 0x80 ? 1 : 0;
                    EventLen = 4 + msg_len + 2 * have_checksum;
                    // Round up to 8-byte alignment
                    EventLen = (EventLen + 0x07) & ~0x07;

                }
            }
            else
            {
                memcpy(pBuf + TotalNumberOfBytesRead, pData->rx_buffer, pData->length);
                TotalNumberOfBytesRead += pData->length;
            }
            AppQueueIn(&g_AppCB->rxGPSEventQueueFree, pData);
            if (TotalNumberOfBytesRead != 0)
            {
                if (EventLen > TotalNumberOfBytesRead)
                {

                }
                else
                {
                    *pRetLen = EventLen;
                    return TRUE;
                }
            }

        }
        else
        {
            DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "Recv: timeout\n", 0);
            *pRetLen = 0;
            return FALSE;
        }
    }
    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "rec:packet too long %d\n", 1, i);
    *pRetLen = 0;
    return FALSE;
}

static bool fill_hci_tx_packet(
    uint8_t have_checksum,
    uint8_t pid,
    uint8_t sid,
    uint8_t *msg_data_buf,
    uint16_t msg_data_len,
    HCI_TX_PKT *p_packet
)
{
    uint8_t tmp_byte;
    uint16_t tmp_short, checksum;


    // params check
    if (((msg_data_len > 0) && (msg_data_buf == NULL)) ||
            (msg_data_len > 300) ||
            (p_packet == NULL))
    {
        return -1;
    }

    memset(p_packet, 0, sizeof(HCI_TX_PKT));

    // alloc pkt buffer
    p_packet->hci_pkt_length = 4        // 0xA5,CM,RSVD,Len,...,0xA5
                               + ((have_checksum > 0) * 2)     // checksum
                               + 2                             // pid,sid
                               + ((msg_data_len > 0) * 2)      // msg data len, 2bytes
                               + msg_data_len;                 // msg data

    // align to 8-byte
    p_packet->hci_pkt_length = (p_packet->hci_pkt_length + 0x07) & ~0x07;

    // fill packet buffer
    p_packet->hci_pkt_buf[0] = 0xA5;
    tmp_short = 2 + ((msg_data_len > 0) ? 2 + msg_data_len : 0);
    tmp_byte = (uint8_t)(tmp_short >> 8);

    if (have_checksum)
        tmp_byte |= 0x80;
    p_packet->hci_pkt_buf[1] = tmp_byte;
    p_packet->hci_pkt_buf[2] = (uint8_t)(tmp_short & 0xff);
    p_packet->hci_pkt_buf[3] = pid;
    p_packet->hci_pkt_buf[4] = sid;
    tmp_short = 5;
    if (msg_data_len > 0)
    {
        *(p_packet->hci_pkt_buf + tmp_short) = (uint8_t)(msg_data_len >> 8);      //msg len0
        tmp_short++;
        *(p_packet->hci_pkt_buf + tmp_short) = (uint8_t)(msg_data_len & 0xff);    //msg len1
        tmp_short++;
        memcpy(p_packet->hci_pkt_buf + tmp_short, msg_data_buf, msg_data_len);  //msg data
        tmp_short += msg_data_len;
    }

    if (have_checksum)
    {
        checksum = crc16(p_packet->hci_pkt_buf + 1, (uint16_t)(tmp_short - 1));
        *(p_packet->hci_pkt_buf + tmp_short) = (uint8_t)(checksum >> 8);      // checksum high byte
        tmp_short++;
        *(p_packet->hci_pkt_buf + tmp_short) = (uint8_t)(checksum);           // checksum low byte
        tmp_short++;
    }

    *(p_packet->hci_pkt_buf + tmp_short) = 0xA5;    // checksum
    tmp_short++;

    // Add dummy bytes 0xff to make the packet 8-byte alignment
    while (tmp_short < p_packet->hci_pkt_length)
    {
        *(p_packet->hci_pkt_buf + tmp_short) = 0xff;
        tmp_short++;
    }

    return TRUE;
}

static bool send_hci_tx_packet(
    HCI_TX_PKT *p_packet
)
{
    return Send(p_packet->hci_pkt_buf, p_packet->hci_pkt_length);
}

static bool fill_hci_rx_packet(
    uint8_t *buf,
    uint16_t len,
    HCI_RX_PKT *p_packet
)
{
    uint16_t msg_len;
    uint16_t crc_begin;
    uint16_t crc_checksum;
    uint16_t crc_result = 0;


    p_packet->hci_pkt_length = len;
    memcpy(p_packet->hci_pkt_buf, buf, len);

    if (buf[1] & 0x80)
        p_packet->have_checksum = 1;

    msg_len = ((buf[1] & 0xf) << 8) + buf[2];
    if (msg_len > 2)
    {
        p_packet->have_msg_data = 1;
        p_packet->msg_data_length = (buf[5] << 8) + buf[6];
        p_packet->msg_data_buf = p_packet->hci_pkt_buf + 7;
    }

    p_packet->pid = buf[3];
    p_packet->sid = buf[4];

    if (p_packet->have_checksum)
    {
        if (p_packet->have_msg_data)
        {
            crc_begin = 5 + 2 + p_packet->msg_data_length;
        }
        else
        {
            crc_begin = 5;
        }

        crc_checksum = (p_packet->hci_pkt_buf[crc_begin] << 8)
                       + p_packet->hci_pkt_buf[crc_begin + 1];

        if (crc16(p_packet->hci_pkt_buf + 1, (uint16_t)(crc_begin - 1)) == crc_checksum)
        {
            crc_result = 1;
        }
        else
        {
            crc_result = 0;
        }

        if (crc_result)
        {
            p_packet->chechsum_right = 1;
        }
    }

    return TRUE;
}

static bool node_2_hci(
    uint8_t *buf,
    uint16_t len,
    HCI_RX_PKT *p_packet
)
{
    uint16_t msg_len;
    uint8_t have_checksum;
    uint8_t data[GPS_RX_LEN];
    uint16_t calc_len;

    if (len >= 6)
    {
        if (buf[0] != 0xA5)
        {
            DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "node_2_hci:1***buf[0,1,2]=%x,%x,%x len=%d\n", 4, buf[0], buf[1], buf[2], len);
            return FALSE;
        }

        if (buf[1] & 0x80)
            have_checksum = 1;
        else
            have_checksum = 0;

        msg_len = ((buf[1] & 0x0f) << 8) + buf[2];
        calc_len = 4 + msg_len + 2 * have_checksum;
        if(calc_len > GPS_RX_LEN)
        {
            DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "node_2_hci:2 calc_len(%d) > GPS_RX_LEN \n", 1, calc_len);
            return FALSE;
        }

        if (len < calc_len)
        {
            //we donot process partial HCI pkt now, but...maybe oneday.
            DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "node_2_hci:2***buf[0,1,2]=%x,%x,%x \n", 3, buf[0], buf[1], buf[2]);
            return FALSE;
        }
        else
        {
            if (buf[calc_len - 1] != 0xA5)
            {
                DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "node_2_hci: 3--------------------------------\n", 0);
                return FALSE;
            }
            else
            {
                memcpy(data, buf, calc_len);
                if (!fill_hci_rx_packet(data, calc_len, p_packet))
                {
                    return FALSE;
                }

            }
        }
    }
    else
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "node_2_hci:4***buf[0,1,2,3,4]=0x%02x,0x%02x,0x%02x,0x%02x,0x%02x len=%d\n", 6, buf[0], buf[1], buf[2], buf[3], buf[4], len);
        return FALSE;
    }

    return TRUE;
}

static bool recv_hci_rx_packet(
    HCI_RX_PKT *p_packet
)
{
    uint8_t buf[GPS_RX_LEN];
    uint32_t len;

    if (!Recv(buf, GPS_RX_LEN, &len))
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "recv_hci_rx_packet: Recv error\n", 0);
        return FALSE;
    }

    if (!node_2_hci(buf, (uint16_t)len, p_packet))
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "recv_hci_rx_packet: node_2_hci error\n", 0);
        return FALSE;
    }

    return TRUE;
}


static bool send_hci_cmd_with_rx_pkt(
    uint8_t have_checksum,
    uint8_t pid,
    uint8_t sid,
    uint8_t *msg_data_buf,
    uint16_t msg_data_len,
    HCI_RX_PKT *p_rx_packet
)
{
    HCI_TX_PKT tx_pkt;
    uint32_t err_status;

    memset(p_rx_packet, 0, sizeof(HCI_RX_PKT));

    if (!fill_hci_tx_packet(have_checksum, pid, sid, msg_data_buf, msg_data_len, &tx_pkt))
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "send_hci_cmd_with_rx_pkt: fill_hci_tx_packet error\n", 0);
        return FALSE;
    }

    if (!send_hci_tx_packet(&tx_pkt))
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "send_hci_cmd_with_rx_pkt: send_hci_tx_packet error\n", 0);
        return FALSE;
    }

    if (!recv_hci_rx_packet(p_rx_packet))
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "send_hci_cmd_with_rx_pkt: recv_hci_rx_packet error\n", 0);
        return FALSE;
    }

    if (p_rx_packet->have_checksum && p_rx_packet->chechsum_right == 0)
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "send_hci_cmd_with_rx_pkt: rx packet crc err\n", 0);
        return FALSE;
    }

    err_status = ((uint32_t)p_rx_packet->msg_data_buf[0]) +
                 ((uint32_t)p_rx_packet->msg_data_buf[1] << 8) +
                 ((uint32_t)p_rx_packet->msg_data_buf[2] << 16) +
                 ((uint32_t)p_rx_packet->msg_data_buf[3] << 24);

    if (err_status != 0)
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "send_hci_cmd_with_rx_pkt: err_status 0x%08x\n", 1, err_status);
        return FALSE;

    }

    return TRUE;
}

bool gps_hci_read_mem_cmd(uint8_t sid, uint32_t address, uint8_t *p_reading_bytes, uint16_t reading_len)
{
    HCI_RX_PKT rx_pkt;
    unsigned int len;
    uint8_t ubuf[6];


    if ((address >= ROM_ADDRESS_START && address <= ROM_ADDRESS_END) ||
            (address >= SRAM_ADDRESS_START && address <= SRAM_ADDRESS_END) ||
            (address >= DMEM_ADDRESS_START && address <= DMEM_ADDRESS_END) ||
            (address >= PATCHCODE_SRAM_ADDRESS_START && address <= PATCHCODE_SRAM_ADDRESS_END) ||
            (address >= ALWAYSON_SRAM_ADDRESS_START && address <= ALWAYSON_SRAM_ADDRESS_END) ||
            (address >= 0xb9000000 && address <= 0xb900FFFF) ||
            (address >= 0x19000000 && address <= 0x190000FF))
    {
        //RTKMP_DBG(GREEN, " addr can read 0x%x!", addr);
    }
    else
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "gps_hci_read_mem_cmd : ERROR addr can not read 0x%x !\n", 1, address);
        return FALSE;
    }

    ubuf[0] = (uint8_t)(address);
    ubuf[1] = (uint8_t)(address >> 8);
    ubuf[2] = (uint8_t)(address >> 16);
    ubuf[3] = (uint8_t)(address >> 24);

    switch (sid)
    {
        case SID_CMD_0:
            if ((reading_len > 1008) || (reading_len <= 0))
            {
                DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "gps_hci_read_mem_cmd : ERROR read len err\n", 0);
                return FALSE;
            }

            ubuf[5] = (uint8_t)(reading_len >> 8);
            ubuf[4] = (uint8_t)(reading_len);
            len = 6;
            break;

        default:
            DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "gps_hci_read_mem_cmd : ERROR sid(%d)err!\n", 1, sid);
            return FALSE;
    }

    if (!send_hci_cmd_with_rx_pkt(CHECKSUM_EN, PID_READ_MEM_CMD, SID_CMD_0, ubuf, (uint16_t)len, &rx_pkt))
        return FALSE;

    switch (rx_pkt.sid)
    {
        case SID_CMD_0:
            memcpy(p_reading_bytes, &rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN], rx_pkt.msg_data_length - HCI_EVENT_DATA_BEGIN);
            break;
    }

    return TRUE;
}

bool gps_hci_write_mem_cmd(uint8_t sid, uint32_t address, const uint8_t *p_writing_bytes, uint16_t len)
{
    uint8_t buf[50];
    HCI_RX_PKT rx_pkt;

    if ((address >= SRAM_ADDRESS_START && address <= SRAM_ADDRESS_END) ||
            (address >= DMEM_ADDRESS_START && address <= DMEM_ADDRESS_END) ||
            (address >= PATCHCODE_SRAM_ADDRESS_START && address <= PATCHCODE_SRAM_ADDRESS_END) ||
            (address >= ALWAYSON_SRAM_ADDRESS_START && address <= ALWAYSON_SRAM_ADDRESS_END) ||
            (address >= 0xb9000000) ||
            (address >= 0x19000000 && address <= 0x190000FF)
       )
    {
        //RTKMP_DBG(GREEN, " addr can write!");
    }
    else
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "gps_hci_write_mem_cmd : ERROR addr can not write!\n", 0);
        return FALSE;
    }

    if ((len > 40) || (len <= 0))
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "gps_hci_write_mem_cmd : ERROR write too much! %d\n", 1, len);
        return FALSE;
    }

    buf[0] = (uint8_t)(address);
    buf[1] = (uint8_t)(address >> 8);
    buf[2] = (uint8_t)(address >> 16);
    buf[3] = (uint8_t)(address >> 24);

    switch (sid)
    {
        case SID_CMD_0:
            memcpy(buf + 4, p_writing_bytes, len);
            len = len + 4;
            if (!send_hci_cmd_with_rx_pkt(CHECKSUM_EN, PID_WRITE_MEM_CMD, SID_CMD_0, buf, len, &rx_pkt))
                return FALSE;
            break;
        case SID_CMD_1:
            memcpy(buf + 4, p_writing_bytes, len);
            len = len + 4;
            if (!send_hci_cmd_with_rx_pkt(CHECKSUM_EN, PID_WRITE_MEM_CMD, SID_CMD_1, buf, len, &rx_pkt))
                return FALSE;
            break;
        case SID_CMD_2:
            memcpy(buf + 4, p_writing_bytes, len);
            len = len + 4;
            if (!send_hci_cmd_with_rx_pkt(CHECKSUM_EN, PID_WRITE_MEM_CMD, SID_CMD_2, buf, len, &rx_pkt))
                return FALSE;
            break;
        case SID_CMD_3:
            memcpy(buf + 4, p_writing_bytes, len);
            len = len + 4;
            if (!send_hci_cmd_with_rx_pkt(CHECKSUM_EN, PID_WRITE_MEM_CMD, SID_CMD_3, buf, len, &rx_pkt))
                return FALSE;
            break;
        default:
            break;
    }

    return TRUE;
}

bool gps_hci_test_cmd(uint8_t sid)
{
    //unsigned int i;
    HCI_RX_PKT rx_pkt;
    uint8_t buf[10];

    switch (sid)
    {
        case SID_CMD_9:
            buf[0] = 1;
            if (!send_hci_cmd_with_rx_pkt(CHECKSUM_EN, PID_TEST_CMD, sid, buf, 1, &rx_pkt))
                return FALSE;
            break;
        case SID_CMD_2:
        case SID_CMD_3:
        case SID_CMD_4:
        case SID_CMD_5:
        case SID_CMD_6:
        case SID_CMD_7:

            if (!send_hci_cmd_with_rx_pkt(CHECKSUM_EN, PID_TEST_CMD, sid, buf, 1, &rx_pkt))
                return FALSE;
            break;

        case SID_CMD_10:
        default:
            break;
    }

    if (!rx_pkt.have_msg_data)
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "RX_HCI: PID_%d, SID%x, CRC_%d_%d\n", 4,
                   rx_pkt.pid, rx_pkt.sid, rx_pkt.have_checksum, rx_pkt.chechsum_right);
    }
    else
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "RX_HCI: PID_%d, SID_%d, CRC_%d_%d, m[0,1,2]=%d,%d,%d, ml=%d\n", 8,
                   rx_pkt.pid, rx_pkt.sid, rx_pkt.have_checksum, rx_pkt.chechsum_right,
                   rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 0], rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 1], rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 2], rx_pkt.msg_data_length);
    }

    return TRUE;
}


bool gps_hci_patch_code_cmd(uint8_t sid, uint8_t error_check_mode, const uint8_t *p_patch_code, int patch_len)
{
    unsigned int i, j, len;
    uint8_t ubuf[ONE_TX_PATCH_MSG_LEN + 4 + 2]; //4 is addr len
    HCI_RX_PKT rx_pkt;
    unsigned int time, retry_times;
    uint32_t patch_end_of_patch;
    uint32_t patch_support_feature;
    uint32_t patch_more_version_var[2];

    switch (sid)
    {
        case SID_CMD_0:
            time = (patch_len / ONE_TX_PATCH_MSG_LEN);
            for (i = 0; i <= time; i++)
            {
                //RTKMP_DBG(_T("gps_hci_patch_code(%d) = %dth\n"), time, i);

                if (i == time)
                {
                    for (j = 0; j < (patch_len - ONE_TX_PATCH_MSG_LEN * i); j++)
                    {
                        ubuf[5 + j] = p_patch_code[i * ONE_TX_PATCH_MSG_LEN + j];

                    }
                }
                else
                {
                    for (j = 0; j < ONE_TX_PATCH_MSG_LEN; j++)
                    {
                        ubuf[5 + j] = p_patch_code[i * ONE_TX_PATCH_MSG_LEN + j];
                    }
                }

                ubuf[0] = (uint8_t)(PATCH_BASE + i * ONE_TX_PATCH_MSG_LEN);
                ubuf[1] = (uint8_t)((PATCH_BASE + i * ONE_TX_PATCH_MSG_LEN) >> 8);
                ubuf[2] = (uint8_t)((PATCH_BASE + i * ONE_TX_PATCH_MSG_LEN) >> 16);
                ubuf[3] = (uint8_t)((PATCH_BASE + i * ONE_TX_PATCH_MSG_LEN) >> 24);
                ubuf[4] = error_check_mode; // error check mode

                len = j + 5;

                for (retry_times = 0; retry_times < 6; retry_times++)
                {
                    if (!send_hci_cmd_with_rx_pkt(CHECKSUM_EN, PID_PATCH_CODE_CMD, SID_CMD_0, ubuf, (uint16_t)len, &rx_pkt))
                    {
                        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "gps_hci_patch_code(%d) = %dth error.....goto retry %dth\n", 3, time, i, retry_times);
                    }
                    else
                    {
                        break;
                    }
                }

                if (retry_times > 5)
                {
                    return FALSE;
                }

            }

            break;

        case SID_CMD_1:
            //tx end packet
            //year = strtoul((const char *)&hci_cmdNode->other[2],&stop_flag,16);
            //year/month/day/version is came from gps_patch.bin
            // satisfy big endian
            patch_end_of_patch = ((unsigned int)p_patch_code[PATCH_VERSION_BASE + 3] << 24) + ((unsigned int)p_patch_code[PATCH_VERSION_BASE + 2] << 16) + ((unsigned int)p_patch_code[PATCH_VERSION_BASE + 1] << 8) + ((unsigned int)p_patch_code[PATCH_VERSION_BASE + 0]);
            patch_support_feature = ((unsigned int)p_patch_code[PATCH_FEATURE_BASE + 3] << 24) + ((unsigned int)p_patch_code[PATCH_FEATURE_BASE + 2] << 16) + ((unsigned int)p_patch_code[PATCH_FEATURE_BASE + 1] << 8) + ((unsigned int)p_patch_code[PATCH_FEATURE_BASE + 0]);
            patch_more_version_var[0] = ((unsigned int)p_patch_code[PATCH_SVNCOEX_BASE + 3] << 24) + ((unsigned int)p_patch_code[PATCH_SVNCOEX_BASE + 2] << 16) + ((unsigned int)p_patch_code[PATCH_SVNCOEX_BASE + 1] << 8) + ((unsigned int)p_patch_code[PATCH_SVNCOEX_BASE + 0]);
            patch_more_version_var[1] = ((unsigned int)p_patch_code[PATCH_SVNCOEX_BASE + 7] << 24) + ((unsigned int)p_patch_code[PATCH_SVNCOEX_BASE + 6] << 16) + ((unsigned int)p_patch_code[PATCH_SVNCOEX_BASE + 5] << 8) + ((unsigned int)p_patch_code[PATCH_SVNCOEX_BASE + 4]);

            ubuf[0] = (uint8_t)patch_end_of_patch;
            ubuf[1] = (uint8_t)(patch_end_of_patch >> 8);
            ubuf[2] = (uint8_t)(patch_end_of_patch >> 16);
            ubuf[3] = (uint8_t)(patch_end_of_patch >> 24);

            ubuf[4] = (uint8_t)patch_support_feature;
            ubuf[5] = (uint8_t)(patch_support_feature >> 8);
            ubuf[6] = (uint8_t)(patch_support_feature >> 16);
            ubuf[7] = (uint8_t)(patch_support_feature >> 24);

            ubuf[8] = (uint8_t)patch_more_version_var[0];
            ubuf[9] = (uint8_t)(patch_more_version_var[0] >> 8) ;
            ubuf[10] = (uint8_t)(patch_more_version_var[0] >> 16);
            ubuf[11] = (uint8_t)(patch_more_version_var[0] >> 24);

            ubuf[12] = (uint8_t)(patch_more_version_var[1]);
            ubuf[13] = (uint8_t)(patch_more_version_var[1] >> 8);
            ubuf[14] = (uint8_t)(patch_more_version_var[1] >> 16);
            ubuf[15] = (uint8_t)(patch_more_version_var[1] >> 24);

            len = 16;

            if (!send_hci_cmd_with_rx_pkt(CHECKSUM_EN, PID_PATCH_CODE_CMD, SID_CMD_1, ubuf, (uint16_t)len, &rx_pkt))
                return FALSE;

            break;

        case SID_CMD_2: // sign ROM patch anyway

            //tx end packet
            ubuf[0] = 0x00;
            len = 1;

            if (!send_hci_cmd_with_rx_pkt(CHECKSUM_EN, PID_PATCH_CODE_CMD, SID_CMD_2, ubuf, (uint16_t)len, &rx_pkt))
                return FALSE;

            break;

        case SID_CMD_3: // erase rom code patched flag
            //tx end packet
            ubuf[0] = 0x00;
            len = 1;

            if (!send_hci_cmd_with_rx_pkt(CHECKSUM_EN, PID_PATCH_CODE_CMD, SID_CMD_3, ubuf, (uint16_t)len, &rx_pkt))
                return FALSE;

            break;

        case SID_CMD_4:
            // clear patched sram
            //tx end packet
            ubuf[3] = (0x80100000 >> 24) & 0xFF;
            ubuf[2] = (0x80100000 >> 16) & 0xFF;
            ubuf[1] = (0x80100000 >> 8) & 0xFF;
            ubuf[0] = (0x80100000) & 0xFF;
            ubuf[7] = (0xA400 >> 24) & 0xFF;
            ubuf[6] = (0xA400 >> 16) & 0xFF;
            ubuf[5] = (0xA400 >> 8) & 0xFF;
            ubuf[4] = (0xA400) & 0xFF;

            len = 8;

            if (!send_hci_cmd_with_rx_pkt(CHECKSUM_EN, PID_PATCH_CODE_CMD, SID_CMD_4, ubuf, (uint16_t)len, &rx_pkt))
                return FALSE;

            break;

        case SID_CMD_5:
            // get patched flag status
            //tx end packet
            ubuf[0] = 0x00;
            len = 1;

            if (!send_hci_cmd_with_rx_pkt(CHECKSUM_EN, PID_PATCH_CODE_CMD, SID_CMD_5, ubuf, (uint16_t)len, &rx_pkt))
                return FALSE;

            break;

        case SID_CMD_6: // clear patched sram
            break;

        case SID_CMD_7: // clear patched sram
            //tx end packet
            ubuf[3] = (0x80100000 >> 24) & 0xFF;
            ubuf[2] = (0x80100000 >> 16) & 0xFF;
            ubuf[1] = (0x80100000 >> 8) & 0xFF;
            ubuf[0] = (0x80100000) & 0xFF;
            ubuf[7] = (0xA400 >> 24) & 0xFF;
            ubuf[6] = (0xA400 >> 16) & 0xFF;
            ubuf[5] = (0xA400 >> 8) & 0xFF;
            ubuf[4] = (0xA400) & 0xFF;

            len = 8;

            if (!send_hci_cmd_with_rx_pkt(CHECKSUM_EN, PID_PATCH_CODE_CMD, SID_CMD_7, ubuf, (uint16_t)len, &rx_pkt))
            {
                return FALSE;
            }

            break;

        default:
            //tx end packet
            ubuf[0] = 0x00;
            len = 1;

            if (!send_hci_cmd_with_rx_pkt(CHECKSUM_EN, PID_PATCH_CODE_CMD, SID_CMD_6, ubuf, (uint16_t)len, &rx_pkt))
                return FALSE;

            break;
    }

    if ((rx_pkt.sid == 0) || (rx_pkt.sid == 6))
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "next start address = 0x%X\n", 1, (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 3] << 24) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 2] << 16) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 1] << 8) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 0]));
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "err check mode = %d\n", 1, (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 4]));
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "sram check error cnt = %d\n", 1, (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 8] << 24) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 7] << 16) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 6] << 8) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 5]));
    }
    else
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "IS ROM PATCHED FLAG = %d\n", 1, (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 3] << 24) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 2] << 16) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 1] << 8) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 0]));
        patch_end_of_patch = (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 7] << 24) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 6] << 16) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 5] << 8) + rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 4];
        patch_support_feature = (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 11] << 24) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 10] << 16) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 9] << 8) + rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 8];
        patch_more_version_var[0] = (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 15] << 24) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 14] << 16) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 13] << 8) + rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 12];
        patch_more_version_var[1] = (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 19] << 24) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 18] << 16) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 17] << 8) + rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 16];
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "version = 0x%08X, support feature = 0x%08X, svn coexistece ver = 0x%08x, 0x%08X\n", 4, patch_end_of_patch, patch_support_feature, patch_more_version_var[0], patch_more_version_var[1]);
    }

    return TRUE;
}

bool gps_hci_power_ctrl_cmd_set_mode(uint8_t mode)
{
    HCI_RX_PKT rx_pkt;
    uint8_t ubuf[6];

    uint8_t rd_wr_byte1;
    uint8_t p_rd_wr_word1[LEN_2_BYTE];
    uint8_t p_rd_wr_word3[LEN_4_BYTE];

    ubuf[0] = mode;

    /* clear some bits */
    if (!mode) {
#if 1
        rd_wr_byte1 = 0;
        if (!gps_hci_write_mem_cmd(SID_CMD_1, 0x8010a731, &rd_wr_byte1, LEN_1_BYTE))
            return FALSE;
        if (!gps_hci_read_mem_cmd(SID_CMD_0, 0x8010a731, &rd_wr_byte1, LEN_1_BYTE))
            return FALSE;
#endif
        rd_wr_byte1 = 0;
        if (!gps_hci_write_mem_cmd(SID_CMD_1, 0xB9000064, &rd_wr_byte1, LEN_1_BYTE))
            return FALSE;
        p_rd_wr_word1[0] = 0x64;
        p_rd_wr_word1[1] = 0x00;
        //rd_wr_word1 = 100;
        if (!gps_hci_write_mem_cmd(SID_CMD_2, 0xB90000D0, p_rd_wr_word1, LEN_2_BYTE))
            return FALSE;
        p_rd_wr_word1[0] = 0xD0;
        p_rd_wr_word1[1] = 0x07;
        //rd_wr_word1 = 2000;
        if (!gps_hci_write_mem_cmd(SID_CMD_2, 0xB90000D4, p_rd_wr_word1, LEN_2_BYTE))
            return FALSE;
        p_rd_wr_word1[0] = 0xF4;
        p_rd_wr_word1[1] = 0x01;
        //rd_wr_word1 = 500;
        if (!gps_hci_write_mem_cmd(SID_CMD_2, 0xB90000D8, p_rd_wr_word1, LEN_2_BYTE))
            return FALSE;

        if (!gps_hci_read_mem_cmd(SID_CMD_0, 0xB90000B8, p_rd_wr_word3, LEN_4_BYTE))
            return FALSE;
        p_rd_wr_word3[1] = p_rd_wr_word3[1] | 0x4;
        if (!gps_hci_write_mem_cmd(SID_CMD_0, 0xB90000B8, p_rd_wr_word3, LEN_4_BYTE))
            return FALSE;
        p_rd_wr_word1[0] = 0xC8;
        p_rd_wr_word1[1] = 0x00;
        //rd_wr_word1 = 500;
        if (!gps_hci_write_mem_cmd(SID_CMD_2, 0xB900005A, p_rd_wr_word1, LEN_2_BYTE))
            return FALSE;
        rd_wr_byte1 = 0;
        if (!gps_hci_write_mem_cmd(SID_CMD_1, 0xB90000E9, &rd_wr_byte1, LEN_1_BYTE))
            return FALSE;
        rd_wr_byte1 = 5;
        if (!gps_hci_write_mem_cmd(SID_CMD_1, 0xB90000EA, &rd_wr_byte1, LEN_1_BYTE))
            return FALSE;
    }
    if (!gps_hci_test_cmd(SID_CMD_9))
    {
    }
    if (!send_hci_cmd_with_rx_pkt(CHECKSUM_EN, PID_POWER_CTRL_CMD, SID_CMD_0, ubuf, LEN_1_BYTE, &rx_pkt))
        return FALSE;

    return TRUE;
}

bool gps_hci_uart_set_baudrate_cmd(uint32_t baudrate, uint32_t char_timeout, uint8_t en_AFC)
{
    HCI_RX_PKT rx_pkt;
    uint8_t ubuf[16];

    ubuf[0] = (uint8_t)baudrate;
    ubuf[1] = (uint8_t)(baudrate >> 8);
    ubuf[2] = (uint8_t)(baudrate >> 16);
    ubuf[3] = (uint8_t)(baudrate >> 24);

    ubuf[4] = (uint8_t)char_timeout;
    ubuf[5] = (uint8_t)(char_timeout >> 8);
    ubuf[6] = (uint8_t)(char_timeout >> 16);
    ubuf[7] = (uint8_t)(char_timeout >> 24);

    ubuf[8] = en_AFC;

    send_hci_cmd_with_rx_pkt(CHECKSUM_EN, PID_SET_BAUDRATE_CMD, SID_CMD_0, ubuf, LEN_9_BYTE, &rx_pkt);

    return TRUE;
}

bool gps_hci_mode_selection(uint8_t param1, uint8_t param2)
{
    uint8_t buf[16];
    HCI_RX_PKT rx_pkt;

    buf[0] = param1;
    buf[1] = param2;

    if (!send_hci_cmd_with_rx_pkt(CHECKSUM_EN, PID_GPS_CONTROL_CMD, SID_CMD_6, buf, 2, &rx_pkt))
        return FALSE;

    return TRUE;
}

bool gps_hci_read_patch_flag(bool *is_patch)
{
    uint8_t ubuf[16];
    unsigned int len;
    HCI_RX_PKT rx_pkt;
    *is_patch = FALSE;
    uint32_t patch_flag;
    uint32_t patch_end_of_patch;
    uint32_t patch_support_feature;
    uint32_t patch_more_version_var[2];

    ubuf[0] = 0x00;
    len = 1;

    if (!send_hci_cmd_with_rx_pkt(CHECKSUM_EN, PID_PATCH_CODE_CMD, SID_CMD_5, ubuf, (uint16_t)len, &rx_pkt))
        return FALSE;


    if (!rx_pkt.have_msg_data)
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "RX_HCI: PID_%d, SID%x, CRC_%d_%d\n", 4,
                   rx_pkt.pid, rx_pkt.sid, rx_pkt.have_checksum, rx_pkt.chechsum_right);
    }
    else
    {

        patch_flag = (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 3] << 24) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 2] << 16) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 1] << 8) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 0]);
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "IS ROM PATCHED FLAG = %d\n", 1, (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 3] << 24) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 2] << 16) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 1] << 8) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 0]));
        patch_end_of_patch = (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 7] << 24) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 6] << 16) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 5] << 8) + rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 4];
        patch_support_feature = (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 11] << 24) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 10] << 16) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 9] << 8) + rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 8];
        patch_more_version_var[0] = (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 15] << 24) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 14] << 16) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 13] << 8) + rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 12];
        patch_more_version_var[1] = (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 19] << 24) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 18] << 16) + (rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 17] << 8) + rx_pkt.msg_data_buf[HCI_EVENT_DATA_BEGIN + 16];
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "version = 0x%08X, support feature = 0x%08X, svn coexistece ver = 0x%08x, 0x%08X\n", 4, patch_end_of_patch, patch_support_feature, patch_more_version_var[0], patch_more_version_var[1]);

        if (patch_flag == 1)
        {
            *is_patch = TRUE;
        }
        else
        {
            *is_patch = FALSE;
        }
    }

    return TRUE;
}

