/*
 *  Routines to access hardware
 *
 *  Copyright (c) 2014 Realtek Semiconductor Corp.
 *
 *  This module is a confidential and proprietary property of RealTek and
 *  possession or use of this module requires written permission of RealTek.
 */


#ifndef _GPS_TASK_H_
#define  _GPS_TASK_H_

#define DOWNLOAD_GPS_PATCH_EVENT          0x01
#define WAKE_UP_GPS_EVENT                 0x02
#define SEND_DATA_TO_GPS_EVENT            0x03

#define MSG_GPS_PATCH_SUCCESS             0x03

typedef enum
{
    GPS_IDLE = 0,
    GPS_CMD  = 1,
    GPS_DATA_TRANS  = 2
} GpsMode;

void GPS_SendGpsMessage(uint8_t event);
void GPS_TaskInit( void );

extern GpsMode gGpsMode;
extern bool IsGpsPatch;

#endif

