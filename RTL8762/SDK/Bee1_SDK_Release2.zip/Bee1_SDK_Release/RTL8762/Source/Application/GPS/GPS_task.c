#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>

#include "GPS_task.h"
#include <string.h>
#include "rtl_delay.h"
#include "app_queue.h"
#include "GPS_application.h"
#include "rtl876x_uart.h"
#include "GPS_cmd.h"
#include "GPS_patch.h"
#include "GPS_uart.h"
#include "os.h"

#define GPS_TASK_PRIORITY          (tskIDLE_PRIORITY + 1)   /* Task priorities. */
#define GPS_TASK_STACK_SIZE            3072

#define MAX_NUMBER_OF_GPS_EVENT     0x10

xQueueHandle hGpsEventQueueHandle;
GpsMode gGpsMode = GPS_IDLE;
TimerHandle_t TimersGPSWakeUp;
bool IsGpsPatch = FALSE;

void GPS_SendGpsMessage(uint8_t event)
{
    if (xQueueSend(hGpsEventQueueHandle, &event, 0) == errQUEUE_FULL)
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "SendGpsMessage: sent failed (%d)", 1, event);
    }
}

static void TimerGPSWakeUpCallback(TimerHandle_t pxTimer )
{
    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "TimerGPSWakeUpCallback", 0);
    if ( xTimerIsTimerActive( pxTimer ) != pdFALSE )
    {
        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "xTimer is already active - delete it", 0);
    }
    else
    {
        GPS_SendGpsMessage(WAKE_UP_GPS_EVENT);
    }
}
/****************************************************************************/
/* TASK                                                                     */
/****************************************************************************/
void GPSTask(void *pParameters)
{
    char event;

    while (true)
    {
        if (xQueueReceive(hGpsEventQueueHandle, &event, portMAX_DELAY) == pdPASS)
        {
            DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "GPSTask receive event %d\n", 1, event);
            if (event == DOWNLOAD_GPS_PATCH_EVENT)
            {
                uint16_t times = 0;
                bool is_patch = FALSE;

                gGpsMode = GPS_CMD;

                if (!gps_hci_test_cmd(SID_CMD_2))
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "DownloadMPFirmware1: gps_hci_test_cmd SID_CMD_2 retry\n", 0);
                    if (!gps_hci_test_cmd(SID_CMD_2))
                    {
                        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "DownloadMPFirmware1: gps_hci_test_cmd SID_CMD_2 failed\n", 0);
                        gGpsMode = GPS_IDLE;
                        GPS_SendGpsMessage(DOWNLOAD_GPS_PATCH_EVENT);
                        continue;
                    }
                }
                if (!gps_hci_read_patch_flag(&is_patch))
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "DownloadMPFirmware2: gps_hci_read_patch_flag failed\n", 0);
                    gGpsMode = GPS_IDLE;
                    GPS_SendGpsMessage(DOWNLOAD_GPS_PATCH_EVENT);
                    continue;
                }
                if (!is_patch)
                {
                    if (!gps_hci_patch_code_cmd(SID_CMD_4, 0, NULL, 0))
                    {
                        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "DownloadMPFirmware3: gps_hci_patch_code_cmd(SID_CMD_4, 0, NULL, 0)\n", 0);
                        gGpsMode = GPS_IDLE;
                        GPS_SendGpsMessage(DOWNLOAD_GPS_PATCH_EVENT);
                        continue;
                    }

                    // 4. download patch code
                    if (!gps_hci_patch_code_cmd(SID_CMD_0, 1, GpsPatchBin, 0xA40C))
                    {
                        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "DownloadMPFirmware4: gps_hci_patch_code_cmd(SID_CMD_0, 1, FileBuf, FileSize)\n", 0);
                        gGpsMode = GPS_IDLE;
                        GPS_SendGpsMessage(DOWNLOAD_GPS_PATCH_EVENT);
                        continue;
                    }

                    // 5. sign patch flag
                    if (!gps_hci_patch_code_cmd(SID_CMD_2, 0, NULL, 0))
                    {
                        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "DownloadMPFirmware5: gps_hci_patch_code_cmd(SID_CMD_2, 0, NULL, 0)\n", 0);
                        gGpsMode = GPS_IDLE;
                        GPS_SendGpsMessage(DOWNLOAD_GPS_PATCH_EVENT);
                        continue;
                    }

                    if (!gps_hci_test_cmd(SID_CMD_3))
                    {

                    }
                    // 6. into sleep mode
                    if (!gps_hci_power_ctrl_cmd_set_mode(0))
                    {
                        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "DownloadMPFirmware6: gps_hci_power_ctrl_cmd_set_mode(0) failed\n", 0);
                        gGpsMode = GPS_IDLE;
                        GPS_SendGpsMessage(DOWNLOAD_GPS_PATCH_EVENT);
                        continue;
                    }
                    gGpsMode = GPS_IDLE;
                    delayMS(200);
                    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, DISABLE);

                    // 7 . try to wake up gps  fix me try some time
                    for (; times < 2; times++)
                    {
                        if (!gps_hci_test_cmd(SID_CMD_2))
                        {
                            delayMS(20);
                        }
                        else
                        {
                            break;
                        }
                    }
                    xTimerStart(TimersGPSWakeUp, 0);
                    continue;
                }

                if (!gps_hci_test_cmd(SID_CMD_3))
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "DownloadMPFirmware:wake up failed\n", 0);

                }
                if (!gps_hci_test_cmd(SID_CMD_3))
                {


                }
                if (!gps_hci_test_cmd(SID_CMD_4))
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "DownloadMPFirmware:gps_hci_test_cmd(SID_CMD_4) failed\n", 0);
                }

                if (!gps_hci_test_cmd(SID_CMD_9))
                {

                }
                if (!gps_hci_test_cmd(SID_CMD_3))
                {

                }
                #if 0
                if (!gps_hci_mode_selection(0, 4))
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "DownloadMPFirmware: PID_GPS_CONTROL_CMD failed\n", 0);
                }
                #endif
                gGpsMode = GPS_IDLE;
                IsGpsPatch = TRUE;
                {
                    BEE_IO_MSG gps_msg;
                    gps_msg.IoType = IO_UART_MSG_TYPE;
                    gps_msg.subType = MSG_GPS_PATCH_SUCCESS;
                    gps_msg.pBuf = NULL;

                    if (!SendMessage(&gps_msg))
                    {
                        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "DownloadMPFirmware: send message failed\n", 0);
                    }
                }
            }
            else if (event == WAKE_UP_GPS_EVENT)
            {
                UARTEnableIntrrupt();
                gGpsMode = GPS_CMD;

                if (!gps_hci_test_cmd(SID_CMD_3))
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "WAKE_UP_GPS_EVENT:wake up failed\n", 0);

                }
                if (!gps_hci_test_cmd(SID_CMD_3))
                {


                }
                if (!gps_hci_test_cmd(SID_CMD_4))
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "WAKE_UP_GPS_EVENT:gps_hci_test_cmd(SID_CMD_4) failed\n", 0);
                }

                if (!gps_hci_test_cmd(SID_CMD_9))
                {

                }
                if (!gps_hci_test_cmd(SID_CMD_3))
                {

                }
                if (!gps_hci_mode_selection(0, 4))
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "WAKE_UP_GPS_EVENT: PID_GPS_CONTROL_CMD failed\n", 0);
                    if (!gps_hci_mode_selection(0, 4))
                    {
                    }
                }
                gGpsMode = GPS_IDLE;
                IsGpsPatch = TRUE;
                {
                    BEE_IO_MSG gps_msg;
                    gps_msg.IoType = IO_UART_MSG_TYPE;
                    gps_msg.subType = MSG_GPS_PATCH_SUCCESS;
                    gps_msg.pBuf = NULL;

                    if (!SendMessage(&gps_msg))
                    {
                        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "WAKE_UP_GPS_EVENT: send message failed\n", 0);
                    }
                }
            }
            else if (event == SEND_DATA_TO_GPS_EVENT)
            {
                PTxData pData = NULL;
                if (xQueueReceive(g_AppCB->QueueHandleTxData, &pData, portMAX_DELAY) == pdPASS)
                {
                    if (!Send(pData->tx_buffer, pData->length))
                    {
                        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "SEND_DATA_TO_GPS_EVENT: send data failed\n", 0);
                    }
                    AppQueueIn(&g_AppCB->dataToUartQueueFree, pData);
                }
                else
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "GPSTask: xQueueReceive fail", 0);
                }
            }
        }

    }
}

static void RxGpsEventQueueInit(void)
{
    uint8_t i = 0;
    uint8_t queue_size = GPS_EVENT_PACKET_COUNT;
    PRxGpsData pRxGpsData = g_AppCB->rxGPSEventBuffer;
    g_AppCB->rxGPSEventQueueFree.ElementCount = 0;
    g_AppCB->rxGPSEventQueueFree.First = NULL;
    g_AppCB->rxGPSEventQueueFree.Last = NULL;

    for ( i = 0; i < queue_size; i++ )
    {
        AppQueueIn(&g_AppCB->rxGPSEventQueueFree, pRxGpsData);
        pRxGpsData++;
    }
}
void GPS_TaskInit( void )
{
    hGpsEventQueueHandle = xQueueCreate(MAX_NUMBER_OF_GPS_EVENT,
                                        sizeof(unsigned char));
    g_AppCB->QueueHandleGpsEvent = xQueueCreate(GPS_EVENT_PACKET_COUNT, sizeof(PRxGpsData));
    RxGpsEventQueueInit();
    TimersGPSWakeUp = xTimerCreate("TimersGPSWakeUp", (800 / portTICK_RATE_MS), pdFALSE, ( void *) 8, TimerGPSWakeUpCallback);

    if ( TimersGPSWakeUp == NULL )
    {
        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "TimerInit TimersGPSWakeUp init failed", 0);
    }
    xTaskCreate(GPSTask, "GPSTask", GPS_TASK_STACK_SIZE / sizeof(portSTACK_TYPE), NULL, GPS_TASK_PRIORITY, &g_AppCB->gpsAssistHandle);
}
