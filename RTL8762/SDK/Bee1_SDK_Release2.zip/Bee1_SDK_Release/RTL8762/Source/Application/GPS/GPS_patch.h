#ifndef __GPS_PATCH_H_
#define __GPS_PATCH_H_

/* Contents of file gps_patch.bin */
extern const long int GpsPatchBinSize;
extern const uint8_t GpsPatchBin[];

#endif
