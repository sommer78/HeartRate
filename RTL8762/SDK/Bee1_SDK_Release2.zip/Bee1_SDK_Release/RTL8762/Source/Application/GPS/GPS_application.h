/*
 *  Routines to access hardware
 *
 *  Copyright (c) 2014 Realtek Semiconductor Corp.
 *
 *  This module is a confidential and proprietary property of RealTek and
 *  possession or use of this module requires written permission of RealTek.
 */


#ifndef _GPS_APPLICATION_H_
#define  _GPS_APPLICATION_H_
#include "rtl_types.h"
#include "app_queue.h"
#include "FreeRTOS.h"
#include "queue.h"
#include "GPS_cmd.h"
#include "timers.h"
#include "bee_message.h"
#include "peripheral.h"

#define UART_RX_BUFFER_LENGTH       400
#define TX_PACKET_MAX_LENGTH 100
#define TX_PACKET_COUNT      1
#define GPS_EVENT_PACKET_MAX_LENGTH 14
#define GPS_EVENT_PACKET_COUNT      10
#define DATA_TO_APP_PACKET_MAX_LENGTH 20
#define DATA_TO_APP_PACKET_COUNT      10
#define DATA_TRANSMIT_DATA_PACKET_MAX_LENGTH 20

typedef struct _TXData
{
    struct _TXData *pNext;
    uint8_t    tx_buffer[TX_PACKET_MAX_LENGTH];
    uint16_t   length;
} TTxData, *PTxData;

typedef struct _RXGpsData
{
    struct _RXGpsData *pNext;
    uint8_t   rx_buffer[GPS_EVENT_PACKET_MAX_LENGTH];
    uint16_t  length;
} TRxGpsData, *PRxGpsData;

typedef struct _TxAppData
{
    struct _TxAppData *pNext;
    uint8_t   send_buffer[DATA_TO_APP_PACKET_MAX_LENGTH];
    uint16_t  length;
} TTxAppData, *PTxAppData;

/** @brief uart control struct */
typedef struct
{
    xTaskHandle      gpsAssistHandle;
    xQueueHandle     QueueHandleTxData;   /* Tx queue */
    xQueueHandle     QueueHandleGpsEvent;   /* Tx queue */

    TTxAppData       dataToAppBuffer[DATA_TO_APP_PACKET_COUNT];
    QUEUE_T          dataToAppQueueFree;
    QUEUE_T          dataToAppQueue;

    uint8_t          rxBuffer[UART_RX_BUFFER_LENGTH];
    uint16_t         rxBufferWriteOffset;
    uint16_t         rxBufferWriteOffsetOld;
    uint16_t         rxBufferReadOffset;
    uint16_t         rxBufferDataLength;
    uint16_t         rxBufferCmdOffset;

    TRxGpsData       rxGPSEventBuffer[GPS_EVENT_PACKET_COUNT];
    QUEUE_T          rxGPSEventQueueFree;

    TTxData          dataToUartBuffer[TX_PACKET_COUNT];
    QUEUE_T          dataToUartQueueFree;

    gaprole_States_t gapProfileState;
    bool             tx_service_cccd_enable;
    uint8_t          wDsCredits;
} TAPP_TCB, *P_APP_TCB;

extern P_APP_TCB g_AppCB;
extern TimerHandle_t TimersUartDataRx;

void AppHandleIODriverMessage(BEE_IO_MSG io_driver_msg_recv);
void AppHandleGATTCallback(uint8_t serviceID, void *pData);
void ApplicationInit( void );

#endif
