enum { __FILE_NUM__ = 0 };

/*
 *  Routines to access hardware
 *
 *  Copyright (c) 2014 Realtek Semiconductor Corp.
 *
 *  This module is a confidential and proprietary property of RealTek and
 *  possession or use of this module requires written permission of RealTek.
 */

#include <string.h>
#include "trace.h"
#include "dataTrans_profile.h"
#include "app_queue.h"
#include "rtl_string.h"
#include "GPS_application.h"
#include "profileApi.h"
#include "GPS_task.h"

uint8_t gDataTransServiceId = 0xff;


static const TAttribAppl GattDataTransmitProfileTable[] =
{
    /*----------------- uart data Service -------------------*/
    /* <<Primary Service>>, .. */
    {
        (ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_LE),   /* wFlags     */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_PRIMARY_SERVICE),
            HI_WORD(GATT_UUID_PRIMARY_SERVICE),
            LO_WORD(GATT_UUID_DATA_TRANSMIT),              /* service UUID */
            HI_WORD(GATT_UUID_DATA_TRANSMIT)
        },
        UUID_16BIT_SIZE,                            /* bValueLen     */
        NULL,                                       /* pValueContext */
        GATT_PERM_READ                              /* wPermissions  */
    },

    /* Data TX Characteristic */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_NOTIFY,              /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* Data TX Characteristic value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHAR_DATA_TX),
            HI_WORD(GATT_UUID_CHAR_DATA_TX)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_NOTIF_IND                         /* wPermissions?????????????????? */
    },

    /* client characteristic configuration */
    {
        ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_CCCD_APPL,                   /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHAR_CLIENT_CONFIG),
            HI_WORD(GATT_UUID_CHAR_CLIENT_CONFIG),
            LO_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT), /* client char. config. bit field */
            HI_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT)
        },
        2,                                          /* bValueLen */
        NULL,
        (GATT_PERM_READ | GATT_PERM_WRITE)          /* wPermissions */
    },

    /* Data RX Characteristic */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_WRITE_NO_RSP, /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* Data RX value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHAR_DATA_RX),
            HI_WORD(GATT_UUID_CHAR_DATA_RX)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_WRITE                         /* wPermissions*/
    }
};



uint8_t  GpsCmdBuffer[TX_PACKET_MAX_LENGTH];
uint16_t GpsCmdBefferLength;
uint32_t GpsEventLen = 0;

static TProfileResult ProfileHandleDataRx(uint16_t wLength, uint8_t *pValue)
{
    TProfileResult wCause = ProfileResult_Success;
    PTxData pTxData = NULL;
    uint8_t have_checksum;
    uint16_t msg_len;
    uint32_t EventLen = 0;

    if (wLength > TX_PACKET_MAX_LENGTH)
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "ProfileHandleDataRx:len too long %d\n", 1, wLength);
        wCause = ProfileResult_InvalidValueSize;
        return wCause;
    }
    if (GpsCmdBefferLength == 0)
    {
        if (pValue[0] != 0xA5)
        {
            DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "ProfileHandleDataRx:start byte is 0x%02x discard\n", 1, pValue[0]);
        }
        else
        {
            memcpy(GpsCmdBuffer, pValue, wLength);
            GpsCmdBefferLength += wLength;
            if (GpsCmdBefferLength < 3)
            {
                DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "GpsCmdBefferLength < 3\n", 0);
                GpsCmdBefferLength = 0;
                GpsEventLen = 0;
                wCause = ProfileResult_Success;
                return wCause;
            }
            msg_len = ((GpsCmdBuffer[1] & 0x0f) << 8) + GpsCmdBuffer[2];
            have_checksum = GpsCmdBuffer[1] & 0x80 ? 1 : 0;
            EventLen = 4 + msg_len + 2 * have_checksum;
            // Round up to 8-byte alignment
            EventLen = (EventLen + 0x07) & ~0x07;
            GpsEventLen = EventLen;

        }
    }
    else
    {
        if (GpsCmdBefferLength + wLength > TX_PACKET_MAX_LENGTH)
        {
            DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "ProfileHandleDataRx packet too large\n", 0);
            GpsCmdBefferLength = 0;
            wCause = ProfileResult_Success;
            return wCause;
        }
        memcpy(GpsCmdBuffer + GpsCmdBefferLength, pValue, wLength);
        GpsCmdBefferLength += wLength;
    }

    if ((GpsCmdBefferLength != 0) && (GpsEventLen <= GpsCmdBefferLength))
    {
        pTxData = AppQueueOut(&g_AppCB->dataToUartQueueFree);
        if (pTxData != NULL)
        {
            memcpy(pTxData->tx_buffer, GpsCmdBuffer, GpsEventLen);
            pTxData->length = GpsEventLen;
            if (xQueueSend(g_AppCB->QueueHandleTxData, &pTxData, 0) == errQUEUE_FULL)
            {
                DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "ProfileHandleDataRx:send data failed\n", 0);
                AppQueueIn(&g_AppCB->dataToUartQueueFree, pTxData);
            }
            else
            {
                GPS_SendGpsMessage(SEND_DATA_TO_GPS_EVENT);
            }
        }
        else
        {
            DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "ProfileHandleDataRx: queue is full\n", 0);
            wCause = ProfileResult_Success;
        }
        GpsCmdBefferLength = 0;
        GpsEventLen = 0;
    }

    return wCause;
}

void Profile_DataTransSendData()
{
    PTxAppData pTxData = NULL;
    if (g_AppCB->dataToAppQueue.ElementCount == 0)
    {
        return;
    }


    for (; g_AppCB->dataToAppQueue.ElementCount != 0;)
    {
        if (g_AppCB->wDsCredits == 0)
        {
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Profile_DataTransSendData: credit is 0\n", 0);
            return;
        }

        pTxData = AppQueueOut(&g_AppCB->dataToAppQueue);
        if (pTxData != NULL)
        {
            if (!g_AppCB->tx_service_cccd_enable)
            {
                DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "Profile_DataTransSendData: cccd is not config\n", 0);
                AppQueueIn(&g_AppCB->dataToAppQueueFree, pTxData);
                return;
            }
            if (ProfileAPI_SendData(gDataTransServiceId, DATA_TX_VALUE_INDEX, pTxData->send_buffer,  pTxData->length))
            {
                AppQueueIn(&g_AppCB->dataToAppQueueFree, pTxData);
                g_AppCB->wDsCredits--;
            }
            else
            {

                DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "Profile_DataTransSendData: ProfileAPI_SendData failed\n", 0);
                AppQueueInsert(&g_AppCB->dataToAppQueue, NULL, pTxData);
                return;
            }
        }
    }
}

TProfileResult DataTransAttrWrite(uint8_t ServiceID, uint16_t iAttribIndex,
                                  uint16_t wLength, uint8_t *pValue,TGATTDWriteIndPostProc * pWriteIndPostProc)
{
    TProfileResult  wCause  = ProfileResult_Success;

    if (!pValue)
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "--> DataTransAttrWrite   pValue %p wLength= 0x%x",
                   2,
                   pValue,
                   wLength);
        wCause = ProfileResult_InvalidParameter;
        return wCause;
    }

    switch (iAttribIndex)
    {
        case DATA_RX_VALUE_INDEX:
            wCause = ProfileHandleDataRx(wLength, pValue);
            break;

        default:
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "DataTransAttrWrite not handle iAttribIndex 0x%x\n", 1, iAttribIndex);
            break;
    }

    return wCause;

}

void DataTransCccdUpdate(uint8_t ServiceId, uint16_t Index, uint16_t wCCCBits)
{
    if (Index == (DATA_TX_VALUE_INDEX + 1)) //+1 = config
    {
        if (wCCCBits & GATT_CCCD_NOTIFICATION_BIT)
        {   // enable notification
            g_AppCB->tx_service_cccd_enable = TRUE;
        }
        else
        {   // disable notification.
            g_AppCB->tx_service_cccd_enable = FALSE;
        }
        if (IsGpsPatch)
        {
            if(g_AppCB->tx_service_cccd_enable)
            {
                gGpsMode = GPS_DATA_TRANS;

            }
            else
            {
                gGpsMode = GPS_IDLE;

            }
        }

        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "cccd %x rxBufferWriteOffsetOld = %d ,rxBufferReadOffset is %d rxBufferDataLength %d gps mode %d", 5,wCCCBits, g_AppCB->rxBufferWriteOffsetOld, g_AppCB->rxBufferReadOffset, g_AppCB->rxBufferDataLength, gGpsMode);
    }
}
/*********************************************************************
 * PROFILE CALLBACKS
 */
CONST gattServiceCBs_t
dataTransCBs =
{
    NULL,  // Read callback function pointer
    DataTransAttrWrite, // Write callback function pointer
    DataTransCccdUpdate  // Authorization callback function pointer
};

void DataTrans_AddService(void *pFunc)
{
    if (FALSE == ProfileAPI_AddService(&gDataTransServiceId,
                                       (uint8_t *)GattDataTransmitProfileTable,
                                       sizeof(GattDataTransmitProfileTable),
                                       dataTransCBs))
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "DataTrans_AddService: ServiceId %d", 1, gDataTransServiceId);
        gDataTransServiceId = 0xff;
    }
}
