enum { __FILE_NUM__ = 0 };

/*
 *  Routines to access hardware
 *
 *  Copyright (c) 2014 Realtek Semiconductor Corp.
 *
 *  This module is a confidential and proprietary property of RealTek and
 *  possession or use of this module requires written permission of RealTek.
 */

#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>
#include <timers.h>
#include "blueapi.h"
#include <string.h>

#include "profileAPI.h"

#include "app_queue.h"
#include "timers.h"
#include "bee_message.h"
#include "peripheral.h"
#include "gap.h"
#include "gapbondmgr.h"

#include "GPS_application.h"
#include "GPS_uart.h"
#include "dataTrans_profile.h"
#include "dev_info_profile.h"
#include "GPS_task.h"

/****************************************************************************/
/* Test Profile task macros                                                       */
/****************************************************************************/
#define MAX_NUMBER_OF_TX_MESSAGE        TX_PACKET_COUNT

P_APP_TCB g_AppCB = NULL;
TimerHandle_t TimersUartDataRx;

bool dataTrans_getSendBufferFromRxBuffer(uint16_t len);


/****************************************************************************/
/* RX DATA handle                                                          */
/****************************************************************************/
static void TimerUartDataRxCallback(TimerHandle_t pxTimer )
{
    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "TimerUartDataRxCallback", 0);
    if ( xTimerIsTimerActive( pxTimer ) != pdFALSE )
    {
        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "xTimer is already active - delete it", 0);
    }
    else
    {
        if (g_AppCB->rxBufferDataLength == 0)
        {
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "TimerUartDataRxCallback len = 0", 0);
            return;
        }
        if (g_AppCB->gapProfileState == GAPSTATE_CONNECTED)
        {
            uint16_t len = 0;
            for (; g_AppCB->rxBufferDataLength != 0;)
            {
                if (g_AppCB->rxBufferDataLength >= DATA_TRANSMIT_DATA_PACKET_MAX_LENGTH)
                    len = DATA_TRANSMIT_DATA_PACKET_MAX_LENGTH;
                else
                    len = g_AppCB->rxBufferDataLength;

                if (dataTrans_getSendBufferFromRxBuffer(len))
                {

                }
                else
                {
                    return;
                }
            }

            Profile_DataTransSendData();
        }
        else
        {
            taskENTER_CRITICAL();
            g_AppCB->rxBufferDataLength = 0;
            g_AppCB->rxBufferReadOffset = g_AppCB->rxBufferWriteOffsetOld;
            taskEXIT_CRITICAL();
        }
    }
}

static void dataTrans_handleUartRX(bool isRxTimeout)
{
    if (g_AppCB->rxBufferDataLength == 0)
    {
        return;
    }

    if (g_AppCB->gapProfileState == GAPSTATE_CONNECTED)
    {
        uint16_t len = 0;
        if (isRxTimeout)
        {
            for (; g_AppCB->rxBufferDataLength != 0;)
            {
                if (g_AppCB->rxBufferDataLength >= DATA_TRANSMIT_DATA_PACKET_MAX_LENGTH)
                    len = DATA_TRANSMIT_DATA_PACKET_MAX_LENGTH;
                else
                    len = g_AppCB->rxBufferDataLength;

                if (dataTrans_getSendBufferFromRxBuffer(len))
                {

                }
                else
                {
                    return;
                }
            }

        }
        else
        {
            for (; g_AppCB->rxBufferDataLength >= DATA_TRANSMIT_DATA_PACKET_MAX_LENGTH;)
            {
                len = DATA_TRANSMIT_DATA_PACKET_MAX_LENGTH;
                if (dataTrans_getSendBufferFromRxBuffer(len))
                {

                }
                else
                {
                    return;
                }
            }
        }
        Profile_DataTransSendData();
    }
    else
    {
        taskENTER_CRITICAL();
        g_AppCB->rxBufferDataLength = 0;
        g_AppCB->rxBufferReadOffset = g_AppCB->rxBufferWriteOffsetOld;
        taskEXIT_CRITICAL();
    }
}

bool dataTrans_getSendBufferFromRxBuffer(uint16_t len)
{
    PTxAppData pTxData = NULL;

    if ((len == 0) || (len > g_AppCB->rxBufferDataLength))
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "dataTrans_getSendBufferFromRxBuffer: length is invalid", 0);
        return FALSE;
    }

    pTxData = AppQueueOut(&g_AppCB->dataToAppQueueFree);
    if (pTxData != NULL)
    {
        pTxData->length = len;
        if (g_AppCB->rxBufferReadOffset + len <= UART_RX_BUFFER_LENGTH)
        {
            memcpy(pTxData->send_buffer, g_AppCB->rxBuffer + g_AppCB->rxBufferReadOffset, len);
            g_AppCB->rxBufferReadOffset += len;
        }
        else
        {
            uint16_t len1 = UART_RX_BUFFER_LENGTH - g_AppCB->rxBufferReadOffset;
            memcpy(pTxData->send_buffer, g_AppCB->rxBuffer + g_AppCB->rxBufferReadOffset, len1);
            g_AppCB->rxBufferReadOffset = 0;
            memcpy(pTxData->send_buffer + len1, g_AppCB->rxBuffer + g_AppCB->rxBufferReadOffset, len - len1);
            g_AppCB->rxBufferReadOffset += len - len1;
        }
        taskENTER_CRITICAL();
        g_AppCB->rxBufferDataLength -= len;
        taskEXIT_CRITICAL();
        AppQueueIn(&g_AppCB->dataToAppQueue, pTxData);
        return true;
    }
    else
    {
        Profile_DataTransSendData();
        DBG_BUFFER(MODULE_APP, LEVEL_TRACE, "dataTrans_getSendBufferFromRxBuffer: dataToAppQueueFree is empty", 0);
        return false;
    }


}

static bool UpdateConnInterval(uint16_t param)
{
    uint16_t desired_min_interval;
    uint16_t desired_max_interval;
    uint16_t desired_slave_latency;
    uint16_t desired_conn_timeout;

    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "moduleParam_SetConnInterval: %d", 1, param);
    if ((g_AppCB->gapProfileState != GAPSTATE_CONNECTED) && (g_AppCB->gapProfileState != GAPSTATE_CONNECTED_ADV))
    {
        return FALSE;
    }
    //fix me later ,set for iphone
    if (param <= 20)
    {
        desired_max_interval = 0x10;
        desired_min_interval = 0x08;
    }
    else
    {
        desired_max_interval = param * 4 / 5;
        desired_min_interval = desired_max_interval - 10;
    }
    desired_slave_latency = 0;
    desired_conn_timeout = 500;

    peripheralSetGapParameter( GAPPRRA_MIN_CONN_INTERVAL, sizeof( uint16_t ), &desired_min_interval );
    peripheralSetGapParameter( GAPPRRA_MAX_CONN_INTERVAL, sizeof( uint16_t ), &desired_max_interval );
    peripheralSetGapParameter( GAPPRRA_SLAVE_LATENCY, sizeof( uint16_t ), &desired_slave_latency );
    peripheralSetGapParameter( GAPPRRA_TIMEOUT_MULTIPLIER, sizeof( uint16_t ), &desired_conn_timeout );
    peripheral_SendUpdateParam();

    return TRUE;

}

/****************************************************************************/
/* GAP Message handle and profile message handle                                                          */
/****************************************************************************/
static void peripheral_HandleBtGapMessage(BEE_IO_MSG *pBeeIoMsg)
{
    BT_STACK_MSG BtStackMsg;
    memcpy(&BtStackMsg, &pBeeIoMsg->parm, sizeof(pBeeIoMsg->parm));

    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "peripheral_HandleBtGapMessage subType = %d", 1, pBeeIoMsg->subType);

    switch (pBeeIoMsg->subType)
    {
        case BT_MSG_TYPE_CONN_STATE_CHANGE:
        {
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_CONN_STATE_CHANGE:(%d->%d)",
                       2, g_AppCB->gapProfileState, BtStackMsg.msgData.gapConnStateChange.newState);


            switch ( BtStackMsg.msgData.gapConnStateChange.newState )
            {
                case GAPSTATE_IDLE_NO_ADV_NO_CONN:
                {
                    g_AppCB->tx_service_cccd_enable = FALSE;
                    if (g_AppCB->gapProfileState == GAPSTATE_CONNECTED)
                    {
                        uint8_t disc_reason;
                        peripheralGetGapParameter(GAPPRRA_DISCONNECTED_REASON, &disc_reason);
                        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "peripheral_HandleBtGapStateChangeEvt: disc_reason = %d", 1, disc_reason);
                        peripheral_StartAdvertising();
                    }
                    else
                    {
                    }
                    if (IsGpsPatch)
                    {
                        gGpsMode = GPS_IDLE;
                    }

                }
                break;

                case GAPSTATE_ADVERTISING:
                {
                }
                break;


                case GAPSTATE_CONNECTED:
                {
                    g_AppCB->gapProfileState = (gaprole_States_t)BtStackMsg.msgData.gapConnStateChange.newState;
                    peripheralGetGapParameter(GAPPRRA_MAXTPDUDSCREDITS, &g_AppCB->wDsCredits);
                    UpdateConnInterval(20);
                    if (IsGpsPatch && g_AppCB->tx_service_cccd_enable)
                    {
                        gGpsMode = GPS_DATA_TRANS;
                    }
                }
                break;

                case GAPSTATE_CONNECTED_ADV:
                {

                }
                break;

                default:
                {

                }
                break;

            }

            g_AppCB->gapProfileState = (gaprole_States_t)BtStackMsg.msgData.gapConnStateChange.newState;

        }
        break;

        case BT_MSG_TYPE_BOND_STATE_CHANGE:
        {
            switch (BtStackMsg.msgData.gapBondStateChange.newState)
            {
                case GAPBOND_PAIRING_STATE_STARTED:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(GAPBOND_PAIRING_STATE_STARTED)", 0);
                }
                break;

                case GAPBOND_PAIRING_STATE_COMPLETE:
                {

                }
                break;

                case GAPBOND_PAIRING_STATE_BONDED:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(GAPBOND_PAIRING_STATE_BONDED)", 0);
                }
                break;

                default:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(unknown newstate: %d)", 1, BtStackMsg.msgData.gapBondStateChange.newState);
                }
                break;
            }

        }
        break;

        case BT_MSG_TYPE_BOND_PASSKEY_DISPLAY:
        {

        }
        break;

        case BT_MSG_TYPE_BOND_PASSKEY_INPUT:
        {
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_PASSKEY_INPUT", 0);
            GAPBondMgr_InputPassKey();
        }
        break;

        case BT_MSG_TYPE_BOND_OOB_INPUT:
        {
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_OOB_INPUT", 0);
            GAPBondMgr_InputOobData();
        }
        break;

        case BT_MSG_TYPE_ENCRYPT_STATE_CHANGE:
        {
            switch (BtStackMsg.msgData.gapEncryptStateChange.newState)
            {
                case GAPBOND_ENCRYPT_STATE_ENABLED:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "GAPBOND_ENCRYPT_STATE_ENABLED", 0);
                }
                break;

                case GAPBOND_ENCRYPT_STATE_DISABLED:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "GAPBOND_ENCRYPT_STATE_DISABLED", 0);
                }
                break;

                default:
                    break;
            }
        }
        break;
        case BT_MSG_TYPE_CONN_PARA_UPDATE_CHANGE:
            if (BtStackMsg.msgData.gapConnParaUpdateChange.status == 0)
            {
                uint16_t conn_interval = 0;
                peripheralGetGapParameter(GAPPRRA_CONN_INTERVAL, &conn_interval);
                DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "BT_MSG_TYPE_CONN_PARA_UPDATE_CHANGE 0x%x", 1, conn_interval);
            }
            break;
        default:
            DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "peripheral_HandleBtGapMessage unknown subtype", 1, pBeeIoMsg->subType);

            break;

    }
}

void AppHandleGATTCallback(uint8_t serviceID, void *pData)
{
    if (serviceID == ProfileAPI_ServiceUndefined)
    {
        TEventInfoCBs_t *pPara = (TEventInfoCBs_t *)pData;
        switch (pPara->eventId)
        {
            case PROFILE_EVT_SRV_REG_COMPLETE:// srv register result event.
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "profile callback PROFILE_EVT_SRV_REG_COMPLETE\n", 0);
                peripheral_Init_StartAdvertising();
                GPS_SendGpsMessage(DOWNLOAD_GPS_PATCH_EVENT);
                break;
            case PROFILE_EVT_SEND_DATA_COMPLETE:
                g_AppCB->wDsCredits = pPara->sParas[0];
                Profile_DataTransSendData();
                break;
        }
    }
}

/****************************************************************************/
/* IO Message handle                                                                    */
/****************************************************************************/
void AppHandleIODriverMessage(BEE_IO_MSG io_driver_msg_recv)
{
    uint16_t msgtype = io_driver_msg_recv.IoType;

    switch (msgtype)
    {
        case IO_UART_MSG_TYPE:
            if (io_driver_msg_recv.subType == MSG_UART_RX)
            {
                xTimerReset(TimersUartDataRx, 0);
                dataTrans_handleUartRX(false);
                break;
            }
            else if (io_driver_msg_recv.subType == MSG_UART_RX_TIMEOUT)
            {
                xTimerStop(TimersUartDataRx, 0);
                dataTrans_handleUartRX(true);
                break;
            }
            else if (io_driver_msg_recv.subType == MSG_GPS_PATCH_SUCCESS)
            {
                if ((g_AppCB->gapProfileState == GAPSTATE_CONNECTED) && g_AppCB->tx_service_cccd_enable)
                {
                    gGpsMode = GPS_DATA_TRANS;
                }
                break;
            }
        case BT_STATUS_UPDATE:
        {
            peripheral_HandleBtGapMessage(&io_driver_msg_recv);
        }
        break;
        default:
            break;
    }
}

/****************************************************************************/
/* application Init                                                                */
/****************************************************************************/
static void TimerInit(void)
{
    TimersUartDataRx = xTimerCreate("TimersUartDataRx", 2, pdFALSE, ( void *) 5, TimerUartDataRxCallback);

    if ( TimersUartDataRx == NULL )
    {
        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "TimerInit TimersUartDataRx init failed", 0);
    }
}


static void DataToUartQueueInit(void)
{
    uint8_t i = 0;
    uint8_t tx_queue_size = TX_PACKET_COUNT;
    PTxData pTxData = g_AppCB->dataToUartBuffer;
    g_AppCB->dataToUartQueueFree.ElementCount = 0;
    g_AppCB->dataToUartQueueFree.First = NULL;
    g_AppCB->dataToUartQueueFree.Last = NULL;

    for ( i = 0; i < tx_queue_size; i++ )
    {
        AppQueueIn(&g_AppCB->dataToUartQueueFree, pTxData);
        pTxData++;
    }
}

static void DataToAppQueueInit(void)
{
    uint8_t i = 0;
    uint8_t send_queue_size = DATA_TO_APP_PACKET_COUNT;
    PTxAppData pTxData = g_AppCB->dataToAppBuffer;
    g_AppCB->dataToAppQueueFree.ElementCount = 0;
    g_AppCB->dataToAppQueueFree.First = NULL;
    g_AppCB->dataToAppQueueFree.Last = NULL;
    g_AppCB->dataToAppQueue.ElementCount = 0;
    g_AppCB->dataToAppQueue.First = NULL;
    g_AppCB->dataToAppQueue.Last = NULL;
    for ( i = 0; i < send_queue_size; i++ )
    {
        AppQueueIn(&g_AppCB->dataToAppQueueFree, pTxData);
        pTxData++;
    }
}

void ApplicationInit( void )
{
    g_AppCB->QueueHandleTxData  = xQueueCreate(MAX_NUMBER_OF_TX_MESSAGE, sizeof(PTxData));
    DataToUartQueueInit();
    DataToAppQueueInit();
    TimerInit();
}

