/**
*********************************************************************************************************
*               Copyright(c) 2014, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     GPS_uart.h
* @brief    Data uart operations for testing profiles.
* @details  Data uart init and print data through data uart.
* @author
* @date     2015-03-19
* @version  v0.1
*********************************************************************************************************
*/

#ifndef _DATA_TRANSMIT_UART_H_
#define  _DATA_TRANSMIT_UART_H_

#include "rtl_types.h"
#include "FreeRTOS.h"
#include "timers.h"

extern uint8_t UartRxTriggerLevel;

void UARTInit(void);
void UARTChangeBaudrate(uint32_t  baudrate);
void UARTEnableIntrrupt(void);

#endif

