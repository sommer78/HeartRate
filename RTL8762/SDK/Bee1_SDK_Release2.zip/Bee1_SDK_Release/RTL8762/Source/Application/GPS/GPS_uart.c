enum { __FILE_NUM__ = 0 };

/**
*********************************************************************************************************
*               Copyright(c) 2014, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     GPS_uart.c
* @brief    Data uart operations for testing profiles.
* @details  Data uart init and print data through data uart.
* @author
* @date     2015-03-19
* @version  v0.1
*********************************************************************************************************
*/
#include "rtl876x.h"
#include "rtl876x_bitfields.h"
#include "rtl876x_it.h"

/* for freertos interface */
#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>
/* for test profile self definitions */
#include "GPS_uart.h"
#include "GPS_application.h"
#include "app_queue.h"
#include <string.h>
#include "dataTrans_profile.h"

#include "rtl876x_uart.h"
#include "rtl876x_pinmux.h"
#include "GPS_task.h"

/****************************************************************************/
/* retarget printf                                                          */
/****************************************************************************/
extern xQueueHandle hEventQueueHandle;
extern xQueueHandle hIoQueueHandle;
uint8_t UartRxTriggerLevel = 14;

static void UartSendMsgFromISR(BEE_IO_MSG *pBeeMsgBlk)
{
    portBASE_TYPE SendQueueResult;
    uint8_t Event = 0;
    portBASE_TYPE TaskWoken = pdFALSE;

    SendQueueResult = xQueueSendFromISR(hIoQueueHandle, pBeeMsgBlk, &TaskWoken);
    if (SendQueueResult != pdPASS)
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "UartSendMsgFromISR fail2", 1, SendQueueResult);
    }

    Event = EVENT_NEWIODRIVER_TO_APP;
    SendQueueResult = xQueueSendFromISR(hEventQueueHandle, &Event, &TaskWoken);
    if (SendQueueResult != pdPASS)
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "UartSendMsgFromISR fail", 1, SendQueueResult);
    }
}

static void RxDataStatusUpdate(void)
{
    uint16_t Length;

    /* will not occur in our uart framework!!! */
    if (g_AppCB->rxBufferWriteOffsetOld == g_AppCB->rxBufferWriteOffset)
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "RxDataStatusUpdate: no data", 0);
        return;       /* no data */

    }
    else
    {
        if (g_AppCB->rxBufferWriteOffsetOld > g_AppCB->rxBufferWriteOffset)
        {
            Length = UART_RX_BUFFER_LENGTH - g_AppCB->rxBufferWriteOffsetOld + g_AppCB->rxBufferWriteOffset;
        }
        else
        {
            Length = g_AppCB->rxBufferWriteOffset - g_AppCB->rxBufferWriteOffsetOld;
        }
        g_AppCB->rxBufferWriteOffsetOld = g_AppCB->rxBufferWriteOffset;
    }

    if ((Length + g_AppCB->rxBufferDataLength) > UART_RX_BUFFER_LENGTH)   /* Rx overrun */
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "RxDataStatusUpdate: Rx overrun (%d)", 1, \
                   Length + g_AppCB->rxBufferDataLength);
        g_AppCB->rxBufferDataLength = UART_RX_BUFFER_LENGTH;
        g_AppCB->rxBufferReadOffset = g_AppCB->rxBufferWriteOffsetOld;
    }
    else
    {
        g_AppCB->rxBufferDataLength += Length;         /* update length */
    }
}


/****************************************************************************/
/* UART interrupt                                                           */
/****************************************************************************/
void DataUartIrqHandle(void)
{
    uint32_t int_status;
    uint16_t len = 0;
    BEE_IO_MSG uart_msg;
    uint8_t  pBuffer[14];
    portBASE_TYPE TaskWoken = pdFALSE;
    /* read interrupt id */
    int_status = UART_GetIID(UART);
    /* disable interrupt */
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, DISABLE);

    switch (int_status)
    {
        /* tx fifo empty */
        case UART_INT_ID_TX_EMPTY:
            /* do nothing */
            break;

        /* rx data valiable */
        case UART_INT_ID_RX_LEVEL_REACH:
            if (gGpsMode == GPS_IDLE)
            {
                UART_ReceiveData(UART, pBuffer, UartRxTriggerLevel);
            }
            else if (gGpsMode == GPS_CMD)
            {
                PRxGpsData pGpsData = NULL;
                pGpsData = AppQueueOut(&g_AppCB->rxGPSEventQueueFree);
                if (pGpsData != NULL)
                {
                    UART_ReceiveData(UART, pGpsData->rx_buffer, UartRxTriggerLevel);
                    pGpsData->length = UartRxTriggerLevel;
                    if (xQueueSendFromISR(g_AppCB->QueueHandleGpsEvent, &pGpsData, &TaskWoken) != pdPASS)
                    {
                        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "DataUartIrqHandle:send QueueHandleGpsEvent failed\n", 0);
                        AppQueueIn(&g_AppCB->rxGPSEventQueueFree, pGpsData);
                    }
                }
                else
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "DataUartIrqHandle: queue is empty\n", 0);
                    UART_ReceiveData(UART, pBuffer, UartRxTriggerLevel);
                }
            }
            else
            {

                if ((g_AppCB->rxBufferWriteOffset + UartRxTriggerLevel)\
                        <= UART_RX_BUFFER_LENGTH)
                {
                    UART_ReceiveData(UART, (g_AppCB->rxBuffer + g_AppCB->rxBufferWriteOffset), UartRxTriggerLevel);

                    g_AppCB->rxBufferWriteOffset += UartRxTriggerLevel;
                }
                else
                {
                    len = UART_RX_BUFFER_LENGTH - g_AppCB->rxBufferWriteOffset;
                    UART_ReceiveData(UART, (g_AppCB->rxBuffer + g_AppCB->rxBufferWriteOffset), len);

                    g_AppCB->rxBufferWriteOffset = 0;
                    UART_ReceiveData(UART, g_AppCB->rxBuffer, UartRxTriggerLevel - len);

                    g_AppCB->rxBufferWriteOffset += (UartRxTriggerLevel - len);
                }

                /* update rx data length */
                RxDataStatusUpdate();
                /* notify app task */
                uart_msg.IoType = IO_UART_MSG_TYPE;
                uart_msg.subType = MSG_UART_RX;
                UartSendMsgFromISR(&uart_msg);
            }

            break;

        /* rx time out */
        case UART_INT_ID_RX_TMEOUT:
            if (gGpsMode == GPS_IDLE)
            {
                while (UART_GetFlagState(UART, UART_FLAG_RX_DATA_RDY) == SET)
                {
                    UART_ReceiveData(UART, pBuffer, 1);
                }
            }
            else if (gGpsMode == GPS_CMD)
            {
                int pos = 0;
                PRxGpsData pGpsData = NULL;
                pGpsData = AppQueueOut(&g_AppCB->rxGPSEventQueueFree);
                pGpsData->length = 0;
                if (pGpsData != NULL)
                {
                    while (UART_GetFlagState(UART, UART_FLAG_RX_DATA_RDY) == SET)
                    {
                        UART_ReceiveData(UART, (pGpsData->rx_buffer + pos), 1);
                        pos++;
                    }
                    pGpsData->length = pos;
                    if (xQueueSendFromISR(g_AppCB->QueueHandleGpsEvent, &pGpsData, &TaskWoken) != pdPASS)
                    {
                        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "DataUartIrqHandle:send QueueHandleGpsEvent failed\n", 0);
                        AppQueueIn(&g_AppCB->rxGPSEventQueueFree, pGpsData);
                    }
                }
                else
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "DataUartIrqHandle2: queue is empty\n", 0);
                    while (UART_GetFlagState(UART, UART_FLAG_RX_DATA_RDY) == SET)
                    {
                        UART_ReceiveData(UART, pBuffer, 1);
                    }
                }
            }
            else
            {
                while (UART_GetFlagState(UART, UART_FLAG_RX_DATA_RDY) == SET)
                {
                    if (g_AppCB->rxBufferWriteOffset == UART_RX_BUFFER_LENGTH)
                    {
                        g_AppCB->rxBufferWriteOffset = 0;
                    }

                    UART_ReceiveData(UART, (g_AppCB->rxBuffer + g_AppCB->rxBufferWriteOffset), 1);
                    g_AppCB->rxBufferWriteOffset++;
                }

                /* update rx data length */
                RxDataStatusUpdate();
                /* notify app task */
                uart_msg.IoType = IO_UART_MSG_TYPE;
                uart_msg.subType = MSG_UART_RX_TIMEOUT;
                UartSendMsgFromISR(&uart_msg);
            }
            break;
        /* receive line status interrupt */
        case UART_INT_ID_LINE_STATUS:

            DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "Line status error: %x!!!\n", 1, UART->LSR);
            UART_ClearRxFifo(UART);
            break;

        default:
            break;
    }
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, ENABLE);
}



void UARTChangeBaudrate(uint32_t  baudrate)
{
    //uart init
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "UARTChangeBaudrate: baudrate %d", 1, baudrate);
    UART_InitTypeDef uartInitStruct;
    UART_StructInit(&uartInitStruct);

    uartInitStruct.rxTriggerLevel = UART_RX_FIFO_TRIGGER_LEVEL_14BYTE;
    switch (baudrate)
    {
        case 9600:
            uartInitStruct.div = 271;
            uartInitStruct.ovsr = 10;
            uartInitStruct.ovsr_adj = 0x24A;
            break;
        case 115200:
            uartInitStruct.div = 20;
            uartInitStruct.ovsr = 12;
            uartInitStruct.ovsr_adj = 0x252;
            break;
        default:
            uartInitStruct.div = 271;
            uartInitStruct.ovsr = 10;
            uartInitStruct.ovsr_adj = 0x24A;
            break;
    }
    UART_Init(UART, &uartInitStruct);
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, ENABLE);
    return;
}

void UARTEnableIntrrupt(void)
{
    NVIC_ClearPendingIRQ(UART_IRQ);
    UART_GetFlagState(UART, UART_FLAG_RX_OVERRUN);
    UART_ClearRxFifo(UART);
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, ENABLE);
    NVIC_EnableIRQ(UART_IRQ);
}

/****************************************************************************/
/* UART init                                                                */
/****************************************************************************/
extern IRQ_FUN UserIrqFunTable[32 + 17];
void UARTInit(void)
{
    //pinmux config
    Pinmux_Config(P4_0, DATA_UART_TX);
    Pinmux_Config(P4_1, DATA_UART_RX);

    //pad config
    Pad_Config(P4_0, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
    Pad_Config(P4_1, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);

    //uart interrupt config
    UserIrqFunTable[UART_IRQ]               = (IRQ_FUN)DataUartIrqHandle;

    //uart init
    UART_InitTypeDef uartInitStruct;
    UART_StructInit(&uartInitStruct);

    uartInitStruct.rxTriggerLevel = UART_RX_FIFO_TRIGGER_LEVEL_14BYTE;

    uartInitStruct.div = 20;
    uartInitStruct.ovsr = 12;
    uartInitStruct.ovsr_adj = 0x252;

    UART_Init(UART, &uartInitStruct);
    //enable line status interrupt and rx data avaliable interrupt
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, ENABLE);
    /*  Enable UART IRQ  */
    NVIC_ClearPendingIRQ(UART_IRQ);
    NVIC_SetPriority(UART_IRQ, 0);
    NVIC_EnableIRQ(UART_IRQ);

    return;
}
