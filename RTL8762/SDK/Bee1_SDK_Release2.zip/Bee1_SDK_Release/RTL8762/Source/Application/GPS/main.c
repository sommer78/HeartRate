/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     main.c
* @brief    .
* @details
* @author   jane
* @date     2015-03-29
* @version  v0.2
*********************************************************************************************************
*/
#include "rtl876x.h"
#include "FreeRTOS.h"
#include "task.h"
#include "application.h"
#include "dlps_platform.h"
#include <string.h>
#include "rtl_string.h"

#include "peripheral.h"
#include "gap.h"
#include "gapbondmgr.h"
#include "simpleBLEPeripheral.h"
#include "profileApi.h"

#include "GPS_application.h"
#include "GPS_uart.h"
#include "trace.h"
#include "dataTrans_profile.h"
#include "dev_info_profile.h"
#include "GPS_task.h"
/*
********************************************************
* parameter for btstack
*
*
*********************************************************
*/


// What is the advertising interval when device is discoverable (units of 625us, 160=100ms)
//#define DEFAULT_ADVERTISING_INTERVAL          160

#define DEFAULT_DISCOVERABLE_MODE             GAP_ADTYPE_FLAGS_GENERAL

#define DEFAULT_ADVERTISING_INTERVAL_MIN            0x83        //0x20 /* 20ms */
#define DEFAULT_ADVERTISING_INTERVAL_MAX            0x83        //0x30 /* 30ms */

// Minimum connection interval (units of 1.25ms, 16=20ms) if automatic parameter update request is enabled
#define DEFAULT_DESIRED_MIN_CONN_INTERVAL     16

// Maximum connection interval (units of 1.25ms, 16=20ms) if automatic parameter update request is enabled
#define DEFAULT_DESIRED_MAX_CONN_INTERVAL     16

// Slave latency to use if automatic parameter update request is enabled
#define DEFAULT_DESIRED_SLAVE_LATENCY         0

// Supervision timeout value (units of 10ms, 1000=10s) if automatic parameter update request is enabled
#define DEFAULT_DESIRED_CONN_TIMEOUT          1000

// Whether to enable automatic parameter update request when a connection is formed
#define DEFAULT_ENABLE_UPDATE_REQUEST         TRUE

// GAP - Advertisement data (max size = 31 bytes, though this is
// best kept short to conserve power while advertisting)
static uint8_t AdvData[31] =//31
{
    /* Core spec. Vol. 3, Part C, Chapter 18 */
    /* Flags */
    0x02,            /* length     */
    //XXXXMJMJ 0x01, 0x06,      /* type="flags", data="bit 1: LE General Discoverable Mode", BR/EDR not supp. */
    0x01, 0x05,      /* type="flags", data="bit 1: LE General Discoverable Mode" */
    /* place holder for Local Name, filled by BT stack. if not present */
    /* BT stack appends Local Name.                                    */
    0x0C,           /* length     */
    0x08,           /* type="short local name" */
    'R', 'e','a', 'l', 't', 'e', 'k','_','G','P','S' /* Realtek_GPS */
};

static uint16_t AdvDataLength = 16;
// GAP - SCAN RSP data (max size = 31 bytes)
static uint8_t scanRspData[4] =
{
    0x03,           /* length     */
    0x03,           /* type="More 16-bit UUIDs available" */
    0xE0,
    0xFF,
};


void BtStack_Init_Gap()
{
    //device name and device appearance
    uint16_t Appearance = GAP_GATT_APPEARANCE_UNKNOWN;
    uint8_t DeviceName[GAP_DEVICE_NAME_LEN] = "Realtek_GPS";

    //default start adv when bt stack initialized
    uint8_t  advEnableDefault = TRUE;

    //advertising parameters
    uint8_t  advEventType = GAP_ADTYPE_ADV_IND;
    uint8_t  advDirectType = PEER_ADDRTYPE_PUBLIC;
    uint8_t  advDirectAddr[B_ADDR_LEN] = {0};
    uint8_t  advChanMap = GAP_ADVCHAN_ALL;
    uint8_t  advFilterPolicy = GAP_FILTER_POLICY_ALL;
    uint16_t advIntMin = DEFAULT_ADVERTISING_INTERVAL_MIN;
    uint16_t advIntMax = DEFAULT_ADVERTISING_INTERVAL_MIN;

    //connection update parameters
    uint16_t desired_min_interval = DEFAULT_DESIRED_MIN_CONN_INTERVAL;
    uint16_t desired_max_interval = DEFAULT_DESIRED_MAX_CONN_INTERVAL;
    uint16_t desired_slave_latency = DEFAULT_DESIRED_SLAVE_LATENCY;
    uint16_t desired_conn_timeout = DEFAULT_DESIRED_CONN_TIMEOUT;

    //GAP Bond Manager parameters
    uint8_t pairMode = GAPBOND_PAIRING_MODE_PAIRABLE;
    uint8_t mitm = GAPBOND_AUTH_NO_MITM_YES_BOND;
    uint8_t ioCap = GAPBOND_IO_CAP_NO_INPUT_NO_OUTPUT;
    uint8_t oobEnable = FALSE;
    uint32_t passkey = 0; // passkey "000000"

    //Set device name and device appearance
    peripheralSetGapParameter(GAPPRRA_DEVICE_NAME, GAP_DEVICE_NAME_LEN, DeviceName);
    peripheralSetGapParameter(GAPPRRA_APPEARANCE, sizeof(Appearance), &Appearance);

    //Set advertising parameters
    peripheralSetGapParameter( GAPPRRA_ADV_ENABLE_DEFAULT, sizeof ( advEnableDefault ), &advEnableDefault );
    peripheralSetGapParameter( GAPPRRA_ADV_EVENT_TYPE, sizeof ( advEventType ), &advEventType );
    peripheralSetGapParameter( GAPPRRA_ADV_DIRECT_ADDR_TYPE, sizeof ( advDirectType ), &advDirectType );
    peripheralSetGapParameter( GAPPRRA_ADV_DIRECT_ADDR, sizeof ( advDirectAddr ), advDirectAddr );
    peripheralSetGapParameter( GAPPRRA_ADV_CHANNEL_MAP, sizeof ( advChanMap ), &advChanMap );
    peripheralSetGapParameter( GAPPRRA_ADV_FILTER_POLICY, sizeof ( advFilterPolicy ), &advFilterPolicy );
    peripheralSetGapParameter(GAPPRRA_ADV_INTERVAL_MIN, sizeof(advIntMin), &advIntMin);
    peripheralSetGapParameter(GAPPRRA_ADV_INTERVAL_MAX, sizeof(advIntMax), &advIntMax);
    peripheralSetGapParameter( GAPPRRA_SCAN_RSP_DATA, sizeof ( scanRspData ), scanRspData );
    peripheralSetGapParameter( GAPPRRA_ADVERT_DATA, AdvDataLength, AdvData);

    //set connection update parameters
    peripheralSetGapParameter( GAPPRRA_MIN_CONN_INTERVAL, sizeof( uint16_t ), &desired_min_interval );
    peripheralSetGapParameter( GAPPRRA_MAX_CONN_INTERVAL, sizeof( uint16_t ), &desired_max_interval );
    peripheralSetGapParameter( GAPPRRA_SLAVE_LATENCY, sizeof( uint16_t ), &desired_slave_latency );
    peripheralSetGapParameter( GAPPRRA_TIMEOUT_MULTIPLIER, sizeof( uint16_t ), &desired_conn_timeout );

    // Setup the GAP Bond Manager
    GAPBondMgr_SetParameter( GAPBOND_PAIRING_MODE, sizeof ( uint8_t ), &pairMode );
    GAPBondMgr_SetParameter( GAPBOND_MITM_PROTECTION, sizeof ( uint8_t ), &mitm );
    GAPBondMgr_SetParameter( GAPBOND_IO_CAPABILITIES, sizeof ( uint8_t ), &ioCap );
    GAPBondMgr_SetParameter( GAPBOND_OOB_ENABLED, sizeof ( uint8_t ), &oobEnable );
    GAPBondMgr_SetParameter( GAPBOND_PASSKEY, sizeof ( uint32_t ), &passkey );

}


void BtProfile_Init(void)
{
    DataTrans_AddService(NULL);
    DIS_AddService(NULL);
    ProfileAPI_RegisterCB(AppHandleGATTCallback);
}

void Board_Init()
{
    g_AppCB = pvPortMalloc(sizeof(TAPP_TCB), RAM_TYPE_DATA_ON);
    if (g_AppCB == NULL)
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "g_AppCB Malloc failed\n", 0);
    }
    memset(g_AppCB, 0, sizeof(TAPP_TCB));
}

void Driver_Init()
{
    UARTInit();
}

void PwrMgr_Init()
{
    LPS_MODE_Pause();
}

void Task_Init()
{
    ApplicationInit();
    GPS_TaskInit();
    application_task_init();
}


int main(void)
{
    UINT32 debug[4];
    debug[0] = 0xffffffff;
    debug[1] = 0;
    debug[2] = 0;
    debug[3] = 0;
    Board_Init();

    BtStack_Init_Peripheral();
    BtStack_Init_Gap();
    BtProfile_Init();
    PwrMgr_Init();
    Task_Init();
    set_debug_mask(debug);
    vTaskStartScheduler();

    return 0;
}

