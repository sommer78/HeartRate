/*
 *  Routines to access hardware
 *
 *  Copyright (c) 2014 Realtek Semiconductor Corp.
 *
 *  This module is a confidential and proprietary property of RealTek and
 *  possession or use of this module requires written permission of RealTek.
 */


#ifndef _DATA_TRANSMIT_PROFILE_H_
#define  _DATA_TRANSMIT_PROFILE_H_

#define GATT_UUID_DATA_TRANSMIT  0xFFE0
#define GATT_UUID_CHAR_DATA_TX 0xFFE4
#define GATT_UUID_CHAR_DATA_RX 0xFFE9
#define DATA_TX_VALUE_INDEX  2
#define DATA_RX_VALUE_INDEX  5

void Profile_DataTransSendData(void);
void DataTrans_AddService(void *pFunc);
#endif

