/*
 *  Routines to access hardware
 *
 *  Copyright (c) 2014 Realtek Semiconductor Corp.
 *
 *  This module is a confidential and proprietary property of RealTek and
 *  possession or use of this module requires written permission of RealTek.
 */


#ifndef _GPS_CMD_H_
#define  _GPS_CMD_H_

#define GPS_MAX_LEN 300
#define GPS_RX_LEN 100
#define PATCH_BASE              0x80100000
#define PATCH_VERSION_BASE      0x9000
#define PATCH_FEATURE_BASE      0x9004
#define PATCH_SVNCOEX_BASE      0x9008
#define ONE_TX_PATCH_MSG_LEN    0x00000100

#define ROM_ADDRESS_START               0x80000000
#define ROM_ADDRESS_END                 0x8006ffff      //448KB
#define SRAM_ADDRESS_START              0x80070000
#define SRAM_ADDRESS_END                0x8008ffff      //128KB
#define DMEM_ADDRESS_START              0x800c0000
#define DMEM_ADDRESS_END                0x800fffff      //256KB
#define PATCHCODE_SRAM_ADDRESS_START    0x80100000
#define PATCHCODE_SRAM_ADDRESS_END      0x8016ffff      //448KB
#define ALWAYSON_SRAM_ADDRESS_START     0xA1010000
#define ALWAYSON_SRAM_ADDRESS_END       0xA1016fff      //28KB


#define PID_REPORT_NMEA_DATA_EVENT      0x01
#define PID_PATCH_CODE_EVENT            0x03
#define PID_READ_MEM_EVENT              0x04
#define PID_WRITE_MEM_EVENT             0x05
#define PID_AGPS_PKT_EVENT              0x06
#define PID_GENERAL_ACK_EVENT           0x1E
#define PID_GEOFENCEING_EVENT1          0x30
#define PID_GEOFENCEING_EVENT2          0x31

#define PID_TEST_CMD                    0xFF
#define PID_VERSION_INFO_CMD            0x00
#define PID_INQUIRE_NMEA_CMD            0x01
#define PID_UART_FORCE_RESET_CMD        0x02
#define PID_PATCH_CODE_CMD              0x03
#define PID_READ_MEM_CMD                0x04
#define PID_WRITE_MEM_CMD               0x05
#define PID_AGPS_PKT_CMD                0x06
#define PID_POWER_CTRL_CMD              0x07
#define PID_SPI_INIT_CMD                0x0A
#define PID_SPI_ERASE_CMD               0x0B
#define PID_SPI_WRITE_CMD               0x0C
#define PID_SPI_READ_CMD                0x0D
#define PID_RF_RADIO_INIT_CMD           0x0E
#define PID_RF_RADIO_REG_READ_CMD       0x0F
#define PID_RF_RADIO_REG_WRITE_CMD      0x10
#define PID_SET_BAUDRATE_CMD            0x16
#define PID_WRITE_EFUSE_DATA_CMD        0x17
#define PID_READ_EFUSE_DATA_CMD         0x18
#define PID_I2C_MASTER_READ_CMD         0x1C
#define PID_I2C_MASTER_WRITE_CMD        0x1D
#define PID_WAKE_INTERFACE_CMD          0x1F
#define PID_GPS_CONTROL_CMD             0x20
#define PID_GEOFENCE_CMD                0x30
#define PID_HOST_ACK_CMD                0x31
#define PID_BT_TOOL_CMD                 0xFC

#define HCI_EVENT_DATA_BEGIN            4

#define SID_CMD_0       0x00
#define SID_CMD_1       0x01
#define SID_CMD_2       0x02
#define SID_CMD_3       0x03
#define SID_CMD_4       0x04
#define SID_CMD_5       0x05
#define SID_CMD_6       0x06
#define SID_CMD_7       0x07
#define SID_CMD_8       0x08
#define SID_CMD_9       0x09
#define SID_CMD_10      0x0a
#define SID_CMD_FF      0xFF


#define TYPE_SNR_VAL 0
#define TYPE_IMRR_VAL 1

#define BYTE_SHIFT                  8
#define CHECKSUM_EN 1

#define LEN_0_BYTE                  0
#define LEN_1_BYTE                  1
#define LEN_2_BYTE                  2
#define LEN_3_BYTE                  3
#define LEN_4_BYTE                  4
#define LEN_5_BYTE                  5
#define LEN_6_BYTE                  6
#define LEN_7_BYTE                  7
#define LEN_8_BYTE                  8
#define LEN_9_BYTE                  9
#define LEN_10_BYTE                 10
#define LEN_11_BYTE                 11
#define LEN_12_BYTE                 12
#define LEN_14_BYTE                 14
#define LEN_16_BYTE                 16
#define LEN_255_BYTE                255

typedef struct hci_tx_pkt {
    uint8_t  hci_pkt_buf[GPS_MAX_LEN]; //transport level buf pointer
    uint16_t hci_pkt_length;      //transport level length
} HCI_TX_PKT;

typedef struct hci_rx_pkt {
    uint8_t  have_checksum;
    uint8_t  chechsum_right;
    uint8_t  pid;
    uint8_t  sid;

    uint8_t  have_msg_data;
    uint16_t msg_data_length;     //msg level packet data length
    uint8_t *msg_data_buf;    //msg level packet data pointer

    uint8_t  hci_pkt_buf[GPS_RX_LEN]; //transport level buf pointer
    uint16_t hci_pkt_length;      //transport level length
} HCI_RX_PKT;

bool Send(uint8_t *pBuf, uint32_t Len);
bool gps_hci_read_mem_cmd(uint8_t sid, uint32_t address, uint8_t *p_reading_bytes, uint16_t reading_len);
bool gps_hci_write_mem_cmd(uint8_t sid, uint32_t address, const uint8_t *p_writing_bytes, uint16_t len);
bool gps_hci_test_cmd(uint8_t sid);
bool gps_hci_patch_code_cmd(uint8_t sid, uint8_t error_check_mode, const uint8_t *p_patch_code, int patch_len);
bool gps_hci_power_ctrl_cmd_set_mode(uint8_t mode);
bool gps_hci_uart_set_baudrate_cmd(uint32_t baudrate, uint32_t char_timeout, uint8_t en_AFC);
bool gps_hci_mode_selection(uint8_t param1, uint8_t param2);
bool gps_hci_read_patch_flag(bool *is_patch);

#endif

