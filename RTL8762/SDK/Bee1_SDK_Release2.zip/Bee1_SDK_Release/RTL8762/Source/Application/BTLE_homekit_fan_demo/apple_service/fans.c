/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     fans.c
* @brief    Homekit fan service.
* @details  None.
* @author   tifnan_ge
* @date     2015-11-09
* @version  v0.1
*********************************************************************************************************
*/
#include "rtl_types.h"
#include "profileApi.h"
#include "fans.h"
#include "trace.h"
#include "string.h"
#include "rtl876x_flash_storage.h"
#include "hmt_api.h"
#include "hw_ctrl.h"

//adddress of fan service parameters in Flash
#define FANS_DB_FLASH_ADDR            1220

/**<  service instant id & characteristic id */
static const uint16_t fans_inst_id_fans = 15;       //service instant id
static const uint16_t fans_inst_id_char_fans = 16;
static const uint16_t fans_inst_id_char_on = 17;
static const uint16_t fans_inst_id_char_rot_dir = 18;
static const uint16_t fans_inst_id_char_rot_spd = 19;
static const uint16_t fans_inst_id_char_name = 20;

//buffer for homekit encrypt and decrypt
uint8_t fans_buf[15 + 16];
//fan service database
fans_db_t fans_db;
//fan service id
uint8_t fans_srv_id = 0;
//fan name
static const char fans_name[] = "DEMO_FAN";

//ccc bits
uint16_t fans_ccc_bit_on = 0x00;
uint16_t fans_ccc_bit_rot_dir = 0x00;
uint16_t fans_ccc_bit_rot_spd = 0x00;
uint8_t fans_wait_ind_conf = 0;

/**< @brief  profile/service definition.  */
static const TAttribAppl fans_attr_tbl[] =
{
    /*----------------- Homekit Fan Service -------------------*/
    /* <<Primary Service>>, index 0*/
    {
        (ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_LE),   /* wFlags     */
        {                                                /* bTypeValue */
            LO_WORD(GATT_UUID_PRIMARY_SERVICE),
            HI_WORD(GATT_UUID_PRIMARY_SERVICE),
            LO_WORD(HOMEKIT_SRV_UUID16_FAN),    /* service UUID */
            HI_WORD(HOMEKIT_SRV_UUID16_FAN)
        },
        UUID_16BIT_SIZE,                            /* bValueLen     */
        NULL,                                       /* pValueContext */
        GATT_PERM_READ                              /* wPermissions  */
    },

    /* <<Characteristic>>, ... index1 */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },
 
    /* characteristic - Service Instance IDs, index2*/
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_SRV_INT_ID
        },
        0,                                          /* "1" */
        NULL,                                       
        GATT_PERM_READ                              /* wPermissions */
    },
    
    /* Characteristic instant id index3 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID                                      /* "2" */
        },
        2,                                           /* bValueLen */
        (void*)&fans_inst_id_char_fans,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 4   [on/off]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_INDICATE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - on/off, index5*/
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_ON
        },
        0,                                          /* "1" */
        NULL,             //15
        (GATT_PERM_WRITE | GATT_PERM_READ | GATT_PERM_NOTIF_IND)     /* wPermissions */
    },
    
    /* client characteristic configuration, index 6 */
    {
        ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_CCCD_APPL,                 /* wFlags */
        {                                         /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            HI_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            /* NOTE: this value has an instantiation for each client, a write to */
            /* this attribute does not modify this default value:                */
            LO_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT), /* client char. config. bit field */
            HI_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT)
        },
        2,                                          /* bValueLen */
        NULL,
        (GATT_PERM_READ | GATT_PERM_WRITE)          /* wPermissions */
    },
    
    /* Characteristic User Description, index 7 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                          /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                           /* bValueLen */
        (void*)&fans_inst_id_char_on,
        GATT_PERM_READ                         /* wPermissions */
    },
    
    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 8   [rotation direction]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_INDICATE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - brightness, index9*/
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_ROT_DIR
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_WRITE | GATT_PERM_READ | GATT_PERM_NOTIF_IND)     /* wPermissions */
    },
    
    /* client characteristic configuration, index 10 */
    {
        ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_CCCD_APPL,                 /* wFlags */
        {                                         /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            HI_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            /* NOTE: this value has an instantiation for each client, a write to */
            /* this attribute does not modify this default value:                */
            LO_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT), /* client char. config. bit field */
            HI_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT)
        },
        2,                                          /* bValueLen */
        NULL,
        (GATT_PERM_READ | GATT_PERM_WRITE)          /* wPermissions */
    },
    
    /* Characteristic User Description, index 11 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&fans_inst_id_char_rot_dir,
        GATT_PERM_READ                         /* wPermissions */
    },


    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 12   [rotation speed]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_INDICATE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - brightness, index13*/
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_ROT_SPD
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_WRITE | GATT_PERM_READ | GATT_PERM_NOTIF_IND)     /* wPermissions */
    },
    
    /* client characteristic configuration, index 14 */
    {
        ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_CCCD_APPL,                 /* wFlags */
        {                                         /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            HI_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            /* NOTE: this value has an instantiation for each client, a write to */
            /* this attribute does not modify this default value:                */
            LO_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT), /* client char. config. bit field */
            HI_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT)
        },
        2,                                          /* bValueLen */
        NULL,
        (GATT_PERM_READ | GATT_PERM_WRITE)          /* wPermissions */
    },
    
    /* Characteristic User Description, index 15 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&fans_inst_id_char_rot_spd,
        GATT_PERM_READ                         /* wPermissions */
    },
    
    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 16   [name]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - name, index 13*/
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_NAME
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_READ)                   /* wPermissions */
    },
    
    /* Characteristic User Description, index 14 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&fans_inst_id_char_name,
        GATT_PERM_READ                         /* wPermissions */
    },   
};

/**< @brief  homekit fan service size definition.  */
const static uint16_t fans_attr_tbl_size = sizeof(fans_attr_tbl);

/**
  * @brief save fan service data to Flash.
  * @param none.
  * @return operation result
  * @retval 0--success
  *         1--failed
  */
uint8_t fans_save_db(void)
{
    return fs_save_vendor_data((void*)&fans_db, sizeof(fans_db_t), FANS_DB_FLASH_ADDR);
}

/**
  * @brief fan service factory reset.
  * @param none.
  * @note called when do homekit accessory factory reset.
  * @return operation result
  * @retval 0--success
  *         1--failed
  */
uint8_t fans_factory_reset(void)
{
    //invalid parameters
    fans_db.valid0 = 0xDD;
    fans_db.valid1 = 0x77;
    return fs_save_vendor_data((void*)&fans_db, sizeof(fans_db_t), FANS_DB_FLASH_ADDR);
}

/**
  * @brief get all parameters of fan service.
  * @param[in] db -pointer to fans_db_t struct.
  * @return none
  */
void fans_get_db(fans_db_t* db)
{
    memcpy(db, &fans_db, sizeof(fans_db_t));
}

/**
  * @brief set all parameters of fan service.
  * @param[in] db -pointer to fans_db_t struct.
  * @return none
  */
void fans_set_db(fans_db_t* db)
{
    memcpy(&fans_db, db, sizeof(fans_db_t));
    fans_save_db();
}

/**
  * @brief get service id of fan service.
  * @param none.
  * @return service id of fan service .
  */

uint8_t fans_get_srv_id(void)
{
    return fans_srv_id;
}


/**
  * @brief fan service atribute read callback function.
  * @param[in] service id -- service id.
  * @param[in] attr_idx   -- attribute index.
  * @param[in] offset     -- attribute value read offset.
  * @param[out] len       -- attribute read value length.
  * @param[out] ppval     -- pointer of attribut value read buffer.    
  * @return attribute read result.
  */
TProfileResult fans_attr_read_cb(uint8_t service_id , uint16_t attr_idx, uint16_t offset, uint16_t* len , uint8_t **ppval)
{
    TProfileResult  wCause  = ProfileResult_Success;
    
    uint16_t c_len = 0;
    
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "fans_attr_read_cb: attr_idx: %d, offset: %d", 2, attr_idx, offset);
    
    switch(attr_idx)
    {
        case FANS_CHAR_SRV_INST_INDEX:
             hmt_session_encrypt((uint8_t*)&fans_inst_id_fans, 2, fans_buf, &c_len);
        break;
        
        case FANS_CHAR_ON_INDEX:
             hmt_session_encrypt(&fans_db.on_off, 1, fans_buf, &c_len);
        break;
        
        case FANS_CHAR_ROT_DIR_INDEX:
             hmt_session_encrypt((uint8_t*)&fans_db.rot_dir, sizeof(int), fans_buf, &c_len);
        break;
        
        case FANS_CHAR_ROT_SPD_INDEX:
            hmt_session_encrypt((uint8_t*)&fans_db.rot_spd, sizeof(float), fans_buf, &c_len);
        break;
        
        case FANS_CHAR_NAME_INDEX:
             hmt_session_encrypt((uint8_t*)fans_name, sizeof(fans_name) - 1, fans_buf, &c_len);
        break;
        
        default:
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "-->fans_attr_read_cb: invalid attr index: %d", 1, attr_idx);
            wCause = ProfileResult_AttrNotFound;
        break;
    }
    
    if(wCause == ProfileResult_Success)
    {
        *ppval = fans_buf;
        *len = c_len;
    }
    
    return wCause;
}

/**
  * @brief fan atribute write callback function.
  * @param[in] service id -- service id.
  * @param[in] attr_idx   -- attribute index.
  * @param[in] wlen       -- length of write value.
  * @param[out] pval      -- value to be written.
  * @param[out] pwr_ind_proc  -- pointer of a function to handle control point write.    
  * @return write result.
  */
TProfileResult fans_attr_write_cb(uint8_t service_id, uint16_t attr_idx,
                              uint16_t wlen, uint8_t * pval , TGATTDWriteIndPostProc * pwr_ind_proc)
{
    TProfileResult  wCause  = ProfileResult_Success;
    
    uint16_t plen = 0;
    fan_hw_par_t hw_par;
    
    hmt_session_decrypt(pval, wlen, fans_buf, &plen);
    
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "-->fans_attr_write_cb: attr_idx:%d, wlen:%d", 2, attr_idx, wlen);

    //user set on/off
    if(attr_idx == FANS_CHAR_ON_INDEX)              //fan on/off
    {
        //turn on
        if(fans_buf[0] == 0x01)
        {
            fans_db.on_off = 1;
        }
        
        //turn off
        if(fans_buf[0] == 0x00)
        {
            fans_db.on_off = 0;
        }
    }
    else if(attr_idx == FANS_CHAR_ROT_DIR_INDEX)      //rotation direction
    {
        if(plen == sizeof(int))
        {
            memcpy((uint8_t*)&fans_db.rot_dir, fans_buf, sizeof(int));
        }
        
    }
    else if(attr_idx == FANS_CHAR_ROT_SPD_INDEX)    //rotation speed
    { 
        if(plen == sizeof(float))
        {
            memcpy((uint8_t*)&fans_db.rot_spd, fans_buf, sizeof(float));


        }
    }
    else
    {
         DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "-->fans_attr_write_cb: invalid char index:%d", 1, attr_idx);
         wCause = ProfileResult_AttrNotFound;
    }

    //fan hardware operation
    hw_par.on = fans_db.on_off;
    hw_par.dir  = fans_db.rot_dir;
    hw_par.speed = fans_db.rot_spd;
    fan_hw_ctrl(&hw_par);
    
    //save to flash
    fans_save_db();
    
  return wCause;
}

/**
  * @brief fan service cccd bits update callback function.
  * @param[in] service id -- service id.
  * @param[in] attr_idx   -- attribute index.
  * @param[in] wccc_bits  -- ccc bits update.
  * @return none.
  */
void fans_cccd_update_cb(uint8_t service_id, uint16_t attr_idx, uint16_t wccc_bits)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "fans_cccd_update_cb:attribute index:%d, ccc_bits:%d", 2, attr_idx, wccc_bits);
    
    if(attr_idx == (FANS_CHAR_ON_INDEX + 1))
    {
        fans_ccc_bit_on= wccc_bits;
    }
    else if(attr_idx == (FANS_CHAR_ROT_DIR_INDEX + 1))
    {
        fans_ccc_bit_rot_dir = wccc_bits;
    }
    else if(attr_idx == (FANS_CHAR_ROT_SPD_INDEX + 1))
    {
        fans_ccc_bit_rot_spd = wccc_bits;
    }
    else
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "-->fans_cccd_update_cb: invalid attr index: %d", 1, attr_idx);
    }
    
    return;
}

/**
  * @brief service status update callback function.
  * @param[in] service id -- service id.
  * @param[in] attr_idx   -- attribute index.
  * @note usually used when send indication done and have received confirmation.
  * @return none.
  */
void fans_update_st_cb(uint8_t service_id, uint16_t attr_idx)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "fans_update_status: attr_idx:%d", 1, attr_idx);
    
    fans_wait_ind_conf = 0;
    
    return;
}

/**
  * @brief send indication.
  * @param[in] service id -- service id.
  * @param[in] attr_idx   -- attribute index.
  * @param[in] data       -- indication data.
  * @param[in] len        -- indication data length.
  * @return none.
  */
bool fans_send_indication(uint8_t service_id, uint16_t attr_idx, uint8_t* data, uint16_t len)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "fans_send_indication: service_id: %d, attr_idx:%d, data:0x%x, len:%d",\
        4, service_id, attr_idx, data, len);

    uint16_t c_len = 0;

    if(attr_idx == FANS_CHAR_ON_INDEX)
    {
        if(fans_ccc_bit_on == 0x02)
        {
            fans_wait_ind_conf = 1;
            hmt_session_encrypt(data, len, fans_buf, &c_len);
            return ProfileAPI_SendData(service_id, attr_idx, fans_buf, c_len);
        }
    }
    else if(attr_idx == FANS_CHAR_ROT_DIR_INDEX)
    {
        if(fans_ccc_bit_rot_dir == 0x02)
        {
            fans_wait_ind_conf = 1;
            hmt_session_encrypt(data, len, fans_buf, &c_len);
            return ProfileAPI_SendData(service_id, attr_idx, fans_buf, c_len);
        }
    }
    else if(attr_idx == FANS_CHAR_ROT_SPD_INDEX)
    {
        if(fans_ccc_bit_rot_spd == 0x02)
        {
            fans_wait_ind_conf = 1;
            hmt_session_encrypt(data, len, fans_buf, &c_len);
            return ProfileAPI_SendData(service_id, attr_idx, fans_buf, c_len);
        }
    }
    else
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "-->fans_send_indication: invalid attr index: %d", 1, attr_idx);
        return false;
    }
    
    return true;
}

/**
 * @brief light bulb service callbacks.
*/
static const gattServiceCBs_t fans_cbs =
{
    fans_attr_read_cb,       // Read callback function pointer
    fans_attr_write_cb,      // Write callback function pointer
    fans_cccd_update_cb,     // CCCD update callback function pointer
    fans_update_st_cb        // confirmation callback function pointer
};

/**
  * @brief ligth bulb service initialization.
  * @param none.
  * @return initialization result.
  * retval  0--success.
  *         1--failde
  */
uint8_t fans_init(void)
{
    uint8_t service_id;
    fan_hw_par_t hw_par;
    
    //1. add light bulb service
    if (FALSE == ProfileAPI_AddService(&service_id,
                                       (uint8_t*)fans_attr_tbl,
                                       fans_attr_tbl_size,
                                       fans_cbs))
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "profile add homekit fan service failed!!", 0);
        service_id = 0xff;
        return 1;  //add service fail
    }
    
    //2. load parameters of fan service in Flash
    fs_load_vendor_data((void*)&fans_db, sizeof(fans_db_t), FANS_DB_FLASH_ADDR);
    
    if(fans_db.valid0 != 0xEE || fans_db.valid1 != 0xBB)
    {
        //default parameters
        fans_db.on_off = 1;      //default on
        fans_db.rot_dir = 0;     //clockwise
        fans_db.rot_spd = 30;    
        fans_db.valid0 = 0xEE;
        fans_db.valid1 = 0xBB;
        //save in flash
        fans_save_db();
    }
    
    DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "-->fans_init: on_off: %d, rotation direction: %d, speed: %f",\
                3, fans_db.on_off, fans_db.rot_dir, (uint32_t)fans_db.rot_spd);
    
    //3.init fan hardware
    hw_par.on = fans_db.on_off;
    hw_par.dir  = fans_db.rot_dir;
    hw_par.speed = fans_db.rot_spd;
    fan_hw_ctrl(&hw_par);
    
    return 0;
}
