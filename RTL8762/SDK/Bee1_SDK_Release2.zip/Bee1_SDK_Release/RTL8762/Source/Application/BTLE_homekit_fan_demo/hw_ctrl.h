/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     hw_ctrl.h
* @brief    declaration of some hardware control func.
* @details  none.
* @author   tifnan
* @date     2015-11-06
* @version  v0.1                       
*********************************************************************************************************
*/

#ifndef _HW_CTRL_H_
#define _HW_CTRL_H_

#ifdef  __cplusplus
 extern "C" {
#endif      /* __cplusplus */

#include <stdint.h>

#define ADV_CON_TIP_LED_PIN             P2_1
#define FAN_LED_PIN                     P2_2
#define OTA_BUTTON_PIN                  P0_2
/* also do totation direction tip */
#define HOMEKIT_IDNTIFY_LED_PIN         P4_3
#define FACTORY_RESET_PIN               P3_1
#define MANUAL_OP_PIN                   P3_2

/* fan hardware control parameters */
typedef struct _fan_hw_par_t
{
    int dir;
    float speed;
    uint8_t on;
}fan_hw_par_t;

//export functions
void homekit_identify(void);
void start_adv_tip(void);
void start_connected_tip(void);
void start_disconnect_tip(void);
void fan_hw_ctrl(fan_hw_par_t* par);
     
#ifdef  __cplusplus
}
#endif      /* __cplusplus */

#endif  /*_HW_CTRL_H_ */

