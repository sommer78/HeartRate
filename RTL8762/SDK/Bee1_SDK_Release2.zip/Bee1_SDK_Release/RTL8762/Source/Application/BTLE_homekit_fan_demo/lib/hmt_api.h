#ifndef _HMT_API_H_
#define _HMT_API_H_

#include "stdint.h"
#include "hmt_char.h"

/* homekit lib API error code */  
#define HMT_SUCCESS                 0x00        /* success */
#define HMT_ERR_NO_CB               0x01        /* have not register homekit event handle callback */
#define HMT_ERR_FLASH_OP            0x02        /* flash operation error */
#define HMT_ERR_NO_RESOURCE         0x03        /* no resource */
#define HMT_ERR_INVALID_PARA        0x04        /* invalid parameters */
#define HMT_ERR_UNKNOWN             0x05        /* unknown error */

/* pairing method */
#define METHOD_PAIR_SETUP           1
#define METHOD_PAIR_VERIFY          2
#define METHOD_PAIR_ADD             3
#define METHOD_PAIR_REMOVE          4
#define METHOD_PAIR_LIST            5

/* pair state */
#define PAIR_STATE_M1               1
#define PAIR_STATE_M2               2
#define PAIR_STATE_M3               3
#define PAIR_STATE_M4               4
#define PAIR_STATE_M5               5
#define PAIR_STATE_M6               6

/* pair error */
#define PAIR_ERR_UNKNOWN            1
#define PAIR_ERR_AUTHENTICATION     2
#define PAIR_ERR_BACKOFF            3
#define PAIR_ERR_MAX_PEERS          4
#define PAIR_ERR_MAX_TRIES          5

/* pair error mesage to App */
typedef struct _hmt_pair_err_t
{
    uint8_t method;
    uint8_t state;
    uint8_t err;
}hmt_pair_err_t;

//hmt event
typedef enum
{
    /* pair event*/
    HMT_EVT_PAIR_SETUP_START,   /* pair setup start */
    HMT_EVT_PAIR_SETUP_OK,      /* pair setup done */
    HMT_EVT_PAIR_VERIFY_START,  /* pair verify start */
    HMT_EVT_PAIR_VERIFY_OK,     /* pair verify done */
    HMT_EVT_PAIR_ADD_START,     /* pair add start */
    HMT_EVT_PAIR_ADD_OK,        /* pair add done */
    HMT_EVT_PAIR_REMOVE_START,  /* pair remove start */
    HMT_EVT_PAIR_REMOVE_OK,     /* pair remove done */
    HMT_EVT_PAIR_LIST_START,    /* pair list start */
    HMT_EVT_PAIR_LIST_OK,       /* pair list done */
    HMT_EVT_PAIR_ERROR,         /* pair error */

    /* other event */
    HMT_EVT_PINCODE,            /* show pincode */
    HMT_EVT_RANDOM,             /* need random bytes */
    HMT_EVT_CLIENT_STORE,       /* store client context */
    HMT_EVT_CLIENT_RM,          /* remove client context */
    HMT_EVT_ALL_CLIENT_LOAD,    /* laod all client context */
    HMT_EVT_ALL_CLIENT_RM,      /* remove all client context */
    HMT_EVT_STATE_NUM_LOAD,     /* load state number */
    HMT_EVT_STATE_NUM_STORE,    /* store state number*/
    HMT_EVT_USER_FACTORY,       /* user need to do some work releated to factory reset, exp. remove the lightness of light bulb */
}hmt_event;

//homekit pairing event handle callback function type
typedef uint8_t (*pfn_hmt_event_hdl_cb)(uint8_t event, void* data, uint16_t len);

//accessory category in advertising data
typedef enum
{
    CAT_OTHER = 1,
    CAT_BRIDGE,
    CAT_FAN,
    CAT_GARAGE,
    CAT_LIGHT_BULB,
    CAT_DOOR_LOCK,
    CAT_OUTLET,
    CAT_SWITCH,
    CAT_THERMOSTAT,
    CAT_SENSOR,
    CAT_SEC_SYSTEM,
    CAT_DOOR,
    CAT_WINDOW,
    CAT_WIN_COVER,
    CAT_PROG_SWITCH,
    RESERVED
}HAP_ASY_CATEGORY;

//advertising interval in advertising data
typedef enum
{
    ADV_INV_10_25MS     = 0x1C,
    ADV_INV_26_100MS    = 0x2C,
    ADV_INV_101_300MS   = 0x3C,
    ADV_INV_301_500MS   = 0x4C,
    ADV_INV_501_1250MS  = 0x5C,
    ADV_INV_1251_2500MS = 0x6C,
    ADV_INV_2500MS      = 0x7C,
}HAP_ADV_INTERVAL;

//used to store client keys and identifier
typedef struct _client_store_info_t
{
    uint8_t admin;      //1--admin client, 0--normal client
    uint8_t valid0;     //0xEE valid, 0xDD invalid
    uint8_t id[36];     //client id
    uint8_t ltpk[32];   //client long-term public key(ed25519)  
    uint8_t pos;        //0--max_client_num
    uint8_t valid1;     //0xBB valid, 0x77 invalid
}client_store_info_t;

/* state number storage struct */
typedef struct _state_num_store_t
{
    uint8_t valid0;     //0xEE valid, 0xDD invalid
    uint8_t valid1;     //0xBB valid, 0x77 invalid
    uint16_t state_num;
}state_num_store_t;

//homekit init struct
typedef struct _hmt_init_t
{
    pfn_hmt_event_hdl_cb event_handle_func;         /* homekit lib event handle callback */
    uint8_t*    ui;                                 /* device unique identifier */
    char*       local_name;                         /* shortened or completed local name in advertising data */  
    char*       setup_code;                         /* length: 10, format: "880-213-06" */
    uint16_t    cat_id;                             /* accessory category identifier */ 
    uint8_t     dis_caps;                           /* display ability, 1-- device can display, 0--device can't display, if can't display,
                                                        lib uses setup_code user provided, otherwise, lib generates setup code itself. */ 
    uint8_t     max_client_num;                     /* 16 is recommanded */
    uint8_t     cfg_num;                            /* configuration number, default 0, increments only when service or characteristic\
                                                        is added or removed after firmware update, only for spec ios9 */
    uint8_t     adv_interval;                       /* advertising interval, see enum: HAP_ADV_INTERVAL, only for spec iOS9 */
    
}hmt_init_t;

/* advertising */
void hmt_set_adv_interval(uint8_t interval);
void hmt_start_adv(void);
void hmt_stop_adv(void);

/* homekit library init */
uint8_t hmt_init(hmt_init_t* pinit);
uint8_t hmt_pair_service_init(void);

/* factory reset */
uint8_t hmt_factory_reset(void);

/* state number */
uint16_t hmt_get_state_num(void);
void hmt_update_state_num(void);
uint8_t hmt_store_state_num(void);
uint8_t hmt_load_state_num(void);

/* session encrypt and decrypt */
uint8_t hmt_session_is_encrypted(void);
void hmt_session_invalid(void);
void hmt_session_encrypt(const uint8_t* plaintext, uint16_t length, uint8_t* ciphertext, uint16_t* clength);
uint8_t hmt_session_decrypt(uint8_t* ciphertext, uint16_t length, uint8_t* plaintext, uint16_t* plength);

/* paired iOS device context */
client_store_info_t* hmt_find_client(uint8_t* client_id);
uint8_t hmt_get_active_client_num(uint32_t* pos);
uint8_t hmt_get_max_client_support(void);

#endif  /* _HMT_API_H_ */
