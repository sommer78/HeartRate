/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     main.c
* @brief    This is the entry of user code which the main function resides in.
* @details
* @author   ranhui
* @date     2015-03-29
* @version  v0.2
*********************************************************************************************************
*/
#include "rtl876x.h"
#include "FreeRTOS.h"
#include "task.h"
#include "application.h"
#include "dlps_platform.h"
#include "peripheral.h"
#include "observer.h"
#include "gap.h"
#include "profileApi.h"
#include "homekit_application.h"
#include "simpleBLEPeripheral.h"
#include "simple_ble_service.h"
#include "ais.h"
#include "fans.h"
#include "rtl876x_rcc.h"
#include "rtl876x_pinmux.h"
#include "rtl876x_nvic.h"
#include "rtl876x_uart.h"
#include "rtl876x_tim.h"
#include "rtl876x_pwm.h"
#include "board.h"
#include "rtl876x_gpio.h"
#include "user_callback.h"
#include "string.h"
#include "trace.h"
#include "hw_ctrl.h"

/*
********************************************************
* parameter for btstack
*
*
*********************************************************
*/
// What is the advertising interval when device is discoverable (units of 625us, 160=100ms)
#define DEFAULT_ADVERTISING_INTERVAL_MIN            0x20
#define DEFAULT_ADVERTISING_INTERVAL_MAX            0x30

// service id for simple profile service
uint8_t gSimpleProfileServiceId;
uint8_t gGasServiceId;  //generic attribute service id
uint8_t gPsServiceId;   //homekit pairing service id
uint8_t gAisServiceId;  //homekit accessory info service id
uint8_t gDisServiceId;  //device information service

extern gattPreExeWrCB_t GattPreExeWrCb;

// GAP - SCAN RSP data (max size = 31 bytes)
static uint8_t scanRspData[] =
{
    /* local name */
    0x10,    /* length */
    0x09,    /* Complete local name */
    'R',
    'T',
    'K',
    '_',
    'H',   
    'k',
    't',
    '_',
    'D',
    'e',
    'v'
};

/******************************************************************
 * @fn         Initial gap parameters
 * @brief      Initialize peripheral and gap bond manager related parameters
 *
 * @return     void
 */
void BtStack_Init_Gap(void)
{
    //device name and device appearance
    char DeviceName[GAP_DEVICE_NAME_LEN] = "RTK_Hkt_Dev";
    uint16_t Appearance = GAP_GATT_APPEARANCE_UNKNOWN;

    //default start adv when bt stack initialized
    uint8_t  advEnableDefault = TRUE;

    //advertising parameters
    uint8_t  advEventType = GAP_ADTYPE_ADV_IND;
    uint8_t  advChanMap = GAP_ADVCHAN_ALL;
    uint8_t  advFilterPolicy = GAP_FILTER_POLICY_ALL;
    uint16_t advIntMin = DEFAULT_ADVERTISING_INTERVAL_MIN;
    uint16_t advIntMax = DEFAULT_ADVERTISING_INTERVAL_MIN;

    //Set device name and device appearance
    peripheralSetGapParameter(GAPPRRA_DEVICE_NAME, strlen(DeviceName), DeviceName);
    peripheralSetGapParameter(GAPPRRA_APPEARANCE, sizeof(Appearance), &Appearance);
    peripheralSetGapParameter( GAPPRRA_ADV_ENABLE_DEFAULT, sizeof ( advEnableDefault ), &advEnableDefault );
    
    //Set advertising parameters
    peripheralSetGapParameter( GAPPRRA_ADV_EVENT_TYPE, sizeof ( advEventType ), &advEventType );
    peripheralSetGapParameter( GAPPRRA_ADV_CHANNEL_MAP, sizeof ( advChanMap ), &advChanMap );
    peripheralSetGapParameter( GAPPRRA_ADV_FILTER_POLICY, sizeof ( advFilterPolicy ), &advFilterPolicy );
    //advertising interval
    peripheralSetGapParameter(GAPPRRA_ADV_INTERVAL_MIN, sizeof(advIntMin), &advIntMin);
    peripheralSetGapParameter(GAPPRRA_ADV_INTERVAL_MAX, sizeof(advIntMax), &advIntMax);
    //scan response data
    peripheralSetGapParameter( GAPPRRA_SCAN_RSP_DATA, sizeof ( scanRspData ), scanRspData );
    
    
    /* scan parameters set */
    uint8_t scan_type = 1; //passive scan
    uint16_t scan_interval = 0x30;    /*0.625ms*interval */
    uint16_t scan_win = 0x20;   /*0.625ms*win */
    observerSetGapParameter(GAPPARA_SCANMODE, sizeof(uint8_t), &scan_type);
    observerSetGapParameter(GAPPARA_SCANINTERVAL, sizeof(uint16_t), &scan_interval);
    observerSetGapParameter(GAPPARA_SCANWINDOW, sizeof(uint16_t), &scan_win);
    
    //change connection interval
    /*uint16_t mimConInterval = 0x40;
    uint16_t maxConInterval = 0x60;
    uint16_t latency = 0x50;
    uint16_t timeout = 0x50;
    peripheralSetGapParameter(GAPPRRA_MIN_CONN_INTERVAL, sizeof(uint16_t), &mimConInterval);
    peripheralSetGapParameter(GAPPRRA_MAX_CONN_INTERVAL, sizeof(uint16_t), &maxConInterval);
    peripheralSetGapParameter(GAPPRRA_SLAVE_LATENCY, sizeof(uint16_t), &latency);
    peripheralSetGapParameter(GAPPRRA_TIMEOUT_MULTIPLIER, sizeof(uint16_t), &timeout);*/
}

/******************************************************************
 * @fn          Initial profile
 * @brief      Add simple profile service and register callbacks 
 *
 * @return     void
 */
void BtProfile_Init(void)
{
    ps_add_service();
    /* accessory info service init */
    ais_init(); 
    /* fan service init */
    fans_init();
    ProfileAPI_RegisterCB((pfnAPPHandleInfoCB_t)AppProfileCallback);
    ProfileAPI_RegisterPreExeWrCB(GattPreExeWrCb);
    /* register observer callback*/
    observer_RegisterAppDirectCB(App_ObserverRoleCallback);
    
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "gPsServiceId:0x%x, gAisServiceId:0x%x", 2, gPsServiceId, gAisServiceId);
}

/**
* @brief    Board_Init() contains the initialization of pinmux settings and pad settings.
*
*               All the pinmux settings and pad settings shall be initiated in this function.
*               But if legacy driver is used, the initialization of pinmux setting and pad setting
*               should be peformed with the IO initializing.
*
* @return  void
*/
void Board_Init(void)
{
    //for fan service, simulate a fan
    Pinmux_Config(FAN_LED_PIN, timer_pwm0);
    Pad_Config(FAN_LED_PIN, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);

    //advertising/connection/disconnected tip
    Pad_Config(ADV_CON_TIP_LED_PIN, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
    Pinmux_Config(ADV_CON_TIP_LED_PIN, timer_pwm1);

    //for ota
    Pad_Config(OTA_BUTTON_PIN, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);;
    Pinmux_Config(OTA_BUTTON_PIN, GPIO_FUN);

    //for factory reset
    Pad_Config(FACTORY_RESET_PIN, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);;
    Pinmux_Config(FACTORY_RESET_PIN, GPIO_FUN);

    //for manually operation
    Pad_Config(MANUAL_OP_PIN, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);;
    Pinmux_Config(MANUAL_OP_PIN, GPIO_FUN);

    //for homekit identify & fan rotation direction tip
    Pad_Config(HOMEKIT_IDNTIFY_LED_PIN, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);
    Pinmux_Config(HOMEKIT_IDNTIFY_LED_PIN, GPIO_FUN);

    RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);

    /************ for homekit identify & fan rotation direction, must be init before profile_init ***********************/
    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_InitStruct.GPIO_Pin  = GPIO_GetPin(HOMEKIT_IDNTIFY_LED_PIN);
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_Init(&GPIO_InitStruct);
    GPIO_SetBits(GPIO_GetPin(HOMEKIT_IDNTIFY_LED_PIN));

    return;
}

/**
* @brief    Driver_Init() contains the initialization of peripherals.
*
*               Both new architecture driver and legacy driver initialization method can be used.
*
* @return  void
*/
void Driver_Init(void)
{
    /****************************** turn on IO clocks *****************************************/
    RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
    RCC_PeriphClockCmd(APBPeriph_TIMER, APBPeriph_TIMER_CLOCK, ENABLE);

    /******************************** adv/connect/disconnect tip ********************************/
    TIM_TimeBaseInitTypeDef TIM_InitStruct;
    TIM_StructInit(&TIM_InitStruct);
    TIM_InitStruct.TIM_ClockSrc = TIM_CLOCK_10MHZ;
    TIM_InitStruct.TIM_Period = 10000;   //1ms
    TIM_InitStruct.TIM_Mode = TIM_Mode_UserDefine;
    TIM_TimeBaseInit(TIM1, &TIM_InitStruct);
    TIM_Cmd(TIM1, ENABLE);
    start_disconnect_tip();
    
    /****************************** fan service pwm init ***********************************/
    PWM_InitTypeDef PWM_InitStruct;
    
    TIM_StructInit(&TIM_InitStruct);
    TIM_InitStruct.TIM_ClockSrc = TIM_CLOCK_10MHZ;
    TIM_InitStruct.TIM_Period = 1000;   //0.1ms
    TIM_InitStruct.TIM_Mode = TIM_Mode_UserDefine;
    TIM_TimeBaseInit(TIM2, &TIM_InitStruct);
    TIM_Cmd(TIM2, ENABLE);

    PWM_InitStruct.PWM_Period = 100;   //10ms
    PWM_InitStruct.PWM_Duty = 50;     //5ms
    PWM_InitStruct.PWM_TIMIndex = 2;
    PWM_Init(PWM0, &PWM_InitStruct);
    PWM_Cmd(PWM0, ENABLE);

    /****************************** timer for key press debounce **************************************/
    TIM_StructInit(&TIM_InitStruct);
    TIM_InitStruct.TIM_ClockSrc = TIM_CLOCK_10MHZ;
    TIM_InitStruct.TIM_Period = 10000 * 100;   //120ms
    TIM_InitStruct.TIM_Mode = TIM_Mode_UserDefine;
    TIM_TimeBaseInit(TIM3, &TIM_InitStruct);
    TIM_ClearINT(TIM3);
    TIM_INTConfig(TIM3, ENABLE);
    //TIM_Cmd(TIM3, ENABLE);
    
    /****************************** for ota***********************************************************/
    GPIO_InitTypeDef GPIO_InitStruct;
   
    GPIO_InitStruct.GPIO_Pin  = GPIO_GetPin(OTA_BUTTON_PIN);
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_ITCmd = ENABLE;
    GPIO_InitStruct.GPIO_ITTrigger = GPIO_INT_Trigger_EDGE;
    GPIO_InitStruct.GPIO_ITPolarity = GPIO_INT_POLARITY_ACTIVE_LOW;
    GPIO_InitStruct.GPIO_ITDebounce = GPIO_INT_DEBOUNCE_ENABLE;  
    GPIO_Init(&GPIO_InitStruct);
    GPIO_INTConfig(GPIO_GetPin(OTA_BUTTON_PIN), ENABLE);
    GPIO_MaskINTConfig(GPIO_GetPin(OTA_BUTTON_PIN), DISABLE);

    /****************************** for factory reset**************************************************/
    GPIO_InitStruct.GPIO_Pin  = GPIO_GetPin(FACTORY_RESET_PIN);
    GPIO_Init(&GPIO_InitStruct);
    GPIO_INTConfig(GPIO_GetPin(FACTORY_RESET_PIN), ENABLE);
    GPIO_MaskINTConfig(GPIO_GetPin(FACTORY_RESET_PIN), DISABLE);
    
    /************************************ nvic **********************************************************/
    NVIC_InitTypeDef NVIC_InitStruct;

    //for factory reset
    NVIC_InitStruct.NVIC_IRQChannel = GPIO2_IRQ;
    NVIC_InitStruct.NVIC_IRQChannelPriority = 1;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStruct);

    NVIC_InitStruct.NVIC_IRQChannel = GPIO6To31_IRQ;
    NVIC_InitStruct.NVIC_IRQChannelPriority = 1;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStruct);

    //enable timer3 interrupt, for key debounce
    NVIC_InitStruct.NVIC_IRQChannel = TIMER3_IRQ;
    NVIC_Init(&NVIC_InitStruct);
    
    return;
}

/**
* @brief    PwrMgr_Init() contains the setting about power mode.
*
* @return  void
*/
void PwrMgr_Init(void)
{
    //LPS_MODE_Set(LPM_DLPS_MODE);
}


/**
* @brief  Task_Init() contains the initialization of all the tasks.
*
*           There are four tasks are initiated.
*           Lowerstack task and upperstack task are used by bluetooth stack.
*           Application task is task which user application code resides in.
*           Emergency task is reserved.
*
* @return  void
*/
void Task_Init(void)
{
    void lowerstack_task_init();
    void upperstack_task_init();
    void emergency_task_init();
    application_task_init();
}

/**
* @brief  main() is the entry of user code.
*
*
* @return  void
*/
int main(void)
{
    Board_Init();
    BtStack_Init_Peripheral();
    BtStack_Init_Observer();
    BtStack_Init_Gap();
    BtProfile_Init();
    PwrMgr_Init();
    Task_Init();
    
    vTaskStartScheduler();  

    return 0;
}
