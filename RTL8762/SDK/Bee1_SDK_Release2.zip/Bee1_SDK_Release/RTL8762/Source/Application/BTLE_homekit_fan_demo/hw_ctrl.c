/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     hw_ctrl.c
* @brief    do some IO releated things.
* @details  none.
* @author   tifnan
* @date     2015-11-09
* @version  v0.1                       
*********************************************************************************************************
*/

#include "fans.h"
#include "rtl876x_rcc.h"
#include "rtl876x_gpio.h"
#include "rtl876x_tim.h"
#include "rtl876x_pwm.h"
#include "hw_ctrl.h"
#include "ota_api.h"
#include "hal_wdg.h"
#include "trace.h"
#include "hmt_api.h"
#include "fans.h"

/**
  * @brief did LED blink when accessory is doing advertising.
  * @param none.
  * @return none
  */
void start_adv_tip(void)
{
    PWM_InitTypeDef PWM_InitStruct;
    PWM_InitStruct.PWM_Period = 500;   //500ms
    PWM_InitStruct.PWM_Duty = 250;     //50%
    PWM_InitStruct.PWM_TIMIndex = 1;
    PWM_Init(PWM1, &PWM_InitStruct);
    PWM_Cmd(PWM1, ENABLE);

    return;
}

/**
  * @brief turn on LED when accessory is connected.
  * @param none.
  * @return none
  */
void start_connected_tip(void)
{
    PWM_InitTypeDef PWM_InitStruct;
    PWM_Cmd(PWM1, DISABLE);
    PWM_InitStruct.PWM_Period = 500;   //500ms
    PWM_InitStruct.PWM_Duty = 0;     //0%
    PWM_InitStruct.PWM_TIMIndex = 1;
    PWM_Init(PWM1, &PWM_InitStruct);
    PWM_Cmd(PWM1, ENABLE);
}

/**
  * @brief turn off LED when accessory is disconnected.
  * @param none.
  * @return none
  */
void start_disconnect_tip(void)
{
    PWM_InitTypeDef PWM_InitStruct;
    PWM_Cmd(PWM1, DISABLE);   
    PWM_InitStruct.PWM_Period = 500;   //500ms
    PWM_InitStruct.PWM_Duty = 500;     //100%
    PWM_InitStruct.PWM_TIMIndex = 1;
    PWM_Init(PWM1, &PWM_InitStruct);
    PWM_Cmd(PWM1, ENABLE);
}

/**
  * @brief do accessory identifiy routine, change color of light from RED to BLUE.
  * @param none.
  * @return none
  */
void homekit_identify(void)
{
    uint32_t i = 0;
    uint8_t count = 7;
    uint8_t gpio_val;

    gpio_val = GPIO_ReadOutputDataBit(GPIO_GetPin(HOMEKIT_IDNTIFY_LED_PIN));

    //do LED blink
    while(count)
    {
        GPIO_ResetBits(GPIO_GetPin(HOMEKIT_IDNTIFY_LED_PIN));
        for(i = 0; i < 240000; i++);
        GPIO_SetBits(GPIO_GetPin(HOMEKIT_IDNTIFY_LED_PIN));
        for(i = 0; i < 240000; i++);
        count--;
    }
    
    GPIO_WriteBit(GPIO_GetPin(HOMEKIT_IDNTIFY_LED_PIN), (BitAction)gpio_val);
}

/**
  * @brief gpio interrupt routine, do factory reset.
  * @param none
  * @return none
  */
void Gpio25IntrHandler(void)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "accessory factory reset......", 0);
    
    GPIO_MaskINTConfig(GPIO_GetPin(FACTORY_RESET_PIN), ENABLE);

    /*prepare to enter into OTA mode*/
    hmt_factory_reset();
    //use watch dog to reset
    HalWatchDogConfig(0, 5, 1);
    HalWatchDogEnable();
    
    GPIO_ClearINTPendingBit(GPIO_GetPin(FACTORY_RESET_PIN));
}

/**
  * @brief gpio interrupt routine, do firmware update.
  * @param none
  * @return none
  */
void Gpio2IntrHandler(void)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "start to enter ota mode......", 0);
    
    GPIO_MaskINTConfig(GPIO_GetPin(OTA_BUTTON_PIN), ENABLE);

     /*prepare to enter into OTA mode*/
    dfuSetOtaMode(ENABLE);
    HalWatchDogConfig(0, 5, 1);
    HalWatchDogEnable();
    
    GPIO_ClearINTPendingBit(GPIO_GetPin(OTA_BUTTON_PIN));
    //GPIO_MaskINTConfig(GPIO_GetPin(P0_2), DISABLE);
}

/**
  * @brief set fan rotation direction.
  * @param[in] dir --target rotation direction.
  * @return none
  */
static void fan_hw_set_rotation_dir(int dir)
{
    if(dir == ROTATION_CLOCKWISE)
    { 
        GPIO_SetBits(GPIO_GetPin(HOMEKIT_IDNTIFY_LED_PIN));
    }
    
    if(dir == ROTATION_COUNTER_CLOCKWISE)
    {
        GPIO_ResetBits(GPIO_GetPin(HOMEKIT_IDNTIFY_LED_PIN));
    }
}

/**
  * @brief set fan rotation speed.
  * @param[in] dir --target rotation speed(0--100).
  * @return none
  */
static void fan_hw_set_rotation_spd(float speed)
{
    PWM_InitTypeDef PWM_InitStruct;
    
    if(speed <= 100 && speed >= 0)
    {
      //disable PWM firstly
      PWM_Cmd(PWM0, DISABLE);

      //setting pwm parameters
      PWM_InitStruct.PWM_Period = 100;
      PWM_InitStruct.PWM_Duty = (uint32_t)speed;
      PWM_InitStruct.PWM_TIMIndex = 2;

      //enable pwm again
      PWM_Init(PWM0, &PWM_InitStruct);
      PWM_Cmd(PWM0, ENABLE);
    }
}

/**
  * @brief fan hardware control.
  * @param[in] par --pointer to fan hardware control parameters.
  * @return none
  */
void fan_hw_ctrl(fan_hw_par_t* par)
{
    //turn off
    if(!par->on)
    {
        PWM_Cmd(PWM0, DISABLE);
    }
    else
    {
        fan_hw_set_rotation_dir(par->dir);
        fan_hw_set_rotation_spd(par->speed);
    }
}
