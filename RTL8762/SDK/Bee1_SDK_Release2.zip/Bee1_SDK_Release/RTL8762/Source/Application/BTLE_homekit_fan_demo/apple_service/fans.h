/**
************************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
************************************************************************************************************
* @file     fans.h
* @brief    Head file for homekit fan service.
* @details  fan service data structs and external functions declaration.
* @author   tifnan_ge
* @date     2015-11-09
* @version  v0.1
*************************************************************************************************************
*/

#ifndef _FANS_H_
#define _FANS_H_

#ifdef  __cplusplus
extern "C" {
#endif      /* __cplusplus */\
    
#include "stdint.h"
#include "stdbool.h"

/** @brief  attribute index defines for homekit fan service Characteristic*/
#define FANS_CHAR_SRV_INST_INDEX          2 /**<  @brief  attribute index for service instant id chars's value      */
#define FANS_CHAR_ON_INDEX                5 /**<  @brief  attribute index for on chars's value      */
#define FANS_CHAR_ROT_DIR_INDEX           9 /**<  @brief  attribute index for rotation direction chars's value      */
#define FANS_CHAR_ROT_SPD_INDEX           13 /**<  @brief  attribute index for rotation speed chars's value      */
#define FANS_CHAR_NAME_INDEX              17 /**<  @brief  attribute index for name chars's value      */

/** @brief fan service data struct */
typedef struct _fans_db_t
{
    int     rot_dir;    //rotation direction, 0--clockwise, 1--counter clockwise
    float   rot_spd;    //rotation speed, 0--100, step value 1
    uint8_t on_off;     //1--on, 0--off
    uint8_t valid0;     //0xEE valid, 0xDD invalid
    uint8_t padding;    //padding
    uint8_t valid1;     //0xBB valid, 0x77 invalid
}fans_db_t;

/****************************************************************************************************************
* exported globals.
****************************************************************************************************************/

/****************************************************************************************************************
* exported functions.
****************************************************************************************************************/
uint8_t fans_init(void);
uint8_t fans_save_db(void);
uint8_t fans_factory_reset(void);
void fans_get_db(fans_db_t* db);
void fans_set_db(fans_db_t* db);
bool fans_send_indication(uint8_t service_id, uint16_t attr_idx, uint8_t* data, uint16_t len);

#ifdef  __cplusplus
}
#endif      /*  __cplusplus */

#endif  /* _FANS_H_ */
