#include <stdint.h>
#include <string.h>
#include "user_callback.h"
#include "rtl876x_flash_storage.h"
#include "rtl876x_adc.h"
#include "rtl876x_rcc.h"
#include "stdlib.h"
#include "hmt_api.h"
#include "trace.h"
#include "light_bulb.h"

void homekit_random_bytes_handle(uint8_t* pRand, uint8_t length)
{
    uint16_t i= 0;
    
    ADC_InitTypeDef adcInitStruct;
    
    ADC_StructInit(&adcInitStruct);
    
    RCC_PeriphClockCmd(APBPeriph_ADC, APBPeriph_ADC_CLOCK, ENABLE);
    
    /* use temperature channel */
    adcInitStruct.channelMap = ADC_CH_TMP;
    ADC_Init(ADC, &adcInitStruct);
    ADC_INTConfig(ADC, ADC_INT_ONE_SHOT_DONE, ENABLE);
    ADC_Cmd(ADC, ADC_One_Shot_Mode, ENABLE);
    
    while(ADC_GetIntFlagStatus(ADC, ADC_INT_ONE_SHOT_DONE) != SET);
    ADC_ClearINTPendingBit(ADC, ADC_INT_ONE_SHOT_DONE);
    srand(ADC_Read(ADC, ADC_CH_TMP));
    
    for(i = 0; i < length; i++)
    {
        *pRand++ = (uint8_t)rand();
    }
    
    ADC_DeInit(ADC);
    
    return;
}

//0-1151(16*72 = 1152) for client key info
//(1152-1155) for state number
//(1156-1175) for light bulb service(sizeof(ltbs_db_t)20bytes)

/**
  * @brief user callback function to handle event in pairing.
  * @param[in] event homekit lib event.
  * @param     event data.
  * @note param[data] can be input param or output param according to specfic event.
  * @return none.
  */
uint8_t homekit_event_handle(uint8_t evt, void* data, uint16_t len)
{
    switch(evt)
    {
        /* save client info when pair-add/remove */
        case HMT_EVT_CLIENT_STORE:
            fs_save_vendor_data(data, sizeof(client_store_info_t), (((client_store_info_t*)data)->pos) * sizeof(client_store_info_t));
        break;
        
        /* load all client info when do homekit init */
        case HMT_EVT_ALL_CLIENT_LOAD:
            fs_load_vendor_data(data, sizeof(client_store_info_t) * hmt_get_max_client_support(), 0);
        break;

        /* remove one client context */
        case HMT_EVT_CLIENT_RM:
             fs_save_vendor_data(data, sizeof(client_store_info_t), (((client_store_info_t*)data)->pos) * sizeof(client_store_info_t));
        break;

        /* remove all client context */
        case HMT_EVT_ALL_CLIENT_RM:
            fs_save_vendor_data(data, sizeof(client_store_info_t) * hmt_get_max_client_support(), 0);
        break;
        
        /* save state num */
        case HMT_EVT_STATE_NUM_STORE:
            fs_save_vendor_data(data, 4, 1152);
        break;

        /* laod state num */
        case HMT_EVT_STATE_NUM_LOAD:
            fs_load_vendor_data(data, 4, 1152);
        break;

        /* generate random bytes */
        case HMT_EVT_RANDOM:
            homekit_random_bytes_handle((uint8_t*)data, len);
        break;

        case HMT_EVT_USER_FACTORY:
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "App handle event: HMT_EVT_USER_FACTORY", 0);
            ltbs_factory_reset();
        break;

        case HMT_EVT_PAIR_ERROR:
        {
            hmt_pair_err_t* error  = (hmt_pair_err_t*)data;
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "App handle event: HMT_EVT_PAIR_ERR, method: %d, state: %d, err:%d", 3,\
                        error->method, error->state, error->err);

        }
        break;

        case HMT_EVT_PAIR_SETUP_START:
             DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "App handle event: HMT_EVT_PAIR_SETUP_START", 0);
        break;
        
        case HMT_EVT_PAIR_SETUP_OK:
             DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "App handle event: HMT_EVT_PAIR_SETUP_OK", 0);
        break;

        case HMT_EVT_PAIR_VERIFY_START:
             DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "App handle event: HMT_EVT_PAIR_VERIFY_START", 0);
        break;

        case HMT_EVT_PAIR_VERIFY_OK:
             DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "App handle event: HMT_EVT_PAIR_VERIFY_OK", 0);
        break;

        case HMT_EVT_PAIR_ADD_START:
             DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "App handle event: HMT_EVT_PAIR_ADD_START", 0);
        break;

        case HMT_EVT_PAIR_ADD_OK:
             DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "App handle event: HMT_EVT_PAIR_ADD_OK", 0);
        break;

        case HMT_EVT_PAIR_REMOVE_START:
             DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "App handle event: HMT_EVT_PAIR_REMOVE_START", 0);
        break;

        case HMT_EVT_PAIR_REMOVE_OK:
             DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "App handle event: HMT_EVT_PAIR_REMOVE_OK", 0);
        break;

        case HMT_EVT_PAIR_LIST_START:
             DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "App handle event: HMT_EVT_PAIR_LIST_START", 0);
        break;

        case HMT_EVT_PAIR_LIST_OK:
             DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "App handle event: HMT_EVT_PAIR_LIST_OK", 0);
        break;
        
        default:
        break;
    }
    
    return 0;   //success
}
