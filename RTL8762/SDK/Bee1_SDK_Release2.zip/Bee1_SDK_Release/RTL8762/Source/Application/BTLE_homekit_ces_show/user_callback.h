#ifndef _USER_CALLBACK_H_
#define _USER_CALLBACK_H_

#ifdef  __cplusplus
extern "C" {
#endif      /* __cplusplus */

#include "hmt_api.h"

uint8_t homekit_event_handle(uint8_t event, void* data, uint16_t len);

#ifdef  __cplusplus
}
#endif      /*  __cplusplus */

#endif  /* _USER_CALLBACK_H_ */
