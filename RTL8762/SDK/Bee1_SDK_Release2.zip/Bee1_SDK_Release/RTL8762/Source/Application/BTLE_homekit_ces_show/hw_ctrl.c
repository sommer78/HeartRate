/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     hw_ctrl.c
* @brief    do some IO releated things.
* @details  none.
* @author   tifnan
* @date     2015-11-09
* @version  v0.1                       
*********************************************************************************************************
*/

#include "dimmable_light.h"
#include "rtl876x_rcc.h"
#include "rtl876x_gpio.h"
#include "rtl876x_tim.h"
#include "rtl876x_pwm.h"
#include "hw_ctrl.h"
#include "ota_api.h"
#include "hal_wdg.h"
#include "trace.h"
#include "hmt_api.h"
#include "light_bulb.h"

/**
  * @brief do accessory identifiy routine, change color of light from RED to BLUE.
  * @param none.
  * @return none
  */
void homekit_identify(void)
{
    ltbs_db_t ltbs_db;
    lgt_hw_ctrl_t par;
    uint32_t i, j;

    //ltbs_get_para_hsv(&hsv);
    ltbs_get_db(&ltbs_db);

    for(j = 0; j < 3; j++)
    {
        //show color red
        par.rgb.r = 255;
        par.rgb.g = 0;
        par.rgb.b = 0;
        par.c = 1;
        par.w = 0;
        light_hw_ctrl(&par);
        for(i = 0; i < 960000; i++);

        //show color green
        par.rgb.r = 0;
        par.rgb.g = 255;
        par.rgb.b = 0;
        par.c = 1;
        par.w = 0;
        light_hw_ctrl(&par);
        for(i = 0; i < 960000; i++);

        //show color blue
        par.rgb.r = 0;
        par.rgb.g = 0;
        par.rgb.b = 255;
        par.c = 1;
        par.w = 0;
        light_hw_ctrl(&par);
        for(i = 0; i < 960000; i++);
    }
    
    //return to previoud color
    hsv_to_rgb(&ltbs_db.hsv, &par.rgb);
    par.c = ltbs_db.pwmc;
    par.w = ltbs_db.pwmw;
    
    if(ltbs_db.on_off)
    {
        light_hw_ctrl(&par);
    }
    else
    {
        light_off();
    }
}

void factory_reset(void)
{
    /*prepare to enter into OTA mode*/
    hmt_factory_reset();
    //use watch dog to reset
    HalWatchDogConfig(0, 5, 1);
    HalWatchDogEnable();
}
