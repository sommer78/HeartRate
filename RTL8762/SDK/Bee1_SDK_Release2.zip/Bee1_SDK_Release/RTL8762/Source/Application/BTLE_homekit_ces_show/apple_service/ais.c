/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     ais.c
* @brief    Accessory Info service.
* @details  None.
* @author   tifnan_ge
* @date     2015-11-09
* @version  v0.1
*********************************************************************************************************
*/

#include "rtl_types.h"
#include "string.h"
#include "profileApi.h"
#include "ais.h"
#include "trace.h"
#include "board.h"
#include "version.h"
#include "hmt_api.h"
#include "hw_ctrl.h"

/* accessory manufacturer */
const uint8_t ais_mfr[] = "Realtek";
/* accessory manufacturer model */
const uint8_t ais_model[] = "RTL876x";
/* accessory name */
const uint8_t ais_name[] = "RTK_Hkt_Dev";
/* accessory manufacturer serial number */
const uint8_t ais_sn[] = "AB36D47E8EFA";
//firmware version
const uint8_t ais_fw_ver[] = FILE_VERSION_STR;

/**<  service instant id & characteristic id */
static const uint16_t ais_inst_id_ais = 1;       //service id accessory info service must be 1
static const uint16_t ais_inst_id_char_ais = 8;
static const uint16_t ais_inst_id_char_identify = 9;
static const uint16_t ais_inst_id_char_manufac = 10;
static const uint16_t ais_inst_id_char_model = 11;
static const uint16_t ais_inst_id_char_name = 12;
static const uint16_t ais_inst_id_char_sn = 13;
static const uint16_t ais_inst_id_char_fm_ver = 14;

//used to save encrypt data and decrypt data
uint8_t ais_buf[35];

/**< @brief  profile/service definition.  */
static const TAttribAppl ais_attr_tbl[] =
{
    /*----------------- Accessory Information Service -------------------*/
    /* <<Primary Service>>, index 0*/
    {
        (ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_LE),   /* wFlags     */
        {                                                /* bTypeValue */
            LO_WORD(GATT_UUID_PRIMARY_SERVICE),
            HI_WORD(GATT_UUID_PRIMARY_SERVICE),
            LO_WORD(HOMEKIT_SRV_UUID16_AIS),              /* service UUID */
            HI_WORD(HOMEKIT_SRV_UUID16_AIS)
        },
        UUID_16BIT_SIZE,                            /* bValueLen     */
        NULL,                                       /* pValueContext */
        GATT_PERM_READ                              /* wPermissions  */
    },

    /* <<Characteristic>>, ... index1 */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - Service Instance IDs, index2*/
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_SRV_INT_ID
        },
        0,                                          /* "1" */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },
    
    /* Characteristic User Description index3 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                       /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID                                 /* "2" */
        },
        2,                                           /* bValueLen */
        (void*)&ais_inst_id_char_ais,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 4   [identify]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_WRITE                    /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },
    
   /* characteristic.....identify, index 5 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                        /* bTypeValue */
            HOMEKIT_CHAR_UUID128_IDENTIFY
        },
        0,                                          /* "1" */
        NULL,
        GATT_PERM_WRITE                            /* wPermissions */
    },

    /* Characteristic User Description, index 6 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                           /* bValueLen */
        (void*)&ais_inst_id_char_identify,
        GATT_PERM_READ                         /* wPermissions */
    },
    
     /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 7   [manufacturer]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ                     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic...Manufacturer, index 8 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                        /* bTypeValue */
            HOMEKIT_CHAR_UUID128_MFR
        },
        0,                         /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },
    
    /* Characteristic User Description, index 9 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                           /* bValueLen */
        (void*)&ais_inst_id_char_manufac,
        GATT_PERM_READ                         /* wPermissions */
    },
    
    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 10   [model]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ                     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },
    
    /* characteristic...model, index 11 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                        /* bTypeValue */
            HOMEKIT_CHAR_UUID128_MODEL
        },
        0,                         /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },
    
    /* Characteristic User Description, index 12 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                           /* bValueLen */
        (void*)&ais_inst_id_char_model,
        GATT_PERM_READ                         /* wPermissions */
    },
    
    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 13   [accessory name]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ                     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },
    
    /* characteristic...name, index 14 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                        /* bTypeValue */
            HOMEKIT_CHAR_UUID128_NAME
        },
        0,                         /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },
    
    /* Characteristic User Description, index 15 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                           /* bValueLen */
        (void*)&ais_inst_id_char_name,
        GATT_PERM_READ                         /* wPermissions */
    },
    
    
    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 16   [accessory serial number]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ                     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },
    
    /* characteristic...serial number, index 17 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                        /* bTypeValue */
            HOMEKIT_CHAR_UUID128_SN
        },
        0,                         /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },
    
    /* Characteristic User Description, index 18 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                           /* bValueLen */
        (void*)&ais_inst_id_char_sn,
        GATT_PERM_READ                         /* wPermissions */
    },

    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 19   [accessory firmware verision]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ                     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },
    
    /* characteristic...firmware reverision, index 20 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                        /* bTypeValue */
            HOMEKIT_CHAR_UUID128_FW_VER
        },
        0,                         /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },
    
    /* Characteristic User Description, index 21 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                           /* bValueLen */
        (void*)&ais_inst_id_char_fm_ver,
        GATT_PERM_READ                         /* wPermissions */
    },
};

/**< @brief  Accessory service size definition.  */
const static uint16_t ais_tbl_size = sizeof(ais_attr_tbl);

/**
  * @brief accessory info service atribute read callback function.
  * @param[in] service id -- accessory info service id.
  * @param[in] attr_idx   -- accessory info attribute index.
  * @param[in] offset     -- attribute value read offset.
  * @param[out] len       -- attribute read value length.
  * @param[out] ppval     -- pointer of attribut value read buffer.    
  * @return attribute read result.
  */
TProfileResult  ais_attr_read_cb(uint8_t service_id , uint16_t attr_idx, uint16_t offset, uint16_t* len , uint8_t **ppval )
{
    TProfileResult  wCause  = ProfileResult_Success;
    
    uint16_t clen = 0;
    
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "ais_attr_read_cb: attr_idx: %d, offset: %d", 2, attr_idx, offset);
    
    switch(attr_idx)
    {
        case AIS_CHAR_INST_INDEX:
             hmt_session_encrypt((uint8_t*)&ais_inst_id_ais, 2, ais_buf, &clen);
        break;
        
        case AIS_CHAR_MANUFACTURER_INDEX:
            hmt_session_encrypt(ais_mfr, sizeof(ais_mfr), ais_buf, &clen);
        break;
        
        case AIS_CHAR_MODEL_INDEX:
            hmt_session_encrypt(ais_model, sizeof(ais_model), ais_buf, &clen);
        break;
        
        case AIS_CHAR_NAME_INDEX:
            hmt_session_encrypt(ais_name, sizeof(ais_name), ais_buf, &clen);
        break;
        
        case AIS_CHAR_SN_INDEX:
            hmt_session_encrypt(ais_sn, sizeof(ais_sn), ais_buf, &clen);
        break;

        case AIS_CHAR_FM_VER_INDEX:
            hmt_session_encrypt(ais_fw_ver, sizeof(ais_fw_ver), ais_buf, &clen);
        break;
        
        default:
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "-->ais_attr_read_cb: invalid attr index: %d", 1, attr_idx);
            wCause = ProfileResult_AttrNotFound;
        break;
    }
    
    if(wCause == ProfileResult_Success)
    {
        *ppval = ais_buf;
        *len = clen;
    }
    
    return wCause;
}

/**
  * @brief accessory info service atribute write callback function.
  * @param[in] service id -- accessory info service id.
  * @param[in] attr_idx   -- accessory info attribute index.
  * @param[in] wlen       -- length of write value.
  * @param[out] pval      -- value to be written.
  * @param[out] pwr_ind_proc  -- pointer of a function to handle control point write.    
  * @return write result.
  */
TProfileResult ais_attr_write_cb(uint8_t service_id, uint16_t attr_idx,
                              uint16_t len, uint8_t* pval , TGATTDWriteIndPostProc * pwr_ind_proc)
{
    TProfileResult  wCause  = ProfileResult_Success;
    uint16_t plen = 0;

    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "ais_attr_write_cb", 0);

    hmt_session_decrypt(pval, len, ais_buf, &plen);
    
    if(AIS_CHAR_IDENTIFY_INDEX == attr_idx)
    {
        //do identify
        homekit_identify();
    }
    
    return wCause;
}

/**
 * @brief accessory info service callbacks.
*/
CONST gattServiceCBs_t ais_cbs =
{
    ais_attr_read_cb,       // Read callback function pointer
    ais_attr_write_cb,      // Write callback function pointer
    NULL,                   // CCCD update callback function pointer
    NULL                    // confirmation callback function pointer
};

/**
  * @brief accessory info service initialization.
  * @param none.
  * @return initialization result.
  * retval  0--success.
  *         1--failde
  */
uint8_t ais_init(void)
{
    uint8_t service_id;

    if (FALSE == ProfileAPI_AddService(&service_id,
                                       (uint8_t*)ais_attr_tbl,
                                       ais_tbl_size,
                                       ais_cbs))
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "ais_init: add accessory info service fail!!", 0);
        service_id = 0xff;
        return 1;
    }

    return 0;   
}
