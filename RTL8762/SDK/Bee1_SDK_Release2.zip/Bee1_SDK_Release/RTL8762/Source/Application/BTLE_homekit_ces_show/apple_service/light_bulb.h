/**
************************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
************************************************************************************************************
* @file     light_bulb.h
* @brief    Head file for homekit light bulb service.
* @details  Light bulb Service data structs and external functions declaration.
* @author   tifnan_ge
* @date     2015-09-22
* @version  v0.1
*************************************************************************************************************
*/

#ifndef _LIGHT_BULB_H_
#define _LIGHT_BULB_H_

#ifdef  __cplusplus
extern "C" {
#endif      /* __cplusplus */
    
#include "stdint.h"
#include "stdbool.h"
#include "dimmable_light.h"

/** @brief  Index defines for light bulb status Characteristic*/
#define GATT_SVC_LTBS_SRV_INST_INDEX          2 /**<  @brief  Index for service instant id chars's value      */
#define GATT_SVC_LTBS_ON_INDEX                5 /**<  @brief  Index for on chars's value      */
#define GATT_SVC_LTBS_HUE_INDEX               9 /**<  @brief  Index for hue chars's value      */
#define GATT_SVC_LTBS_BRIGHTNESS_INDEX        13 /**<  @brief  Index for brightness chars's value      */
#define GATT_SVC_LTBS_SATURATION_INDEX        17 /**<  @brief  Index for saturation chars's value      */
#define GATT_SVC_LTBS_NAME_INDEX              21 /**<  @brief  Index for name chars's value      */
//only for node light
#define GATT_SVC_LTBS_PWM_C_INDEX             24 /**<  @brief  Index for pwm c chars's value */
#define GATT_SVC_LTBS_PWM_W_INDEX             31 /**<  @brief  Index for PWM w chars's value */
#define GATT_SVC_LTBS_FAC_RST_INDEX           38 /**<  @brief  Index for factory reset value, write only */

//user define characteristic UUID
#define HOMEKIT_CHAR_PWM_C                    0x91, 0x52, 0x76, 0xBB, 0x26, 0x00, 0x00, 0x80, 0x00, 0x10, 0x00, 0x00, 0x88, 0x00, 0x00, 0x00
#define HOMEKIT_CHAR_PWM_W                    0x91, 0x52, 0x76, 0xBB, 0x26, 0x00, 0x00, 0x80, 0x00, 0x10, 0x00, 0x00, 0x89, 0x00, 0x00, 0x00
#define HOMEKIT_CHAR_FACTORY_RESET            0x91, 0x52, 0x76, 0xBB, 0x26, 0x00, 0x00, 0x80, 0x00, 0x10, 0x00, 0x00, 0x8a, 0x00, 0x00, 0x00

//hsv struct
typedef struct _hsv_t
{
    float h;         //hue: 0--360
    float s;         //sturation: 0--100
    int v;           //value(brightness): 0--100
}hsv_t;

typedef struct _ltbs_db_t
{
    hsv_t   hsv; 
    uint8_t pwmc;        //pwm c
    uint8_t pwmw;        //pwm w
    uint8_t on_off;       //0 or 1
    uint8_t valid0;       //for valid
    uint8_t valid1;
    uint8_t padding[3];
}ltbs_db_t;

/****************************************************************************************************************
* exported globals.
****************************************************************************************************************/

/****************************************************************************************************************
* exported functions.
****************************************************************************************************************/
uint8_t ltbs_init(void);
bool ltbs_send_indication(uint8_t service_id, uint16_t attr_idx, uint8_t* data, uint16_t len);
uint8_t ltbs_save_db(void);
uint8_t ltbs_factory_reset(void);
void hsv_to_rgb(hsv_t* hsv, rgb_t* rgb);
void ltbs_set_db(ltbs_db_t* db);
void ltbs_get_db(ltbs_db_t* db);
uint8_t ltbs_get_srv_id(void);

#ifdef  __cplusplus
}
#endif      /*  __cplusplus */

#endif  /* _LIGHT_BULB_H_ */
