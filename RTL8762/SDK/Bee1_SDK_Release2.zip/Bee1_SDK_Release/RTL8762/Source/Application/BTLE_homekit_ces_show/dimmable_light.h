/**
*****************************************************************************************
*     Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
  * @file     dimmable_light.h
  * @brief    Head file for dimmable light.
  * @details  Data structs and external functions declaration.
  * @author   bill
  * @date     2015-11-03
  * @version  v0.1
  * *************************************************************************************
  */

/* Define to prevent recursive inclusion */
#ifndef _DIMMABLE_LIGHT_H_
#define _DIMMABLE_LIGHT_H_

#ifdef  __cplusplus
 extern "C" {
#endif      /* __cplusplus */

/* Add Includes here */
#include "rtl_types.h"

/* Defines ------------------------------------------------------------------*/
typedef enum
{
    LED_C = 0,
    LED_W,
    LED_R,
    LED_G,
    LED_B
} TLedChannel;

typedef struct _rgb_t
{
    uint8_t r;
    uint8_t g;
    uint8_t b;
}rgb_t;

typedef struct _lgt_hw_ctrl_t
{
    uint8_t c;
    uint8_t w;
    rgb_t rgb;
}lgt_hw_ctrl_t;

void light_init(lgt_hw_ctrl_t* par, uint8_t onoff);
void light_on(lgt_hw_ctrl_t* par);
void light_off(void);
void light_hw_ctrl(lgt_hw_ctrl_t* par);

#ifdef  __cplusplus
}
#endif      /* __cplusplus */

#endif /* _DIMMABLE_LIGHT_H_ */
