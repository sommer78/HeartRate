/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file		dimmable_light.c
* @brief	This file provides demo code for the operation of nord dimmable led light.
* @details
* @author	elliot chen
* @date 	2015-11-03
* @version	v0.1
*********************************************************************************************************
*/

/* Includes ------------------------------------------------------------------*/
#include "dimmable_light.h"
#include "rtl876x_rcc.h"
#include "rtl876x_PWM.h"
#include "rtl876x_nvic.h"
#include "rtl876x_pinmux.h"
#include "rtl876x_gpio.h"
#include "rtl876x_tim.h"

/* Defines ------------------------------------------------------------------*/
/* Pin define */
#define LEDC        			P2_0
#define LEDW                    P2_1
#define LEDR                    P4_1
#define LEDG                    P4_0
#define LEDB                    P4_2
#define GPIO_LEDB               GPIO_GetPin(LEDB)

/*Timer define */
#define TIM_ID                  TIM2
#define TIM_INDEX               2
/* frequency of timer  = 10M/(period+1) = 50 kHz*/
#define TIM_PERIOD              (200-1)

/* PWM define */
#define LEDC_PERIOD             2
#define LEDC_DUTY               1

#define LEDW_PERIOD             2
#define LEDW_DUTY               1

#define LEDR_PERIOD             2
#define LEDR_DUTY               1

#define LEDG_PERIOD             2
#define LEDG_DUTY               1

/*PWM test code---------------------------------------------------------------*/
void RCC_Configuration(void)
{
	/* turn on timer clock */
    RCC_PeriphClockCmd(APBPeriph_TIMER, APBPeriph_TIMER_CLOCK, ENABLE);
    RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
}

void PINMUXConfiguration(void)
{
    Pinmux_Config(LEDC, timer_pwm0);
    Pinmux_Config(LEDW, timer_pwm1);
    Pinmux_Config(LEDR, timer_pwm2);
    Pinmux_Config(LEDG, timer_pwm3);
    Pinmux_Config(LEDB, GPIO_FUN);
}

void PADConfiguration(void)
{
    Pad_Config(LEDC, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_HIGH);
    Pad_Config(LEDW, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_HIGH);
    Pad_Config(LEDR, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_HIGH);
    Pad_Config(LEDG, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_HIGH);
    Pad_Config(LEDB, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_HIGH);
}

static void light_pwm_init(lgt_hw_ctrl_t* par, uint8_t onoff)
{
	PWM_InitTypeDef PWM_InitStruct;
	TIM_TimeBaseInitTypeDef TIM_InitStruct;
	
    TIM_StructInit(&TIM_InitStruct);
	TIM_InitStruct.TIM_ClockSrc = TIM_CLOCK_10MHZ;
	TIM_InitStruct.TIM_Period = TIM_PERIOD;
	TIM_InitStruct.TIM_Mode = TIM_Mode_UserDefine;
	TIM_TimeBaseInit(TIM_ID, &TIM_InitStruct);
	TIM_Cmd(TIM_ID, ENABLE);

    //c
	PWM_InitStruct.PWM_Period = 255;
    PWM_InitStruct.PWM_Duty = par->c;
	PWM_InitStruct.PWM_TIMIndex = TIM_INDEX;
	PWM_Init(PWM0, &PWM_InitStruct);

    //w
	PWM_InitStruct.PWM_Period = 255;
    PWM_InitStruct.PWM_Duty = par->w;
	PWM_InitStruct.PWM_TIMIndex = TIM_INDEX;
	PWM_Init(PWM1, &PWM_InitStruct);
	//PWM_Cmd(PWM1, ENABLE);

    //r
	PWM_InitStruct.PWM_Period = 255;
    PWM_InitStruct.PWM_Duty = par->rgb.r;
	PWM_InitStruct.PWM_TIMIndex = TIM_INDEX;
	PWM_Init(PWM2, &PWM_InitStruct);
	//PWM_Cmd(PWM2, ENABLE);

    //g
	PWM_InitStruct.PWM_Period = 255;
    PWM_InitStruct.PWM_Duty = par->rgb.g;
	PWM_InitStruct.PWM_TIMIndex = TIM_INDEX;
	PWM_Init(PWM3, &PWM_InitStruct);
	//PWM_Cmd(PWM3, ENABLE);

    //b
    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_InitStruct.GPIO_Pin  = GPIO_LEDB;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_ITCmd = DISABLE;
    GPIO_Init(&GPIO_InitStruct);
    GPIO_ResetBits(GPIO_LEDB);

    if(onoff)
    {
        if (par->rgb.b < 128)
        {
            GPIO_ResetBits(GPIO_LEDB);
        }
        else
        {
            GPIO_SetBits(GPIO_LEDB);
        }

        PWM_Cmd(PWM0, ENABLE);
        PWM_Cmd(PWM1, ENABLE);
        PWM_Cmd(PWM2, ENABLE);
        PWM_Cmd(PWM3, ENABLE);
    }
}

void light_init(lgt_hw_ctrl_t* par, uint8_t onoff)
{
    RCC_Configuration();
    PINMUXConfiguration();
    PADConfiguration();
    light_pwm_init(par, onoff);
}

void light_hw_ctrl(lgt_hw_ctrl_t* par)
{
    PWM_InitTypeDef PWM_InitStruct;
    PWM_InitStruct.PWM_Period = 255;
    PWM_InitStruct.PWM_Duty = 0;
	PWM_InitStruct.PWM_TIMIndex = TIM_INDEX;

    //set c
    PWM_InitStruct.PWM_Duty = par->c;
    PWM_Cmd(PWM0, DISABLE);
    PWM_Init(PWM0, &PWM_InitStruct);
    PWM_Cmd(PWM0, ENABLE);

    //set w
    PWM_InitStruct.PWM_Duty = par->w;
    PWM_Cmd(PWM1, DISABLE);
    PWM_Init(PWM1, &PWM_InitStruct);
    PWM_Cmd(PWM1, ENABLE);
    
    //set r
    PWM_InitStruct.PWM_Duty = par->rgb.r;
    PWM_Cmd(PWM2, DISABLE);
    PWM_Init(PWM2, &PWM_InitStruct);
    PWM_Cmd(PWM2, ENABLE);
    
    //set g
    PWM_InitStruct.PWM_Duty = par->rgb.g;
    PWM_Cmd(PWM3, DISABLE);
    PWM_Init(PWM3, &PWM_InitStruct);
    PWM_Cmd(PWM3, ENABLE);
    
    //set b
    if(par->rgb.b < 128)
    {
        GPIO_ResetBits(GPIO_LEDB);
    }
    else
    {
        GPIO_SetBits(GPIO_LEDB);
    }
}

void light_off(void)
{
    PWM_Cmd(PWM0, DISABLE);
    PWM_Cmd(PWM1, DISABLE);
    PWM_Cmd(PWM2, DISABLE);
    PWM_Cmd(PWM3, DISABLE);
    GPIO_ResetBits(GPIO_LEDB);
}

void light_on(lgt_hw_ctrl_t* par)
{
    light_hw_ctrl(par);
}
