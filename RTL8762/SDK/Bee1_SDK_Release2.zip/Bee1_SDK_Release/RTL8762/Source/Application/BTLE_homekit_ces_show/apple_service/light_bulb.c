/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     light_bulb.c
* @brief    Homekit light bulb service.
* @details  None.
* @author   tifnan_ge
* @date     2015-11-06
* @version  v0.1
*********************************************************************************************************
*/
#include "rtl_types.h"
#include "profileApi.h"
#include "light_bulb.h"
#include "trace.h"
#include "string.h"
#include "rtl876x_flash_storage.h"
#include "hmt_api.h"
#include "hw_ctrl.h"

//adddress of light bulb service parameters in Flash
#define LIGHT_BULB_DB_FLASH_ADDR            1156

/**<  service instant id & characteristic id */
static const uint16_t ltbs_inst_id_ltbs = 15;       //service instant id
static const uint16_t ltbs_inst_id_char_ltbs = 16;
static const uint16_t ltbs_inst_id_char_on = 17;
static const uint16_t ltbs_inst_id_char_hue = 18;
static const uint16_t ltbs_inst_id_char_brightness = 19;
static const uint16_t ltbs_inst_id_char_saturation = 20;
static const uint16_t ltbs_inst_id_char_name = 21;
static const uint16_t ltbs_inst_id_char_pwmc = 22;
static const uint16_t ltbs_inst_id_char_pwmw = 23;
static const uint16_t ltbs_inst_id_char_fac_rst = 24;

//step value
uint8_t step_val = 0x01;

//buffer for homekit encrypt and decrypt
uint8_t ltbs_buff[15 + 16];
//light bulb service database
ltbs_db_t ltbs_db;
//light bulb service id
uint8_t ltbs_srv_id = 0;
//light bulb name
static const char ltbs_name[] = "RTK_light_bulb";

//ccc bits
uint16_t ltbs_ccc_bit_on = 0x00;
uint16_t ltbs_ccc_bit_hue = 0x00;
uint16_t ltbs_ccc_bit_brightness = 0x00;
uint16_t ltbs_ccc_bit_saturation = 0x00;
uint8_t ltbs_wait_ind_conf = 0;

/**< @brief  profile/service definition.  */
static const TAttribAppl ltbs_attr_tbl[] =
{
    /*----------------- Light Bulb Service -------------------*/
    /* <<Primary Service>>, index 0*/
    {
        (ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_LE),   /* wFlags     */
        {                                                /* bTypeValue */
            LO_WORD(GATT_UUID_PRIMARY_SERVICE),
            HI_WORD(GATT_UUID_PRIMARY_SERVICE),
            LO_WORD(HOMEKIT_SRV_UUID16_LIGHT_BULB),    /* service UUID */
            HI_WORD(HOMEKIT_SRV_UUID16_LIGHT_BULB)
        },
        UUID_16BIT_SIZE,                            /* bValueLen     */
        NULL,                                       /* pValueContext */
        GATT_PERM_READ                              /* wPermissions  */
    },

    /* <<Characteristic>>, ... index1 */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },
 
    /* characteristic - Service Instance IDs, index2*/
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_SRV_INT_ID
        },
        0,                                          /* "1" */
        NULL,                                       
        GATT_PERM_READ                              /* wPermissions */
    },
    
    /* Characteristic instant id index3 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID                                      /* "2" */
        },
        2,                                           /* bValueLen */
        (void*)&ltbs_inst_id_char_ltbs,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 4   [on/off]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_INDICATE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - on/off, index5*/
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_ON
        },
        0,                                          /* "1" */
        NULL,             //15
        (GATT_PERM_WRITE | GATT_PERM_READ | GATT_PERM_NOTIF_IND)     /* wPermissions */
    },
    
    /* client characteristic configuration, index 6 */
    {
        ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_CCCD_APPL,                 /* wFlags */
        {                                         /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            HI_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            /* NOTE: this value has an instantiation for each client, a write to */
            /* this attribute does not modify this default value:                */
            LO_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT), /* client char. config. bit field */
            HI_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT)
        },
        2,                                          /* bValueLen */
        NULL,
        (GATT_PERM_READ | GATT_PERM_WRITE)          /* wPermissions */
    },
    
    /* Characteristic User Description, index 7 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                          /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                           /* bValueLen */
        (void*)&ltbs_inst_id_char_on,
        GATT_PERM_READ                         /* wPermissions */
    },
    
    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 8   [hue]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_INDICATE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - brightness, index9*/
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_HUE
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_WRITE | GATT_PERM_READ | GATT_PERM_NOTIF_IND)     /* wPermissions */
    },
    
    /* client characteristic configuration, index 10 */
    {
        ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_CCCD_APPL,                 /* wFlags */
        {                                         /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            HI_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            /* NOTE: this value has an instantiation for each client, a write to */
            /* this attribute does not modify this default value:                */
            LO_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT), /* client char. config. bit field */
            HI_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT)
        },
        2,                                          /* bValueLen */
        NULL,
        (GATT_PERM_READ | GATT_PERM_WRITE)          /* wPermissions */
    },
    
    /* Characteristic User Description, index 11 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ltbs_inst_id_char_hue,
        GATT_PERM_READ                         /* wPermissions */
    },


    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 12   [brightness]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_INDICATE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - brightness, index13*/
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_BRIGHT
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_WRITE | GATT_PERM_READ | GATT_PERM_NOTIF_IND)     /* wPermissions */
    },
    
    /* client characteristic configuration, index 14 */
    {
        ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_CCCD_APPL,                 /* wFlags */
        {                                         /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            HI_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            /* NOTE: this value has an instantiation for each client, a write to */
            /* this attribute does not modify this default value:                */
            LO_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT), /* client char. config. bit field */
            HI_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT)
        },
        2,                                          /* bValueLen */
        NULL,
        (GATT_PERM_READ | GATT_PERM_WRITE)          /* wPermissions */
    },
    
    /* Characteristic User Description, index 15 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ltbs_inst_id_char_brightness,
        GATT_PERM_READ                         /* wPermissions */
    },
    
    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 16   [saturation]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_INDICATE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - saturation, index17 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_SATURATION
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_WRITE | GATT_PERM_READ | GATT_PERM_NOTIF_IND)     /* wPermissions */
    },
    
    /* client characteristic configuration, index 18 */
    {
        ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_CCCD_APPL,                 /* wFlags */
        {                                         /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            HI_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            /* NOTE: this value has an instantiation for each client, a write to */
            /* this attribute does not modify this default value:                */
            LO_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT), /* client char. config. bit field */
            HI_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT)
        },
        2,                                          /* bValueLen */
        NULL,
        (GATT_PERM_READ | GATT_PERM_WRITE)          /* wPermissions */
    },
    
    /* Characteristic User Description, index 19 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ltbs_inst_id_char_saturation,
        GATT_PERM_READ                         /* wPermissions */
    },
    
    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 20   [name]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - name, index 21*/
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_NAME
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_READ)                   /* wPermissions */
    },
    
    /* Characteristic User Description, index 22 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ltbs_inst_id_char_name,
        GATT_PERM_READ                         /* wPermissions */
    },

    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 23  [pwm c]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - PWM C, index 24 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_PWM_C
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_WRITE | GATT_PERM_READ)     /* wPermissions */
    },
    
     /* Characteristic user descriptor index 25 */
    {
        ATTRIB_FLAG_VALUE_INCL,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_USER_DESP),
            HI_WORD(HOMEKIT_DESP_CHAR_USER_DESP),
            'P',
            'W',
            'M',
            'C'
        },
        4,                                           /* bValueLen */
        NULL,
        GATT_PERM_READ                             /* wPermissions */
    },
    
     /* Characteristic format, index 26 */
    {
        ATTRIB_FLAG_VALUE_INCL,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HOMEKIT_FORMAT_INT,
            0,                                         /* 8bit exponent */
            LO_WORD(HOMEKIT_UNIT_UNITLESS),
            HI_WORD(HOMEKIT_UNIT_UNITLESS),
            1,                                        /* 8bit namespace */
            0,                                        /* 16bit Description */
            0       
        },
        7,                                           /* bValueLen */
        NULL,
        GATT_PERM_READ                             /* wPermissions */
    },
    
     /* Characteristic value range(0 -- 255), index 27 */
    {
        ATTRIB_FLAG_VALUE_INCL,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_VALID_RANGE),
            HI_WORD(HOMEKIT_DESP_VALID_RANGE),
            0x00,
            0x00,
            0xFF,
            0x00
        },
        4,                                           /* bValueLen */
        NULL,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic step value, index 28 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,      /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_STEP_VALUE
        },
        1,                                           /* bValueLen */
        (void*)&step_val,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic User Description, index 29 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ltbs_inst_id_char_pwmc,
        GATT_PERM_READ                         /* wPermissions */
    },

    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 30  [pwm w]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - PWM C, index 31 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_PWM_W
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_WRITE | GATT_PERM_READ)     /* wPermissions */
    },
    
     /* Characteristic user descriptor index 32 */
    {
        ATTRIB_FLAG_VALUE_INCL,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_USER_DESP),
            HI_WORD(HOMEKIT_DESP_CHAR_USER_DESP),
            'P',
            'W',
            'M',
            'W'
        },
        4,                                           /* bValueLen */
        NULL,
        GATT_PERM_READ                             /* wPermissions */
    },
    
     /* Characteristic format, index 33 */
    {
        ATTRIB_FLAG_VALUE_INCL,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HOMEKIT_FORMAT_INT,
            0,                                         /* 8bit exponent */
            LO_WORD(HOMEKIT_UNIT_UNITLESS),
            HI_WORD(HOMEKIT_UNIT_UNITLESS),
            1,                                        /* 8bit namespace */
            0,                                        /* 16bit Description */
            0       
        },
        7,                                           /* bValueLen */
        NULL,
        GATT_PERM_READ                             /* wPermissions */
    },
    
     /* Characteristic value range(0 -- 255), index 34 */
    {
        ATTRIB_FLAG_VALUE_INCL,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_VALID_RANGE),
            HI_WORD(HOMEKIT_DESP_VALID_RANGE),
            0x00,
            0x00,
            0xFF,
            0x00
        },
        4,                                           /* bValueLen */
        NULL,
        GATT_PERM_READ                             /* wPermissions */
    },
    
       /* Characteristic step value, index 35 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,      /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_STEP_VALUE
        },
        1,                                           /* bValueLen */
        (void*)&step_val,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic User Description, index 36 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ltbs_inst_id_char_pwmw,
        GATT_PERM_READ                         /* wPermissions */
    },
    
    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 37  [factory reset]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - PWM C, index 38 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_FACTORY_RESET
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_WRITE)     /* wPermissions */
    },
    
     /* Characteristic user descriptor index 39 */
    {
        ATTRIB_FLAG_VALUE_INCL,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_USER_DESP),
            HI_WORD(HOMEKIT_DESP_CHAR_USER_DESP),
            'F',
            'A',
            'C',
            'R',
            'S',
            'T'
        },
        6,                                           /* bValueLen */
        NULL,
        GATT_PERM_READ                             /* wPermissions */
    },
 
#if 0    
     /* Characteristic format, index 40 */
    {
        ATTRIB_FLAG_VALUE_INCL,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HOMEKIT_FORMAT_BOOL,
            0,                                         /* 8bit exponent */
            LO_WORD(HOMEKIT_UNIT_UNITLESS),
            HI_WORD(HOMEKIT_UNIT_UNITLESS),
            1,                                        /* 8bit namespace */
            0,                                        /* 16bit Description */
            0       
        },
        7,                                           /* bValueLen */
        NULL,
        GATT_PERM_READ                             /* wPermissions */
    },
#endif
    
    /* Characteristic User Description, index 41 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ltbs_inst_id_char_fac_rst,
        GATT_PERM_READ                         /* wPermissions */
    },
};

/**< @brief  Accessory service size definition.  */
const static uint16_t ltbs_attr_tbl_size = sizeof(ltbs_attr_tbl);

/**
  * @brief convert hsv color to RGB color.
  * @param[in] hsv -- pointer to hsv struct.
  * @param[out] rgb -- pointer to rgb struct.
  * @return none
  */
void hsv_to_rgb(hsv_t* hsv, rgb_t* rgb)
{
    float r, g, b;
	
	float h = ((float)hsv->h) / 360;
	float s = ((float)hsv->s) / 100;
	float v = ((float)hsv->v) / 100;
	
	int i = (h * 6);          //0 -- 5
	float f = h * 6 - i;      //0 -- 0.983333(h = 359)
	float p = v * (1 - s);
	float q = v * (1 - f * s);
	float t = v * (1 - (1 - f) * s);
	
	switch (i % 6) 
    {
		case 0: r = v, g = t, b = p; break;
		case 1: r = q, g = v, b = p; break;
		case 2: r = p, g = v, b = t; break;
		case 3: r = p, g = q, b = v; break;
		case 4: r = t, g = p, b = v; break;
		case 5: r = v, g = p, b = q; break;
	}
	
	rgb->r = r * 255;
	rgb->g = g * 255;
	rgb->b = b * 255;
}

/**
  * @brief save light bulb service data to Flash.
  * @param none.
  * @return operation result
  * @retval 0--success
  *         1--failed
  */
uint8_t ltbs_save_db(void)
{
    return fs_save_vendor_data((void*)&ltbs_db, sizeof(ltbs_db_t), LIGHT_BULB_DB_FLASH_ADDR);
}

/**
  * @brief light bulb service factory reset.
  * @param none.
  * @note called when do homekit accessory factory reset.
  * @return operation result
  * @retval 0--success
  *         1--failed
  */
uint8_t ltbs_factory_reset(void)
{
    //invalid parameters
    ltbs_db.valid0 = 0xDD;
    ltbs_db.valid1 = 0x77;
    return fs_save_vendor_data((void*)&ltbs_db, sizeof(ltbs_db_t), LIGHT_BULB_DB_FLASH_ADDR);
}

/**
  * @brief set light bulb service parameters.
  * @param[in] pointer to ltbs_db_t struct instance.
  * @return none
  */
void ltbs_set_db(ltbs_db_t* db)
{
    memcpy(&ltbs_db, db, sizeof(ltbs_db_t));
    ltbs_save_db();
}

/**
  * @brief set light bulb service parameters.
  * @param[in] pointer to ltbs_db_t struct instance.
  * @return none
  */
void ltbs_get_db(ltbs_db_t* db)
{
    memcpy(db, &ltbs_db, sizeof(ltbs_db_t));
} 

/**
  * @brief get service id of light bulb service.
  * @param none.
  * @return service id of light bulb service .
  */
uint8_t ltbs_get_srv_id(void)
{
    return ltbs_srv_id;
}

/**
  * @brief light bulb service atribute read callback function.
  * @param[in] service_id -- light bulb service id.
  * @param[in] attr_idx   -- light bulb attribute index.
  * @param[in] offset     -- attribute value read offset.
  * @param[out] len       -- attribute read value length.
  * @param[out] ppval     -- pointer of attribut value read buffer.    
  * @return attribute read result.
  */
TProfileResult ltbs_attr_read_cb(uint8_t service_id , uint16_t attr_idx, uint16_t offset, uint16_t* len , uint8_t **ppval)
{
    TProfileResult  wCause  = ProfileResult_Success;
    
    uint16_t c_len = 0;
    
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "ltbs_attr_read_cb: attr_idx: %d, offset: %d", 2, attr_idx, offset);
    
    switch(attr_idx)
    {
        case GATT_SVC_LTBS_SRV_INST_INDEX:
             hmt_session_encrypt((uint8_t*)&ltbs_inst_id_ltbs, 2, ltbs_buff, &c_len);
        break;
        
        case GATT_SVC_LTBS_ON_INDEX:
             hmt_session_encrypt(&ltbs_db.on_off, 1, ltbs_buff, &c_len);
        break;
        
        case GATT_SVC_LTBS_HUE_INDEX:
             hmt_session_encrypt((uint8_t*)&ltbs_db.hsv.h, sizeof(float), ltbs_buff, &c_len);
        break;
        
        case GATT_SVC_LTBS_BRIGHTNESS_INDEX:
            hmt_session_encrypt((uint8_t*)&ltbs_db.hsv.v, sizeof(int), ltbs_buff, &c_len);
        break;
        
        case GATT_SVC_LTBS_SATURATION_INDEX:
             hmt_session_encrypt((uint8_t*)&ltbs_db.hsv.s, sizeof(float), ltbs_buff, &c_len);
        break;

        case GATT_SVC_LTBS_NAME_INDEX:
            hmt_session_encrypt((uint8_t*)ltbs_name, sizeof(ltbs_name) - 1, ltbs_buff, &c_len);
        break;

        case GATT_SVC_LTBS_PWM_C_INDEX:
            hmt_session_encrypt((uint8_t*)&ltbs_db.pwmc, sizeof(uint8_t), ltbs_buff, &c_len);
        break;

        case GATT_SVC_LTBS_PWM_W_INDEX:
            hmt_session_encrypt((uint8_t*)&ltbs_db.pwmw, sizeof(uint8_t), ltbs_buff, &c_len);
        break;
        
        default:
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "-->LtbsAttrReadCb: invalid attr index: %d", 1, attr_idx);
            wCause = ProfileResult_AttrNotFound;
        break;
    }
    
    if(wCause == ProfileResult_Success)
    {
        *ppval = ltbs_buff;
        *len = c_len;
    }
    
    return wCause;
}

/**
  * @brief light bulb service atribute write callback function.
  * @param[in] service id -- light bulb service id.
  * @param[in] attr_idx   -- light bulb attribute index.
  * @param[in] wlen       -- length of write value.
  * @param[out] pval      -- value to be written.
  * @param[out] pwr_ind_proc  -- pointer of a function to handle control point write.    
  * @return write result.
  */
TProfileResult ltbs_attr_write_cb(uint8_t service_id, uint16_t attr_idx,
                              uint16_t wlen, uint8_t * pval , TGATTDWriteIndPostProc * pwr_ind_proc)
{
    TProfileResult  wCause  = ProfileResult_Success;
    
    uint16_t plen = 0;
    lgt_hw_ctrl_t par;
    
    hmt_session_decrypt(pval, wlen, ltbs_buff, &plen);
    
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "-->ltbs_attr_write_cb: attr_idx:%d, wlen:%d", 2, attr_idx, wlen);

    //user set on/off
    if(attr_idx == GATT_SVC_LTBS_ON_INDEX)
    {
        //turn on
        if(ltbs_buff[0] == 0x01)
        {
            ltbs_db.on_off = 1;
        }
        
        //turn off
        if(ltbs_buff[0] == 0x00)
        {
            ltbs_db.on_off = 0;
            light_off();
        }
    }
    else if(attr_idx == GATT_SVC_LTBS_HUE_INDEX)   //hue
    {
        if(plen == sizeof(float))
        {
            memcpy((uint8_t*)&ltbs_db.hsv.h, ltbs_buff, sizeof(float));
        }
        
    }
    else if(attr_idx == GATT_SVC_LTBS_BRIGHTNESS_INDEX)    //brightness
    { 
        if(plen == sizeof(int))
        {
            memcpy((uint8_t*)&ltbs_db.hsv.v, ltbs_buff, sizeof(int));
        }
    }
    else if(attr_idx == GATT_SVC_LTBS_SATURATION_INDEX)      //sturation
    {
        if(plen == sizeof(int))
        {
            memcpy((uint8_t*)&ltbs_db.hsv.s, ltbs_buff, sizeof(int));
        }
    }
    else if(attr_idx == GATT_SVC_LTBS_PWM_C_INDEX)      //pwm c
    {
        if(plen == sizeof(uint8_t))
        {
            memcpy((uint8_t*)&ltbs_db.pwmc, ltbs_buff, sizeof(uint8_t));
        }
    }
    else if(attr_idx == GATT_SVC_LTBS_PWM_W_INDEX)      //pwm w
    {
        if(plen == sizeof(uint8_t))
        {
            memcpy((uint8_t*)&ltbs_db.pwmw, ltbs_buff, sizeof(uint8_t));
        }
    }
    else if(attr_idx == GATT_SVC_LTBS_FAC_RST_INDEX)      //pwm w
    {
        //if(plen == sizeof(uint8_t))
        {
            //do factory reset
            factory_reset();
        }
    }
    else
    {
         DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "-->ltbs_attr_write_cb: invalid char index:%d", 1, attr_idx);
         wCause = ProfileResult_AttrNotFound;
    }

    //hardware control
    if(ltbs_db.on_off)
    {
        hsv_to_rgb(&ltbs_db.hsv, &par.rgb);
        par.c = ltbs_db.pwmc;
        par.w = ltbs_db.pwmw;
        light_hw_ctrl(&par);
    }

    //save to flash
    ltbs_save_db();
    
  return wCause;
}

/**
  * @brief light bulb service cccd bits update callback function.
  * @param[in] service id -- light bulb service id.
  * @param[in] attr_idx   -- light bulb attribute index.
  * @param[in] wccc_bits  -- ccc bits update.
  * @return none.
  */
void ltbs_cccd_update_cb(uint8_t service_id, uint16_t attr_idx, uint16_t wccc_bits)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "ltbs_cccd_update_cb:attribute index:%d, ccc_bits:%d", 2, attr_idx, wccc_bits);
    
    if(attr_idx == (GATT_SVC_LTBS_ON_INDEX + 1))
    {
        ltbs_ccc_bit_on= wccc_bits;
    }
    else if(attr_idx == (GATT_SVC_LTBS_HUE_INDEX + 1))
    {
        ltbs_ccc_bit_hue = wccc_bits;
    }
    else if(attr_idx == (GATT_SVC_LTBS_BRIGHTNESS_INDEX + 1))
    {
        ltbs_ccc_bit_brightness= wccc_bits;
    }
    else if(attr_idx == (GATT_SVC_LTBS_SATURATION_INDEX + 1))
    {
        ltbs_ccc_bit_saturation = wccc_bits;
    }
    else
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "-->ltbs_cccd_update_cb: invalid attr index: %d", 1, attr_idx);
    }
    
    return;
}

/**
  * @brief light bulb service status update callback function.
  * @param[in] service id -- light bulb service id.
  * @param[in] attr_idx   -- light bulb attribute index.
  * @note usually used when send indication done and have received confirmation.
  * @return none.
  */
void ltbs_update_st_cb(uint8_t service_id, uint16_t attr_idx)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "ltbs_update_status: attr_idx:%d", 1, attr_idx);
    
    ltbs_wait_ind_conf = 0;
    
    return;
}

/**
  * @brief send indication.
  * @param[in] service id -- light bulb service id.
  * @param[in] attr_idx   -- light bulb attribute index.
  * @param[in] data       -- indication data.
  * @param[in] len        -- indication data length.
  * @return none.
  */
bool ltbs_send_indication(uint8_t service_id, uint16_t attr_idx, uint8_t* data, uint16_t len)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "ltbs_send_indication: service_id: %d, attr_idx:%d, data:0x%x, len:%d",\
        4, service_id, attr_idx, data, len);

    uint16_t c_len = 0;

    if(attr_idx == GATT_SVC_LTBS_ON_INDEX)
    {
        if(ltbs_ccc_bit_on == 0x02)
        {
            ltbs_wait_ind_conf = 1;
            hmt_session_encrypt(data, len, ltbs_buff, &c_len);
             return ProfileAPI_SendData(service_id, attr_idx, ltbs_buff, c_len);
        }
    }
    else if(attr_idx == GATT_SVC_LTBS_ON_INDEX)
    {
        if(ltbs_ccc_bit_brightness== 0x02)
        {
            ltbs_wait_ind_conf = 1;
            hmt_session_encrypt(data, len, ltbs_buff, &c_len);
            return ProfileAPI_SendData(service_id, attr_idx, ltbs_buff, c_len);
        }
    }
    else
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "-->ltbs_send_indication: invalid attr index: %d", 1, attr_idx);
        return false;
    }
    
    return true;
}

/**
 * @brief light bulb service callbacks.
*/
static const gattServiceCBs_t ltbsCBs =
{
    ltbs_attr_read_cb,       // Read callback function pointer
    ltbs_attr_write_cb,      // Write callback function pointer
    ltbs_cccd_update_cb,     // CCCD update callback function pointer
    ltbs_update_st_cb        // confirmation callback function pointer
};

/**
  * @brief ligth bulb service initialization.
  * @param none.
  * @return initialization result.
  * retval  0--success.
  *         1--failde
  */
uint8_t ltbs_init(void)
{
    lgt_hw_ctrl_t par;
    
    //1. add light bulb service
    if (FALSE == ProfileAPI_AddService(&ltbs_srv_id,
                                       (uint8_t*)ltbs_attr_tbl,
                                       ltbs_attr_tbl_size,
                                       ltbsCBs))
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "Ltbs_AddService: service_id %d", 1, ltbs_srv_id);
        ltbs_srv_id = 0xff;
        return 1;  //add service fail
    }
    
    //2. load parameters of light bulb in Flash
    fs_load_vendor_data((void*)&ltbs_db, sizeof(ltbs_db_t), LIGHT_BULB_DB_FLASH_ADDR);
    
    if(ltbs_db.valid0 != 0xEE || ltbs_db.valid1 != 0xBB)
    {
        //default parameters
        ltbs_db.hsv.h = 0;       //red color
        ltbs_db.hsv.s = 100;
        ltbs_db.hsv.v = 100;
        ltbs_db.pwmc  = 2;
        ltbs_db.pwmw  = 0;
        ltbs_db.on_off = 1;      //default on
        ltbs_db.valid0 = 0xEE;
        ltbs_db.valid1 = 0xBB;
        //save in flash
        ltbs_save_db();
    }
    
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "-->ltbs_init: on_off: %d, hue: %d, brightness: %d, saturation:%d",\
                4, ltbs_db.on_off, (uint32_t)ltbs_db.hsv.h, (uint32_t)ltbs_db.hsv.v, (uint32_t)ltbs_db.hsv.s);
    
    //3.init light
    hsv_to_rgb(&ltbs_db.hsv, &par.rgb);
    par.c = ltbs_db.pwmc;
    par.w = ltbs_db.pwmw;
    light_init(&par, ltbs_db.on_off);
    
    return 0;
}
