/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     hw_ctrl.h
* @brief    declaration of some hardware control func.
* @details  none.
* @author   tifnan
* @date     2015-11-06
* @version  v0.1                       
*********************************************************************************************************
*/

#ifndef _HW_CTRL_H_
#define _HW_CTRL_H_

#ifdef  __cplusplus
 extern "C" {
#endif      /* __cplusplus */

#include <stdint.h>
     
#define FACTORY_RESET_PIN               P3_1

//export functions
void homekit_identify(void);
void factory_reset(void);
     
#ifdef  __cplusplus
}
#endif      /* __cplusplus */

#endif  /*_HW_CTRL_H_ */

