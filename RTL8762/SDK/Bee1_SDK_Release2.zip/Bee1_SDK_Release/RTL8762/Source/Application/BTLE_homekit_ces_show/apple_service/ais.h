/**
************************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
************************************************************************************************************
* @file     bas.h
* @brief    Head file for using accessory info service.
* @details  Accessory Info Service data structs and external functions declaration.
* @author   tifnan_ge
* @date     2015-11-09
* @version  v0.1
*************************************************************************************************************
*/

#ifndef _AIS_H_
#define _AIS_H_

#ifdef  __cplusplus
extern "C" {
#endif      /* __cplusplus */

/****************************************************************************************************************
* exported functions.
****************************************************************************************************************/

//attribute index
#define AIS_CHAR_INST_INDEX             2
#define AIS_CHAR_IDENTIFY_INDEX         5
#define AIS_CHAR_MANUFACTURER_INDEX     8
#define AIS_CHAR_MODEL_INDEX            11
#define AIS_CHAR_NAME_INDEX             14
#define AIS_CHAR_SN_INDEX               17
#define AIS_CHAR_FM_VER_INDEX           20

/****************************************************************************************************************
* exported functions.
****************************************************************************************************************/
uint8_t ais_init(void);

#ifdef  __cplusplus
}
#endif      /*  __cplusplus */

#endif
