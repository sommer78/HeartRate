/*
 *  Routines to access hardware
 *
 *  Copyright (c) 2014 Realtek Semiconductor Corp.
 *
 *  This module is a confidential and proprietary property of RealTek and
 *  possession or use of this module requires written permission of RealTek.
 */
#ifndef _TEST_HMT_CMD_H_
#define _TEST_HMT_CMD_H_

#ifdef  __cplusplus
extern "C" {
#endif      /* __cplusplus */

#include "test_hmt_uart.h"
#include "test_hmt_parse_cmd.h"

/****************************************************************************************************************
* exported variables other .c files may use all defined here.
****************************************************************************************************************/
extern const TestCmdTableEntry testCmdTable[];
extern TestCmdIF    gTestCmdIF;

#ifdef  __cplusplus
}
#endif      /*  __cplusplus */

#endif

