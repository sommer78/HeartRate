/**
*********************************************************************************************************
*               Copyright(c) 2014, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     thermostat.c
* @brief    Homekit thermostat service.
* @details  None.
* @author   tifnan_ge
* @date     2015-11-19
* @version  v0.1
*********************************************************************************************************
*/
#include "rtl_types.h"
#include "gatt.h"
#include "profileApi.h"
#include "thermostat.h"
#include <string.h>
#include "hmt_char.h"
#include "trace.h"
#include "rtl876x_tim.h"
#include "hmt_api.h"
#include "rtl876x_flash_storage.h"

/********************************************************************************************************
* local static variables defined here, only used in this source file.
********************************************************************************************************/
#define THERMOSTAT_DB_FLASH_ADDR                1172

/**<  service data */
tts_db_t tts_db;
uint8_t tts_srv_id = 0;
char tts_name[20] = "RTK_thermostat";

/**<  service instant id & characteristic id */
char siid_tts[5] = "20";
uint16_t ciid_tts_siid = 21;
uint16_t ciid_cst = 22;
uint16_t ciid_tst = 23;
uint16_t ciid_ctmp = 24;
uint16_t ciid_ttmp = 25;
uint16_t ciid_unit = 26;
uint16_t ciid_tts_name = 27;

//ccc_bit flag
uint16_t ccc_cst  = 0x00;
uint16_t ccc_tst  = 0x00;
uint16_t ccc_ctmp = 0x00;
uint16_t ccc_ttmp = 0x00;
uint16_t ccc_unit = 0x00;
uint8_t  tts_wait_ind_conf = 0;

//for encrypt and decrypt data
uint8_t tts_buff[15 + 16];

/*****************  characteristic format start ******************************/
uint8_t fmt_tts_siid[7] = 
{
    HOMEKIT_FORMAT_STRING,
    0,                                         /* 8bit exponent */
    LO_WORD(HOMEKIT_UNIT_UNITLESS),
    HI_WORD(HOMEKIT_UNIT_UNITLESS),
    1,                                        /* 8bit namespace, Bluetooth SIG Assigned Numbers */
    0,                                        /* 16bit Description */
    0    
};

uint8_t fmt_tts_name[7] = 
{
    HOMEKIT_FORMAT_STRING,
    0,                                         /* 8bit exponent */
    LO_WORD(HOMEKIT_UNIT_UNITLESS),
    HI_WORD(HOMEKIT_UNIT_UNITLESS),
    1,                                        /* 8bit namespace, Bluetooth SIG Assigned Numbers */
    0,                                        /* 16bit Description */
    0    
};

uint8_t fmt_cst[7] = 
{
    HOMEKIT_FORMAT_INT,
    0,                                         /* 8bit exponent */
    LO_WORD(HOMEKIT_UNIT_UNITLESS),
    HI_WORD(HOMEKIT_UNIT_UNITLESS),
    1,                                        /* 8bit namespace, Bluetooth SIG Assigned Numbers */
    0,                                        /* 16bit Description */
    0    
};

uint8_t fmt_tst[7] = 
{
    HOMEKIT_FORMAT_INT,
    0,                                         /* 8bit exponent */
    LO_WORD(HOMEKIT_UNIT_UNITLESS),
    HI_WORD(HOMEKIT_UNIT_UNITLESS),
    1,                                        /* 8bit namespace, Bluetooth SIG Assigned Numbers */
    0,                                        /* 16bit Description */
    0    
};

uint8_t fmt_ctmp[7] = 
{
    HOMEKIT_FORMAT_FLOAT,
    0,                                         /* 8bit exponent */
    LO_WORD(HOMEKIT_UNIT_CELSIUS),
    HI_WORD(HOMEKIT_UNIT_CELSIUS),
    1,                                        /* 8bit namespace, Bluetooth SIG Assigned Numbers */
    0,                                        /* 16bit Description */
    0    
};

uint8_t fmt_ttmp[7] = 
{
    HOMEKIT_FORMAT_FLOAT,
    0,                                         /* 8bit exponent */
    LO_WORD(HOMEKIT_UNIT_CELSIUS),
    HI_WORD(HOMEKIT_UNIT_CELSIUS),
    1,                                        /* 8bit namespace, Bluetooth SIG Assigned Numbers */
    0,                                        /* 16bit Description */
    0    
};

uint8_t fmt_unit[7] = 
{
    HOMEKIT_FORMAT_INT,
    0,                                         /* 8bit exponent */
    LO_WORD(HOMEKIT_UNIT_UNITLESS),
    HI_WORD(HOMEKIT_UNIT_UNITLESS),
    1,                                        /* 8bit namespace, Bluetooth SIG Assigned Numbers */
    0,                                        /* 16bit Description */
    0    
};

/*****************  characteristic format end ******************************/

/*****************  characteristic valid range start ******************************/
uint16_t vrg_tts_name[2] = 
{
    1,     //Lower inclusive value
    64,   //Upper inclusive value
};

uint8_t vrg_cst[2] = 
{
    0,     //Lower inclusive value
    2,   //Upper inclusive value
};

uint8_t vrg_tst[2] = 
{
    0,     //Lower inclusive value
    3,   //Upper inclusive value
};

float vrg_ctmp[2] = 
{
    0.0,     //Lower inclusive value
    100.0,   //Upper inclusive value
};

float vrg_ttmp[2] = 
{
    10.0,     //Lower inclusive value
    38.0,     //Upper inclusive value
};

uint8_t vrg_unit[2] = 
{
    0,     //Lower inclusive value
    1,   //Upper inclusive value
};

/*****************  characteristic valid range end ******************************/

/*****************  characteristic step value start  ******************************/
uint8_t  spv_cst = 1;
uint8_t  spv_tst = 1;
float  spv_ctmp = 0.1;
float  spv_ttmp = 0.1;
uint8_t  spv_unit = 1;
/*****************  characteristic step value end ******************************/

/**< @brief  profile/service definition.  */
static const TAttribAppl tts_attr_tbl[] =
{
#if THMST_SUPPORT_IOS9_R3
    /*----------------- Thermostat Service -------------------*/
    /* <<Primary Service>>, index 0*/
    {
        (ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_LE),   /* wFlags     */
        {                                                /* bTypeValue */
            LO_WORD(GATT_UUID_PRIMARY_SERVICE),
            HI_WORD(GATT_UUID_PRIMARY_SERVICE),
            LO_WORD(HOMEKIT_SRV_UUID16_THERMOSTAT),              /* service UUID */
            HI_WORD(HOMEKIT_SRV_UUID16_THERMOSTAT)
        },
        UUID_16BIT_SIZE,                            /* bValueLen     */
        NULL,                                       /* pValueContext */
        GATT_PERM_READ                              /* wPermissions  */
    },

    /* <<Characteristic>>, ... index1 */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },
 
    /* characteristic - Service Instance IDs, index2*/
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_SRV_INT_ID
        },
        0,                                          /* "1" */
        NULL,                                       
        GATT_PERM_READ                              /* wPermissions */
    },
    
    /* Characteristic Instance ID index3 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,     /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID                                     /* "2" */
        },
        2,                                           /* bValueLen */
        (void*)&ciid_tts_siid,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* characteristic descriptor: Format, index 4 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_tts_siid),                     /* bValueLen */
        (void*)fmt_tts_siid,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 5   [current heating/cooling status]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_INDICATE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - current status, index6*/
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_CUR_HC_ST
        },
        0,                                          /* "1" */
        NULL,                                       
        (GATT_PERM_READ | GATT_PERM_NOTIF_IND)     /* wPermissions */
    },
    
    /* client characteristic configuration, index 7 */
    {
        ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_CCCD_APPL,                 /* wFlags */
        {                                         /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            HI_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            /* NOTE: this value has an instantiation for each client, a write to */
            /* this attribute does not modify this default value:                */
            LO_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT), /* client char. config. bit field */
            HI_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT)
        },
        2,                                          /* bValueLen */
        NULL,
        (GATT_PERM_READ | GATT_PERM_WRITE)          /* wPermissions */
    },

    /* characteristic descriptor: Format, index 8 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_cst),                     /* bValueLen */
        (void*)fmt_cst,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: value range, index 9 */
    {
        ATTRIB_FLAG_VOID,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_VALID_RANGE),
            HI_WORD(HOMEKIT_DESP_VALID_RANGE),
        },
        sizeof(vrg_cst),               /* bValueLen */
        (void*)vrg_cst,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: step value(1), index 10 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,      /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_STEP_VALUE
        },
        sizeof(spv_cst),                  /* bValueLen */
        (void*)&spv_cst,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic User Description, index 11 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                           /* bValueLen */
        (void*)&ciid_cst,
        GATT_PERM_READ                         /* wPermissions */
    },

    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 12   [target heating/cooling status]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_INDICATE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - target status, index13 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_TAR_HC_ST
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_WRITE | GATT_PERM_READ | GATT_PERM_NOTIF_IND)     /* wPermissions */
    },
    
    /* client characteristic configuration, index 14 */
    {
        ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_CCCD_APPL,                 /* wFlags */
        {                                                            /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            HI_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            /* NOTE: this value has an instantiation for each client, a write to */
            /* this attribute does not modify this default value:                */
            LO_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT),          /* client char. config. bit field */
            HI_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT)
        },
        2,                                              /* bValueLen */
        NULL,
        (GATT_PERM_READ | GATT_PERM_WRITE)          /* wPermissions */
    },

    /* characteristic descriptor: Format, index 15 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_tst),                     /* bValueLen */
        (void*)fmt_tst,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: value range, index 16 */
    {
        ATTRIB_FLAG_VOID,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_VALID_RANGE),
            HI_WORD(HOMEKIT_DESP_VALID_RANGE),
        },
        sizeof(vrg_tst),               /* bValueLen */
        (void*)vrg_tst,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: step value(1), index 17 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,      /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_STEP_VALUE
        },
        sizeof(spv_tst),                  /* bValueLen */
        (void*)&spv_tst,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic User Description, index 18 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ciid_tst,
        GATT_PERM_READ                         /* wPermissions */
    },

    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 19  [current temperature]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_INDICATE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - target status, index 20 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_CUR_TMP
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_READ | GATT_PERM_NOTIF_IND)     /* wPermissions */
    },
    
    /* client characteristic configuration, index 21 */
    {
        ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_CCCD_APPL,                 /* wFlags */
        {                                         /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            HI_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            /* NOTE: this value has an instantiation for each client, a write to */
            /* this attribute does not modify this default value:                */
            LO_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT), /* client char. config. bit field */
            HI_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT)
        },
        2,                                          /* bValueLen */
        NULL,
        (GATT_PERM_READ | GATT_PERM_WRITE)          /* wPermissions */
    },

    /* characteristic descriptor: Format, index 22 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_ctmp),                     /* bValueLen */
        (void*)fmt_ctmp,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: value range, index 23*/
    {
        ATTRIB_FLAG_VOID,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_VALID_RANGE),
            HI_WORD(HOMEKIT_DESP_VALID_RANGE),
        },
        sizeof(vrg_ctmp),               /* bValueLen */
        (void*)vrg_ctmp,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: step value(1.0), index 24 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,      /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_STEP_VALUE
        },
        sizeof(spv_ctmp),                  /* bValueLen */
        (void*)&spv_ctmp,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic User Description, index 25 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ciid_ctmp,
        GATT_PERM_READ                         /* wPermissions */
    },

    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 26   [target temperature]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_INDICATE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - target status, index27 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_TAR_TMP
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_WRITE | GATT_PERM_READ | GATT_PERM_NOTIF_IND)     /* wPermissions */
    },
    
    /* client characteristic configuration, index 28 */
    {
        ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_CCCD_APPL,                 /* wFlags */
        {                                         /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            HI_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            /* NOTE: this value has an instantiation for each client, a write to */
            /* this attribute does not modify this default value:                */
            LO_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT), /* client char. config. bit field */
            HI_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT)
        },
        2,                                          /* bValueLen */
        NULL,
        (GATT_PERM_READ | GATT_PERM_WRITE)          /* wPermissions */
    },

    /* characteristic descriptor: Format, index 29 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_ttmp),                     /* bValueLen */
        (void*)fmt_ttmp,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: value range, index 30 */
    {
        ATTRIB_FLAG_VOID,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_VALID_RANGE),
            HI_WORD(HOMEKIT_DESP_VALID_RANGE),
        },
        sizeof(vrg_ttmp),               /* bValueLen */
        (void*)vrg_ttmp,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: step value(1.0), index 31 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,      /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_STEP_VALUE
        },
        sizeof(spv_ttmp),                  /* bValueLen */
        (void*)&spv_ttmp,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic User Description, index 32 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ciid_ttmp,
        GATT_PERM_READ                         /* wPermissions */
    },

    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 33   [Temperature Display Units]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_INDICATE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - target status, index 34 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_TMP_DIS_UNIT
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_WRITE | GATT_PERM_READ | GATT_PERM_NOTIF_IND)     /* wPermissions */
    },
    
    /* client characteristic configuration, index 35 */
    {
        ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_CCCD_APPL,                 /* wFlags */
        {                                         /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            HI_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            /* NOTE: this value has an instantiation for each client, a write to */
            /* this attribute does not modify this default value:                */
            LO_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT), /* client char. config. bit field */
            HI_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT)
        },
        2,                                          /* bValueLen */
        NULL,
        (GATT_PERM_READ | GATT_PERM_WRITE)          /* wPermissions */
    },

    /* characteristic descriptor: Format, index 36 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_unit),                     /* bValueLen */
        (void*)fmt_unit,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: value range, index 37 */
    {
        ATTRIB_FLAG_VOID,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_VALID_RANGE),
            HI_WORD(HOMEKIT_DESP_VALID_RANGE),
        },
        sizeof(vrg_unit),               /* bValueLen */
        (void*)vrg_unit,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: step value(1.0), index 38 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,      /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_STEP_VALUE
        },
        sizeof(spv_unit),                  /* bValueLen */
        (void*)&spv_unit,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic User Description, index 39 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                          /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ciid_unit,
        GATT_PERM_READ                         /* wPermissions */
    },

    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 40   [name]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - name, index 41 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_NAME
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_READ)                   /* wPermissions */
    },

    /* characteristic descriptor: Format, index 42 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(char_tt_name_format),                     /* bValueLen */
        (void*)char_tt_name_format,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic User Description, index 43 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ciid_tts_name,
        GATT_PERM_READ                         /* wPermissions */
    },
    
     /* Characteristic descriptor: value range(1 -- 64), index 44 */
    {
        ATTRIB_FLAG_VOID,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_VALID_RANGE),
            HI_WORD(HOMEKIT_DESP_VALID_RANGE),
        },
        sizeof(vrg_tts_name),               /* bValueLen */
        (void*)vrg_tts_name,
        GATT_PERM_READ                             /* wPermissions */
    },
#else
    /*----------------- Thermostat Service -------------------*/
    /* <<Primary Service>>, index 0*/
    {
        (ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_LE),   /* wFlags     */
        {                                                /* bTypeValue */
            LO_WORD(GATT_UUID_PRIMARY_SERVICE),
            HI_WORD(GATT_UUID_PRIMARY_SERVICE),
            LO_WORD(HOMEKIT_SRV_UUID16_THERMOSTAT),              /* service UUID */
            HI_WORD(HOMEKIT_SRV_UUID16_THERMOSTAT)
        },
        UUID_16BIT_SIZE,                            /* bValueLen     */
        NULL,                                       /* pValueContext */
        GATT_PERM_READ                              /* wPermissions  */
    },

    /* <<Characteristic>>, ... index1 */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },
 
    /* characteristic - Service Instance IDs, index2*/
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_SRV_INT_ID
        },
        0,                                          /* "1" */
        NULL,                                       
        GATT_PERM_READ                              /* wPermissions */
    },
    
    /* Characteristic Instance ID index3 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,     /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID                                     /* "2" */
        },
        2,                                           /* bValueLen */
        (void*)&ciid_tts_siid,
        GATT_PERM_READ                             /* wPermissions */
    },
    
     /* characteristic descriptor: Format, index 4 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_tts_siid),                     /* bValueLen */
        (void*)fmt_tts_siid,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 5  [current heating/cooling status]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - current status, index6 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_CUR_HC_ST
        },
        0,                                          /* "1" */
        NULL,                                       
        (GATT_PERM_READ)     /* wPermissions */
    },

    /* characteristic descriptor: Format, index 7 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_cst),                     /* bValueLen */
        (void*)fmt_cst,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: value range, index 8 */
    {
        ATTRIB_FLAG_VOID,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_VALID_RANGE),
            HI_WORD(HOMEKIT_DESP_VALID_RANGE),
        },
        sizeof(vrg_cst),               /* bValueLen */
        (void*)vrg_cst,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: step value(1), index 9 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,      /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_STEP_VALUE
        },
        sizeof(spv_cst),                  /* bValueLen */
        (void*)&spv_cst,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic User Description, index 10 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                           /* bValueLen */
        (void*)&ciid_cst,
        GATT_PERM_READ                         /* wPermissions */
    },

    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 11   [target heating/cooling status]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - target status, index12 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_TAR_HC_ST
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_WRITE | GATT_PERM_READ)     /* wPermissions */
    },

    /* characteristic descriptor: Format, index 13 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_tst),                     /* bValueLen */
        (void*)fmt_tst,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: value range, index 14 */
    {
        ATTRIB_FLAG_VOID,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_VALID_RANGE),
            HI_WORD(HOMEKIT_DESP_VALID_RANGE),
        },
        sizeof(vrg_tst),               /* bValueLen */
        (void*)vrg_tst,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: step value(1), index 15 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,      /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_STEP_VALUE
        },
        sizeof(spv_tst),                  /* bValueLen */
        (void*)&spv_tst,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic User Description, index 16 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ciid_tst,
        GATT_PERM_READ                         /* wPermissions */
    },

    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 17   [current temperature]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - target status, index 18 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_CUR_TMP
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_READ)     /* wPermissions */
    },

    /* characteristic descriptor: Format, index 19 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_ctmp),                     /* bValueLen */
        (void*)fmt_ctmp,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: value range, index 20 */
    {
        ATTRIB_FLAG_VOID,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_VALID_RANGE),
            HI_WORD(HOMEKIT_DESP_VALID_RANGE),
        },
        sizeof(vrg_ctmp),               /* bValueLen */
        (void*)vrg_ctmp,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: step value(1.0), index 21 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,      /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_STEP_VALUE
        },
        sizeof(spv_ctmp),                  /* bValueLen */
        (void*)&spv_ctmp,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic User Description, index 22 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ciid_ctmp,
        GATT_PERM_READ                         /* wPermissions */
    },

    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 23  [target temperature]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - target status, index24 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_TAR_TMP
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_WRITE | GATT_PERM_READ)     /* wPermissions */
    },

    /* characteristic descriptor: Format, index 25 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_ttmp),                     /* bValueLen */
        (void*)fmt_ttmp,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: value range, index 26 */
    {
        ATTRIB_FLAG_VOID,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_VALID_RANGE),
            HI_WORD(HOMEKIT_DESP_VALID_RANGE),
        },
        sizeof(vrg_ttmp),               /* bValueLen */
        (void*)vrg_ttmp,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: step value(1.0), index 27 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,      /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_STEP_VALUE
        },
        sizeof(spv_ttmp),                  /* bValueLen */
        (void*)&spv_ttmp,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic User Description, index 28 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ciid_ttmp,
        GATT_PERM_READ                         /* wPermissions */
    },

    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 29   [Temperature Display Units]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - target status, index 30 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_TMP_DIS_UNIT
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_WRITE | GATT_PERM_READ)     /* wPermissions */
    },

    /* characteristic descriptor: Format, index 31 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_unit),                     /* bValueLen */
        (void*)fmt_unit,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: value range, index 32 */
    {
        ATTRIB_FLAG_VOID,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_VALID_RANGE),
            HI_WORD(HOMEKIT_DESP_VALID_RANGE),
        },
        sizeof(vrg_unit),               /* bValueLen */
        (void*)vrg_unit,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: step value(1.0), index 33 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,      /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_STEP_VALUE
        },
        sizeof(spv_unit),                  /* bValueLen */
        (void*)&spv_unit,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic User Description, index 34 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                          /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ciid_unit,
        GATT_PERM_READ                         /* wPermissions */
    },

    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 35  [name]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - name, index 36 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_NAME
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_READ)                   /* wPermissions */
    },

    /* characteristic descriptor: Format, index 37 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_tts_name),                     /* bValueLen */
        (void*)fmt_tts_name,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic User Description, index 38 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ciid_tts_name,
        GATT_PERM_READ                         /* wPermissions */
    },
    
     /* Characteristic descriptor: value range(1 -- 64), index 39 */
    {
        ATTRIB_FLAG_VOID,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_VALID_RANGE),
            HI_WORD(HOMEKIT_DESP_VALID_RANGE),
        },
        sizeof(vrg_tts_name),               /* bValueLen */
        (void*)vrg_tts_name,
        GATT_PERM_READ                             /* wPermissions */
    },
#endif /* THMST_SUPPORT_IOS9_R3 */
};

/**< @brief lock mechanism service databse size definition.  */
const static uint16_t tts_attr_tbl_size = sizeof(tts_attr_tbl);

/**
  * @brief save thermostat service data to Flash.
  * @param none.
  * @return operation result
  * @retval 0--success
  *         1--failed
  */
uint8_t tts_save_db(void)
{
    return fs_save_vendor_data((void*)&tts_db, sizeof(tts_db_t), THERMOSTAT_DB_FLASH_ADDR);
}
/**
  * @brief thermostat service factory reset.
  * @param none.
  * @note called when do homekit accessory factory reset.
  * @return operation result
  * @retval 0--success
  *         1--failed
  */
uint8_t tts_factory_reset(void)
{
    //invalid parameters
    tts_db.valid0 = 0xDD;
    tts_db.valid1 = 0x77;
    return fs_save_vendor_data((void*)&tts_db, sizeof(tts_db_t), THERMOSTAT_DB_FLASH_ADDR);
}

/**
  * @brief set thermostat service parameters.
  * @param[in] pointer to tts_db_t struct instance.
  * @return none
  */
void tts_set_db(tts_db_t* db)
{
    memcpy(&tts_db, db, sizeof(tts_db_t));
    tts_save_db();
}

/**
  * @brief set thermostat service parameters.
  * @param[in] pointer to tts_db_t struct instance.
  * @return none
  */
void tts_get_db(tts_db_t* db)
{
    memcpy(db, &tts_db, sizeof(tts_db_t));
} 

/**
  * @brief get service id of thermostat service.
  * @param none.
  * @return service id of thermostat service .
  */
uint8_t tts_get_srv_id(void)
{
    return tts_srv_id;
}

/**
  * @brief thermostat service atribute read callback function.
  * @param[in] service_id -- thermostat service id.
  * @param[in] attr_idx   -- thermostat attribute index.
  * @param[in] offset     -- attribute value read offset.
  * @param[out] len       -- attribute read value length.
  * @param[out] ppval     -- pointer of attribut value read buffer.    
  * @return attribute read result.
  */
TProfileResult  tts_attr_read_cb(uint8_t service_id , uint16_t attr_idx, uint16_t offset, uint16_t* len , uint8_t **ppval )
{
    TProfileResult  wCause  = ProfileResult_Success;
    
    uint16_t c_len = 0;
    
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "tts_attr_read_cb:%d", attr_idx, 1);
    
    switch(attr_idx)
    {
        case GATT_SVC_THMST_SRV_INST_INDEX:
             hmt_session_encrypt((uint8_t*)siid_tts, strlen(siid_tts), tts_buff, &c_len);
        break;
        
        case GATT_SVC_THMST_CUR_ST_INDEX:
            hmt_session_encrypt(&tts_db.cur_st, sizeof(uint8_t), tts_buff, &c_len);
        break;

        case GATT_SVC_THMST_TAR_ST_INDEX:
            hmt_session_encrypt(&tts_db.tar_st, sizeof(uint8_t), tts_buff, &c_len);
        break;

        case GATT_SVC_THMST_CUR_TMP_INDEX:
            hmt_session_encrypt((uint8_t*)&tts_db.cur_tmp, sizeof(float), tts_buff, &c_len);
        break;

        case GATT_SVC_THMST_TAR_TMP_INDEX:
            hmt_session_encrypt((uint8_t*)&tts_db.tar_tmp, sizeof(float), tts_buff, &c_len);
        break;

        case GATT_SVC_THMST_TMP_UNITS_INDEX:
            hmt_session_encrypt(&tts_db.units, sizeof(uint8_t), tts_buff, &c_len);
        break;

        case GATT_SVC_THMST_NAME_INDEX:
            hmt_session_encrypt(tts_name, strlen(tts_name), tts_buff, &c_len); 
        break;
        
        default:
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "-->tts_attr_read_cb: invalid attr index: %d", 1, attr_idx);
            wCause = ProfileResult_AttrNotFound;
        break;
    }
    
    if(wCause == ProfileResult_Success)
    {
        *ppval = tts_buff;
        *len = c_len;
    }
    
    return wCause;
}

/**
  * @brief thermostat service atribute write callback function.
  * @param[in] service_id -- thermostat service id.
  * @param[in] attr_idx   -- thermostat attribute index.
  * @param[in] wlen       -- length of write value.
  * @param[out] pval      -- value to be written.
  * @param[out] pwr_ind_proc  -- pointer of a function to handle control point write.    
  * @return write result.
  */
TProfileResult tts_attr_write_cb(uint8_t service_id, uint16_t attr_idx,
                              uint16_t wlen, uint8_t * pval , TGATTDWriteIndPostProc * pwr_ind_proc)
{
    TProfileResult  wCause  = ProfileResult_Success;
    
    uint16_t plen = 0;
    
    if(!hmt_session_decrypt(pval, wlen, tts_buff, &plen))
    {
        //decrypt fail, junk data, disconnect immediately
        session_setEncryption(0);
        peripheral_Disconnect();
        return wCause;
    }
    
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "-->tts_attr_write_cb: decrypted length:%d", 1, plen);

    //target state
    if(attr_idx == GATT_SVC_THMST_TAR_ST_INDEX)
    {
        tts_db.tar_st = tts_buff[0];
    }
    //target temperature
    else if(attr_idx == GATT_SVC_THMST_TAR_TMP_INDEX)
    {
        memcpy((uint8_t*)&tts_db.tar_tmp, tts_buff, sizeof(float));
    }
    //units
    else if(attr_idx == GATT_SVC_THMST_TMP_UNITS_INDEX)
    {
        tts_db.units = tts_buff[0];
    }
    else
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "-->tts_attr_write_cb: invalid attr index: %d", 1, attr_idx);
    }

    //save to flash
    tts_save_db();
  
  return wCause;
}

/**
  * @brief thermostat service cccd bits update callback function.
  * @param[in] service_id -- thermostat service id.
  * @param[in] attr_idx   -- thermostat attribute index.
  * @param[in] wccc_bits  -- ccc bits update.
  * @return none.
  */
void tts_cccd_update(uint8_t service_id, uint16_t attr_idx, uint16_t wccc_bits)
{   
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "tts_cccd_update:attribute index: %d", attr_idx, 1);
    
    if(attr_idx == (GATT_SVC_THMST_CUR_ST_INDEX + 1))
    {
        ccc_cst = wccc_bits;
    }
    else if(attr_idx == (GATT_SVC_THMST_TAR_ST_INDEX + 1))
    {
        ccc_tst = wccc_bits;
    }
    else if(attr_idx == (GATT_SVC_THMST_CUR_TMP_INDEX + 1))
    {
        ccc_ctmp = wccc_bits;
    }
    else if(attr_idx == (GATT_SVC_THMST_TAR_TMP_INDEX + 1))
    {
        ccc_ttmp = wccc_bits;
    }
    else if(attr_idx == (GATT_SVC_THMST_TMP_UNITS_INDEX + 1))
    {
        ccc_unit = wccc_bits;
    }
    else
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "-->tts_cccd_update: invalid attr index: %d", 1, attr_idx);
    }
    
    return;
}

/**
  * @brief thermostat service status update callback function.
  * @param[in] service_id -- thermostat service id.
  * @param[in] attr_idx   -- thermostat attribute index.
  * @note usually used when send indication done and have received confirmation.
  * @return none.
  */
void tts_update_status(uint8_t service_id, uint16_t attr_idx)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "themst_update_status", 0);
    
    tts_wait_ind_conf = 0;
    
    return;
}

/**
  * @brief send indication.
  * @param[in] attr_idx   -- thermostat service attribute index.
  * @param[in] data       -- indication data.
  * @param[in] len        -- indication data length.
  * @return none.
  */
bool tts_send_indication(uint16_t attr_idx, uint8_t* data, uint16_t len)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "tts_send_indication: service_id: %d, attr_idx:%d, data:0x%x, len:%d",\
        4, tts_srv_id, attr_idx, data, len);

    tts_wait_ind_conf = 1;
    uint8_t ind_flag = 0;

    if(attr_idx == GATT_SVC_THMST_CUR_ST_INDEX)
    {
        if(ccc_cst == 0x02)
        {
            ind_flag = 1;           
        }       
    }
    else if(attr_idx == GATT_SVC_THMST_TAR_ST_INDEX)
    {
        if(ccc_tst == 0x02)
        {
            ind_flag = 1;           
        }       
    }
    else if(attr_idx == GATT_SVC_THMST_CUR_TMP_INDEX)
    {
        if(ccc_ctmp == 0x02)
        {
            ind_flag = 1;            
        }       
    }
    else if(attr_idx == GATT_SVC_THMST_TAR_TMP_INDEX)
    {
        if(ccc_ttmp == 0x02)
        {
            ind_flag = 1;           
        }       
    }
    else if(attr_idx == GATT_SVC_THMST_TMP_UNITS_INDEX)
    {
        if(ccc_unit == 0x02)
        {
            ind_flag = 1;               
        }       
    }
    else
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "-->tts_send_indication: invalid attr index: %d", 1, attr_idx);
    }
    
    if(ind_flag)
    {
        return ProfileAPI_SendData(tts_srv_id, attr_idx, data, len);
    }
    else
    {
        return false;
    }
}

/**
 * @brief thermostat service callbacks.
*/
static const gattServiceCBs_t tts_cbs =
{
    tts_attr_read_cb,       // Read callback function pointer
    tts_attr_write_cb,      // Write callback function pointer
    tts_cccd_update,        // CCCD update callback function pointer
    tts_update_status       // confirmation callback function pointer
};

/**
  * @brief thermostat service initialization.
  * @param none.
  * @return initialization result.
  * retval  0--success.
  *         1--failde
  */
uint8_t tts_init(void)
{   
    //1. add thermostat service
    if (FALSE == ProfileAPI_AddService(&tts_srv_id,
                                       (uint8_t*)tts_attr_tbl,
                                       tts_attr_tbl_size,
                                       tts_cbs))
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "tts_AddService: service_id %d", 1, tts_srv_id);
        tts_srv_id = 0xff;
        return 1;  //add service fail
    }
    
    //2. load parameters of thermostat in Flash
    fs_load_vendor_data((void*)&tts_db, sizeof(tts_db_t), THERMOSTAT_DB_FLASH_ADDR);
    
    if(tts_db.valid0 != 0xEE || tts_db.valid1 != 0xBB)
    {
        //default parameters
        tts_db.cur_tmp = 25.5;
        tts_db.cur_st  = CUR_HEAT_COOL_ST_HEAT_ON;
        tts_db.tar_st  = CUR_HEAT_COOL_ST_HEAT_ON;
        tts_db.tar_tmp = 25.5;
        tts_db.units   = TMP_UNIT_CELSIUS;
        tts_db.valid0  = 0xEE;
        tts_db.valid1  = 0xBB;
        //save in flash
        tts_save_db();
    }
    
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "-->tts_init: cur_st:%d, cur_tmp:%d/10, tar_st:%d, tar_tmp:%d/10, uints:%d",\
                5, tts_db.cur_st, (uint32_t)(tts_db.cur_tmp * 10), tts_db.tar_st, (uint32_t)(tts_db.tar_tmp * 10), tts_db.units);
    
    //3.init thermostat hardware

    return 0;
}
