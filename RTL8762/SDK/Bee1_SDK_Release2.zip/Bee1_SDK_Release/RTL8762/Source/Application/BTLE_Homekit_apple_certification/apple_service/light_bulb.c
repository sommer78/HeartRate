/**
*********************************************************************************************************
*               Copyright(c) 2014, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     light_bulb.c
* @brief    Homekit light bulb service.
* @details  None.
* @author   tifnan_ge
* @date     2015-09-22
* @version  v0.1
*********************************************************************************************************
*/
#include "rtl_types.h"
#include "profileApi.h"
#include "light_bulb.h"
#include "trace.h"
#include "string.h"
#include "rtl876x_flash_storage.h"
#include "hmt_api.h"
#include "hw_ctrl.h"

//adddress of light bulb service parameters in Flash
#define LIGHT_BULB_DB_FLASH_ADDR            1164

/**<  service instant id & characteristic id */
char siid_lbs[5] = "15";       //service instant id
uint16_t ciid_lbs_siid = 16;
uint16_t ciid_on = 17;
uint16_t ciid_bri = 18;
uint16_t ciid_lbs_name = 19;

/**<  service instant id & characteristic id */
lbs_db_t lbs_db;
char lbs_name[20] = "RTK_light_bulb";
uint8_t lbs_srv_id = 0;  //light bulb service id

//buffer for encrypt and decrypt
uint8_t lbs_buff[15 + 16];

//ccc bits
uint16_t ccc_on = 0x00;
uint16_t ccc_bri = 0x00;
uint8_t lbs_wait_ind_conf = 0;

/*****************  characteristic format start ******************************/
uint8_t fmt_lbs_siid[7] = 
{
    HOMEKIT_FORMAT_STRING,
    0,                                         /* 8bit exponent */
    LO_WORD(HOMEKIT_UNIT_UNITLESS),
    HI_WORD(HOMEKIT_UNIT_UNITLESS),
    1,                                        /* 8bit namespace, Bluetooth SIG Assigned Numbers */
    0,                                        /* 16bit Description */
    0    
};

uint8_t fmt_on[7] = 
{
    HOMEKIT_FORMAT_BOOL,
    0,                                         /* 8bit exponent */
    LO_WORD(HOMEKIT_UNIT_UNITLESS),
    HI_WORD(HOMEKIT_UNIT_UNITLESS),
    1,                                        /* 8bit namespace, Bluetooth SIG Assigned Numbers */
    0,                                        /* 16bit Description */
    0    
};

uint8_t fmt_bri[7] = 
{
    HOMEKIT_FORMAT_INT,
    0,                                         /* 8bit exponent */
    LO_WORD(HOMEKIT_UNIT_PERCENT),
    HI_WORD(HOMEKIT_UNIT_PERCENT),
    1,                                        /* 8bit namespace, Bluetooth SIG Assigned Numbers */
    0,                                        /* 16bit Description */
    0    
};

uint8_t fmt_lbs_name[7] = 
{
    HOMEKIT_FORMAT_STRING,
    0,                                         /* 8bit exponent */
    LO_WORD(HOMEKIT_UNIT_UNITLESS),
    HI_WORD(HOMEKIT_UNIT_UNITLESS),
    1,                                        /* 8bit namespace, Bluetooth SIG Assigned Numbers */
    0,                                        /* 16bit Description */
    0    
};

/*****************  valid range start ******************************/
uint32_t vrg_bri[2] = 
{
    0,     //Lower inclusive value
    100,   //Upper inclusive value
};

uint16_t vrg_lbs_name[2] = 
{
    1,     //Lower inclusive value
    64,   //Upper inclusive value
};
/*****************  valid range end ******************************/

/*****************  step value start ******************************/
uint32_t  spv_bri = 1;
/*****************  step value end ******************************/

/**< @brief  profile/service definition.  */
static const TAttribAppl lbs_attr_tbl[] =
{
#if LTBS_SUPPORT_IOS9_R3
    /*----------------- Light Bulb Service -------------------*/
    /* <<Primary Service>>, index 0*/
    {
        (ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_LE),   /* wFlags     */
        {                                                /* bTypeValue */
            LO_WORD(GATT_UUID_PRIMARY_SERVICE),
            HI_WORD(GATT_UUID_PRIMARY_SERVICE),
            LO_WORD(HOMEKIT_SRV_UUID16_LIGHT_BULB),    /* service UUID */
            HI_WORD(HOMEKIT_SRV_UUID16_LIGHT_BULB)
        },
        UUID_16BIT_SIZE,                            /* bValueLen     */
        NULL,                                       /* pValueContext */
        GATT_PERM_READ                              /* wPermissions  */
    },

    /* <<Characteristic>>, ... index1 */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },
 
    /* characteristic - Service Instance IDs, index2*/
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_SRV_INT_ID
        },
        0,                                          /* "1" */
        NULL,                                       
        GATT_PERM_READ                              /* wPermissions */
    },
    
    /* Characteristic instant id index3 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID                                      /* "2" */
        },
        2,                                           /* bValueLen */
        (void*)&ciid_lbs_siid,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* characteristic descriptor: Format, index4 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_lbs_siid),                     /* bValueLen */
        (void*)fmt_lbs_siid,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 5  [on/off]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_INDICATE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - on/off, index6*/
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_ON
        },
        0,                                          /* "1" */
        NULL,             //15
        (GATT_PERM_WRITE | GATT_PERM_READ | GATT_PERM_NOTIF_IND)     /* wPermissions */
    },
    
    /* client characteristic configuration, index 7 */
    {
        ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_CCCD_APPL,                 /* wFlags */
        {                                         /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            HI_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            /* NOTE: this value has an instantiation for each client, a write to */
            /* this attribute does not modify this default value:                */
            LO_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT), /* client char. config. bit field */
            HI_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT)
        },
        2,                                          /* bValueLen */
        NULL,
        (GATT_PERM_READ | GATT_PERM_WRITE)          /* wPermissions */
    },

    /* characteristic descriptor: Format, index8 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_on),                     /* bValueLen */
        (void*)fmt_on,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic User Description, index 9 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                          /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                           /* bValueLen */
        (void*)&ciid_on,
        GATT_PERM_READ                         /* wPermissions */
    },

    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 10   [brightness]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_INDICATE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - brightness, index11 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_BRIGHT
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_WRITE | GATT_PERM_READ | GATT_PERM_NOTIF_IND)     /* wPermissions */
    },
    
    /* client characteristic configuration, index 12 */
    {
        ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_CCCD_APPL,                 /* wFlags */
        {                                         /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            HI_WORD(HOMEKIT_DESP_CLIENT_CHAR_CONFIG),
            /* NOTE: this value has an instantiation for each client, a write to */
            /* this attribute does not modify this default value:                */
            LO_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT), /* client char. config. bit field */
            HI_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT)
        },
        2,                                          /* bValueLen */
        NULL,
        (GATT_PERM_READ | GATT_PERM_WRITE)          /* wPermissions */
    },

    /* characteristic descriptor: Format, index 13 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_bri),                     /* bValueLen */
        (void*)fmt_bri,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: value range(0 -- 100), index 14 */
    {
        ATTRIB_FLAG_VOID,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_VALID_RANGE),
            HI_WORD(HOMEKIT_DESP_VALID_RANGE),
        },
        sizeof(vrg_bri),               /* bValueLen */
        (void*)vrg_bri,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: step value(1), index 15 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,      /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_STEP_VALUE
        },
        sizeof(spv_bri),                                           /* bValueLen */
        (void*)&spv_bri,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic User Description, index 16 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ciid_bri,
        GATT_PERM_READ                         /* wPermissions */
    },

    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 17   [name]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - name, index 18 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_NAME
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_READ)                   /* wPermissions */
    },

    /* characteristic descriptor: Format, index 19 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_lbs_name),                     /* bValueLen */
        (void*)fmt_lbs_name,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic User Description, index 20 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ciid_lbs_name,
        GATT_PERM_READ                         /* wPermissions */
    },
    
    /* Characteristic descriptor: value range(1-- 64), index 21 */
    {
        ATTRIB_FLAG_VOID,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_VALID_RANGE),
            HI_WORD(HOMEKIT_DESP_VALID_RANGE),
        },
        sizeof(vrg_lbs_name),               /* bValueLen */
        (void*)vrg_lbs_name,
        GATT_PERM_READ                             /* wPermissions */
    },
#else    /* LTBS_SUPPORT_IOS9_R3 */
    /*----------------- Light Bulb Service -------------------*/
    /* <<Primary Service>>, index 0*/
    {
        (ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_LE),   /* wFlags     */
        {                                                /* bTypeValue */
            LO_WORD(GATT_UUID_PRIMARY_SERVICE),
            HI_WORD(GATT_UUID_PRIMARY_SERVICE),
            LO_WORD(HOMEKIT_SRV_UUID16_LIGHT_BULB),    /* service UUID */
            HI_WORD(HOMEKIT_SRV_UUID16_LIGHT_BULB)
        },
        UUID_16BIT_SIZE,                            /* bValueLen     */
        NULL,                                       /* pValueContext */
        GATT_PERM_READ                              /* wPermissions  */
    },

    /* <<Characteristic>>, ... index1 */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },
 
    /* characteristic - Service Instance IDs, index2*/
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_SRV_INT_ID
        },
        0,                                          /* "1" */
        NULL,                                       
        GATT_PERM_READ                              /* wPermissions */
    },
    
    /* Characteristic instant id index3 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID                                      /* "2" */
        },
        2,                                           /* bValueLen */
        (void*)&ciid_lbs_siid,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* characteristic descriptor: Format, index4 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_lbs_siid),                     /* bValueLen */
        (void*)fmt_lbs_siid,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 5   [on/off]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - on/off, index6 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_ON
        },
        0,                                          /* "1" */
        NULL,                                      
        (GATT_PERM_WRITE | GATT_PERM_READ)     /* wPermissions */
    },
    
    /* characteristic descriptor: Format, index7 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_on),                     /* bValueLen */
        (void*)fmt_on,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic Description: Characteristic instance id, index 8 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                          /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                           /* bValueLen */
        (void*)&ciid_on,
        GATT_PERM_READ                         /* wPermissions */
    },

    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 9   [brightness]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE)     /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - brightness, index10 */
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_BRIGHT
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_WRITE | GATT_PERM_READ)     /* wPermissions */
    },
    
    /* characteristic descriptor: Format, index 11 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_bri),                     /* bValueLen */
        (void*)fmt_bri,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: value range(0 -- 100), index 12 */
    {
        ATTRIB_FLAG_VOID,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_VALID_RANGE),
            HI_WORD(HOMEKIT_DESP_VALID_RANGE),
        },
        sizeof(vrg_bri),               /* bValueLen */
        (void*)vrg_bri,
        GATT_PERM_READ                             /* wPermissions */
    },

    /* Characteristic descriptor: step value(1), index 13 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,      /* wFlags */
        {                                             /* bTypeValue */
            HOMEKIT_DESP_STEP_VALUE
        },
        sizeof(spv_bri),                                           /* bValueLen */
        (void*)&spv_bri,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic User Description, index 14 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ciid_bri,
        GATT_PERM_READ                         /* wPermissions */
    },

    /* --------------->>>>>>>>>>>>>>>>>>> characteristic, .... index 15   [name]*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {                                           /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            (GATT_CHAR_PROP_READ)                    /* characteristic properties */
                                                    /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* characteristic - name, index 16*/
    {
        ATTRIB_FLAG_VALUE_APPL | ATTRIB_FLAG_UUID_128BIT,                     /* wFlags */
        {                                                                   /* bTypeValue */
            HOMEKIT_CHAR_UUID128_NAME
        },
        0,                                          /* "1" */
        NULL,
        (GATT_PERM_READ)                   /* wPermissions */
    },

    /* characteristic descriptor: Format, index 17 */
    {
        ATTRIB_FLAG_VOID,                             /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT),
            HI_WORD(HOMEKIT_DESP_CHAR_PRENT_FORMAT)
              
        },
        sizeof(fmt_lbs_name),                     /* bValueLen */
        (void*)fmt_lbs_name,
        GATT_PERM_READ                             /* wPermissions */
    },
    
    /* Characteristic User Description, index 18 */
    {
        ATTRIB_FLAG_VOID | ATTRIB_FLAG_UUID_128BIT,                           /* wFlags */
        {                                           /* bTypeValue */
            HOMEKIT_DESP_CHAR_INST_ID
        },
        2,                                     /* bValueLen */
        (void*)&ciid_lbs_name,
        GATT_PERM_READ                         /* wPermissions */
    },
    
     /* Characteristic descriptor: value range(1 -- 64), index 19 */
    {
        ATTRIB_FLAG_VOID,                           /* wFlags */
        {                                             /* bTypeValue */
            LO_WORD(HOMEKIT_DESP_VALID_RANGE),
            HI_WORD(HOMEKIT_DESP_VALID_RANGE),
        },
        sizeof(vrg_lbs_name),               /* bValueLen */
        (void*)vrg_lbs_name,
        GATT_PERM_READ                             /* wPermissions */
    },
#endif   /* LTBS_SUPPORT_IOS9_R3 */
};

/**< @brief  Accessory service size definition.  */
const static uint16_t lbs_attr_tbl_size = sizeof(lbs_attr_tbl);

/**
  * @brief save light bulb service data to Flash.
  * @param none.
  * @return operation result
  * @retval 0--success
  *         1--failed
  */
uint8_t lbs_save_db(void)
{
    return fs_save_vendor_data((void*)&lbs_db, sizeof(lbs_db_t), LIGHT_BULB_DB_FLASH_ADDR);
}
/**
  * @brief light bulb service factory reset.
  * @param none.
  * @note called when do homekit accessory factory reset.
  * @return operation result
  * @retval 0--success
  *         1--failed
  */
uint8_t lbs_factory_reset(void)
{
    //invalid parameters
    lbs_db.valid0 = 0xDD;
    lbs_db.valid1 = 0x77;
    return fs_save_vendor_data((void*)&lbs_db, sizeof(lbs_db_t), LIGHT_BULB_DB_FLASH_ADDR);
}

/**
  * @brief set light bulb service parameters.
  * @param[in] pointer to lbs_db_t struct instance.
  * @return none
  */
void lbs_set_db(lbs_db_t* db)
{
    memcpy(&lbs_db, db, sizeof(lbs_db_t));
    lbs_save_db();
}

/**
  * @brief set light bulb service parameters.
  * @param[in] pointer to lbs_db_t struct instance.
  * @return none
  */
void lbs_get_db(lbs_db_t* db)
{
    memcpy(db, &lbs_db, sizeof(lbs_db_t));
} 

/**
  * @brief get service id of light bulb service.
  * @param none.
  * @return service id of light bulb service .
  */
uint8_t lbs_get_srv_id(void)
{
    return lbs_srv_id;
}

/**
  * @brief light bulb service atribute read callback function.
  * @param[in] service_id -- light bulb service id.
  * @param[in] attr_idx   -- light bulb attribute index.
  * @param[in] offset     -- attribute value read offset.
  * @param[out] len       -- attribute read value length.
  * @param[out] ppval     -- pointer of attribut value read buffer.    
  * @return attribute read result.
  */
TProfileResult lbs_attr_read_cb(uint8_t service_id , uint16_t attr_idx, uint16_t offset, uint16_t* len , uint8_t **ppval)
{
    TProfileResult  wCause  = ProfileResult_Success;
    
    uint16_t c_len = 0;
    
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "lbs_attr_read_cb: attr_idx: %d, offset: %d", 2, attr_idx, offset);
    
    switch(attr_idx)
    {
        case GATT_SVC_LTBS_SRV_INST_INDEX:
             hmt_session_encrypt((uint8_t*)siid_lbs, strlen(siid_lbs), lbs_buff, &c_len);
        break;
        
        case GATT_SVC_LTBS_ON_INDEX:
             hmt_session_encrypt(&lbs_db.on_off, 1, lbs_buff, &c_len);
        break;
        
        case GATT_SVC_LTBS_BRIGHTNESS_INDEX:
            hmt_session_encrypt((uint8_t*)&lbs_db.brightness, sizeof(uint32_t), lbs_buff, &c_len);
        break;

        case GATT_SVC_LTBS_NAME_INDEX:
            hmt_session_encrypt((uint8_t*)lbs_name, strlen(lbs_name), lbs_buff, &c_len);
        break;
        
        default:
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "-->lbs_attr_read_cb: invalid attr index: %d", 1, attr_idx);
            wCause = ProfileResult_AttrNotFound;
        break;
    }
    
    if(wCause == ProfileResult_Success)
    {
        *ppval = lbs_buff;
        *len = c_len;
    }
    
    return wCause;
}

/**
  * @brief light bulb service atribute write callback function.
  * @param[in] service_id -- light bulb service id.
  * @param[in] attr_idx   -- light bulb attribute index.
  * @param[in] wlen       -- length of write value.
  * @param[out] pval      -- value to be written.
  * @param[out] pwr_ind_proc  -- pointer of a function to handle control point write.    
  * @return write result.
  */
TProfileResult lbs_attr_write_cb(uint8_t service_id, uint16_t attr_idx,
                              uint16_t wlen, uint8_t * pval , TGATTDWriteIndPostProc * pwr_ind_proc)
{
    TProfileResult  wCause  = ProfileResult_Success;
    
    uint16_t plen = 0;
    ltb_hw_ctrl_t hw_ctrl;
    
    if(!hmt_session_decrypt(pval, wlen, lbs_buff, &plen))
    {
        //decrypt fail, junk data, disconnect immediately
        session_setEncryption(0);
        peripheral_Disconnect();
        return wCause;
    }
    
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "-->lbs_attr_write_cb: attr_idx:%d, wlen:%d", 2, attr_idx, wlen);

    //user set on/off
    if(attr_idx == GATT_SVC_LTBS_ON_INDEX)
    {
        //turn on
        if(lbs_buff[0] == 0x01)
        {
            lbs_db.on_off = 1; 
        }
        
        //turn off
        if(lbs_buff[0] == 0x00)
        {
            lbs_db.on_off = 0;
        }
    }
    else if(attr_idx == GATT_SVC_LTBS_BRIGHTNESS_INDEX)
    { 
        if(plen == sizeof(uint32_t))
        {
            memcpy((uint8_t*)&lbs_db.brightness, lbs_buff, 4);
        }
    }
    else
    {
         DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "-->lbs_attr_write_cb: invalid char index:%d", 1, attr_idx);
         wCause = ProfileResult_AttrNotFound;
    }
    
    //save to flash
    lbs_save_db();
    //light bulb hardware control
    hw_ctrl.on_off = lbs_db.on_off;
    hw_ctrl.brightness = lbs_db.brightness;
    light_hw_ctrl(&hw_ctrl);
    
  return wCause;
}

/**
  * @brief light bulb service cccd bits update callback function.
  * @param[in] service_id -- light bulb service id.
  * @param[in] attr_idx   -- light bulb attribute index.
  * @param[in] wccc_bits  -- ccc bits update.
  * @return none.
  */
void lbs_cccd_update_cb(uint8_t service_id, uint16_t attr_idx, uint16_t wccc_bits)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "lbs_cccd_update_cb:attribute index:%d, ccc_bits:%d", 2, attr_idx, wccc_bits);
    
    if(attr_idx == (GATT_SVC_LTBS_ON_INDEX + 1))
    {
        ccc_on= wccc_bits;
    }
    else if(attr_idx == (GATT_SVC_LTBS_BRIGHTNESS_INDEX + 1))
    {
        ccc_bri= wccc_bits;
    }
    else
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "-->lbs_cccd_update_cb: invalid attr index: %d", 1, attr_idx);
    }
    
    return;
}

/**
  * @brief light bulb service status update callback function.
  * @param[in] service_id -- light bulb service id.
  * @param[in] attr_idx   -- light bulb attribute index.
  * @note usually used when send indication done and have received confirmation.
  * @return none.
  */
void lbs_update_st_cb(uint8_t service_id, uint16_t attr_idx)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "lbs_update_status: attr_idx:%d", 1, attr_idx);
    
    lbs_wait_ind_conf = 0;
    
    return;
}

/**
  * @brief send indication.
  * @param[in] serviceid -- light bulb service id.
  * @param[in] attr_idx   -- light bulb attribute index.
  * @param[in] data       -- indication data.
  * @param[in] len        -- indication data length.
  * @return none.
  */
bool lbs_send_indication(uint16_t attr_idx, uint8_t* data, uint16_t len)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "lbs_send_indication: service_id: %d, attr_idx:%d, data:0x%x, len:%d",\
        4, lbs_srv_id, attr_idx, data, len);

    lbs_wait_ind_conf = 1;

    if(attr_idx == GATT_SVC_LTBS_ON_INDEX)
    {
        if(ccc_on == 0x02)
        {
            return ProfileAPI_SendData(lbs_srv_id, attr_idx, data, len);
        }
    }
    else if(attr_idx == GATT_SVC_LTBS_BRIGHTNESS_INDEX)
    {
        if(ccc_bri== 0x02)
        {
            return ProfileAPI_SendData(lbs_srv_id, attr_idx, data, len);
        }
    }
    else
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "-->lbs_send_indication: invalid attr index: %d", 1, attr_idx);
        return false;
    }
    
    return true;
}

/**
 * @brief light bulb service callbacks.
*/
static const gattServiceCBs_t lbs_cbs =
{
    lbs_attr_read_cb,       // Read callback function pointer
    lbs_attr_write_cb,      // Write callback function pointer
    lbs_cccd_update_cb,     // CCCD update callback function pointer
    lbs_update_st_cb        // confirmation callback function pointer
};

/**
  * @brief ligth bulb service initialization.
  * @param none.
  * @return initialization result.
  * retval  0--success.
  *         1--failde
  */
uint8_t lbs_init(void)
{   
    ltb_hw_ctrl_t hw_ctrl;

    //1. add light bulb service
    if (FALSE == ProfileAPI_AddService(&lbs_srv_id,
                                       (uint8_t*)lbs_attr_tbl,
                                       lbs_attr_tbl_size,
                                       lbs_cbs))
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "Ltbs_AddService: service_id %d", 1, lbs_srv_id);
        lbs_srv_id = 0xff;
        return 1;  //add service fail
    }
    
    //2. load parameters of light bulb in Flash
    fs_load_vendor_data((void*)&lbs_db, sizeof(lbs_db_t), LIGHT_BULB_DB_FLASH_ADDR);
    
    if(lbs_db.valid0 != 0xEE || lbs_db.valid1 != 0xBB)
    {
        //default parameters
        lbs_db.on_off = 1;      //default on
        lbs_db.brightness = 50;
        lbs_db.valid0 = 0xEE;
        lbs_db.valid1 = 0xBB;
        //save in flash
        lbs_save_db();
    }
    
    DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "-->lbs_init: on_off: %d, brightness: %d",\
                2, lbs_db.on_off, lbs_db.brightness);
    
    //3.init light
    hw_ctrl.on_off = lbs_db.on_off;
    hw_ctrl.brightness = lbs_db.brightness;
    light_hw_init(&hw_ctrl);
    
    return 0;
}
