enum { __FILE_NUM__ = 0 };

/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     test_mesh_parse_cmd.c
* @brief    Parse user command from lower Data UART data.
* @details  Parse user commands and execute right commands.
* @author
* @date     2015-03-19
* @version  v0.1
*********************************************************************************************************
*/
#include <string.h>
#include "test_hmt_uart.h"
#include "test_hmt_parse_cmd.h"
#include "section_config.h"

/* globals */
TestCmdIF  gTestCmdIF;

/** @brief  this external function for comparing string. */
extern int32_t _strcmp(const char *cs, const char *ct);

/**
 * @brief  Check, if a character is a white space.
 *
 * @param c         char data to check.
 * @return check result.
 * @retval 1  TRUE.
 * @retval 1  FALSE.
*/
static bool test_CmdIsWhiteSpace(char c)
{
    return (((c >= 9) && (c <= 13)) || (c == 32));
}

/**
 * @brief  Skip white spaces in buffer.
 *
 * @param buffer
 * @return pointer to skipped white spaces' new buffer.
*/
static char* Test_CmdSkipSpaces(char *buffer)
{
    char* p = buffer;

    while (test_CmdIsWhiteSpace(*p)) /* white space */
    {
        p++;
    }
    return p;
}

/**
 * @brief  Find end of a word.
 *
 * @param buffer
 * @return
*/
static char *Test_CmdFindEndOfWord(char *buffer)
{
    char *p = buffer;

    while (!test_CmdIsWhiteSpace(*p) && (*p != '\0'))
    {
        p++;
    }
    return p;
}

/**
 * @brief  Read ASCII string and convert to uint32_t.
 *
 * @param p
 * @return
*/
static uint32_t Test_CmdString2uint32_t(char *p)
{
    uint32_t result = 0;
    char     ch;
    bool     hex = false;

    /* check if value is dec */
    if (p[0] == 'x')
    {
        hex = true;
        p = &p[1];
    }
    else if ((p[0] == '0') && (p[1] == 'x'))
    {
        hex = true;
        p = &p[2];
    }

    for (;;)
    {
        ch = *( p++ ) | 0x20;               /* convert to lower case */

        if ( hex)                           /* dec value */
        {
            /* hex value */
            if ((ch >= 'a') && (ch <= 'f'))
            {
                ch -= ('a' - 10);
            }
            else if ((ch >= '0') && (ch <= '9'))
            {
                ch -= '0';
            }
            else
            {
                break;
            }
            result =  (result << 4);
            result += (ch & 0x0f);
        }
        else
        {
            if ( ch < '0' || ch > '9' )
                break;  /* end of string reached */
            result = 10 * result + ch - '0';
        }
    }
    return (result);
}

/**
 * @brief  Send result, display in UART Assitant.
 *
 * @param pTestCmdIF command parsed.
 * @param Result                command parse result.
 * @return none
*/
static void Test_CmdSendResult(TestCmdIF * pTestCmdIF, TestCmdParseResult Result)
{
    switch (Result)
    {
    case ResultError:
        testUserIFSendString(pTestCmdIF, "Error\n\r", NULL);
        break;
    case ResultCommandNotFound:
        testUserIFSendString(pTestCmdIF, "Command not found\n\r", NULL);
        break;
    case ResultWrongNumberOfParameters:
        testUserIFSendString(pTestCmdIF, "Wrong number of parameters\n\r", NULL);
        break;
    case ResultWrongParameter:
        testUserIFSendString(pTestCmdIF, "Wrong parameter\n\r", NULL);
        break;
    case ResultValueOutOfRange:
        testUserIFSendString(pTestCmdIF, "Value out of range\n\r", NULL);
        break;
    default:
        break;
    }
}

/**
 * @brief  flush buffer with echo characters.
 *
 * @param pTestCmdIF command parsed.
 * @return none
*/
static void Test_CmdFlushEchoChars( TestCmdIF * pTestCmdIF )
{
    if ( pTestCmdIF->iTxLength > 0 )
    {
        testUserIFSendChar(pTestCmdIF, 0);     /* flush buffer with echo data */
        pTestCmdIF->iTxLength   = 0;
        pTestCmdIF->pTxBuffer   = NULL;
    }
}

/**
 * @brief  execute cmd.
 *
 * @param pTestCmdIF command parsed.
 * @param pParseValue       command parse value.
 * @param pCmdTable         command table, include user self-definition command function.
 * @return command execute result.
*/
static TestCmdParseResult Test_CmdExecute( TestCmdIF * pTestCmdIF,
        TestCmdParseValue * pParseValue,
        const TestCmdTableEntry * pCmdTable )
{
    int32_t              i = 0;
    TestCmdParseResult  Result = ResultCommandNotFound;

    /* find command in table */
    while ((pCmdTable + i)->pCommand != NULL)
    {
        if ( _strcmp((const char *)(pCmdTable + i)->pCommand,
                     (const char *)pParseValue->pCommand) == 0 )
        {
            /* command found */

            /* check if user wants help */
            if (pParseValue->iParameterCount && *pParseValue->pParameter[0] == '?')
            {
                testUserIFSendString(pTestCmdIF, (pCmdTable + i)->pOption, NULL);
                Result = ResultOk;
            }
            else
            {
                /* execute command function */
                Result = (pCmdTable + i)->Func(pTestCmdIF, pParseValue);
            }
            /* exit while */
            break;
        }
        i++;
    };

    return ( Result );
}

/**
 * @brief  Parse a command line and return the found
 *       command and parameters in "pParseValue"
 *
 * @param pTestCmdIF command parsed.
 * @param pParseValue       command parse value.
 * @return command parse result.
*/
static TestCmdParseResult Test_CmdParse( TestCmdIF * pTestCmdIF,
        TestCmdParseValue * pParseValue )
{
    int32_t              i;
    TestCmdParseResult  Result;
    char            *p, *q;

    /* clear all results */
    Result = ResultOk;
    pParseValue->pCommand            = NULL;
    pParseValue->pRestOfCommandLine  = NULL;
    pParseValue->iParameterCount     = 0;
    for (i = 0 ; i < TEST_MAX_PARAMETERS; i++)
    {
        pParseValue->pParameter[i]     = NULL;
        pParseValue->dwParameter[i]    = 0;
    }

    /* Parse line */
    p = pTestCmdIF->cCommandLine;

    /*ignore leading spaces */
    p = Test_CmdSkipSpaces(p);
    if ( *p == '\0')                      /* empty command line ? */
    {
        Result = ResultEmptyCommandLine;
    }
    else
    {
        /* find end of word */
        q = Test_CmdFindEndOfWord( p);
        if (p == q)                        /* empty command line ? */
        {
            Result = ResultEmptyCommandLine;
        }
        else                                /* command found */
        {
            pParseValue->pCommand = p;
            *q = '\0';                        /* mark end of command */
            p = q + 1;

            /* parse parameters */
            if ( *p != '\0')                  /* end of line ? */
            {
                int32_t j;

                pParseValue->pRestOfCommandLine = p;

                j = 0;
                do
                {
                    uint32_t d;
                    /* ignore leading spaces */
                    p = Test_CmdSkipSpaces(p);
                    d = Test_CmdString2uint32_t(p);

                    pParseValue->pParameter[j]    = p;
                    pParseValue->dwParameter[j++] = d;

                    if ( j >= TEST_MAX_PARAMETERS)
                    {
                        break;
                    }

                    /* find next parameter */
                    p  = Test_CmdFindEndOfWord( p);
                    *p++ = '\0';                        /* mark end of parameter */
                }
                while (*p != '\0');
                pParseValue->iParameterCount = j;
            }
        }
    }

    return ( Result );
}

/**
 * @brief  clear command line buffer.
 *
 * @param pTestCmdIF command parsed.
 * @return none.
*/
static void Test_CmdClearCommand( TestCmdIF * pTestCmdIF )
{
    pTestCmdIF->iCommandLength = 0;
    memset( pTestCmdIF->cCommandLine, 0,
            sizeof(pTestCmdIF->cCommandLine) );
}

/**
 * @brief  print service id related string.
 *
 * @param none.
 * @return print service id related string.
*/
static char * Test_CmdServiceID( void )
{
    static char *pStr;
    pStr = "Test Homekit";
    return ( pStr );
}

/**
 * @brief  collect cmd characters.
 *
 * @param pTestCmdIF store parsed commands.
 * @param pData             data to be parsed.
 * @param iLength           length of data to be command parsed.
 * @param pCmdTable         command table to execute function.
 * @return command collect result.
 * @retval 1 TRUE.
 * @retval 0 FALSE.
*/
bool Test_CmdCollect( TestCmdIF * pTestCmdIF,
                             char * pData,
                             int32_t iLength,
                             const TestCmdTableEntry * pCmdTable )
{
    TestCmdParseValue ParseResult;
    char                 c;

    pTestCmdIF->iTxLength   = -iLength;       /* < 0: tx buffer must be allocated */
    pTestCmdIF->pTxBuffer   = NULL;

    /* discard rx data as long help text output is in progress */
    while (!pTestCmdIF->HelpTextInProgress && iLength--)
    {
        c = *pData++;
        if (c != 0x0)                       /* not ESC character received */
        {
            switch (c)                        /* Normal handling */
            {
            case '\n':
            case '\r':                      /* end of line */
                Test_CmdFlushEchoChars( pTestCmdIF );
                pTestCmdIF->SendPrompt = true;

                testUserIFSendString(pTestCmdIF, pTestCmdIF->cCrLf, NULL);
                if (pTestCmdIF->iCommandLength > 0)  /* at least one character in command line ? */
                {
                    TestCmdParseResult Result;

                    pTestCmdIF->cCommandLine[pTestCmdIF->iCommandLength] = '\0';
                    Result = Test_CmdParse(pTestCmdIF, &ParseResult);
                    if (Result == ResultOk)
                        Result = Test_CmdExecute(pTestCmdIF, &ParseResult, pCmdTable);

                    if (Result != ResultOk)
                        Test_CmdSendResult(pTestCmdIF, Result);
                }

                if (pTestCmdIF->SendPrompt)
                    testUserIFSendString(pTestCmdIF, pTestCmdIF->cPrompt, NULL);

                Test_CmdClearCommand( pTestCmdIF );

                /* maybe more than 1 cmd in pData: */
                pTestCmdIF->iTxLength   = -iLength;
                pTestCmdIF->pTxBuffer   = NULL;
                break;
            case '\b':                        /* backspace */
                if (pTestCmdIF->iCommandLength > 0)
                {
                    pTestCmdIF->iCommandLength--;
                    pTestCmdIF->cCommandLine[pTestCmdIF->iCommandLength] = '\0';
                }
                if ( pTestCmdIF->iTxLength < 0 )
                    pTestCmdIF->iTxLength -= 2;     /* OK only if BS is first char ... */
                testUserIFSendChar(pTestCmdIF, c);
                testUserIFSendChar(pTestCmdIF, ' ');
                testUserIFSendChar(pTestCmdIF, c);
                break;
            default:
                /* Put character in command buffer */
                if (pTestCmdIF->iCommandLength < TEST_MAX_COMMAND_LINE)
                {
                    testUserIFSendChar(pTestCmdIF, c);
                    pTestCmdIF->cCommandLine[pTestCmdIF->iCommandLength++] = c;
                }
                break;
            }
        }
    }

    Test_CmdFlushEchoChars( pTestCmdIF );

    return ( true );
}

/**
 * @brief   init. cmd set.
 *
 * @param pTestCmdIF store parsed commands.
 * @return none.
*/
void Test_CmdInit(void)
{
    TestCmdIF *pTestCmdIF = &gTestCmdIF;
    
    memset( pTestCmdIF, 0, sizeof(TestCmdIF) );
    pTestCmdIF->cCrLf[0]   = '\r';
    pTestCmdIF->cCrLf[1]   = '\n';
    pTestCmdIF->cPrompt[0] = '>';

    testCmdPrint( pTestCmdIF, ">> Command Parse Init (%s) <<\r\n%s",
                         Test_CmdServiceID(),
                         pTestCmdIF->cPrompt );
}

