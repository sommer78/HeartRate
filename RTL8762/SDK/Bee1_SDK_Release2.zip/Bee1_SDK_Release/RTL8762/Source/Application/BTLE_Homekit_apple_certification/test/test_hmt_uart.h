/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     test_mesh_uart.h
* @brief    Data uart operations for testing mesh network.
* @details  Data uart init and print data through data uart.
* @author
* @date     2015-03-19
* @version  v0.1
*********************************************************************************************************
*/
#ifndef _TEST_HMT_UART_H_
#define  _TEST_HMT_UART_H_

#ifdef  __cplusplus
extern "C" {
#endif      /* __cplusplus */

#include "rtl_types.h"

/****************************************************************************************************************
* macros that other .c files may use all defined here
****************************************************************************************************************/
/** @brief  Print data use Data UART. */
#define testCmdPrint(a, b...)             test_Print(b)
#define testUserIFSendString(a, b, c)     test_Print("%s", b)
#define testUserIFSendChar(a, b)          if (b != 0) test_Print("%c", b)

typedef struct _char_pkt_t
{
    char* data;
    int len;
}char_pkt_t;

/****************************************************************************************************************
* exported functions other .c files may use all defined here.
****************************************************************************************************************/
/* Print formated data use Data UART in test mesh application */
extern int32_t test_Print(IN  char *fmt, ...);
/* initiate Data UART in test mesh application */
extern void Test_UARTInit(void);

#ifdef  __cplusplus
}
#endif      /*  __cplusplus */

#endif   /* _TEST_HMT_UART_H_ */

