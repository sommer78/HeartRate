/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     hw_ctrl.h
* @brief    declaration of some hardware control func.
* @details  none.
* @author   tifnan
* @date     2015-09-24
* @par History: 2015-11-16 add _ltb_hw_ctrl_t struct, export more API.
* @version  v1.0                       
*********************************************************************************************************
*/

#ifndef _HW_CTRL_H_
#define _HW_CTRL_H_

#include <stdint.h>

#define ADV_CON_TIP_LED_PIN             P2_1
#define LIGHT_BULB_LED_PIN              P2_2
#define OTA_BUTTON_PIN                  P0_2
#define HOMEKIT_IDNTIFY_LED_PIN         P4_3
#define FACTORY_RESET_PIN               P3_1
#define LIGHT_MANU_OP_PIN               P3_2
#define THERMOSTAT_MANU_OP_PIN          P4_2

/* light bulb hardware control struct */
typedef struct _ltb_hw_ctrl_t
{
    uint32_t brightness;  //0-100
    uint8_t on_off;       //0--off, 1--on
}ltb_hw_ctrl_t;

//export function
void start_adv_tip(void);
void start_connected_tip(void);
void start_disconnect_tip(void);
void homekit_identify(void);
void light_hw_ctrl(ltb_hw_ctrl_t* hw_ctrl_par);
void light_hw_init(ltb_hw_ctrl_t* hw_ctrl_par);

#endif  /*_HW_CTRL_H_ */

