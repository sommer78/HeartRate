/**
************************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
************************************************************************************************************
* @file     thermostat.h
* @brief    Head file for homekit hermostat service.
* @details  Thermostat service data structs and external functions declaration.
* @author   tifnan_ge
* @date     2015-09-22
* @version  v0.1
*************************************************************************************************************
*/

#ifndef _LOCK_THERMOSTAT_H_
#define _LOCK_THERMOSTAT_H_

#ifdef  __cplusplus
extern "C" {
#endif      /* __cplusplus */
    
#include "stdint.h"
#include "stdbool.h"

#define THMST_SUPPORT_IOS9_R3          0
    
/****************************************************************************************************************
* macros that other .c files may use all defined here
****************************************************************************************************************/


/** @brief  Index defines for light bulb status Characteristic*/
#if THMST_SUPPORT_IOS9_R3
#define GATT_SVC_THMST_SRV_INST_INDEX               2 /**<  @brief  Index for service instant id chars's value      */
#define GATT_SVC_THMST_CUR_ST_INDEX                 6 /**<  @brief  Index for target heating cooling status chars's value      */
#define GATT_SVC_THMST_TAR_ST_INDEX                 13 /**<  @brief  Index for target heating cooling status chars's value      */
#define GATT_SVC_THMST_CUR_TMP_INDEX                20 /**<  @brief  Index for current temperature chars's value      */
#define GATT_SVC_THMST_TAR_TMP_INDEX                27 /**<  @brief  Index for target temperature chars's value      */
#define GATT_SVC_THMST_TMP_UNITS_INDEX              34 /**<  @brief  Index for temperature dispaly unit chars's value      */
#define GATT_SVC_THMST_NAME_INDEX                   41 /**<  @brief  Index for name unit chars's value      */
#else
#define GATT_SVC_THMST_SRV_INST_INDEX               2 /**<  @brief  Index for service instant id chars's value      */
#define GATT_SVC_THMST_CUR_ST_INDEX                 6 /**<  @brief  Index for target heating cooling status chars's value      */
#define GATT_SVC_THMST_TAR_ST_INDEX                 12 /**<  @brief  Index for target heating cooling status chars's value      */
#define GATT_SVC_THMST_CUR_TMP_INDEX                18 /**<  @brief  Index for current temperature chars's value      */
#define GATT_SVC_THMST_TAR_TMP_INDEX                24 /**<  @brief  Index for target temperature chars's value      */
#define GATT_SVC_THMST_TMP_UNITS_INDEX              30 /**<  @brief  Index for temperature dispaly unit chars's value      */
#define GATT_SVC_THMST_NAME_INDEX                   36 /**<  @brief  Index for name unit chars's value      */
#endif /* THMST_SUPPORT_IOS9_R3 */

typedef struct _tts_db_t
{
    float   cur_tmp;      
    float   tar_tmp;
    uint8_t cur_st;
    uint8_t tar_st;
    uint8_t units;
    uint8_t valid0;     //0xEE valid, 0xDD invalid
    uint8_t valid1;     //0xBB valid, 0x77 invalid
    uint8_t padding[3];     
}tts_db_t;

/****************************************************************************************************************
* exported globals.
****************************************************************************************************************/

/****************************************************************************************************************
* exported functions other .c files may use all defined here.
****************************************************************************************************************/
uint8_t thmst_init(void);
bool tts_send_indication(uint16_t attr_idx, uint8_t* data, uint16_t len);
uint8_t tts_save_db(void);
uint8_t tts_factory_reset(void);
void tts_set_db(tts_db_t* db);
void tts_get_db(tts_db_t* db);
uint8_t thmst_get_srv_id(void);


#ifdef  __cplusplus
}
#endif      /*  __cplusplus */

#endif  /* _LOCK_THERMOSTAT_H_ */
