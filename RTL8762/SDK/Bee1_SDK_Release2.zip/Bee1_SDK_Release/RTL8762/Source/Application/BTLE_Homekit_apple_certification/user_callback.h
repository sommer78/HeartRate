#ifndef _USER_CALLBACK_H_
#define _USER_CALLBACK_H_


#include "hmt_api.h"

uint8_t homekit_event_handle(uint8_t event, void* data, uint16_t len);

#endif  /* _USER_CALLBACK_H_ */
