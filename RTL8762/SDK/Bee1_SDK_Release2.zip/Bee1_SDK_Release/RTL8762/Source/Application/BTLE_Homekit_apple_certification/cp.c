/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     cp.c
* @brief    apple's authentication coprocessor driver.
* @details  none.
* @author   tifnan
* @date     2015-09-08
* @version  v0.1                       
*********************************************************************************************************
*/

#include "rtl876x_rcc.h"
#include "rtl876x_i2c.h"
#include "trace.h"
#include "rtl876x_pinmux.h"
#include "cp.h"

/************************************* cp static functtions ******************************************/

/**
  * @brief cp delay micro-second.
  * @param[in] us how many micro second.
  * @return none.
  * @retval void
  */
static void cp_delay_us(uint16_t us)
{
    uint16_t i = 0;
    uint16_t j = 0;
    
    for(i = 0; i < us; i++)
    {
        for(j = 0; j < 5; j++);
    }
    
    return;
}

/**
  * @brief cp write.
  * @param[in] start_addr start register address.
  * @param[in] data data to be written.
  * @param[in] length data length.
  * @return write result(always 0).
  */
static uint8_t cp_write(uint8_t start_addr, uint8_t* data, uint16_t length)
{
    uint8_t no_ack = 0;
    uint16_t i  =0;
    
    //write device address(W) & start register address
    do
    {
        no_ack = 0;
        I2C0->IC_DATA_CMD = start_addr;
        //wait tx fifo empty
        while(!I2C_GetFlagState(I2C0, I2C_FLAG_TFE));
        
        i = 200; //can not too short!!!!!
        while(1)
        { 
            no_ack = I2C_CheckEvent(I2C0, ABRT_7B_ADDR_NOACK);
             i--;
            if(no_ack == 1 || i == 0)
            {
                break;
            }
        }
        
        if(no_ack)
        {
            //clear ABRT_7B_ADDR_NOACK bit
            I2C_ClearINTPendingBit(I2C0, I2C_INT_TX_ABRT);
            //delay min 500us and retry
            cp_delay_us(500);
        }
        
    }while(no_ack);

    //write data
    if(length > 0 && data != NULL)
    {
        while(length > 1)
        {
            I2C0->IC_DATA_CMD = *data++;
            //wait tx fifo empty
            while(!I2C_GetFlagState(I2C0, I2C_FLAG_TFE));
            length--;
        }

        //stop
        I2C0->IC_DATA_CMD = ((*data++) | (1 << 9));
        while(!I2C_GetFlagState(I2C0, I2C_FLAG_TFE));
    }

    return 0;
}

/**
  * @brief cp signal read.
  * @param[in] reg_addr register to be read.
  * @return byte read.
  */
static uint8_t cp_signal_read(uint8_t reg_addr)
{
    uint8_t reg_val = 0x00;
    uint8_t no_ack = 0;
    uint16_t i;

    //write register address
    cp_write(reg_addr, NULL, 0);
    
    //start read
    do
    {
        no_ack = 0;
        I2C0->IC_DATA_CMD = (0x00) | (0x001 << 8) | (1 << 9);

        //wait tx fifo empty
        while(!I2C_GetFlagState(I2C0, I2C_FLAG_TFE));
        i = 200;
        while(1)
        {
            i--;
            no_ack = I2C_CheckEvent(I2C0, ABRT_7B_ADDR_NOACK);
            if(no_ack == 1 || i == 0)
            {
                break;
            }
        }
        
        if(no_ack)
        {
            //clear ABRT_7B_ADDR_NOACK bit
            I2C_ClearINTPendingBit(I2C0, I2C_INT_TX_ABRT);
            //delay min 500us and retry
            cp_delay_us(500);
        }
    }while(no_ack);
    
    //wait data ready
    while(!I2C_GetFlagState(I2C0, I2C_FLAG_RFNE));
    
    reg_val = I2C_ReceiveData(I2C0);
    
    return reg_val;
}

/**
  * @brief cp burst read.
  * @param[in] start_addr start read register address.
  * @param[out] pbuf read data buffer.
  * @param[in] length read length.
  * @return write result(always 0).
  */
static uint8_t cp_burst_read(uint8_t start_addr, uint8_t* pbuf, uint16_t length)
{
    uint8_t no_ack = 0;
    uint16_t i;
    
    //write start register address
    cp_write(start_addr, NULL, 0);

    //read command
    do
    {
        no_ack = 0;
        I2C0->IC_DATA_CMD = (0x00) | (0x01 << 8);
        //wait tx fifo empty
        while(!I2C_GetFlagState(I2C0, I2C_FLAG_TFE));
        i = 100;
        while(1)
        {
            no_ack = I2C_CheckEvent(I2C0, ABRT_7B_ADDR_NOACK);
            i--;
            if(no_ack == 1 || i == 0)
            {
                break;
            }
        }
        
        if(no_ack)
        {
            //clear ABRT_7B_ADDR_NOACK bit
            I2C_ClearINTPendingBit(I2C0, I2C_INT_TX_ABRT);
            //delay min 500us and retry
            cp_delay_us(500);
        }
    }while(no_ack);

    while(length > 1)
    {
        I2C0->IC_DATA_CMD = (0x00) | (1 << 8);
        //wait rx fifo data
        while(!I2C_GetFlagState(I2C0, I2C_FLAG_RFNE));
        *pbuf++ = (uint8_t)I2C0->IC_DATA_CMD;
        length--;
    }

    //stop and read last byte
    I2C0->IC_DATA_CMD = ((0x00) | (1 << 8) | (1 << 9));
    //wait rx fifo data
    while(!I2C_GetFlagState(I2C0, I2C_FLAG_RFNE));
    *pbuf++ = (uint8_t)I2C0->IC_DATA_CMD;
    
    return 0;
}

/************************************* cp export functtions ******************************************/

/**
  * @brief cp hardware init.
  * @param none.
  * @return none.
  * @retval void
  */
void cp_hw_init(void)
{
    I2C_InitTypeDef  I2C_InitStructure;
    
    Pad_Config(CP_SDA_PIN, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW); //i2c0 sda
    Pad_Config(CP_SCL_PIN, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW); //i2c0 scl
    Pinmux_Config(CP_SDA_PIN, I2C0_DAT);
    Pinmux_Config(CP_SCL_PIN, I2C0_CLK);
    
    I2C_DeInit(I2C0);
    RCC_PeriphClockCmd(APBPeriph_I2C0, APBPeriph_I2C0_CLOCK, ENABLE);
    
    /* I2C configuration */
    I2C_InitStructure.I2C_ClockSpeed = 400000;
    I2C_InitStructure.I2C_DeviveMode = I2C_DeviveMode_Master;
    I2C_InitStructure.I2C_AddressMode = I2C_AddressMode_7BIT;
    I2C_InitStructure.I2C_SlaveAddress = CP_DEVICE_ADDRESS;
    I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;

    /* I2C module Initialize */
    I2C_Init(I2C0, &I2C_InitStructure);
    /* I2C Peripheral Enable */
    I2C_Cmd(I2C0, ENABLE);
    I2C_SetSlaveAddress(I2C0, CP_DEVICE_ADDRESS);
    I2C_INTConfig(I2C0, I2C_INT_TX_ABRT, ENABLE);

    return;
}

/**
  * @brief read cp basic information.
  * @param[out] info cp device info buffer.
  * @return read result.
  */
uint8_t cp_read_cp_info(cp_info* info)
{
    return cp_burst_read(CP_REG_DEV_VER, (uint8_t*)info, 8);
}

/**
  * @brief read signature info.
  * @param[out] signature info buffer.
  * @note the first 2 bytes in signature buffer are signature data length.
  * @return read result.
  */
uint8_t cp_read_signature_info(uint8_t* sig_buf)
{
    return cp_burst_read(CP_SIG_LEN, sig_buf, 2 + 128);
}

/**
  * @brief write challenge info.
  * @param[in] cha_buf challenge info buffer.
  * @param[in] buf_len challenge info buffer length.
  * @note the first 2 bytes in challenge info buffer are challenge data length.
  * @return write result.
  */
uint8_t cp_write_cha_info(uint8_t* cha_buf, uint16_t buf_len)
{
    return cp_write(CP_REG_CHA_LEN, cha_buf, buf_len);
}

uint8_t cp_write_cha_len(uint16_t len)
{
    uint8_t len_buf[2];
    len_buf[0] = len >> 8;
    len_buf[1] = (uint8_t)len;
    return cp_write(CP_REG_CHA_LEN, len_buf, 2);
}

uint8_t cp_write_cha_data(uint8_t* cha_buf, uint16_t buf_len)
{
    return cp_write(CP_REG_CHA_DATA, cha_buf, buf_len);
}

/**
  * @brief read certificate data length.
  * @param none
  * @return certificate data length.
  */
uint16_t cp_read_crf_data_len(void)
{
    uint8_t data[2];
    
    cp_burst_read(CP_REG_ACD_LEN, data, 2);

    return (((uint16_t)data[0] << 8) | ((uint16_t)data[1]));
}

/**
  * @brief read certificate data.
  * @param[in] data certificate data buffer.
  * @param[in] length certificate data length.
  * @return read result.
  */
uint16_t cp_read_crf_data(uint8_t *data, uint16_t length)
{
    return cp_burst_read(CP_REG_ACD1, data, length);
}

/**
  * @brief start cp cpntrol process.
  * @param[in] cmd cp control comamnd.
  * @return write result.
  */
uint8_t cp_ctrl(cp_cmd_m cmd)
{
    uint8_t op = (uint8_t)cmd;
    return cp_write(CP_REG_CS, &op, 1);
}

/**
  * @brief read cp process result.
  * @param none.
  * @return cp process result.
  */
cp_pro_res_m cp_read_proc_result(void)
{
    return (cp_pro_res_m)cp_signal_read(CP_REG_CS);
}

/**
  * @brief read cp error code.
  * @param none.
  * @return cp process error code.
  */
cp_err_code_m cp_read_err_code(void)
{
    return (cp_err_code_m)cp_signal_read(CP_ERR_CODE);
}

void cp_test(void)
{
#if 0   //test read device verison
    uint8_t version = 0xff;
    uint8_t i = 0;
    
    for(i = 1; i <= 100; i++)
    {
        version = 0xff;
        version = cp_signal_read(0x00);
        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "verision[%d] = %d", 2, i, version);
    }
#endif

#if 0 //test read all device information
    cp_info info;
    uint8_t a[8];
    uint32_t dev_id = 0xFFFFFFFF;
    cp_read_cp_info(&info);
    //cp_burst_read(0x00, a, 8);
    dev_id = (((uint32_t)info.dev_id[0] << 24) | ((uint32_t)info.dev_id[1] << 16)\
        | ((uint32_t)info.dev_id[2] << 8) | ((uint32_t)info.dev_id[3] << 0));
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "dev_verison = 0x%x, fw_verison = 0x%x, auth_protocol_mar = 0x%x,\
        auth_protocol_mir = 0x%x, device_id = 0x%x", 5,\
        info.dev_ver, info.fw_ver, info.aup_mar_ver, info.aup_mir_ver, dev_id);
#endif

#if 0 //test cp_write
    uint8_t cmd = 0x01;
    cp_write(CP_REG_CS, &cmd, 1);
#endif
    
#if 0   //test write challenge data
    uint8_t cha_buf[34];
    uint8_t i = 0;
    cha_buf[0] = 0;
    cha_buf[1] = 32;
    for(i = 0; i < 32; i++)
    {
        cha_buf[i + 2] = i + 1;
    }
    //cp_write_cha_info(cha_buf, 34);
    
    //uint8_t cha_buf1[34] = {0};
    //cp_burst_read(CP_REG_CHA_LEN, cha_buf1, 34);

#endif
    
#if 0
    cp_pro_res_m cp_res = CP_PRO_RES_NO_VALID;
    cp_err_code_m cp_err = CP_ERR_NO_ERR;
    cp_write_cha_len(20);
    cp_write_cha_data(cha_buf, 20);
    //start signature
    cp_ctrl(CP_CMD_START_SIG_GEN);
    cp_res = cp_read_proc_result();
    if(cp_res == CP_PRO_RES_SIG_GEN_OK)
    {
        
    }
    else
    {
        cp_err = cp_read_err_code();
    }
    
    return;
    
#endif
}

