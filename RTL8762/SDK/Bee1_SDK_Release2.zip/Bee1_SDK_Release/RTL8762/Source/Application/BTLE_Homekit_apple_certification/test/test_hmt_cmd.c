enum { __FILE_NUM__ = 0 };

/**
************************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
************************************************************************************************************
* @file     test_mesh_cmd.c
* @brief    User define commands to test interaction with Accessory.
* @details  .
* @author
* @date     2015-03-19
* @version  v0.1
*************************************************************************************************************
*/
#include "test_hmt_cmd.h"
#include <blueapi.h>
#include "trace.h"
#include <string.h>
#include "hmt_char.h"
#include "ais.h"
#include "light_bulb.h"
#include "thermostat.h"
#include "hw_ctrl.h"

TestCmdParseResult TestReadAttr(PTestCmdIF pTestCmdIF, TestCmdParseValue *pParseResult);
TestCmdParseResult TestWriteAttr(PTestCmdIF pTestCmdIF, TestCmdParseValue *pParseResult);

/*----------------------------------------------------
 * command table
 * --------------------------------------------------*/
const TestCmdTableEntry testCmdTable[] =
{
    {
        "read",
        "read <service name> [characteristic name]\n\r",
        "Read attributes\n\r",
         TestReadAttr
    },
    
    {
        "write",
        "readu <service name> [characteristic name] [write_type] [val1] [val2].....[valn]\n\r",
        "Write attributes\n\r",
         TestWriteAttr
    },
    
    /* MUST be at the end: */
    {
        0,
        0,
        0,
        0
    }
};

/************************************** for accessory info service **************************************/
//data
extern char ais_mfr[20];
extern char ais_model[20];
extern char ais_name[20];
extern char ais_sn[20];
extern char ais_fw_ver[20];
extern uint8_t ais_idfy;
//service instance id
extern char siid_ais[6]; //service id accessory info service must be 1, can not be modified
//characteristic instance id
extern uint16_t ciid_ais_siid;
extern uint16_t ciid_idfy;
extern uint16_t ciid_manu;
extern uint16_t ciid_mdl;
extern uint16_t ciid_ais_name;
extern uint16_t ciid_sn;
extern uint16_t ciid_fmv;
//format
extern uint8_t fmt_ais_siid[7];
extern uint8_t fmt_idfy[7];
extern uint8_t fmt_manu[7];
extern uint8_t fmt_sn[7];
extern uint8_t fmt_fmv[7];
extern uint8_t fmt_ais_name[7];
extern uint8_t fmt_mdl[7];
//valid range
extern uint16_t vrg_manu[2];
extern uint16_t vrg_sn[2];
extern uint16_t vrg_ais_name[2];
extern uint16_t vrg_mdl[2];

/************************************** for light bulb service **************************************/
//data
extern lbs_db_t lbs_db;
extern char lbs_name[20];
//service instance id
extern char siid_lbs[5];
//characteristic isntance id
extern uint16_t ciid_lbs_siid;
extern uint16_t ciid_on;
extern uint16_t ciid_bri;
extern uint16_t ciid_lbs_name;
//format
extern uint8_t fmt_lbs_siid[7];
extern uint8_t fmt_on[7];
extern uint8_t fmt_bri[7];
extern uint8_t fmt_lbs_name[7];
//valid range
extern uint32_t vrg_bri[2];
extern uint16_t vrg_lbs_name[2];
//step value
extern uint32_t spv_bri;

/************************************** for thermostat service **************************************/
//service instant id
extern char siid_tts[5];       
extern uint16_t ciid_tts_siid;
extern uint16_t ciid_cst;
extern uint16_t ciid_tst;
extern uint16_t ciid_ctmp;
extern uint16_t ciid_ttmp;
extern uint16_t ciid_unit;
extern uint16_t ciid_tts_name;
extern uint8_t tts_name[];
extern uint8_t char_str_format;
extern tts_db_t tts_db;
//format
extern uint8_t fmt_tts_siid[7];
extern uint8_t fmt_tts_name[7];
extern uint8_t fmt_cst[7];
extern uint8_t fmt_tst[7];
extern uint8_t fmt_ctmp[7];
extern uint8_t fmt_ttmp[7];
extern uint8_t fmt_unit[7];
//valid range
extern uint16_t vrg_tts_name[2];
extern uint8_t vrg_cst[2];
extern uint8_t vrg_tst[2];
extern float vrg_ctmp[2];
extern float vrg_ttmp[2];
extern uint8_t vrg_unit[2];
//step value
extern uint8_t  spv_cst;
extern uint8_t  spv_tst;
extern float  spv_ctmp;
extern float  spv_ttmp;
extern uint8_t  spv_unit;

#define MAX_SRV_NUM          (3 + 1)
#define MAX_CHAR_NUM         (14 + 1)
#define MAX_DESP_NUM         (5 + 1)
#define MAX_AIS_CHAR_NUM     (8 + 1)
#define MAX_LBS_CHAR_NUM     (4 + 1)
#define MAX_TTS_CHAR_NUM     (7 + 1)

//characteristic context
typedef struct _char_ctx_t
{
    char*       cname;        //comamnd name
    char*       uuid;
    void*       val;
    uint16_t*   ciid;
    char*       usdp;
    uint8_t*    format;       //row format
    void*       vrg;
    void*       spv;
    char*       format_str;  //format(string)
    char*       fname;       //full name
}char_ctx_t;

//service context
typedef struct _srv_ctx_t
{
    char* sname;
    char* fname;  //full name
    char* uuid;   //service uuid
    char* siid;   //service instance id
}srv_ctx_t;

const char* srv_ctx_tbl[MAX_SRV_NUM][4] = 
{
    /* service cmd, service full name */
    {"ais", "Accessory Information Service", "FED3", siid_ais},
    {"lbs", "Light Bulb Service", "FED2", siid_lbs},
    {"tts", "Thermostat Service", "FED1", siid_tts},
    {'\0'}
};

#if 0
const char* desp_name_tbl[MAX_DESP_NUM][2] = 
{
    /* desp cmd, descriptor full name */
    {"usdp", "User descriptor"},
    {"ciid", "Characteristic Instance ID"},
    {"fmt",  "Format"},
    {"vrg",  "Valid Range"},
    {"spv",  "Step Value"},
    {'\0'}
};
#endif

//accessory inforation service attribute table
//(format flag, '1'--bool, )
void* ais_char_tbl[MAX_AIS_CHAR_NUM][10] = 
{
    /* char command +  uuid + value + ciid + usdp + format + valid_range + step value + format(str) + full_name */
    {"siid", "00000051-0000-1000-8000-0026BB765291", siid_ais,  &ciid_ais_siid,\
            '\0', fmt_ais_siid, '\0', '\0', "string", "Service Instance ID"},
    {"idfy", "00000014-0000-1000-8000-0026BB765291", &ais_idfy, &ciid_idfy,\
            '\0', fmt_idfy, '\0', '\0',  "uint8", "Identify"},
    {"manu", "00000020-0000-1000-8000-0026BB765291", ais_mfr,   &ciid_manu,\
            '\0', fmt_manu, vrg_manu, '\0', "string", "Manufacture"},
    {"sn",   "00000030-0000-1000-8000-0026BB765291", ais_sn,    &ciid_sn,\
            '\0', fmt_sn, vrg_sn, '\0', "string","Serial Number"},
    {"name", "00000023-0000-1000-8000-0026BB765291", ais_name,  &ciid_ais_name,\
            '\0', fmt_ais_name, vrg_ais_name, '\0', "string","Name"},
    {"mdl",  "00000021-0000-1000-8000-0026BB765291", ais_model, &ciid_mdl,\
            '\0', fmt_mdl, vrg_sn, '\0', "string",   "Model"},
    {"fmv",  "00000052-0000-1000-8000-0026BB765291", ais_fw_ver,&ciid_fmv, \
            '\0', fmt_fmv, vrg_sn, '\0', "string",   "Firmware Revision"},
    {'\0'}
};

//light bulb service attribute table
void* lbs_char_tbl[MAX_LBS_CHAR_NUM][10] = 
{
    {"siid", "00000051-0000-1000-8000-0026BB765291", siid_lbs,  &ciid_lbs_siid,\
            '\0', fmt_lbs_siid, '\0', '\0', "string", "Service Instance ID"},
    {"on",   "00000025-0000-1000-8000-0026BB765291", &lbs_db.on_off, &ciid_on,\
            '\0', fmt_on, '\0', '\0', "bool", "ON"},
    {"bri",  "00000008-0000-1000-8000-0026BB765291", &lbs_db.brightness, &ciid_bri,\
            '\0', fmt_bri, vrg_bri, &spv_bri, "uint32", "Brightness"},
    {"name", "00000023-0000-1000-8000-0026BB765291", lbs_name,  &ciid_lbs_name,\
            '\0', fmt_lbs_name, vrg_lbs_name, '\0', "string","Name"},
    {'\0'}
};

//thermostat service attribute table
void* tts_char_tbl[MAX_TTS_CHAR_NUM][10] = 
{
    {"siid", "00000051-0000-1000-8000-0026BB765291", siid_tts, &ciid_tts_siid,\
            '\0', fmt_tts_siid,'\0', '\0', "string", "Service Instance ID"},
    {"name", "00000023-0000-1000-8000-0026BB765291", tts_name, &ciid_tts_name,\
            '\0', fmt_tts_name, vrg_tts_name, '\0', "string","Name"},
    {"cst",  "0000000F-0000-1000-8000-0026BB765291", &tts_db.cur_st, &ciid_cst,\
            '\0', fmt_cst, vrg_cst, &spv_cst, "uint8", "Current Heating Cooling State"},
    {"tst",  "00000033-0000-1000-8000-0026BB765291", &tts_db.tar_st, &ciid_tst,\
            '\0', fmt_tst, vrg_tst, &spv_tst, "uint8", "Target Heating Cooling State"},
    {"ctmp", "00000011-0000-1000-8000-0026BB765291", &tts_db.cur_tmp, &ciid_ctmp,\
            '\0', fmt_ctmp, vrg_ctmp, &spv_ctmp, "float", "Current Temperature"},
    {"ttmp", "00000035-0000-1000-8000-0026BB765291", &tts_db.tar_tmp, &ciid_ttmp,\
            '\0', fmt_ttmp, vrg_ttmp, &spv_ttmp, "float", "Target Temperature"},
    {"unit", "00000036-0000-1000-8000-0026BB765291", &tts_db.units, &ciid_unit,\
            '\0', fmt_unit, vrg_unit, &spv_unit, "uint8", "Display Units"},
    {'\0'}
};

/*const char* char_fmt_tbl[5] = {"bool", "int", "float", "string", "tlv8"};
const char* char_unit_tbl[4] = {"celsius", "angle", "percent", "unitless"};*/
const char* int_fmt_tbl[][2] = 
{
    {"idfy", "bool"},
    {"on",   "bool"},
    {"bri",  "uint32"},
    {"cst",  "uint8"},
    {"tst",  "uint8"},
    {"unit", "uint8"},
};

const char* write_type_tbl[][2] = 
{
    {"val",  "Value"},
    {"spv",  "Step Value Descriptor"},
    {"ciid", "Characteristic Instance Id Descriptor"},
    {"vrg",  "Valid Range Descriptor"},
    {'\0'}
};

const char* tts_st_tbl[] = {"Off" , "Heat", "Cool", "Auto", '\0'};

/**************************************************************** tool fucntion ************************************/
const char* find_write_type(const char* name)
{
    const char* (*p)[2] = write_type_tbl;
    
    while(**p)
    {
       if(!memcmp(p[0][0], name, strlen(p[0][0])))
       {
           return (const char*)p[0][1];
       }
       p++;
    }
    
    return NULL;
}

const char* find_int_type(const char* name)
{
    const char* (*p)[2] = int_fmt_tbl;
    
    while(**p)
    {
       if(!memcmp(p[0][0], name, strlen(p[0][0])))
       {
           return (const char*)p[0][1];
       }
       p++;
    }
    
    return NULL;
}

const char* get_char_fmt(const char* cname, uint8_t* fmt)
{
    const char* format  = NULL;
    
    switch(fmt[0])
    {
        //one byte
        case HOMEKIT_FORMAT_BOOL:
            format = "bool";
        break;
        
        //1/2/4/8 byte
        case HOMEKIT_FORMAT_INT:
            format = "int";
        break;
         
        case HOMEKIT_FORMAT_FLOAT:
            format = "float";
        break;
        
        case HOMEKIT_FORMAT_STRING:
            format = "string";
        break;
        
        case HOMEKIT_FORMAT_TLV8:
            format = "tlv8";
        break;
        
        default:
        break;
    }
    
    return format;
}

const char* get_char_unit(const char* cname, uint8_t* fmt)
{
    const char* uint  = NULL;
    uint16_t units = ((uint16_t)(fmt[3] << 8)) | fmt[2];
    
    switch(units)
    {
        case HOMEKIT_UNIT_CELSIUS:
            uint = "celsius";
        break;
        
        case HOMEKIT_UNIT_ANGLE:
            uint = "angle";
        break;
         
        case HOMEKIT_UNIT_PERCENT:
            uint = "percent";
        break;
        
        case HOMEKIT_UNIT_UNITLESS:
            uint = "unitless";
        break;
        
        default:
        break;
    }
    
    return uint;
}

char_ctx_t* find_ais_char_ctx(const char* name)
{
    void* (*p)[10] = ais_char_tbl;
    
    while(**p)
    {
       if(!memcmp(p[0][0], name, strlen(name)))
       {
           return (char_ctx_t*)p[0];
       }
       p++;
    }
    
    return NULL;
}

char_ctx_t* find_lbs_char_ctx(const char* name)
{
    void* (*p)[10] = lbs_char_tbl;
    
    while(**p)
    {
       if(!memcmp(p[0][0], name, strlen(name)))
       {
           return (char_ctx_t*)p[0];
       }
       p++;
    }
    
    return NULL;
}

char_ctx_t* find_tts_char_ctx(const char* name)
{
    void* (*p)[10] = tts_char_tbl;
    
    while(**p)
    {
       if(!memcmp(p[0][0], name, strlen(name)))
       {
           return (char_ctx_t*)p[0];
       }
       p++;
    }
    
    return NULL;
}

#if 0
/* hex to char */
static uint8_t hex_to_char(uint8_t hex)
{
    if(hex <= 9)
    {
        return (hex - 0x00 + '0');
    }
    else if(hex >= 0x0A && hex <= 0x0F)
    {
        return (hex - 0x0A + 'A');
    }
    else
    {
        /* wrong */
        return '*';
    }  
}

static uint8_t uint16_to_str(uint16_t hex, char* str)
{
    *str++ = hex_to_char(hex >> 12);
    *str++ = hex_to_char((hex >> 8) & 0x0F);
    *str++ = hex_to_char((hex >> 4) & 0x0F);
    *str++ = hex_to_char(hex & 0x0F);
    
    return 0;
}

static uint8_t hex_to_str(uint8_t* hex, uint16_t count, char* str)
{
    uint16_t i;
    
    for(i = 0; i < count; i++)
    {
        *str++ = hex_to_char(*hex >> 4);
        *str++ = hex_to_char((*hex & 0x0F));
        *str = ' ';
        hex++;
    }
    
    return 0;
}
#endif

srv_ctx_t* find_srv_ctx(const char* sname)
{
    const char* (*p)[4] = srv_ctx_tbl;
    
    while(**p)
    {
       if(!memcmp(p[0][0], sname, strlen(sname)))
       {
           return (srv_ctx_t*)p[0];
       }
       p++;
    }
    
    return NULL;
}

bool is_float_str(const char* str)
{
    const char* c = str;
    uint16_t len = strlen(str);
    bool dot  = false;
    
    //last char can not be '.'
    if(str[len - 1] == '.')
        return false;
    
    while(*c)
    {
        if(*c == '.')
        {
            if(!dot)
            {
                dot = true;
            }
            else
                return false;  //can not more than one '.'
        }
        else
        {
            if(*c < '0' || *c > '9')
                return false;
        }
        
        c++;
    }
    
    return true;
}

bool str_to_float(const char* str, float* f)
{
    const char* c = str;
    uint16_t len = strlen(str);
    uint32_t tmp_int = 0;
    uint32_t dec = 0;
    bool is_int_part = true;
    uint32_t dec_bit = 1;
    
    if(!is_float_str(str))
        return false;
    
    //do convert
    while(*c)
    {
        if(is_int_part)
        {
            if(*c != '.')
                tmp_int = tmp_int * 10 + *c - '0';
            else
                is_int_part = false;
        }
        else
        {
            dec = dec*10 + *c - '0';
            dec_bit = dec_bit * 10;       
        }
        
        c++;
    }
    
    *f = (float)tmp_int + (float)dec / (float)dec_bit;
    
    return true;
}

int str_to_int(const char* str)
{
    uint16_t len = strlen(str);
    bool is_hex = false;
    int res = 0;

    if(len > 2 && str[0] == '0')
    {    
        if(str[1] == 'x' || str[1] == 'X')
            is_hex = true;
    }
    
    if(is_hex)
    {
        str+= 2;
        while(*str)
        {
            if(*str >= '0' && *str <= '9')
                res = 16 * res + *str - '0';
            else if(*str >= 'A' && *str <= 'F')
                res = 16 * res + *str - 'A' + 10;
            else if(*str >= 'a' && *str <= 'f')
                res = 16 * res + *str - 'a' + 10;
            else
                return -1;

            str++;
        }    
    }
    else
    {
        while(*str)
        {
            if(*str >= '0' && *str <= '9')
                res = res * 10 + (*str - '0');
            else
                return -1;

            str++;
        }
    }
    

    return res;
}

/**************************************************************** tool fucntion ************************************/
//read service
TestCmdParseResult srv_read(PTestCmdIF pTestCmdIF, char* srv_name)
{
    TestCmdParseResult result = ResultOk;
    srv_ctx_t* sctx = NULL;
    
    //find service context
    if(!(sctx = find_srv_ctx(srv_name)))
    {
        //read service UUID
        testCmdPrint( pTestCmdIF, "--> Invalid servie name:%s\r\n%s",
                      srv_name,
                      pTestCmdIF->cPrompt);
        
        return result;
    }
    
    testCmdPrint( pTestCmdIF, "[%s]\r\n%s",
                  sctx->fname, 
                  pTestCmdIF->cPrompt);
    
    //service UUID
    testCmdPrint( pTestCmdIF, "  --- [UUID]:%s\r\n%s",
                  sctx->uuid,
                  pTestCmdIF->cPrompt);
   
    //read service instance id
    testCmdPrint( pTestCmdIF, "  --- [Instance id]:%s\r\n%s",
                  sctx->siid,
                  pTestCmdIF->cPrompt);
    
    return result;
}

//read characteristic
TestCmdParseResult char_read(PTestCmdIF pTestCmdIF, char* srv_name, char* char_name)
{
    TestCmdParseResult result = ResultOk;
    const char* format = NULL;
    const char* unit = NULL;
    const char* int_type = NULL;
    char_ctx_t* cctx = NULL;
    srv_ctx_t* sctx = NULL;
    
    //find servce context
    if(!(sctx = find_srv_ctx(srv_name)))
    {
        //wrong service name
        testCmdPrint( pTestCmdIF, "--> Invalid service name:%s\r\n%s",
                      srv_name,
                      pTestCmdIF->cPrompt);
        
        return result;
    }
    
    //find characteristic context
    if(!memcmp(sctx->sname, "ais", 3))
    {
        if(!(cctx = find_ais_char_ctx(char_name)))
        {
             //invalid characteristic name
             testCmdPrint( pTestCmdIF, "--> Invalid characteristic name:%s\r\n%s",
                          char_name,
                          pTestCmdIF->cPrompt);
            
            return result;
        }
    }
    else if(!memcmp(sctx->sname, "lbs", 3))
    {
        if(!(cctx = find_lbs_char_ctx(char_name)))
        {
             //invalid characteristic name
             testCmdPrint( pTestCmdIF, "--> Invalid characteristic name:%s\r\n%s",
                          char_name,
                          pTestCmdIF->cPrompt);
            
            return result;
        }
    }
    else //tts
    {
        if(!(cctx = find_tts_char_ctx(char_name)))
        {
             //invalid characteristic name
             testCmdPrint( pTestCmdIF, "--> Invalid characteristic name:%s\r\n%s",
                          char_name,
                          pTestCmdIF->cPrompt);
            
            return result;
        }
    }
    
    testCmdPrint( pTestCmdIF, "--> [%s] [%s]:\r\n%s",
              sctx->fname,
              cctx->fname,
              pTestCmdIF->cPrompt);
    
    /**************************************************** characteristic UUID *********************************************/
    testCmdPrint( pTestCmdIF, "  --- [UUID]:%s\r\n%s",
              cctx->uuid,
              pTestCmdIF->cPrompt);
    
    /**************************************************** characteristic isntance id ************************************/
     testCmdPrint( pTestCmdIF, "  --- [Charcteristic Instance Id]:%d\r\n%s",
              *(cctx->ciid),
              pTestCmdIF->cPrompt);
    
    /**************************************************** characteristic value *********************************************/
    format = get_char_fmt(char_name, cctx->format);
    unit   = get_char_unit(char_name, cctx->format);
        
    if(!format || !unit)
    {
        testCmdPrint( pTestCmdIF, "--> %s, format[%s] or unit[%s] of characteristic\"%s\" invalid!\r\n%s",
              sctx->fname,
              format,
              unit,
              cctx->fname,
              pTestCmdIF->cPrompt);
        
        return result;
    }
    
    //print string
    if(!memcmp(format, "string", strlen(format)))
    {
        testCmdPrint( pTestCmdIF, "  --- [Value(string)]:%s\r\n%s",
              (char*)cctx->val,
              pTestCmdIF->cPrompt);
    }
    //print float
    else if(!memcmp(format, "float", strlen(format)))
    {
        uint8_t tmpint = (uint8_t)(*(float*)cctx->val);
        uint8_t dec    = (uint8_t)((*(float*)cctx->val - tmpint) * 10);
        
        testCmdPrint( pTestCmdIF, "  --- [Value(float)]:%d.%d\r\n%s",
              tmpint,
              dec,
              pTestCmdIF->cPrompt);
    }
     //print int/bool
    else if(!memcmp(format, "int", strlen(format)) || !memcmp(format, "bool", strlen(format)))
    {
        int_type = find_int_type(char_name);
        uint32_t tmpint;
        if(!memcmp(int_type, "bool", strlen(int_type)) || !memcmp(int_type, "uint8", strlen(int_type)))
        {
            tmpint = *(uint8_t*)cctx->val;
        }
        else if(!memcmp(int_type, "uint16", strlen(int_type)))
        {
            tmpint = *(uint16_t*)cctx->val;
        }
        else if(!memcmp(int_type, "uint32", strlen(int_type)))
        {
            tmpint = *(uint32_t*)cctx->val;
        }
        
        testCmdPrint( pTestCmdIF, "  --- [Value(int)]:%d\r\n%s",
                  tmpint,
                  pTestCmdIF->cPrompt);
        
        //read identify and clear it to zero.
        if(!memcmp(cctx->cname, "idfy", 4))
            *((uint8_t*)cctx->val) = 0;
    }
    else
    {
        //tlv8 format
    }
    
    /*********************************************** characteristic user descriptor ***************************************/
    /*if(cctx->usdp)
    {
        testCmdPrint( pTestCmdIF, "  --- [User Descriptor]:%s\r\n%s",
              (char*)cctx->usdp,
              pTestCmdIF->cPrompt);
    }
    else
    {
        testCmdPrint( pTestCmdIF, "  --- [User Descriptor]: No User Description \r\n%s",
              pTestCmdIF->cPrompt);
    }*/
    
    /**************************************************** characteristic format *********************************************/
    testCmdPrint( pTestCmdIF, "  --- [Format]:%s, [unit]:%s\r\n%s",
              format,
              unit,
              pTestCmdIF->cPrompt);
    
    /*********************************************** characteristic valid range [low, up]*****************************************/
    //have valid range
    if(cctx->vrg)
    {
        if(!memcmp(format, "float", strlen(format)))
        {
            uint8_t lowinit = (uint8_t)(*(float*)cctx->vrg);
            uint8_t lowdec = (uint8_t)((*(float*)cctx->vrg - lowinit) * 10);
            
            uint8_t highinit = (uint8_t)(*((float*)cctx->vrg + 1));
            uint8_t highdec = (uint8_t)((*((float*)cctx->vrg + 1) - highinit) * 10);
            
            testCmdPrint( pTestCmdIF, "  --- [Valid Range]: [%d.%d, %d.%d]\r\n%s",
                  lowinit,
                  lowdec,
                  highinit,
                  highdec,
                  pTestCmdIF->cPrompt);
        }
        
        if(!memcmp(format, "string", strlen(format)))
        {
            uint32_t low, high;
            low = *(uint16_t*)cctx->vrg;
            high = *(((uint16_t*)cctx->vrg) + 1);
            
             testCmdPrint( pTestCmdIF, "  --- [Valid Range]:[%d, %d]\r\n%s",
                    low,
                    high,
                    pTestCmdIF->cPrompt);
        }
        
        if(!memcmp(format, "int", strlen(format)))
        {
            uint32_t low, high;
            if(!memcmp(int_type, "bool", strlen(int_type)) || !memcmp(int_type, "uint8", strlen(int_type)))
            {
                low = *(uint8_t*)cctx->vrg;
                high = *(((uint8_t*)cctx->vrg) + 1);
            }
            else if(!memcmp(int_type, "uint16", strlen(int_type)))
            {
                low = *(uint16_t*)cctx->vrg;
                high = *(((uint16_t*)cctx->vrg) + 1);
            }
            else if(!memcmp(int_type, "uint32", strlen(int_type)))
            {
                low = *(uint32_t*)cctx->vrg;
                high = *(((uint32_t*)cctx->vrg) + 1);
            }
            
            testCmdPrint( pTestCmdIF, "  --- [Valid Range]:[%d, %d]\r\n%s",
                    low,
                    high,
                    pTestCmdIF->cPrompt);
        }
    }
    else
    {
        testCmdPrint( pTestCmdIF, "  --- [Valid Range]:No Valid Range Descriptor\r\n%s",
                    pTestCmdIF->cPrompt);
    }
    
    /**************************************************   characteristic step value  ********************************************/
    if(cctx->spv)
    {
        if(!memcmp(format, "float", strlen(format)))
        {
            uint8_t tmpint = (uint8_t)(*(float*)cctx->spv);
            uint8_t dec = (uint8_t)((*(float*)cctx->spv - tmpint) * 10);
            
            testCmdPrint( pTestCmdIF, "  --- [Step Value]:%d.%d\r\n%s",
                    tmpint,
                    dec,
                    pTestCmdIF->cPrompt);
        }
        
        if(!memcmp(format, "int", strlen(format)))
        {
            uint32_t tmpint;
            if(!memcmp(int_type, "bool", strlen(int_type)) || !memcmp(int_type, "uint8", strlen(int_type)))
            {
                tmpint = *(uint8_t*)cctx->spv;
            }
            else if(!memcmp(int_type, "uint16", strlen(int_type)))
            {
                tmpint = *(uint16_t*)cctx->spv;
            }
            else if(!memcmp(int_type, "uint32", strlen(int_type)))
            {
                tmpint = *(uint32_t*)cctx->spv;
            }
            
            testCmdPrint( pTestCmdIF, "  --- [Step Value]:%d\r\n%s",
                    tmpint,
                    pTestCmdIF->cPrompt);
        }
    }
    else
    {
        testCmdPrint( pTestCmdIF, "  --- [Step Value]:No Step Value Descriptor\r\n%s",
                    pTestCmdIF->cPrompt);
    }
    
    return result;
}

TestCmdParseResult ais_write(PTestCmdIF pTestCmdIF, srv_ctx_t* sctx, char_ctx_t* cctx, const char* wtype, TestCmdParseValue *pParseResult)
{
    TestCmdParseResult result = ResultOk;
    const char* val1 = pParseResult->pParameter[3];
    int int1 = str_to_int(val1);
    const char* val2 = NULL;
    int int2;
    const char* fwtype = find_write_type(wtype);
    void* p = NULL;
    
    if(pParseResult->iParameterCount == 5)
    {
        val2 = pParseResult->pParameter[4];
        int2 = str_to_int(val2);
    }
    
    //ais all characteristics have no step value
    if(!memcmp(wtype, "spv", 3))
    {
        testCmdPrint( pTestCmdIF, "  --- [%s][%s] has no %s\r\n%s",
              sctx->fname,
              cctx->fname,
              fwtype,
              pTestCmdIF->cPrompt);
        
        return result;
    }
    
    //write characteristic value
    if(!memcmp(wtype, "val", 3))
    {
        p = (char*)*((uint32_t*)cctx + 2);
        
        if(!memcmp(cctx->cname, "idfy", 4))   //uint8
        {
            testCmdPrint( pTestCmdIF, "  --- [%s][%s][%s] can not be written locally!!\"\r\n%s",
                  sctx->fname,
                  cctx->fname,
                  fwtype,
                  pTestCmdIF->cPrompt);
            
            return result;
        }
        
       if(!memcmp(cctx->cname, "siid", 4))   //must be "1", can not be modified
       {
            testCmdPrint( pTestCmdIF, "  --- [%s][%s][%s]must be \"1\", can not be modified!!\"\r\n%s",
              sctx->fname,
              cctx->fname,
              fwtype,
              pTestCmdIF->cPrompt);
       
           return result;
       }
        
        memset((char*)p, 0, strlen((char*)p));
        memcpy((char*)p, val1, strlen(val1));
        
        testCmdPrint( pTestCmdIF, "  --- [Write] [%s] [%s] [%s]:%s(%s)\r\n%s",
                sctx->fname,
                cctx->fname,
                fwtype,
                val1,
                cctx->format_str,
                pTestCmdIF->cPrompt);
    
        return result;
    }
    
    //write characteristic instance id
    if(!memcmp(wtype, "ciid", 4))
    {
        if(int1 == -1 || int1 < 2 || int1 > 65535)
        {
            testCmdPrint( pTestCmdIF, "  --- [%s][%s][%s] must be 'uint16' type (2--65535)!!\"\r\n%s",
                      sctx->fname,
                      cctx->fname,
                      fwtype,
                      pTestCmdIF->cPrompt);
            
            return result;
        }
        
        p = (uint16_t*)*((uint32_t*)cctx + 3);
        *(uint16_t*)p = int1;
        
         testCmdPrint( pTestCmdIF, "  --- [Write] [%s] [%s] [%s]:%d(%s)\r\n%s",
            sctx->fname,
            cctx->fname,
            fwtype,
            int1,
            cctx->format_str,
            pTestCmdIF->cPrompt);
        
        return result;
    }
    
    //write valid range
    if(!memcmp(wtype, "vrg", 3))
    {
        if(!cctx->vrg)
        {
            testCmdPrint( pTestCmdIF, "  --- [%s][%s] has no %s\r\n%s",
                sctx->fname,
                cctx->fname,
                fwtype,
                pTestCmdIF->cPrompt);
        
            return result;
        }

        if(int1 == -1 || int2 == -1 || int1 < 1)
        {
            testCmdPrint( pTestCmdIF, "  --- [%s][%s]'valid range' must be 'uint16' type!!\r\n%s",
                      sctx->fname,
                      cctx->fname,
                      val1,
                      val2,
                      pTestCmdIF->cPrompt);
            
            return result;
        }
        p = (uint16_t*)*((uint32_t*)cctx + 6);
        *(uint16_t*)p = int1;
        *((uint16_t*)p + 1) = int2;
        
        testCmdPrint( pTestCmdIF, "  --- [Write] [%s] [%s] [%s]:[%d, %d](%s)\r\n%s",
            sctx->fname,
            cctx->fname,
            fwtype,
            int1,
            int2,
            cctx->format_str,
            pTestCmdIF->cPrompt);
        
        return result;
    }
    
    return result;
}



TestCmdParseResult lbs_write(PTestCmdIF pTestCmdIF, srv_ctx_t* sctx, char_ctx_t* cctx, const char* wtype, TestCmdParseValue *pParseResult)
{
    TestCmdParseResult result = ResultOk;
    const char* val1 = pParseResult->pParameter[3];
    int int1 = str_to_int(pParseResult->pParameter[3]);
    int int2;
    const char* val2 = NULL;
    const char* fwtype = find_write_type(wtype);
    const char* format = get_char_fmt(cctx->cname, cctx->format);
    void* p = NULL;
    
    if(pParseResult->iParameterCount == 5)
    {
        val2 = pParseResult->pParameter[4];
        int2 = str_to_int(val2);
    }         
    
    //write step value
    if(!memcmp(wtype, "spv", 3))
    {
        if(!cctx->spv)
        {
            testCmdPrint( pTestCmdIF, "  --- [%s][%s] has no %s\r\n%s",
                  sctx->fname,
                  cctx->fname,
                  fwtype,
                  pTestCmdIF->cPrompt);
        }
        else
        {
            //brightness
            if(int1 == -1 || int1 > 100)
            {
                testCmdPrint( pTestCmdIF, "  --- [%s][%s][%s]must be 'uint32' type (0--100)!!\"\r\n%s",
                          sctx->fname,
                          cctx->fname,
                          fwtype,
                          pTestCmdIF->cPrompt);
                
                return result;
            }

            p = (uint32_t*)*((uint32_t*)cctx + 7);
            *(uint32_t*)p = int1;
            
            testCmdPrint( pTestCmdIF, "  --- [Write] [%s] [%s] [%s]:%d(%s)\r\n%s",
                sctx->fname,
                cctx->fname,
                fwtype,
                int1,
                cctx->format_str,
                pTestCmdIF->cPrompt);
        }
        
        return result;
    }
    
    //write characteristic value
    if(!memcmp(wtype, "val", 3))
    {
        p = (char*)*((uint32_t*)cctx + 2);
        
        //string format
        if(!memcmp(cctx->cname, "name", 4))
        {
            memset((char*)p, 0, strlen((char*)p));
            memcpy((char*)p, val1, strlen(val1));
            
            testCmdPrint( pTestCmdIF, "  --- [Write] [%s] [%s] [%s]:%s(%s)\r\n%s",
                    sctx->fname,
                    cctx->fname,
                    fwtype,
                    val1,
                    cctx->format_str,
                    pTestCmdIF->cPrompt);
            
            return result;
        }
        
        if(!memcmp(cctx->cname, "siid", 4))
        {
            if(int1 == -1)
            {
                testCmdPrint( pTestCmdIF, "  --- [%s][%s][%s] must be 'uint16' type(2--65535)!!\"\r\n%s",
                          sctx->fname,
                          cctx->fname,
                          fwtype,
                          pTestCmdIF->cPrompt);
                
                return result;
            }
            
            testCmdPrint( pTestCmdIF, "  --- [Write] [%s] [%s] [%s]:%s(%s)\r\n%s",
                sctx->fname,
                cctx->fname,
                fwtype,
                val1,
                cctx->format_str,
                pTestCmdIF->cPrompt);
        } 
        
        //uint8 format
        if(!memcmp(cctx->cname, "on", 2))
        {
            if(int1 == -1 || int1 > 1)
            {
                testCmdPrint( pTestCmdIF, "  --- [%s][%s] [%s] must be 'bool' type(0 or 1)!!\"\r\n%s",
                          sctx->fname,
                          cctx->fname,
                          fwtype,
                          pTestCmdIF->cPrompt);
                
                return result;
            }
            
            p = (uint8_t*)*((uint32_t*)cctx + 2);
            *(uint8_t*)p = int1;
            
            //hardware operation
            ltb_hw_ctrl_t hw_ctrl;
            hw_ctrl.on_off = int1;
            hw_ctrl.brightness = lbs_db.brightness;
            light_hw_ctrl(&hw_ctrl);

            testCmdPrint( pTestCmdIF, "  --- [Write] [%s] [%s] [%s]:%d(%s)\r\n%s",
                sctx->fname,
                cctx->fname,
                fwtype,
                int1,
                cctx->format_str,
                pTestCmdIF->cPrompt);
            
        
            return result;
        }
        
        //uint32 format
        if(!memcmp(cctx->cname, "bri", 3))
        {
            if(int1 == -1 || int1 > 100)
            {
                testCmdPrint( pTestCmdIF, "  --- [%s][%s] [%s] must be 'uint32' type(0--100)!!\"\r\n%s",
                          sctx->fname,
                          cctx->fname,
                          fwtype,
                          pTestCmdIF->cPrompt);
                
                return result;
            }

            p = (uint8_t*)*((uint32_t*)cctx + 2);
            *(uint8_t*)p = int1;
            
            //hardware operation
            ltb_hw_ctrl_t hw_ctrl;
            hw_ctrl.on_off = lbs_db.on_off;
            hw_ctrl.brightness = int1;
            light_hw_ctrl(&hw_ctrl);

            testCmdPrint( pTestCmdIF, "  --- [Write] [%s] [%s] [%s]:%d(%s)\r\n%s",
                sctx->fname,
                cctx->fname,
                fwtype,
                int1,
                cctx->format_str,
                pTestCmdIF->cPrompt);
        
            return result;
        }
        
        return result;
    }
    
    //write characteristic instance id
    if(!memcmp(wtype, "ciid", 4))
    {
        if(int1 == -1 || int1 < 2 || int1 > 65535)
        {
            testCmdPrint( pTestCmdIF, "  --- [%s][%s][%s] must be 'uint16' type (2--65535)!!\"\r\n%s",
                      sctx->fname,
                      cctx->fname,
                      fwtype,
                      pTestCmdIF->cPrompt);
            
            return result;
        }
        
        p = (uint16_t*)*((uint32_t*)cctx + 3);
        *(uint16_t*)p = int1;
        
         testCmdPrint( pTestCmdIF, "  --- [Write] [%s] [%s] [%s]:%d(%s)\r\n%s",
            sctx->fname,
            cctx->fname,
            fwtype,
            int1,
            cctx->format_str,
            pTestCmdIF->cPrompt);
        
        return result;
    }
    
    //write valid range
    if(!memcmp(wtype, "vrg", 3))
    {
        if(!cctx->vrg)
        {
             testCmdPrint( pTestCmdIF, "  --- [%s][%s] has no [%s]\r\n%s",
              sctx->fname,
              cctx->fname,
              fwtype,
              pTestCmdIF->cPrompt);
        
            return result;
        }
        else
        {
            //name(uint16), brigtness(uint32)
            if(!memcmp(cctx->cname, "name", 4))
            {
                p = (uint16_t*)*((uint32_t*)cctx + 6);
                *(uint16_t*)p = int1;
                *((uint16_t*)p + 1) = int2;
                
                testCmdPrint( pTestCmdIF, "  --- [Write] [%s] [%s] [%s]:[%d, %d](%s)\r\n%s",
                    sctx->fname,
                    cctx->fname,
                    fwtype,
                    int1,
                    int2,
                    cctx->format_str,
                    pTestCmdIF->cPrompt);
                
                return result;
            }
            
            if(!memcmp(cctx->cname, "bri", 3))
            {
                p = (uint16_t*)*((uint32_t*)cctx + 6);
                *(uint16_t*)p = int1;
                *((uint16_t*)p + 1) = int2;
                
                testCmdPrint( pTestCmdIF, "  --- [Write] [%s] [%s] [%s]:[%d, %d](%s)\r\n%s",
                    sctx->fname,
                    cctx->fname,
                    fwtype,
                    int1,
                    int2,
                    cctx->format_str,
                    pTestCmdIF->cPrompt);
                
                return result;
            }
        }
        
        return result;
    }
    
    return result;
}

TestCmdParseResult tts_write(PTestCmdIF pTestCmdIF, srv_ctx_t* sctx, char_ctx_t* cctx,
        const char* wtype, TestCmdParseValue *pParseResult)
{
    TestCmdParseResult result = ResultOk;
    const char* val1 = pParseResult->pParameter[3];
    int int1 = str_to_int(val1);
    const char* val2 = NULL;
    int int2;
    const char* fwtype = find_write_type(wtype);
    const char* format = get_char_fmt(cctx->cname, cctx->format);
    void* p = NULL;
    
    if(pParseResult->iParameterCount == 5)
    {
        val2 = pParseResult->pParameter[4];
        int2 = str_to_int(val2);
    }
    
    //write step value
    if(!memcmp(wtype, "spv", 3))
    {
        if(cctx->spv)
        {
            if(!memcmp(cctx->cname, "name", 4))
            {
                p = (uint16_t*)*((uint32_t*)cctx + 7);
                *(uint16_t*)p = int1;
            }
            else if(!memcmp(cctx->cname, "cst", 3) || !memcmp(cctx->cname, "sst", 3) || !memcmp(cctx->cname, "unit", 4))
            {
                testCmdPrint( pTestCmdIF, "  --- [%s][%s][%s] can not be modified!!\"\r\n%s",
                      sctx->fname,
                      cctx->fname,
                      fwtype,
                      pTestCmdIF->cPrompt);
       
           return result;
            }
            else  //temperature
            {
                float f1;
                if(!str_to_float(val1, &f1))
                {
                    testCmdPrint( pTestCmdIF, "  --- [%s][%s][%s]must be 'float' type!!\r\n%s",
                      sctx->fname,
                      cctx->fname,
                      fwtype,
                      pTestCmdIF->cPrompt);  
                    
                    return result;
                }
                
                p = (float*)*((uint32_t*)cctx + 7);
                *(float*)p = f1;
            }
            
            testCmdPrint( pTestCmdIF, "  --- [Write] [%s] [%s] [%s]:%d(%s)\r\n%s",
                sctx->fname,
                cctx->fname,
                fwtype,
                int1,
                cctx->format_str,
                pTestCmdIF->cPrompt);
        }
        else
        {
            testCmdPrint( pTestCmdIF, "  --- [%s][%s] has no %s\r\n%s",
                  sctx->fname,
                  cctx->fname,
                  fwtype,
                  pTestCmdIF->cPrompt);  
        }
        
        return result;
    }
    
    //write characteristic value
    if(!memcmp(wtype, "val", 3))
    {
        //string format
        if(!memcmp(cctx->cname, "name", 4))
        {
            p = (char*)*((uint32_t*)cctx + 2);
            memset((char*)p, 0, strlen((char*)p));
            memcpy((char*)p, val1, strlen(val1));
            
            testCmdPrint( pTestCmdIF, "  --- [Write] [%s] [%s] [%s]:%s(%s)\r\n%s",
                    sctx->fname,
                    cctx->fname,
                    fwtype,
                    val1,
                    cctx->format_str,
                    pTestCmdIF->cPrompt);
        } 
        
        if(!memcmp(cctx->cname, "siid", 4))
        {
            //check format
            if(int1 < 1 || int1 > 65535)
            {
                testCmdPrint( pTestCmdIF, "  --- [%s][%s][%s] must be 'uint16' type(2--65535)!!\"\r\n%s",
                      sctx->fname,
                      cctx->fname,
                      fwtype,
                      pTestCmdIF->cPrompt);
                
                return result;
            }
            
            testCmdPrint( pTestCmdIF, "  --- [Write] [%s] [%s] [%s]:%s(%s)\r\n%s",
                sctx->fname,
                cctx->fname,
                fwtype,
                val1,
                cctx->format_str,
                pTestCmdIF->cPrompt);
        } 
        
        //uint8 format
        else if(!memcmp(cctx->cname, "cst", 3) || !memcmp(cctx->cname, "tst", 3) || !memcmp(cctx->cname, "unit", 4))
        {
            //invalid range
            if((!memcmp(cctx->cname, "cst", 3) && int1 > 2)
                || (!memcmp(cctx->cname, "tst", 3) && int1 > 3)
                || (!memcmp(cctx->cname, "unit", 3) && int1 > 1))
            {
                testCmdPrint( pTestCmdIF, "  --- [%s][%s][%s] can not be set to %s!!\"\r\n%s",
                      sctx->fname,
                      cctx->fname,
                      fwtype,
                      val1,
                      pTestCmdIF->cPrompt);
                
                return result;
            }
            
            p = (uint8_t*)*((uint32_t*)cctx + 2);
            *(uint8_t*)p = int1;
                
            testCmdPrint( pTestCmdIF, "  --- [Write] [%s] [%s] [%s]:%d(%s)\r\n%s",
                sctx->fname,
                cctx->fname,
                fwtype,
                int1,
                cctx->format_str,
                pTestCmdIF->cPrompt);
            
            return result;
        }
        //float format
        else
        {
#if 0
            float f1;
            if(!str_to_float(val1, &f1))
            {
                testCmdPrint( pTestCmdIF, "  --- [%s][%s][%s] must be float!!\r\n%s",
                  sctx->fname,
                  cctx->fname,
                  fwtype,
                  pTestCmdIF->cPrompt);  
                
                return result;
            }
            
            p = (float*)*((uint32_t*)cctx + 2);
            memcpy(p, &f1, sizeof(float));

            testCmdPrint( pTestCmdIF, "  --- [Write] [%s] [%s] [%s]:%d.%d(%s)\r\n%s",
                sctx->fname,
                cctx->fname,
                fwtype,
                (uint16_t)f1,
                (uint16_t)((f1 - (uint16_t)f1) * 10),
                cctx->format_str,
                pTestCmdIF->cPrompt);
            
            return result;
#endif
            testCmdPrint( pTestCmdIF, "  --- [%s][%s][%s] can not be modified\r\n%s",
                  sctx->fname,
                  cctx->fname,
                  fwtype,
                  pTestCmdIF->cPrompt);
            
            return result;
        }
    }
    
    //write characteristic instance id
    if(!memcmp(wtype, "ciid", 4))
    {
        if(int1 == -1 || int1 < 2 || int1 > 65535)
        {
            testCmdPrint( pTestCmdIF, "  --- [%s][%s][%s] must be 'uint16' type (2--65535)!!\"\r\n%s",
                      sctx->fname,
                      cctx->fname,
                      fwtype,
                      pTestCmdIF->cPrompt);
            
            return result;
        }
        
        p = (uint16_t*)*((uint32_t*)cctx + 3);
        *(uint16_t*)p = int1;
        
         testCmdPrint( pTestCmdIF, "  --- [Write] [%s] [%s] [%s]:%d(%s)\r\n%s",
            sctx->fname,
            cctx->fname,
            fwtype,
            int1,
            cctx->format_str,
            pTestCmdIF->cPrompt);
        
        return result;
    }
    
    //write valid range
    if(!memcmp(wtype, "vrg", 3))
    {
        if(!cctx->vrg)
        {
             testCmdPrint( pTestCmdIF, "  --- [%s][%s] has no %s\r\n%s",
              sctx->fname,
              cctx->fname,
              fwtype,
              pTestCmdIF->cPrompt);
        
            return result;
        }
        
        //name(uint16)
        if(!memcmp(cctx->cname, "name", 4))
        {
            p = (uint16_t*)*((uint32_t*)cctx + 6);
            *(uint16_t*)p = int1;
            *((uint16_t*)p + 1) = int2;
            
            testCmdPrint( pTestCmdIF, "  --- [Write] [%s] [%s] [%s]:[%d, %d](%s)\r\n%s",
                sctx->fname,
                cctx->fname,
                fwtype,
                int1,
                int2,
                cctx->format_str,
                pTestCmdIF->cPrompt);
            
            return result;
        }
            
        if(!memcmp(cctx->cname, "cst", 3) || !memcmp(cctx->cname, "sst", 3) || !memcmp(cctx->cname, "unit", 4))
        {
            testCmdPrint( pTestCmdIF, "  --- [%s][%s][%s] can not be modified\r\n%s",
                  sctx->fname,
                  cctx->fname,
                  fwtype,
                  pTestCmdIF->cPrompt);
            
            return result;
        }
        
        if(!memcmp(cctx->cname, "ttmp", 4) || !memcmp(cctx->cname, "ctmp", 5))
        {
            float f1, f2;
            if(!str_to_float(val1, &f1) || !str_to_float(val2, &f2))
            {
                testCmdPrint( pTestCmdIF, "  --- [%s][%s][%s] must be float type!!\r\n%s",
                  sctx->fname,
                  cctx->fname,
                  fwtype,
                  pTestCmdIF->cPrompt);  
                
                return result;
            }
            
            p = (float*)*((uint32_t*)cctx + 6);
            *(float*)p = f1;
            *((float*)p + 1) = f2;
            
            uint16_t tmpint1 = (uint16_t)f1;
            uint16_t dec1 = (f1 - tmpint1);
            uint16_t tmpint2 = (uint16_t)f2;
            uint16_t dec2 = (f2 - tmpint2);

            testCmdPrint( pTestCmdIF, "  --- [Write] [%s] [%s] [%s]:[%d.%d, %d.%d](%s)\r\n%s",
                sctx->fname,
                cctx->fname,
                fwtype,
                tmpint1,
                dec1,
                tmpint2,
                dec2,
                cctx->format_str,
                pTestCmdIF->cPrompt);
            
            return result;
        }
        
        return result;
    }
    
    return result;
}

//write attribute
TestCmdParseResult char_write(PTestCmdIF pTestCmdIF, TestCmdParseValue *pParseResult)
{
    TestCmdParseResult result = ResultOk;
    srv_ctx_t* sctx = NULL;
    char_ctx_t* cctx = NULL;
    const char* sname = pParseResult->pParameter[0];
    const char* cname = pParseResult->pParameter[1];
    const char* wtype = pParseResult->pParameter[2];
    const char* val1 = pParseResult->pParameter[3];
    const char* val2 = NULL;
    
    if(pParseResult->iParameterCount == 5)
    {
        val2 = pParseResult->pParameter[4];
    }
    
    //find servce context
    if(!(sctx = find_srv_ctx(sname)))
    {
        //invalid service name
        testCmdPrint( pTestCmdIF, "--> Invalid service name:%s\r\n%s",
                      sname,
                      pTestCmdIF->cPrompt);
        
        return result;
    }
    
    //check write type(3 types now)
    if(!memcmp(wtype, "val", 3) || !memcmp(wtype, "ciid", 4) || !memcmp(wtype, "spv", 3))
    {
        if(pParseResult->iParameterCount != 4)
        {
            //invalid parameters count
            testCmdPrint( pTestCmdIF, "--> Value: %s is invalid value:\r\n%s",
                      val2,
                      pTestCmdIF->cPrompt);
            
            return result;
        }
    }
    else if(!memcmp(wtype, "vrg", 3))
    {
        if(pParseResult->iParameterCount != 5)
        {
            //invalid parameters count
            testCmdPrint( pTestCmdIF, "--> Set \"Valid Range Descriptor\" need two values\r\n%s",
                      pTestCmdIF->cPrompt);
            
            return result;
        }
    }
    else
    {
        //invalid write type
        testCmdPrint( pTestCmdIF, "--> Invalid write type:%s\r\n%s",
                      wtype,
                      pTestCmdIF->cPrompt);
        
        return result;
    }
    
    //find characteristic context
    if(!memcmp(sctx->sname, "ais", 3))
    {
        if(!(cctx = find_ais_char_ctx(cname)))
        {
             //invalid characteristic name
             testCmdPrint( pTestCmdIF, "--> Invalid characteristic name:%s\r\n%s",
                          cname,
                          pTestCmdIF->cPrompt);
            
            return result;
        }
        
        return ais_write(pTestCmdIF, sctx, cctx, wtype, pParseResult);
    }
    else if(!memcmp(sctx->sname, "lbs", 3))
    {
        if(!(cctx = find_lbs_char_ctx(cname)))
        {
             //invalid characteristic name
             testCmdPrint( pTestCmdIF, "--> Invalid characteristic name:%s\r\n%s",
                          cname,
                          pTestCmdIF->cPrompt);
            
            return result;
        }
        
        return lbs_write(pTestCmdIF, sctx, cctx, wtype, pParseResult);
    }
    else //tts
    {
        if(!(cctx = find_tts_char_ctx(cname)))
        {
             //invalid characteristic name
             testCmdPrint( pTestCmdIF, "--> Invalid characteristic name:%s\r\n%s",
                          cname,
                          pTestCmdIF->cPrompt);
            
            return result;
        }
        
        return tts_write(pTestCmdIF, sctx, cctx, wtype, pParseResult);
    }
    
    return result;
}

TestCmdParseResult TestReadAttr(PTestCmdIF pTestCmdIF, TestCmdParseValue *pParseResult)
{
    TestCmdParseResult result = ResultOk;
    
    //invalid commad length
    if(pParseResult->iParameterCount < 1 || pParseResult->iParameterCount > 2)
    {
         testCmdPrint( pTestCmdIF, "--> Invalid parameters count:%s [cmd + sname or cmd + sname + cname]\r\n%s",
                      pParseResult->iParameterCount,
                      pTestCmdIF->cPrompt);
        return result;
    }
    
     //read service
     if(pParseResult->iParameterCount == 1)
     {  
        result = srv_read(pTestCmdIF, pParseResult->pParameter[0]);
     }
     
      //read characteristic
     if(pParseResult->iParameterCount == 2)
     {  
        result = char_read(pTestCmdIF, pParseResult->pParameter[0], pParseResult->pParameter[1]);
     }
     
    return result;
}

TestCmdParseResult TestWriteAttr(PTestCmdIF pTestCmdIF, TestCmdParseValue *pParseResult)
{
    TestCmdParseResult result = ResultOk;
    
    //invalid commad length
    if(pParseResult->iParameterCount < 4 || pParseResult->iParameterCount > 5)
    {
         testCmdPrint( pTestCmdIF, "--> Invalid parameters count:%s [cmd + sname + cname + wtype + val1 + val2(optional)]\r\n%s",
                      pParseResult->iParameterCount,
                      pTestCmdIF->cPrompt);
        return result;
    }
    
    //write characteristic
    result = char_write(pTestCmdIF, pParseResult);
     
    return result;
}

