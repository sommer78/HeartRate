/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     hw_ctrl.c
* @brief    do some IO releated things.
* @details  none.
* @author   tifnan
* @date     2015-09-24
* @par History: 2015-11-16 add some comemnt, add fucntion light_hw_init() & light_hw_ctrl().
* @version  v1.0                       
*********************************************************************************************************
*/

#include "rtl876x_rcc.h"
#include "rtl876x_gpio.h"
#include "rtl876x_tim.h"
#include "rtl876x_pwm.h"
#include "hw_ctrl.h"
#include "ota_api.h"
#include "hal_wdg.h"
#include "trace.h"
#include "hmt_api.h"
#include "light_bulb.h"
#include "thermostat.h"
#include "hmt_api.h"

extern uint8_t g_connect_flag;
uint8_t manu_op_flag = 0;     //manual operation flag

/**
  * @brief do advertising tip, LED blinking.
  * @param none.
  * @return none
  */
void start_adv_tip(void)
{
    PWM_InitTypeDef PWM_InitStruct;
    PWM_InitStruct.PWM_Period = 500;   //500ms
    PWM_InitStruct.PWM_Duty = 250;     //50%
    PWM_InitStruct.PWM_TIMIndex = 1;
    PWM_Init(PWM1, &PWM_InitStruct);
    PWM_Cmd(PWM1, ENABLE);

    return;
}

/**
  * @brief do connected tip, turn on LED when connected.
  * @param none.
  * @return none
  */
void start_connected_tip(void)
{
    PWM_InitTypeDef PWM_InitStruct;
    PWM_Cmd(PWM1, DISABLE);
    PWM_InitStruct.PWM_Period = 500;   //500ms
    PWM_InitStruct.PWM_Duty = 0;     //0%
    PWM_InitStruct.PWM_TIMIndex = 1;
    PWM_Init(PWM1, &PWM_InitStruct);
    PWM_Cmd(PWM1, ENABLE);
}

/**
  * @brief disconnect tip, turn off LED when disconneccted.
  * @param none.
  * @return none
  */
void start_disconnect_tip(void)
{
    PWM_InitTypeDef PWM_InitStruct;
    PWM_Cmd(PWM1, DISABLE);   
    PWM_InitStruct.PWM_Period = 500;   //500ms
    PWM_InitStruct.PWM_Duty = 500;     //100%
    PWM_InitStruct.PWM_TIMIndex = 1;
    PWM_Init(PWM1, &PWM_InitStruct);
    PWM_Cmd(PWM1, ENABLE);
}

/**
  * @brief do homekit identify.
  * @param none.
  * @return none
  */
void homekit_identify(void)
{
    uint32_t i = 0;
    uint8_t count = 7;
    GPIO_InitTypeDef gpioInitStruct;

    //pad & clock
    Pad_Config(HOMEKIT_IDNTIFY_LED_PIN, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);
    Pinmux_Config(HOMEKIT_IDNTIFY_LED_PIN, GPIO_FUN);

    //gpio init
    GPIO_StructInit(&gpioInitStruct);
    gpioInitStruct.GPIO_Pin  = GPIO_GetPin(HOMEKIT_IDNTIFY_LED_PIN);
    gpioInitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_Init(&gpioInitStruct);

    //do LED blink to identify itself
    while(count)
    {
        GPIO_ResetBits(GPIO_GetPin(HOMEKIT_IDNTIFY_LED_PIN));
        for(i = 0; i < 240000; i++);
        GPIO_SetBits(GPIO_GetPin(HOMEKIT_IDNTIFY_LED_PIN));
        for(i = 0; i < 240000; i++);
        count--;
    }
    
    return;
}

/**
  * @brief gpio interrupt hendle routine--firmware update.
  * @param none.
  * @return none
  */
void Gpio2IntrHandler(void)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "start to enter ota mode......", 0);
    
    GPIO_MaskINTConfig(GPIO_GetPin(OTA_BUTTON_PIN), ENABLE);

     /*prepare to enter into OTA mode*/
    dfuSetOtaMode(ENABLE);
    HalWatchDogConfig(0, 5, 1);
    HalWatchDogEnable();
    
    GPIO_ClearINTPendingBit(GPIO_GetPin(OTA_BUTTON_PIN));
}

/**
  * @brief gpio interrupt hendle routine--factory reset(P3_1-->P0_1).
  * @param none.
  * @return none
  */
void Gpio25IntrHandler(void)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "accessory factory reset......", 0);
    
    GPIO_MaskINTConfig(GPIO_GetPin(FACTORY_RESET_PIN), ENABLE);

    /*prepare to enter into OTA mode*/
    hmt_factory_reset();
    //use watch dog to reset
    HalWatchDogConfig(0, 5, 1);
    HalWatchDogEnable();
    
    GPIO_ClearINTPendingBit(GPIO_GetPin(FACTORY_RESET_PIN));
    //GPIO_MaskINTConfig(GPIO_GetPin(P0_2), DISABLE);
}

/**
  * @brief gpio interrupt hendle routine--light bulb manual operation(P3_2->P3_3).
  * @param none.
  * @return none
  */
void Gpio26IntrHandler(void)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "light bulb manual operation......", 0);
    
    GPIO_MaskINTConfig(GPIO_GetPin(LIGHT_MANU_OP_PIN), ENABLE);

    manu_op_flag = 1; //light bulb manual operation

    TIM_Cmd(TIM3, ENABLE);
}

/**
  * @brief gpio interrupt hendle routine--thermostat manual operation(P4_2-->P1_2).
  * @param none.
  * @return none
  */
void Gpio30IntrHandler(void)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "thermostat manual operation......", 0);
    
    GPIO_MaskINTConfig(GPIO_GetPin(THERMOSTAT_MANU_OP_PIN), ENABLE);

    manu_op_flag = 2;  //thermostat manual operation

    TIM_Cmd(TIM3, ENABLE);
}

/**
  * @brief key press debounce timer timeout handle.
  * @param none.
  * @return none
  */
void Timer3IntrHandler(void)
{
    if(manu_op_flag == 1)
    {
        lbs_db_t lbs_db;
        ltb_hw_ctrl_t hw_ctrl_par;
      
        //light bulb operation
        DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Timer3IntrHandler light bulb operation", 0);
        
        lbs_get_db(&lbs_db);
        
        if(lbs_db.on_off)
        {
            lbs_db.on_off = 0;
        }
        else
        {
            lbs_db.on_off = 1;
        }
        
        lbs_set_db(&lbs_db);
        
        //hardware control
        hw_ctrl_par.on_off = lbs_db.on_off;
        hw_ctrl_par.brightness = lbs_db.brightness;
        light_hw_ctrl(&hw_ctrl_par);
        
        //can send indication only when connected
        /*if(g_connect_flag)
        {
            lbs_send_indication(GATT_SVC_LTBS_ON_INDEX, NULL, 0); 
        }*/
    }

    if(manu_op_flag == 2)
    {
        tts_db_t tts_db; 

        //thermostat operation
        DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Timer3IntrHandler thermostat operation", 0);
        
        tts_get_db(&tts_db);
        
        //set current state == target state
        if(tts_db.tar_st != 3)
        {
            tts_db.cur_st = tts_db.tar_st;
        }

        tts_set_db(&tts_db);
        
        //can send indication only when connected
        /*if(g_connect_flag)
        {
            tts_send_indication(GATT_SVC_THMST_CUR_ST_INDEX, NULL, 0);   
        }*/
    }

    //stop key press debounce timer
    TIM_ClearINT(TIM3);
    TIM_Cmd(TIM3, DISABLE);

     //enable interrupt gagin
    if(manu_op_flag == 1)
    {
        GPIO_ClearINTPendingBit(GPIO_GetPin(LIGHT_MANU_OP_PIN));
        GPIO_MaskINTConfig(GPIO_GetPin(LIGHT_MANU_OP_PIN), DISABLE);
    }
    else
    {
        GPIO_ClearINTPendingBit(GPIO_GetPin(THERMOSTAT_MANU_OP_PIN));
        GPIO_MaskINTConfig(GPIO_GetPin(THERMOSTAT_MANU_OP_PIN), DISABLE);
    }

     manu_op_flag = 0;
}

/**
  * @brief light bulb hardware init.
  * @param[in] hw_ctrl_par --pointer to fan hardware control parameters.
  * @return none
  */
void light_hw_init(ltb_hw_ctrl_t* hw_ctrl_par)
{
    RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
    RCC_PeriphClockCmd(APBPeriph_TIMER, APBPeriph_TIMER_CLOCK, ENABLE);

    PWM_InitTypeDef PWM_InitStruct;
    TIM_TimeBaseInitTypeDef TIM_InitStruct;
    
    //pwm init 
    TIM_StructInit(&TIM_InitStruct);
    TIM_InitStruct.TIM_ClockSrc = TIM_CLOCK_10MHZ;
    TIM_InitStruct.TIM_Period = 1000;   //0.1ms
    TIM_InitStruct.TIM_Mode = TIM_Mode_UserDefine;
    TIM_TimeBaseInit(TIM2, &TIM_InitStruct);
    TIM_Cmd(TIM2, ENABLE);

    //timer init
    PWM_InitStruct.PWM_Period = 100;   //10ms
    PWM_InitStruct.PWM_Duty = hw_ctrl_par->brightness;     //5ms
    PWM_InitStruct.PWM_TIMIndex = 2;
    PWM_Init(PWM0, &PWM_InitStruct);

    if(hw_ctrl_par->on_off)
    {
        PWM_Cmd(PWM0, ENABLE);        
    }
}

/**
  * @brief light bulb hardware control.
  * @param[in] hw_ctrl_par --pointer to fan hardware control parameters.
  * @return none
  */
void light_hw_ctrl(ltb_hw_ctrl_t* hw_ctrl_par)
{
    if(hw_ctrl_par->on_off)
    {
        PWM_InitTypeDef PWM_InitStruct;

        //disable PWM firstly
        PWM_Cmd(PWM0, DISABLE);

        //setting pwm parameters
        PWM_InitStruct.PWM_Period = 100;
        PWM_InitStruct.PWM_Duty = hw_ctrl_par->brightness;
        PWM_InitStruct.PWM_TIMIndex = 2;

        //enable pwm again
        PWM_Init(PWM0, &PWM_InitStruct);
        PWM_Cmd(PWM0, ENABLE);
    }
    else
    {
        PWM_Cmd(PWM0, DISABLE);        
    }
}
