/**
************************************************************************************************************
*               Copyright(c) 2014-2015, Realtek Semiconductor Corporation. All rights reserved.
************************************************************************************************************
* @file     cvsd_encode.h
* @brief    
* @author   Susan_Zhang
* @date     2015-10
* @version  v0.1
*************************************************************************************************************
*/

#ifndef __CVSD_ENCODE_H__
#define __CVSD_ENCODE_H__

#include	"stdint.h"

extern void CVSD_Encode(int16_t *VoiceBuffer, uint8_t *EncodeBuffer, int sample_num);

#endif /* __CVSD_ENCODE_H__ */
