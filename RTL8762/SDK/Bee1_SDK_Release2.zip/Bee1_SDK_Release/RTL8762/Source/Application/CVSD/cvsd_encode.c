/**
*****************************************************************************************
*     Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
  * @file    cvsd_encode.c
  * @brief   cvsd encode.
    * @details
  * @author  Susan_Zhang
  * @date    20-Oct-2015
  * @version v0.2
  ******************************************************************************
    * @attention
  * <h2><center>&copy; COPYRIGHT 2015 Realtek Semiconductor Corporation</center></h2>
  ******************************************************************************
  */
	
#include	"cvsd_encode.h"
#include	"stdint.h"

#define PI 3.1415
#define COEF	0.9845
#define STEP0 10

double step = 6.5;//153
double predict = 0;

char pre1_encode = 10;
char pre2_encode = 10;

//158 bytes
int CVSD_Encode_Bit(short sample)
{
	int encode;

	if (sample >= predict)
	{
		encode = 1;

		if ((pre1_encode != 10) && (pre2_encode != 10))
		{
			if ((encode == 1) && (pre1_encode == 1) && (pre2_encode == 1))
			{
				step = COEF * step + STEP0;
				predict = predict + step;
			}
			else
			{
				step = COEF * step;
				predict = predict+step;
			}
		}
		else
		{
			step = COEF * step;
			predict = predict + step;
		}

	}
	else
	{
		encode = 0;
		if ((pre1_encode != 10) && (pre2_encode != 10))
		{	
			if ((encode == 0) && (pre1_encode == 0) && (pre2_encode == 0))
			{
				step = COEF * step + STEP0;
				predict = predict - step;
			}
			else
			{
				step = COEF * step;
				predict = predict - step;
			}
		}
		else
		{
			step = COEF * step;
			predict = predict - step;
		}
	}

	pre2_encode = pre1_encode;
	pre1_encode = encode;

	return encode;
}

void CVSD_Encode(int16_t *VoiceBuffer, uint8_t* EncodeBuffer, int sample_num)
{
	memset(EncodeBuffer, 0, sample_num / 8);
	int encode_bit;//4
	for(int i = 0; i < sample_num; i++)
	{
		encode_bit = CVSD_Encode_Bit(VoiceBuffer[i]);
		if (encode_bit)
		{
			EncodeBuffer[i / 8] = EncodeBuffer[i / 8] | ((char)0x01 << (i % 8));
		}
	}	
}

//158 bytes
//int CVSD_Encode1(short sample)
//{
//	int encode = (sample >= predict ? 1 : 0);

//	
//	char IsTree = ((encode == pre1_encode) && (pre1_encode == pre2_encode)) ? 1 :0;
//	pre2_encode = pre1_encode;
//	pre1_encode = encode;

//	
//	step = IsTree * STEP0 + COEF * step;

//	
//	char sign = (encode == 1) ? 1: (-1);
//	predict = predict + step * sign;

//	return encode;
//}
