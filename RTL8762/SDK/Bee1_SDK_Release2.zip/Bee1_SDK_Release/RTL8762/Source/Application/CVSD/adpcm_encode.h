/**
************************************************************************************************************
*               Copyright(c) 2014-2015, Realtek Semiconductor Corporation. All rights reserved.
************************************************************************************************************
* @file     adpcm_encode.h
* @brief    
* @author   Susan_Zhang
* @date     2015-10
* @version  v0.1
*************************************************************************************************************
*/

#ifndef __ADPCM_ENCODE_H__
#define __ADPCM_ENCODE_H__

#include	"stdint.h"
typedef struct {
    short	valprev;	/* Previous output value */
    char	index;		/* Index into stepsize table */
}adpcm_state;

int adpcm_coder(short *indata, unsigned char *outdata, int len, adpcm_state *state);

#endif /* __CVSD_ENCODE_H__ */
