/**
*****************************************************************************************
*     Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
  * @file    main.c
  * @brief   This is the entry of user code which the main function resides in.
    * @details
  * @author  Chuanguo Xue
  * @date    29-March-2015
  * @version v0.2
  ******************************************************************************
    * @attention
  * <h2><center>&copy; COPYRIGHT 2015 Realtek Semiconductor Corporation</center></h2>
  ******************************************************************************
  */

#include "rtl876x.h"
#include "rtl876x_rcc.h"
#include "FreeRTOS.h"
#include "task.h"
#include "application.h"
#include "board.h"
#include "profile_init.h"
#include "dlps_platform.h"
#include "rtl876x_pinmux.h"
#include <string.h>
#include "rtl876x_gpio.h"
#include "rtl876x_uart.h"
#include "rtl876x_io_dlps.h"
#include "rtl876x_tim.h"
#include "rtl876x_nvic.h"
#include "rtl876x_tim.h"
#include "math.h"
#include "cvsd_encode.h"
#include "rtl876x_adc.h"
#include "rtl876x_gdma.h"
#include "rtl876x_codec.h"


/* uart command */
#define START_AMIC          0x01
#define STOP_AMIC           0x02

/* queue size & stak size & task priority */
#define IO_DEMO_EVENT_QUEUE_SIZE        0x10
#define IO_DEMO_MESSAGE_QUEUE_SIZE      0x10
#define IO_DEMO_TASK_STACK_SIZE         1024
#define IO_DEMO_TASK_PRIORITY           (tskIDLE_PRIORITY + 1)

#define CVSD_FRAME_SIZE		640
#define VOICE_SAMPLE_NUM	320
#define UART_FRAME_SIZE		40

/* task handle & queue handle */
xTaskHandle IODemoTaskHandle;
xQueueHandle DemoIOMessageQueue;
xQueueHandle DemoIOEventQueue;

SRAM_OFF_BD_DATA_SECTION
int16_t VoiceBuffer[VOICE_SAMPLE_NUM];
char EncodeBuffer[UART_FRAME_SIZE];
int encode_bit;//4
char Encode;

int beg;
int end;
int time;

/**
  * @brief  Board_Init() contains the initialization of pinmux settings and pad settings.
  *         All the pinmux settings and pad settings shall be initiated in this function.
  *         But if legacy driver is used, the initialization of pinmux setting and pad setting
  *         should be peformed with the IO initializing.
  * @param  None
  * @retval None
  */
void Board_Init()
{
    /* Setting all pins to the default state */
    All_Pad_Config_Default();

    /*pin setting */
    {
			  //pinmux and pad config
        Pinmux_Config(UART_TX_PIN, DATA_UART_TX);//P3_0
        Pinmux_Config(UART_RX_PIN, DATA_UART_RX);//P3_1
        Pinmux_Config(KEY_0, GPIO_FUN);//P0_2
        Pinmux_Config(BEEP, GPIO_FUN);//P4_1
        Pinmux_Config(LED_0, GPIO_FUN);//P3_2
	
        Pad_Config(KEY_0, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);//INPUT
        Pad_Config(BEEP, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_LOW);//OUTPUT
        Pad_Config(LED_0, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_LOW);//OUTPUT
        Pad_Config(UART_TX_PIN, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
        Pad_Config(UART_RX_PIN, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);
	
			  //for amic input, must pull none
				Pad_Config(P2_0, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
				Pad_Config(P2_1, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
				
    }

}

/**
  * @brief  Driver_Init() contains the initialization of peripherals.
  *         Both new architecture driver and legacy driver initialization method can be used.
  * @param  None
  * @retval None
  */
void Driver_Init()
{
		//GPIO
    RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
	
    GPIO_InitTypeDef GPIO_Param;        /* Define GPIO parameter structure. KEY Beep LED is configed as GPIO. */
    GPIO_Param.GPIO_Pin = GPIO_GetPin(LED_0) | GPIO_GetPin(BEEP);
    GPIO_Param.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_Param.GPIO_ITCmd = DISABLE;
    GPIO_Init(&GPIO_Param);

//    GPIO_StructInit(&GPIO_Param);
//    GPIO_Param.GPIO_Pin = GPIO_GetPin(KEY_0);
//    GPIO_Param.GPIO_Mode = GPIO_Mode_IN;
//    GPIO_Param.GPIO_ITCmd = ENABLE;
//    GPIO_Param.GPIO_ITTrigger = GPIO_INT_Trigger_LEVEL;
//    GPIO_Param.GPIO_ITPolarity = GPIO_INT_POLARITY_ACTIVE_LOW;
//    GPIO_Init(&GPIO_Param);
//	
//	   
//		GPIO_INTConfig(GPIO_GetPin(KEY_0), ENABLE);
//		NVIC_ClearPendingIRQ(PERIPHERAL_IRQ);
//		NVIC_SetPriority(PERIPHERAL_IRQ, 0);
//		NVIC_EnableIRQ(PERIPHERAL_IRQ);
    
		//timer
//    RCC_PeriphClockCmd(APBPeriph_TIMER, APBPeriph_TIMER_CLOCK, ENABLE);
//    TIM_TimeBaseInitTypeDef TIM_InitStruct;
//    TIM_StructInit(&TIM_InitStruct);
//    TIM_InitStruct.TIM_ClockSrc = TIM_CLOCK_10MHZ;
//    TIM_InitStruct.TIM_Period = KEY_PRESS_DEBOUNCE_TIME * 10000;
//    TIM_InitStruct.TIM_Mode = TIM_Mode_UserDefine;
//    TIM_TimeBaseInit(KEY0_Timer, &TIM_InitStruct);
//    TIM_INTConfig(KEY0_Timer, ENABLE);
	
		//UART
	  RCC_PeriphClockCmd(APBPeriph_UART, APBPeriph_UART_CLOCK, ENABLE);
		
    UART_InitTypeDef uartInitStruct;
    UART_StructInit(&uartInitStruct);
		 /* change to 3M baudrate */
    uartInitStruct.div = 1;
    uartInitStruct.ovsr = 8;
    uartInitStruct.ovsr_adj = 0x492;
    uartInitStruct.rxTriggerLevel = UART_RX_FIFO_TRIGGER_LEVEL_14BYTE;
    UART_Init(UART, &uartInitStruct);
    //enable line status interrupt and rx data avaliable interrupt
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, ENABLE);
		
		//ADC
		RCC_PeriphClockCmd(APBPeriph_ADC, APBPeriph_ADC_CLOCK, ENABLE);
		
		ADC_InitTypeDef adcInitStruct;
    ADC_StructInit(&adcInitStruct);
    /* change to audio mode */
    adcInitStruct.adcMode   = ADC_Audio_Mode;
    adcInitStruct.amicEn    = ADC_AMIC_Enable;
    adcInitStruct.diffModeEn = ANA_DIFF_MODE_ENABLE;    //enable diff mode
    adcInitStruct.adcBurstSize        = 0x10;
    adcInitStruct.adcFifoThd          = 0x20;  
    ADC_Init(ADC, &adcInitStruct);
		
		//GDMA
		RCC_PeriphClockCmd(APBPeriph_GDMA, APBPeriph_GDMA_CLOCK, ENABLE);
		
		GDMA_InitTypeDef GDMA_InitStruct;
    GDMA_StructInit(&GDMA_InitStruct);        
    GDMA_InitStruct.GDMA_ChannelNum             = 1;
    GDMA_InitStruct.GDMA_DIR                    = GDMA_DIR_PeripheralToMemory;
    GDMA_InitStruct.GDMA_BufferSize             = CVSD_FRAME_SIZE / 4;          /* CVSD_FRAME_SIZE */
    GDMA_InitStruct.GDMA_SourceInc              = DMA_SourceInc_Fix;
    GDMA_InitStruct.GDMA_DestinationInc         = DMA_DestinationInc_Inc;
    GDMA_InitStruct.GDMA_SourceDataSize         = GDMA_DataSize_Word;
    GDMA_InitStruct.GDMA_DestinationDataSize    = GDMA_DataSize_Word;
    GDMA_InitStruct.GDMA_SourceMsize            = GDMA_Msize_4;
    GDMA_InitStruct.GDMA_DestinationMsize       = GDMA_Msize_4;
    GDMA_InitStruct.GDMA_SourceAddr             = (uint32_t)((uint32_t*)&(ADC->FIFO));
    GDMA_InitStruct.GDMA_DestinationAddr        = (uint32_t)((uint32_t*)VoiceBuffer);
    GDMA_InitStruct.GDMA_TransferType           = GDMA_TransferType_ADC;
    GDMA_InitStruct.GDMA_ChannelPriority        = 6;                               /*channel prority between 0 to 7*/
    GDMA_Init(GDMA_Channel1, &GDMA_InitStruct);   
    /* enable gdma interrup */
    GDMA_INTConfig(1, GDMA_INT_Transfer, ENABLE);
		
		//CODEC
		RCC_PeriphClockCmd(APBPeriph_CODEC, APBPeriph_CODEC_CLOCK, ENABLE);

    /*Enable IRQ  */
//    NVIC_ClearPendingIRQ(UART_IRQ);
//    NVIC_SetPriority(UART_IRQ, 0);
//    NVIC_EnableIRQ(UART_IRQ);
		NVIC_InitTypeDef NVIC_InitStruct;     
    NVIC_InitStruct.NVIC_IRQChannel = GDMA0_CHANNEL1_IRQ;
    NVIC_InitStruct.NVIC_IRQChannelPriority = 1;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE; 
    NVIC_Init(&NVIC_InitStruct);
		NVIC_InitStruct.NVIC_IRQChannel = UART_IRQ;
    NVIC_InitStruct.NVIC_IRQChannelPriority = 1;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE; 
    NVIC_Init(&NVIC_InitStruct);
}

void IO_DemoTask(void* param)
{
		Board_Init();
    Driver_Init();
		
		CODEC_InitTypeDef codecInitStruct;
    CODEC_StructInit(&codecInitStruct);
		codecInitStruct.micVolume =0x4f; 
	
		B = 0.9845;
		liangjie = 6.5;
		liangjie1 = 10;
//	  B = 1 - ( 1 / (double)(16000 * 0.01));//0.99375
//		liangjie = 2 * PI * 100 * (double)16000 / (double)(64 * 1024);//153
//		liangjie1 = liangjie / 2;//76
		yuce = 0;

		pre1_encode = 10;
		pre2_encode = 10;
	
    uint8_t blkCount = 0;
    uint8_t remainder = 0;
    uint8_t demoStrLen = 0;
    uint8_t i = 0;
    uint8_t event = 0;
    uint8_t rxByte = 0;
    uint8_t* pBuf = EncodeBuffer;
    
    while(1)
    {
        if (xQueueReceive(DemoIOEventQueue, &event, portMAX_DELAY) == pdPASS)//û�г�ʱ���ƣ��������Ϊ��һֱ��������״̬
        {
            /* uart rx event */
            if (event == IO_DEMO_EVENT_UART_RX) 
            {
                /* uart message */
                while (xQueueReceive(DemoIOMessageQueue, &rxByte, 0) == pdPASS)
                {
                    /* start amic */
                    if(rxByte == START_AMIC)
                    {
                        /* start amic */
                        CODEC_Init(CODEC, &codecInitStruct);
                                              
                         /* enable gdma */
                        GDMA_Cmd(1, ENABLE);
											   
												GPIO_SetBits(GPIO_GetPin(LED_0));
 
                        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "Amic started!", 0);
                    }
                    /* stop amic */
                    else if(rxByte == STOP_AMIC)
                    {
                        /* stop amic */
                        
                        CODEC_DeInit(CODEC);
                        /* disable gdma */
                        GDMA_Cmd(1, DISABLE); 
											
												GPIO_ResetBits(GPIO_GetPin(LED_0));
											
                        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "Amic stoped!", 0);
                    }
                }
            }
            
            /* gdma event */
            if (event == IO_DEMO_EVENT_GDMA_RX) 
            {
                DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "Voice gdma rx", 0);
								
								
//								for(int i = 0; i < VOICE_SAMPLE_NUM; i++)
//								{
//									encode_bit = CVSD_Encode(VoiceBuffer[i]);
//									if (encode_bit)
//									{
//										Encode = Encode | ((char)0x01 << (i % 8));
//									}
//									if((i % 8) == 7)
//									{
//										UART_SendByte(UART, Encode);
//										Encode = 0;
//									}
//								}
								beg = read_vendor_counter_no_display();
								for(int i = 0; i < VOICE_SAMPLE_NUM; i++)
								{
									encode_bit = CVSD_Encode(VoiceBuffer[i]);
									if (encode_bit)
									{
										EncodeBuffer[i / 8] = EncodeBuffer[i / 8] | ((char)0x01 << (i % 8));
									}
								}
								
//								for(int i = 0; i < UART_FRAME_SIZE; i++)
//								{
//									UART_SendByte(UART,EncodeBuffer[i]);
//									while(UART_GetFlagState(UART, UART_FLAG_THR_EMPTY) != SET);
//								}
//								memset(EncodeBuffer, 0, sizeof(EncodeBuffer));
								
								blkCount = (UART_FRAME_SIZE) / UART_TX_FIFO_SIZE;
                remainder = (UART_FRAME_SIZE) % UART_TX_FIFO_SIZE;  
								
								/* send voice data through uart */
                for(int i = 0; i < blkCount; i++)
                {
                    /* 1. max send 16 bytes(Uart tx and rx fifo size is 16) */
                    UART_SendData(UART, pBuf, 16);
                    /* wait tx fifo empty */
                    while(UART_GetFlagState(UART, UART_FLAG_THR_EMPTY) != SET);
                    pBuf+= 16;
                }
                
								if(remainder != 0)
								{
										/* send left bytes */
										UART_SendData(UART, pBuf, remainder);
										/* wait tx fifo empty */
										while(UART_GetFlagState(UART, UART_FLAG_THR_EMPTY) != SET);
								}          
                pBuf = EncodeBuffer;
								
                memset(EncodeBuffer, 0, sizeof(EncodeBuffer));
								
								end = read_vendor_counter_no_display();
								time = (end - beg) * 25 / 1000;
//								
//								for(int i = VOICE_SAMPLE_NUM / 2; i < VOICE_SAMPLE_NUM ; i++)
//								{
//									encode_bit = CVSD_Encode(VoiceBuffer[i]);
//									if (encode_bit)
//									{
//										int j = i - VOICE_SAMPLE_NUM / 2;
//										EncodeBuffer[j / 8] = EncodeBuffer[j / 8] | ((char)0x01 << (j % 8));
//									}
//								}
//								
//								blkCount = (UART_FRAME_SIZE) / UART_TX_FIFO_SIZE;
//                remainder = (UART_FRAME_SIZE) % UART_TX_FIFO_SIZE;  
//								
//								/* send voice data through uart */
//                for(int i = 0; i < blkCount; i++)
//                {
//                    /* 1. max send 16 bytes(Uart tx and rx fifo size is 16) */
//                    UART_SendData(UART, pBuf, 16);
//                    /* wait tx fifo empty */
//                    while(UART_GetFlagState(UART, UART_FLAG_THR_EMPTY) != SET);
//                    pBuf+= 16;
//                }
//                
//								if(remainder != 0)
//								{
//										/* send left bytes */
//										UART_SendData(UART, pBuf, remainder);
//										/* wait tx fifo empty */
//										while(UART_GetFlagState(UART, UART_FLAG_THR_EMPTY) != SET);
//								}          
//                pBuf = VoiceBuffer;
//								
//                memset(EncodeBuffer, 0, sizeof(EncodeBuffer));
								
                /* reset destination address */
                GDMA_SetDestinationAddress(GDMA_Channel1, (uint32_t)(VoiceBuffer));
                /* enable gdma gagin */
                GDMA_Cmd(1, ENABLE);
            }
        }
    }
}


int main(void)
{
		/* create io test task */
    xTaskCreate(IO_DemoTask, "IO_Demo", IO_DEMO_TASK_STACK_SIZE / sizeof(portSTACK_TYPE), NULL, IO_DEMO_TASK_PRIORITY, &IODemoTaskHandle);
    
    /* create event queue and message queue */
    DemoIOEventQueue = xQueueCreate(IO_DEMO_EVENT_QUEUE_SIZE, sizeof(char));
    DemoIOMessageQueue = xQueueCreate(IO_DEMO_MESSAGE_QUEUE_SIZE, sizeof(char));
    
    /* start task schedule */
    vTaskStartScheduler();
		

    return 0;
}
