/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     rtl876x_it.c
* @brief    Amic demo interrupt handle
* @details
* @author   tifnan
* @date     2015-05-28
* @version  v0.1
*********************************************************************************************************
*/

#include "freeRTOS.h"
#include "task.h"
#include "queue.h"
#include "rtl876x_uart.h"
#include "rtl876x_gdma.h"
#include "rtl876x_gpio.h"
#include "rtl876x_tim.h"
#include "board.h"
#include "trace.h"

uint8_t keystatus = 1;
uint8_t isPress = FALSE;

void DataUartIntrHandler(void)
{
    uint32_t int_status = 0;
    uint8_t event = 0;
    uint8_t rxByte = 0;
    portBASE_TYPE TaskWoken = pdFALSE;
    
    /* read interrupt id */
    int_status = UART_GetIID(UART);
    /* disable interrupt */
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, DISABLE);
    
    switch(int_status)
    {
        /* tx fifo empty, not enable */
        case UART_INT_ID_TX_EMPTY:
        break;

        /* rx data valiable */
        case UART_INT_ID_RX_LEVEL_REACH:
            /* rx trigger is 14, not possible */
            break;
        
        case UART_INT_ID_RX_TMEOUT:
            while(UART_GetFlagState(UART, UART_FLAG_RX_DATA_RDY) == SET)
            {
                rxByte = UART_ReceiveByte(UART);
            }
            
            event = IO_DEMO_EVENT_UART_RX;
            /* send message to DemoIO task */
            xQueueSendFromISR(DemoIOMessageQueue, &rxByte, &TaskWoken);
            xQueueSendFromISR(DemoIOEventQueue, &event, &TaskWoken);
        break;
        
        /* receive line status interrupt */
        case UART_INT_ID_LINE_STATUS:
            DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "Line status error!!!!\n", 0);
        break;      

        default:
        break;
    }
    
    /* enable interrupt again */
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, ENABLE);
    portEND_SWITCHING_ISR(TaskWoken);
    
    return;
}

void Gdma0Ch1IntrHandler(void)
{
    uint8_t event = 0;
    portBASE_TYPE TaskWoken = pdFALSE;
    
    DBG_BUFFER(MODULE_LTP, LEVEL_ERROR, "Gdma0Ch1IntrHandler", 0);

    GDMA_ClearAllTypeINT(1);
    
    GDMA_Cmd(1, DISABLE);

    /* send voice data in task */
    event = IO_DEMO_EVENT_GDMA_RX;
    
    /* send event to DemoIO task */
    xQueueSendFromISR(DemoIOEventQueue, &event, &TaskWoken);
    
    portEND_SWITCHING_ISR(TaskWoken);
    
    return;
}

//void Key0GpioIntrHandler()
//{
//    keystatus = GPIO_ReadInputDataBit(GPIO_GetPin(KEY_0));
//    /*  Mask GPIO interrupt */
//    GPIO_INTConfig(GPIO_GetPin(KEY_0), DISABLE);
//    GPIO_MaskINTConfig(GPIO_GetPin(KEY_0), ENABLE);
//    GPIO_ClearINTPendingBit(GPIO_GetPin(KEY_0));

//    //DBG_BUFFER(MODULE_APP, LEVEL_INFO, "Enter Key0 intr\n", 0);
//    if (isPress == FALSE) {
//        /* delay 16ms to read the GPIO status */
//        TIM_ChangePeriod(KEY0_Timer, KEY_PRESS_DEBOUNCE_TIME * 10000);
//    } else {
//        /* delay 32ms to read the GPIO status */
//        TIM_ChangePeriod(KEY0_Timer, KEY_RELEASE_DEBOUNCE_TIME * 10000);
//    }
//    //TIM_Cmd(KEY0_Timer, ENABLE);
//		GPIO_SetBits(GPIO_GetPin(LED_0));
//    GPIO_MaskINTConfig(GPIO_GetPin(KEY_0), DISABLE);
//    GPIO_INTConfig(GPIO_GetPin(KEY_0), ENABLE);
//}

//void Key0TimerIntrHandler()
//{
//    long xHigherPriorityTaskWoken = pdFALSE;
//    TIM_Cmd(KEY0_Timer, DISABLE);
//    TIM_ClearINT(KEY0_Timer);
//    //DBG_BUFFER(MODULE_KEYSCAN, LEVEL_INFO, " SEND MSG.", 0);

//    if (keystatus != GPIO_ReadInputDataBit(GPIO_GetPin(KEY_0)))
//    {
//        GPIO_MaskINTConfig(GPIO_GetPin(KEY_0), DISABLE);
//        GPIO_INTConfig(GPIO_GetPin(KEY_0), ENABLE);
//        return;
//    }

//    /* Change GPIO Interrupt Polarity, Enable Interrupt */
//    GPIO->INTPOLARITY &= ~GPIO_GetPin(KEY_0);       //Polarity Low

//    if (keystatus)                                         //If left button released
//    {
//        isPress = FALSE;
//    }
//    else                                                                //If left button pressed.
//    {
//        GPIO->INTPOLARITY |= GPIO_GetPin(KEY_0);        //Polarity High
//        isPress = TRUE;
//    }
//		GPIO_SetBits(GPIO_GetPin(LED_0));
//    GPIO_MaskINTConfig(GPIO_GetPin(KEY_0), DISABLE);
//    GPIO_INTConfig(GPIO_GetPin(KEY_0), ENABLE);
//}
