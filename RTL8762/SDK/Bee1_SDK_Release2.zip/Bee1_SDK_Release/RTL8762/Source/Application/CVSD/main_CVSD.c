/**
*****************************************************************************************
*     Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
  * @file    main.c
  * @brief   This is the entry of user code which the main function resides in.
    * @details
  * @author  Chuanguo Xue
  * @date    29-March-2015
  * @version v0.2
  ******************************************************************************
    * @attention
  * <h2><center>&copy; COPYRIGHT 2015 Realtek Semiconductor Corporation</center></h2>
  ******************************************************************************
  */

#include "rtl876x.h"
#include "rtl876x_rcc.h"
#include "FreeRTOS.h"
#include "task.h"
#include "application.h"
#include "board.h"
#include "profile_init.h"
#include "dlps_platform.h"
#include "rtl876x_pinmux.h"
#include <string.h>
#include "rtl876x_gpio.h"
#include "rtl876x_uart.h"
#include "rtl876x_io_dlps.h"
#include "rtl876x_tim.h"
#include "rtl876x_nvic.h"
#include "rtl876x_tim.h"
#include "math.h"
#include "cvsd_encode.h"

#define TIM_ID   TIM2
#define TIM_GPIOTEST			P2_4

#define BUF_SIZE 16 * 20

xQueueHandle hEventQueueHandle;
xQueueHandle hIoQueueHandle;

uint8_t RxBuffer[100];
uint8_t RxCount = 0;
uint8_t RxEndFlag = 0;

short sinBuf[BUF_SIZE];

//4 * 2 = 8 bytes
int my_index; //4
int encode_bit;//4

char Encode;

uint64_t beg = 0;
uint64_t end = 0;


/**
  * @brief  Board_Init() contains the initialization of pinmux settings and pad settings.
  *         All the pinmux settings and pad settings shall be initiated in this function.
  *         But if legacy driver is used, the initialization of pinmux setting and pad setting
  *         should be peformed with the IO initializing.
  * @param  None
  * @retval None
  */
void Board_Init()
{
    /* Setting all pins to the default state */
    All_Pad_Config_Default();

    /* PXP pin setting */
    {
			      //pinmux and pad config
        Pinmux_Config(UART_TX_PIN, DATA_UART_TX);//P3_0
        Pinmux_Config(UART_RX_PIN, DATA_UART_RX);//P3_1
        Pinmux_Config(KEY_0, GPIO_FUN);//P0_2
        Pinmux_Config(BEEP, GPIO_FUN);//P4_1
        Pinmux_Config(LED_0, GPIO_FUN);//P3_2
				Pinmux_Config(TIM_GPIOTEST, GPIO_FUN);//P0_5
			
        Pad_Config(KEY_0, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);//INPUT
        Pad_Config(BEEP, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_LOW);//OUTPUT
        Pad_Config(LED_0, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_LOW);//OUTPUT
        Pad_Config(UART_TX_PIN, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
        Pad_Config(UART_RX_PIN, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);
				Pad_Config(TIM_GPIOTEST, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
				
    }

}

/**
  * @brief  PwrMgr_Init() contains the setting about power mode.
  * @param  None
  * @retval None
  */
void PwrMgr_Init()
{
    System_WakeUp_Pin_Enable(KEY_0, 0);

#if CONFIG_DLPS_EN
    DLPS_IO_Register();

    if (FALSE == DLPS_ENTER_CHECK_CB_REG(DLPS_ProximityCheck))
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "Error: DLPS_ENTER_CHECK_CB_REG(DLPS_ProximityCheck) failed!\n", 0);
    }
    DLPS_IO_RegUserDlpsEnterCb(Proximity_DLPS_Enter);
    DLPS_IO_RegUserDlpsExitCb(Proximity_DLPS_Exit);
    LPS_MODE_Set(LPM_DLPS_MODE);
#else
    LPS_MODE_Pause();
#endif
}

/**
  * @brief  Driver_Init() contains the initialization of peripherals.
  *         Both new architecture driver and legacy driver initialization method can be used.
  * @param  None
  * @retval None
  */
void Driver_Init()
{
    RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
    GPIO_InitTypeDef GPIO_Param;        /* Define GPIO parameter structure. KEY Beep LED is configed as GPIO. */
    GPIO_Param.GPIO_Pin = GPIO_GetPin(LED_0) | GPIO_GetPin(BEEP);
    GPIO_Param.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_Param.GPIO_ITCmd = DISABLE;
    GPIO_Init(&GPIO_Param);

    GPIO_StructInit(&GPIO_Param);
    GPIO_Param.GPIO_Pin = GPIO_GetPin(KEY_0);
    GPIO_Param.GPIO_Mode = GPIO_Mode_IN;
    GPIO_Param.GPIO_ITCmd = ENABLE;
    GPIO_Param.GPIO_ITTrigger = GPIO_INT_Trigger_LEVEL;
    GPIO_Param.GPIO_ITPolarity = GPIO_INT_POLARITY_ACTIVE_LOW;
    GPIO_Init(&GPIO_Param);
	
    GPIO_StructInit(&GPIO_Param);
		GPIO_Param.GPIO_Pin  = GPIO_GetPin(TIM_GPIOTEST);
		GPIO_Param.GPIO_Mode = GPIO_Mode_OUT;
		GPIO_Param.GPIO_ITCmd = DISABLE;
		GPIO_Param.GPIO_ITTrigger = GPIO_INT_Trigger_LEVEL;
		GPIO_Param.GPIO_ITPolarity = GPIO_INT_POLARITY_ACTIVE_LOW;
		GPIO_Param.GPIO_ITDebounce = GPIO_INT_DEBOUNCE_DISABLE;
    
		GPIO_Init(&GPIO_Param);
		GPIO_SetBits(GPIO_GetPin(TIM_GPIOTEST));
	
	  RCC_PeriphClockCmd(APBPeriph_UART, APBPeriph_UART_CLOCK, ENABLE);
    //uart init
    UART_InitTypeDef uartInitStruct;
    UART_StructInit(&uartInitStruct);

    uartInitStruct.rxTriggerLevel = UART_RX_FIFO_TRIGGER_LEVEL_14BYTE;
    UART_Init(UART, &uartInitStruct);
    //enable line status interrupt and rx data avaliable interrupt
    UART_INTConfig(UART, UART_INT_RD_AVA | UART_INT_LINE_STS, ENABLE);

    /*  Enable UART IRQ  */
    NVIC_ClearPendingIRQ(UART_IRQ);
    NVIC_SetPriority(UART_IRQ, 0);
    NVIC_EnableIRQ(UART_IRQ);
		
		RCC_PeriphClockCmd(APBPeriph_TIMER, APBPeriph_TIMER_CLOCK, ENABLE);
		TIM_TimeBaseInitTypeDef TIM_InitStruct;
		TIM_StructInit(&TIM_InitStruct);
		TIM_InitStruct.TIM_ClockSrc = TIM_CLOCK_10MHZ;
		TIM_InitStruct.TIM_Period = 625;
		TIM_InitStruct.TIM_Mode = 1;
		TIM_TimeBaseInit(TIM_ID, &TIM_InitStruct);
    
		NVIC_InitTypeDef NVIC_InitStruct;
		NVIC_InitStruct.NVIC_IRQChannel = TIMER2_IRQ;
		NVIC_InitStruct.NVIC_IRQChannelPriority = 0;
		NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
		NVIC_Init(&NVIC_InitStruct);

		TIM_ClearINT(TIM_ID);
    TIM_INTConfig(TIM_ID,ENABLE);
		TIM_Cmd(TIM_ID, ENABLE);
}


int main(void)
{

		B = 0.9845;
		liangjie = 6.5;
		liangjie1 = 10;
//	  B = 1 - ( 1 / (double)(16000 * 0.01));//0.99375
//		liangjie = 2 * PI * 100 * (double)16000 / (double)(64 * 1024);//153
//		liangjie1 = liangjie / 2;//76
		yuce = 0;

		pre1_encode = 10;
		pre2_encode = 10;
	
		for(int i = 0; i < BUF_SIZE; i++)
		{
			double temp = (double)i * 3.14 / 8;
			sinBuf[i] = (short)(10000 * sin(temp));
		}
	
    Board_Init();
		PwrMgr_Init();
    Driver_Init();
		
		while(1)
		{
		}

    return 0;
}

//86 bytes
void Timer2IntrHandler(void)
{	

	if(my_index < BUF_SIZE)
	{
		GPIO_SetBits(GPIO_GetPin(TIM_GPIOTEST));
		beg = read_vendor_counter_no_display();
		encode_bit = CVSD_Encode(sinBuf[my_index]);
		if (encode_bit)
		{
			Encode = Encode | ((char)0x01 << (my_index % 8));
		}
		end = read_vendor_counter_no_display();
		
		end = (end -beg) * 25 / 1000;
		
		GPIO_ResetBits(GPIO_GetPin(TIM_GPIOTEST));
		
		if((my_index % 8) == 7)
		{
			UART_SendByte(UART, Encode);
			Encode = 0;
		}
		
		my_index++;		
	}

	TIM_ClearINT(TIM_ID);    
}
