/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      observerFullTestApp_application.c
* @brief     Observer full test application implementation
* @details   Observer full test application implementation
* @author    ranhui Xue
* @date      2015-03-27
* @version   v0.2
* *********************************************************************************************************
*/
#include "rtl876x.h"
#include "application.h"
#include "observerFullTestApp_application.h"

#include "bee_message.h"
#include "trace.h"

#include "bee_message.h"
#include "observer.h"
#include "gap.h"
#include "gapbondmgr.h"
#include <string.h>


#include "board.h"
#include "keyscan.h"


/* Keypad key mapping */
const UINT8 App_Keymap[MOUSE_KEYPAD_ROW_SIZE][MOUSE_KEYPAD_COLUMN_SIZE] =

{
    {VK_F,      VK_E,           VK_D,           VK_C},
    {VK_B,      VK_A,           VK_9,           VK_8},
    {VK_7,       VK_6,           VK_5,           VK_4},
    {VK_3,       VK_2,           VK_1,           VK_0},

};


BOOL bIsKeyPress = FALSE;

gaprole_States_t gapProfileState = GAPSTATE_INIT;




void observer_HandleKeyEvent(KEYSCAN_DATA_STRUCT *pKey_Data)
{
    UINT32 i;
    UINT8 keyCode;

    for (i = 0; i < pKey_Data->Length; i++)
    {
        DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "%d/%d: (row, column) = (%d, %d) n", 4, i + 1, pKey_Data->Length, pKey_Data->key[i].row, pKey_Data->key[i].column);
        keyCode = App_Keymap[pKey_Data->key[i].row][pKey_Data->key[i].column];
        switch (keyCode)
        {
        case VK_0:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_0\n\n", 0);
                observer_StartScan();
            }
            break;
        case VK_1:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_1\n\n", 0);
            }
            break;
        case VK_2:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_2\n\n", 0);
            }
            break;
        case VK_3:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_3\n\n", 0);
            }
            break;
        case VK_4:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_4\n\n", 0);
            }
            break;
        case VK_5:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_5\n\n", 0);
            }
            break;
        case VK_6:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_6\n\n", 0);
            }
            break;
        case VK_7:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_7\n\n", 0);
            }
            break;
        case VK_8:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_8\n\n", 0);
            }
            break;
        case VK_9:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_9\n\n", 0);
            }
            break;
        case VK_A:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_A\n\n", 0);

            }
            break;
        case VK_B:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_B\n\n", 0);
            }
            break;
        case VK_C:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_C\n\n", 0);
            }
            break;
        case VK_D:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_D\n\n", 0);
            }
            break;
        case VK_E:
            DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_E\n\n", 0);
            break;
        case VK_F:
            DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_F\n\n", 0);
            observer_StopScan();
            break;
        default:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "Unknown key keyCode: 0x%x\n\n", 1, keyCode);
            }
            break;
        }
    }
}



void observer_HandleBtGapMessage(BEE_IO_MSG  *pBeeIoMsg);


/**
* @brief  All the application events are pre-handled in this function.
*
* All the IO MSGs are sent to this function.
* Then the event handling function shall be called according to the MSG type.
*
* @param   io_driver_msg_recv  The BEE_IO_MSG from peripherals or BT stack state machine.
* @return  void
*/
void AppHandleIODriverMessage(BEE_IO_MSG io_driver_msg_recv)
{
    UINT16 msgtype = io_driver_msg_recv.IoType;

    switch (msgtype)
    {
    case IO_KEYSCAN_MSG_TYPE:
        if (io_driver_msg_recv.subType == MSG_KEYSCAN_RX_PKT)
        {
            bIsKeyPress = TRUE;
            observer_HandleKeyEvent(io_driver_msg_recv.pBuf);
            break;
        }

        break;
    case BT_STATUS_UPDATE:
        {

            observer_HandleBtGapMessage(&io_driver_msg_recv);
        }
        break;
    default:
        break;
    }
}

void observer_HandleBtGapStateChangeEvt(uint8_t newState)
{
    switch ( newState )
    {
    case GAPSTATE_IDLE_NO_SCAN_NO_CONN:
        {

        }

        break;

    case GAPSTATE_SCANNING:
        {

        }
        break;



    default:
        {

        }
        break;

    }

    gapProfileState = (gaprole_States_t)newState;
}

void observer_HandleBtGapBondStateChangeEvt(uint8_t newState)
{

    switch (newState)
    {
    case GAPBOND_PAIRING_STATE_STARTED:
        {
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(GAPBOND_PAIRING_STATE_STARTED)", 0);
        }
        break;

    case GAPBOND_PAIRING_STATE_COMPLETE:
        {
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(GAPBOND_PAIRING_STATE_COMPLETE)", 0);
        }
        break;

    case GAPBOND_PAIRING_STATE_BONDED:
        {
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(GAPBOND_PAIRING_STATE_BONDED)", 0);
        }
        break;

    default:
        {
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(unknown newstate: %d)", 1, newState);
        }
        break;
    }

}


void observer_HandleBtGapEncryptStateChangeEvt(uint8_t newState)
{
    switch (newState)
    {
    case GAPBOND_ENCRYPT_STATE_ENABLED:
        {
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "GAPBOND_ENCRYPT_STATE_ENABLED", 0);
        }
        break;

    case GAPBOND_ENCRYPT_STATE_DISABLED:
        {
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "GAPBOND_ENCRYPT_STATE_DISABLED", 0);
        }
        break;

    default:
        break;
    }
}




/**
* @brief
*
*
* @param   pBtStackMsg
* @return  void
*/
void observer_HandleBtGapMessage(BEE_IO_MSG  *pBeeIoMsg)
{
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "observer_HandleBtGapMessage subType = %d", 1, pBeeIoMsg->subType);
    BT_STACK_MSG BtStackMsg;
    memcpy(&BtStackMsg, &pBeeIoMsg->parm, sizeof(pBeeIoMsg->parm));

    switch (pBeeIoMsg->subType)
    {
    case BT_MSG_TYPE_CONN_STATE_CHANGE:
        {
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_CONN_STATE_CHANGE:(%d->%d)",
                       2, gapProfileState, BtStackMsg.msgData.gapConnStateChange.newState);

            observer_HandleBtGapStateChangeEvt(BtStackMsg.msgData.gapConnStateChange.newState);
        }
        break;



    default:
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "observer_HandleBtGapMessage unknown subtype", 1, pBeeIoMsg->subType);

        break;

    }

}

/* This callback will be called when advertising or scan response data received. */
void App_ObserverRoleCallback(TObserverAppCB_MsgType msgType, TObserverAppCB_MsgData observerCbData)
{
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "App_ObserverRoleCallback: msgType = %d", 1, msgType);
    switch(msgType)
    {
        case ADV_SCAN_RSP_DATA_MSGTYPE:
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "  ADV_SCAN_RSP_DATA_MSGTYPE: bd = 0x%x,0x%x,0x%x,0x%x,0x%x,0x%x, bdtype=%d, event=0x%x, rssi=%d, len=%d",
                10, observerCbData.pAdvScanRspData->remote_BD[5],
                   observerCbData.pAdvScanRspData->remote_BD[4],
                   observerCbData.pAdvScanRspData->remote_BD[3],
                   observerCbData.pAdvScanRspData->remote_BD[2],
                   observerCbData.pAdvScanRspData->remote_BD[1],
                   observerCbData.pAdvScanRspData->remote_BD[0],
                   observerCbData.pAdvScanRspData->remote_BD_type,
                   observerCbData.pAdvScanRspData->advType,
                   observerCbData.pAdvScanRspData->rssi,
                   observerCbData.pAdvScanRspData->dataLength);
            break;
        default:
            break;
    }
}

uint16_t AppHandleGATTCallback(void* pData)
{

    return TRUE;
}


