/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     broadcaster_stack_api.c 
* @brief    .
* @details
* @author   ranhui
* @date     2015-03-27
* @version  v0.2
*********************************************************************************************************
*/
#include "rtl876x.h"
#include "bee_message.h"

#include "trace.h"
#include <blueapi.h>



#include "broadcaster.h"
#include "gap.h"
#include "gapbondmgr.h"



void broadcaster_StartAdv_ind()
{

    //advertising parameters
    uint8_t  advEventType = GAP_ADTYPE_ADV_IND;
    uint8_t  advChanMap = GAP_ADVCHAN_ALL;
    uint8_t  advFilterPolicy = GAP_FILTER_POLICY_ALL;
    uint16_t advIntMin = 0x80;
    uint16_t advIntMax = 0x80;
    broadcasterSetGapParameter( GAPPRRA_ADV_EVENT_TYPE, sizeof ( advEventType ), &advEventType );
    broadcasterSetGapParameter( GAPPRRA_ADV_CHANNEL_MAP, sizeof ( advChanMap ), &advChanMap );
    broadcasterSetGapParameter( GAPPRRA_ADV_FILTER_POLICY, sizeof ( advFilterPolicy ), &advFilterPolicy );
    broadcasterSetGapParameter(GAPPRRA_ADV_INTERVAL_MIN, sizeof(advIntMin), &advIntMin);
    broadcasterSetGapParameter(GAPPRRA_ADV_INTERVAL_MAX, sizeof(advIntMax), &advIntMax);



    broadcaster_StartAdvertising();
}


void broadcaster_StartAdv_ind_with_whitelist()
{

    //advertising parameters
    uint8_t  advEventType = GAP_ADTYPE_ADV_IND;
    uint8_t  advChanMap = GAP_ADVCHAN_ALL;
    uint8_t  advFilterPolicy = GAP_FILTER_POLICY_WHITE;
    uint16_t advIntMin = 0x80;
    uint16_t advIntMax = 0x80;


    uint8_t  whiteListAddrType = PEER_ADDRTYPE_PUBLIC;
    uint8_t  whiteListAddr[B_ADDR_LEN] = {0};


    broadcasterSetGapParameter( GAPPRRA_ADV_EVENT_TYPE, sizeof ( advEventType ), &advEventType );
    broadcasterSetGapParameter( GAPPRRA_ADV_CHANNEL_MAP, sizeof ( advChanMap ), &advChanMap );
    broadcasterSetGapParameter( GAPPRRA_ADV_FILTER_POLICY, sizeof ( advFilterPolicy ), &advFilterPolicy );
    broadcasterSetGapParameter(GAPPRRA_ADV_INTERVAL_MIN, sizeof(advIntMin), &advIntMin);
    broadcasterSetGapParameter(GAPPRRA_ADV_INTERVAL_MAX, sizeof(advIntMax), &advIntMax);



    broadcaster_StartAdvertising();
}




void broadcaster_StartAdv_scan_ind()
{
    //advertising parameters
    uint8_t  advEventType = GAP_ADTYPE_ADV_SCAN_IND;
    uint8_t  advChanMap = GAP_ADVCHAN_ALL;
    uint8_t  advFilterPolicy = GAP_FILTER_POLICY_ALL;
    uint16_t advIntMin = 0x80;
    uint16_t advIntMax = 0x80;
    broadcasterSetGapParameter( GAPPRRA_ADV_EVENT_TYPE, sizeof ( advEventType ), &advEventType );
    broadcasterSetGapParameter( GAPPRRA_ADV_CHANNEL_MAP, sizeof ( advChanMap ), &advChanMap );
    broadcasterSetGapParameter( GAPPRRA_ADV_FILTER_POLICY, sizeof ( advFilterPolicy ), &advFilterPolicy );
    broadcasterSetGapParameter(GAPPRRA_ADV_INTERVAL_MIN, sizeof(advIntMin), &advIntMin);
    broadcasterSetGapParameter(GAPPRRA_ADV_INTERVAL_MAX, sizeof(advIntMax), &advIntMax);

    broadcaster_StartAdvertising();
}

void broadcaster_StartAdv_noconn_ind()
{
    //advertising parameters
    uint8_t  advEventType = GAP_ADTYPE_ADV_NONCONN_IND;
    uint8_t  advChanMap = GAP_ADVCHAN_ALL;
    uint8_t  advFilterPolicy = GAP_FILTER_POLICY_ALL;
    uint16_t advIntMin = 0x80;
    uint16_t advIntMax = 0x80;
    broadcasterSetGapParameter( GAPPRRA_ADV_EVENT_TYPE, sizeof ( advEventType ), &advEventType );
    broadcasterSetGapParameter( GAPPRRA_ADV_CHANNEL_MAP, sizeof ( advChanMap ), &advChanMap );
    broadcasterSetGapParameter( GAPPRRA_ADV_FILTER_POLICY, sizeof ( advFilterPolicy ), &advFilterPolicy );
    broadcasterSetGapParameter(GAPPRRA_ADV_INTERVAL_MIN, sizeof(advIntMin), &advIntMin);
    broadcasterSetGapParameter(GAPPRRA_ADV_INTERVAL_MAX, sizeof(advIntMax), &advIntMax);

    broadcaster_StartAdvertising();
}

void broadcaster_StartAdv_direct_ind_hd()
{
    uint8_t  advEventType = GAP_ADTYPE_ADV_HDC_DIRECT_IND;
    uint8_t  advDirectAddrType = PEER_ADDRTYPE_PUBLIC;
    uint8_t  advDirectAddr[B_ADDR_LEN] = {0};
    uint8_t  advChanMap = GAP_ADVCHAN_ALL;



    broadcasterSetGapParameter( GAPPRRA_ADV_EVENT_TYPE, sizeof ( advEventType ), &advEventType );
    broadcasterSetGapParameter( GAPPRRA_ADV_DIRECT_ADDR_TYPE, sizeof ( advDirectAddrType ), &advDirectAddrType );
    broadcasterSetGapParameter( GAPPRRA_ADV_DIRECT_ADDR, sizeof ( advDirectAddr ), advDirectAddr );
    broadcasterSetGapParameter( GAPPRRA_ADV_CHANNEL_MAP, sizeof ( advChanMap ), &advChanMap );


    broadcaster_StartAdvertising();
}

void broadcaster_StartAdv_direct_ind_ld()
{
    uint8_t  advEventType = GAP_ADTYPE_ADV_LDC_DIRECT_IND;
    uint8_t  advDirectAddrType = PEER_ADDRTYPE_PUBLIC;
    uint8_t  advDirectAddr[B_ADDR_LEN] = {0};

    uint8_t  advChanMap = GAP_ADVCHAN_ALL;
    uint16_t advIntMin = 0x80;
    uint16_t advIntMax = 0x80;



    broadcasterSetGapParameter( GAPPRRA_ADV_EVENT_TYPE, sizeof ( advEventType ), &advEventType );
    broadcasterSetGapParameter( GAPPRRA_ADV_DIRECT_ADDR_TYPE, sizeof ( advDirectAddrType ), &advDirectAddrType );
    broadcasterSetGapParameter( GAPPRRA_ADV_DIRECT_ADDR, sizeof ( advDirectAddr ), advDirectAddr );
    broadcasterSetGapParameter( GAPPRRA_ADV_CHANNEL_MAP, sizeof ( advChanMap ), &advChanMap );
    broadcasterSetGapParameter(GAPPRRA_ADV_INTERVAL_MIN, sizeof(advIntMin), &advIntMin);
    broadcasterSetGapParameter(GAPPRRA_ADV_INTERVAL_MAX, sizeof(advIntMax), &advIntMax);

    broadcaster_StartAdvertising();
}

void broadcaster_StopAdv()
{
    broadcaster_StopAdvertising();
}

