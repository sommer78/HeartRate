/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      hids.h
* @brief     
* @details   
* @author    Chuanguo Xue
* @date      2015-3-27
* @version   v0.1
* *********************************************************************************************************
*/


#ifndef _HIDS_H
#define _HIDS_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "rtl876x.h"
#include "rtl876x_bitfields.h"

extern void HIDDemo_profileInit(void);
	 
#ifdef __cplusplus
}
#endif

#endif /* __HIDS_H */
