/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      broadcasterFullTestApp_application.c
* @brief     Broadcaster full test application implementation
* @details   Broadcaster full test application implementation
* @author    ranhui
* @date      2015-03-27
* @version   v0.2
* *********************************************************************************************************
*/
#include "rtl876x.h"
#include "application.h"
#include "broadcasterFullTestApp_application.h"

#include "bee_message.h"
#include "trace.h"

#include "bee_message.h"
#include "broadcaster.h"
#include "gap.h"
#include "broadcaster_stack_api.h"
#include <string.h>

#include "board.h"
#include "keyscan.h"



/* Keypad key mapping */
const UINT8 App_Keymap[MOUSE_KEYPAD_ROW_SIZE][MOUSE_KEYPAD_COLUMN_SIZE] =

{
    {VK_F,      VK_E,           VK_D,           VK_C},
    {VK_B,      VK_A,           VK_9,           VK_8},
    {VK_7,       VK_6,           VK_5,           VK_4},
    {VK_3,       VK_2,           VK_1,           VK_0},

};




BOOL bIsKeyPress = FALSE;

gaprole_States_t gapProfileState = GAPSTATE_INIT;

void broadcaster_HandleBtGapMessage(BEE_IO_MSG  *pBeeIoMsg);


void broadcaster_HandleKeyEvent(KEYSCAN_DATA_STRUCT *pKey_Data)
{
    UINT32 i;
    UINT8 keyCode;

    for (i = 0; i < pKey_Data->Length; i++)
    {
        DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "%d/%d: (row, column) = (%d, %d) n", 4, i + 1, pKey_Data->Length, pKey_Data->key[i].row, pKey_Data->key[i].column);
        keyCode = App_Keymap[pKey_Data->key[i].row][pKey_Data->key[i].column];
        switch (keyCode)
        {
        case VK_0:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_0\n\n", 0);
                broadcaster_StartAdv_ind();
            }
            break;
        case VK_1:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_1\n\n", 0);
                broadcaster_StartAdv_scan_ind();
            }
            break;
        case VK_2:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_2\n\n", 0);
                broadcaster_StartAdv_noconn_ind();
            }
            break;
        case VK_3:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_3\n\n", 0);
            }
            break;
        case VK_4:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_4\n\n", 0);
            }
            break;
        case VK_5:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_5\n\n", 0);
            }
            break;
        case VK_6:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_6\n\n", 0);
            }
            break;
        case VK_7:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_7\n\n", 0);
            }
            break;
        case VK_8:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_8\n\n", 0);
            }
            break;
        case VK_9:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_9\n\n", 0);
            }
            break;
        case VK_A:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_A\n\n", 0);

            }
            break;
        case VK_B:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_B\n\n", 0);
            }
            break;
        case VK_C:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_C\n\n", 0);
            }
            break;
        case VK_D:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_D\n\n", 0);
            }
            break;
        case VK_E:
            DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_E\n\n", 0);
            break;
        case VK_F:
            DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "VK_F\n\n", 0);
            broadcaster_StopAdv();
            break;
        default:
            if (bIsKeyPress)
            {
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "Unknown key keyCode: 0x%x\n\n", 1, keyCode);
            }
            break;
        }
    }
}


/**
* @brief  All the application events are pre-handled in this function.
*
* All the IO MSGs are sent to this function.
* Then the event handling function shall be called according to the MSG type.
*
* @param   io_driver_msg_recv  The BEE_IO_MSG from peripherals or BT stack state machine.
* @return  void
*/
void AppHandleIODriverMessage(BEE_IO_MSG io_driver_msg_recv)
{
    UINT16 msgtype = io_driver_msg_recv.IoType;

    switch (msgtype)
    {



    case IO_KEYSCAN_MSG_TYPE:
        if (io_driver_msg_recv.subType == MSG_KEYSCAN_RX_PKT)
        {
            bIsKeyPress = TRUE;
            broadcaster_HandleKeyEvent(io_driver_msg_recv.pBuf);
            break;
        }

        break;


    case BT_STATUS_UPDATE:
        {

            broadcaster_HandleBtGapMessage(&io_driver_msg_recv);
        }
        break;
    default:
        break;
    }
}

/**
* @brief
*
*
* @param   pBtStackMsg
* @return  void
*/
void broadcaster_HandleBtGapMessage(BEE_IO_MSG  *pBeeIoMsg)
{
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "broadcaster_HandleBtGapMessage subType = %d", 1, pBeeIoMsg->subType);
    BT_STACK_MSG BtStackMsg;
    memcpy(&BtStackMsg, &pBeeIoMsg->parm, sizeof(pBeeIoMsg->parm));

    switch (pBeeIoMsg->subType)
    {
    case BT_MSG_TYPE_CONN_STATE_CHANGE:
        {
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_CONN_STATE_CHANGE:(%d->%d)",
                       2, gapProfileState, BtStackMsg.msgData.gapConnStateChange.newState);


            switch ( BtStackMsg.msgData.gapConnStateChange.newState )
            {
            case GAPSTATE_STACK_READY:
                {

                }
                break;

            case GAPSTATE_ADVERTISING:
                {

                }
                break;

            case GAPSTATE_IDLE:
                {

                }
                break;

            default:
                {

                }
                break;

            }

            gapProfileState = (gaprole_States_t)BtStackMsg.msgData.gapConnStateChange.newState;

        }
        break;



    default:
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "broadcaster_HandleBtGapMessage unknown subtype", 1, pBeeIoMsg->subType);

        break;

    }

}





