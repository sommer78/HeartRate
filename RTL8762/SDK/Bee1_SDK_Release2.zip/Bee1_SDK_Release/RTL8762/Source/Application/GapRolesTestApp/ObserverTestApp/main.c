/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     main.c
* @brief    This is the entry of user code which the main function resides in.
* @details
* @author   ranhui
* @date     2015-03-29
* @version  v0.2
*********************************************************************************************************
*/
#include "rtl876x.h"
#include "FreeRTOS.h"
#include "task.h"
#include "application.h"

#include "dlps_platform.h"



#include "observer.h"
#include "gap.h"
#include "gapbondmgr.h"


#include "observerFullTestApp_application.h"
#include "simple_ble_observer.h"

#include "board.h"
#include "rtl876x_pinmux.h"
#include "rtl876x_io_dlps.h"
#include "rtl876x_keyscan.h"
#include "rtl876x_gpio.h"
#include "rtl876x_rcc.h"
#include "rtl876x_nvic.h"
#include "keyscan.h"



#define MOUSE_KEYPAD_ROW_SIZE             4
#define MOUSE_KEYPAD_COLUMN_SIZE          4
#define MOUSE_SWDEBOUNCE_TIMES            8*32   // DEBOUNCE_TIME_8ms
#define MOUSE_KEYSCAN_INTERVAL            3   // SCAN_INTERVAL: 0 - 12.5ms, 1 - 25ms, 2 - 50ms, 3 - 100ms

void BtStack_Init_Gap()
{
    uint8_t DeviceName[GAP_DEVICE_NAME_LEN] = "Bee_perip";
    uint16_t Appearance = GAP_GATT_APPEARANCE_UNKNOWN;

    observerSetGapParameter(GAPPRRA_DEVICE_NAME, GAP_DEVICE_NAME_LEN, DeviceName);
    observerSetGapParameter(GAPPRRA_APPEARANCE, sizeof(Appearance), &Appearance);
}

void BtProfile_Init(void)
{
    /* We register this callback for receiving ADV and SCAN RSP data. */
    observer_RegisterAppDirectCB( App_ObserverRoleCallback );
}

void Board_Init()
{
//  void InitializePlatform_IO(uint32_t);

    /* Keypad pin setting */
    {
        Pinmux_Config(KEYPAD_ROW0, KEY_ROW_0);
        Pinmux_Config(KEYPAD_ROW1, KEY_ROW_1);
        Pinmux_Config(KEYPAD_ROW2, KEY_ROW_2);
        Pinmux_Config(KEYPAD_ROW3, KEY_ROW_3);
        Pad_Config(KEYPAD_ROW0, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
        Pad_Config(KEYPAD_ROW1, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
        Pad_Config(KEYPAD_ROW2, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
        Pad_Config(KEYPAD_ROW3, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);

        Pinmux_Config(KEYPAD_COLUMN0, KEY_COL_0);
        Pinmux_Config(KEYPAD_COLUMN1, KEY_COL_1);
        Pinmux_Config(KEYPAD_COLUMN2, KEY_COL_2);
        Pinmux_Config(KEYPAD_COLUMN3, KEY_COL_3);
        Pad_Config(KEYPAD_COLUMN0, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_DOWN, PAD_OUT_ENABLE, PAD_OUT_LOW);
        Pad_Config(KEYPAD_COLUMN1, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_DOWN, PAD_OUT_ENABLE, PAD_OUT_LOW);
        Pad_Config(KEYPAD_COLUMN2, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_DOWN, PAD_OUT_ENABLE, PAD_OUT_LOW);
        Pad_Config(KEYPAD_COLUMN3, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_DOWN, PAD_OUT_ENABLE, PAD_OUT_LOW);
    }


    System_WakeUp_Pin_Enable(KEYPAD_ROW0, 0);
    System_WakeUp_Pin_Enable(KEYPAD_ROW1, 0);

}

/**
* @brief  Driver_Init() contains the initialization of peripherals.
*
* Both new architecture driver and legacy driver initialization method can be used.
*
* @param   No parameter.
* @return  void
*/
void Driver_Init()
{
    RCC_PeriphClockCmd(APBPeriph_KEYSCAN, APBPeriph_KEYSCAN_CLOCK, ENABLE);
    KeyPad_Init();
}


/**
* @brief  PwrMgr_Init() contains the setting about power mode.
*
* @param   No parameter.
* @return  void
*/
void PwrMgr_Init()
{
    LPS_MODE_Pause();
}


/**
* @brief  Task_Init() contains the initialization of all the tasks.
*
* There are four tasks are initiated.
* Lowerstack task and upperstack task are used by bluetooth stack.
* Application task is task which user application code resides in.
* Emergency task is reserved.
*
* @param   No parameter.
* @return  void
*/
void Task_Init()
{
    void lowerstack_task_init();
    void upperstack_task_init();
    void emergency_task_init();
    application_task_init();
}


/**
* @brief  main() is the entry of user code.
*
*
* @param   No parameter.
* @return  void
*/
int main(void)
{
    Board_Init();
    Driver_Init();
    BtStack_Init_Observer();
    BtStack_Init_Gap();
    BtProfile_Init();
    PwrMgr_Init();
    Task_Init();
    vTaskStartScheduler();

    return 0;
}

