/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     hw_ctrl.h
* @brief    declaration of some hardware control func.
* @details  none.
* @author   tifnan
* @date     2015-11-06
* @version  v0.1                       
*********************************************************************************************************
*/

#ifndef _RCU_H_
#define _RCU_H_

#ifdef  __cplusplus
 extern "C" {
#endif      /* __cplusplus */

#include <stdint.h>

/* power key */
#define POWER_KEY               P3_1
/* rotation direction key */
#define ROT_DIR_KEY             P0_2
/* rotation speed+ key */
#define ROT_SPD_UP_KEY          P3_2
/* rotation speed- key */
#define ROT_SPD_DOWN_KEY        P4_2
/* rcu key pressd tip LED */
#define TIP_LED                 P2_1  

/* command */
#define CMD_POWER               0x01
#define CMD_ROT_DIR             0x02   
#define CMD_ROT_SPD_UP          0x03
#define CMD_ROT_SPD_DOWN        0x04

/* state number storage struct */
typedef struct _state_num_store_t
{
    uint8_t valid0;     //0xEE valid, 0xDD invalid
    uint8_t valid1;     //0xBB valid, 0x77 invalid
    uint16_t state;
}state_num_store_t;

//globals
extern uint8_t adv_data[29];

//export functions
void rcu_init(void);
     
#ifdef  __cplusplus
}
#endif      /* __cplusplus */

#endif  /*_RCU_H_ */

