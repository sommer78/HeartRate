/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file		main.c
* @brief	This is the entry of user code which the main function resides in.
* @details	
* @author	ranhui
* @date		2015-03-29
* @version	v0.2
*********************************************************************************************************
*/
#include "rtl876x.h"
#include "FreeRTOS.h"
#include "task.h"
#include "application.h"
#include "dlps_platform.h"
#include "broadcaster.h"
#include "gap.h"
#include "fan_rcu_application.h"
#include "simple_ble_broadcaster.h"
#include "rtl876x_gpio.h"
#include "rtl876x_rcc.h"
#include "rtl876x_tim.h"
#include "rtl876x_flash_storage.h"
#include "rtl876x_nvic.h"
#include "rcu.h"
#include "rtl876x_pinmux.h"

/*
********************************************************
* parameter for btstack
*
*
*********************************************************
*/

// What is the advertising interval when device is discoverable (units of 625us, 160=100ms)
//#define DEFAULT_ADVERTISING_INTERVAL_MIN            0x00A0 /* 100ms */
//#define DEFAULT_ADVERTISING_INTERVAL_MAX            0x00A0 /* 100ms */

#define DEFAULT_ADVERTISING_INTERVAL_MIN            0x0020 /* 20ms */
#define DEFAULT_ADVERTISING_INTERVAL_MAX            0x0030 /* 30ms */

#define DEFAULT_DISCOVERABLE_MODE             GAP_ADTYPE_FLAGS_GENERAL

// Minimum connection interval (units of 1.25ms, 80=100ms) if automatic parameter update request is enabled
#define DEFAULT_DESIRED_MIN_CONN_INTERVAL     80
// Maximum connection interval (units of 1.25ms, 800=1000ms) if automatic parameter update request is enabled
#define DEFAULT_DESIRED_MAX_CONN_INTERVAL     800
// Slave latency to use if automatic parameter update request is enabled
#define DEFAULT_DESIRED_SLAVE_LATENCY         0
// Supervision timeout value (units of 10ms, 1000=10s) if automatic parameter update request is enabled
#define DEFAULT_DESIRED_CONN_TIMEOUT          1000

void BtStack_Init_Gap()
{
      //device name and device appearance
    uint8_t DeviceName[GAP_DEVICE_NAME_LEN] = "Bee_broadcaster";
    uint16_t Appearance = GAP_GATT_APPEARANCE_UNKNOWN;

    //default start adv when bt stack initialized
    uint8_t  advEnableDefault = TRUE;

    //advertising parameters
    uint8_t  advEventType = GAP_ADTYPE_ADV_NONCONN_IND;
    uint8_t  advDirectType = PEER_ADDRTYPE_PUBLIC;
    uint8_t  advDirectAddr[B_ADDR_LEN] = {0};
    uint8_t  advChanMap = GAP_ADVCHAN_ALL;
    uint8_t  advFilterPolicy = GAP_FILTER_POLICY_ALL;
    uint16_t advIntMin = DEFAULT_ADVERTISING_INTERVAL_MIN;
    uint16_t advIntMax = DEFAULT_ADVERTISING_INTERVAL_MIN;

    //Set device name and device appearance
    broadcasterSetGapParameter(GAPPRRA_DEVICE_NAME, GAP_DEVICE_NAME_LEN, DeviceName);
    broadcasterSetGapParameter(GAPPRRA_APPEARANCE, sizeof(Appearance), &Appearance);

    //Set advertising parameters
    broadcasterSetGapParameter( GAPPRRA_ADV_ENABLE_DEFAULT, sizeof ( advEnableDefault ), &advEnableDefault );
    
    broadcasterSetGapParameter( GAPPRRA_ADV_EVENT_TYPE, sizeof ( advEventType ), &advEventType );
    broadcasterSetGapParameter( GAPPRRA_ADV_DIRECT_ADDR_TYPE, sizeof ( advDirectType ), &advDirectType );
    broadcasterSetGapParameter( GAPPRRA_ADV_DIRECT_ADDR, sizeof ( advDirectAddr ), advDirectAddr );
    broadcasterSetGapParameter( GAPPRRA_ADV_CHANNEL_MAP, sizeof ( advChanMap ), &advChanMap );
    broadcasterSetGapParameter( GAPPRRA_ADV_FILTER_POLICY, sizeof ( advFilterPolicy ), &advFilterPolicy );

    broadcasterSetGapParameter( GAPPRRA_ADVERT_DATA, sizeof(adv_data), adv_data);
    //broadcasterSetGapParameter( GAPPRRA_SCAN_RSP_DATA, sizeof(adv_data), scanRspData );

    broadcasterSetGapParameter(GAPPRRA_ADV_INTERVAL_MIN, sizeof(advIntMin), &advIntMin);
    broadcasterSetGapParameter(GAPPRRA_ADV_INTERVAL_MAX, sizeof(advIntMax), &advIntMax);
}


/**
* @brief  Board_Init() contains the initialization of pinmux settings and pad settings.
*
* All the pinmux settings and pad settings shall be initiated in this function.
* But if legacy driver is used, the initialization of pinmux setting and pad setting
* should be peformed with the IO initializing. 
*
* @param   No parameter.
* @return  void
*/
void Board_Init(void)
{
    //tip LED
    Pad_Config(TIP_LED, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);;
    Pinmux_Config(TIP_LED, GPIO_FUN);

    //power key
    Pad_Config(POWER_KEY, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);;
    Pinmux_Config(POWER_KEY, GPIO_FUN);

    //rotation direction key
    Pad_Config(ROT_DIR_KEY, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);;
    Pinmux_Config(ROT_DIR_KEY, GPIO_FUN);

    //rotation direction key
    Pad_Config(ROT_SPD_UP_KEY, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);;
    Pinmux_Config(ROT_SPD_UP_KEY, GPIO_FUN);

    //rotation direction key
    Pad_Config(ROT_SPD_DOWN_KEY, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);;
    Pinmux_Config(ROT_SPD_DOWN_KEY, GPIO_FUN);

}

/**
* @brief  Driver_Init() contains the initialization of peripherals.
*
* Both new architecture driver and legacy driver initialization method can be used.
*
* @param   No parameter.
* @return  void
*/
void Driver_Init(void)
{
    /****************************** turn on IO clocks *********************************************/
    RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
    RCC_PeriphClockCmd(APBPeriph_TIMER, APBPeriph_TIMER_CLOCK, ENABLE);

    /******************************** for key press tip LED *********************************************/
    GPIO_InitTypeDef GPIO_InitStruct;
   
    GPIO_InitStruct.GPIO_Pin  = GPIO_GetPin(TIP_LED);
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT; 
    GPIO_Init(&GPIO_InitStruct);
    GPIO_SetBits(GPIO_GetPin(TIP_LED));

    /****************************** timer for advertising time ****************************************/
    TIM_TimeBaseInitTypeDef TIM_InitStruct;
    
    TIM_StructInit(&TIM_InitStruct);
    TIM_InitStruct.TIM_ClockSrc = TIM_CLOCK_10MHZ;
    TIM_InitStruct.TIM_Period = 120 * 10000;  //120ms
    TIM_InitStruct.TIM_Mode = TIM_Mode_UserDefine;
    TIM_TimeBaseInit(TIM2, &TIM_InitStruct);
    TIM_ClearINT(TIM2);
    TIM_INTConfig(TIM2, ENABLE);

    /****************************** timer for key press debounce **************************************/
    TIM_InitStruct.TIM_Period = 10000 * 40;   //40ms
    TIM_TimeBaseInit(TIM3, &TIM_InitStruct);
    TIM_ClearINT(TIM3);
    TIM_INTConfig(TIM3, ENABLE);

    /****************************** for power key ***********************************************************/
    GPIO_InitStruct.GPIO_Pin  = GPIO_GetPin(POWER_KEY);
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_ITCmd = ENABLE;
    GPIO_InitStruct.GPIO_ITTrigger = GPIO_INT_Trigger_LEVEL;
    GPIO_InitStruct.GPIO_ITPolarity = GPIO_INT_POLARITY_ACTIVE_LOW;
    GPIO_InitStruct.GPIO_ITDebounce = GPIO_INT_DEBOUNCE_ENABLE;  
    GPIO_Init(&GPIO_InitStruct);
    GPIO_INTConfig(GPIO_GetPin(POWER_KEY), ENABLE);

    /****************************** for rotation direction key ***********************************************************/
    GPIO_InitStruct.GPIO_Pin  = GPIO_GetPin(ROT_DIR_KEY);
    //GPIO_Init(&GPIO_InitStruct);
    GPIO_INTConfig(GPIO_GetPin(ROT_DIR_KEY), ENABLE);
    GPIO_MaskINTConfig(GPIO_GetPin(ROT_DIR_KEY), DISABLE);

    /****************************** for rotation speed up key ***********************************************************/
    GPIO_InitStruct.GPIO_Pin  = GPIO_GetPin(ROT_SPD_UP_KEY);
    //GPIO_Init(&GPIO_InitStruct);
    GPIO_INTConfig(GPIO_GetPin(ROT_SPD_UP_KEY), ENABLE);
    GPIO_MaskINTConfig(GPIO_GetPin(ROT_SPD_UP_KEY), DISABLE);

    /****************************** for rotation speed down key ***********************************************************/
    GPIO_InitStruct.GPIO_Pin  = GPIO_GetPin(ROT_SPD_DOWN_KEY);
    //GPIO_Init(&GPIO_InitStruct);
    GPIO_INTConfig(GPIO_GetPin(ROT_SPD_DOWN_KEY), ENABLE);
    GPIO_MaskINTConfig(GPIO_GetPin(ROT_SPD_DOWN_KEY), DISABLE);

    /*************************************************** nvic **************************************************************/
    NVIC_InitTypeDef NVIC_InitStruct;
    NVIC_InitStruct.NVIC_IRQChannel = GPIO2_IRQ;
    NVIC_InitStruct.NVIC_IRQChannelPriority = 1;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStruct); 

    NVIC_InitStruct.NVIC_IRQChannel = GPIO6To31_IRQ;
    NVIC_InitStruct.NVIC_IRQChannelPriority = 1;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStruct);

    //enable timer3 interrupt, for key debounce
    NVIC_InitStruct.NVIC_IRQChannel = TIMER3_IRQ;
    NVIC_Init(&NVIC_InitStruct);

    //enable timer1 interrupt, for advertising time
    NVIC_InitStruct.NVIC_IRQChannel = TIMER2_IRQ;
    NVIC_Init(&NVIC_InitStruct);

}

/**
* @brief  PwrMgr_Init() contains the setting about power mode.
*
* @param   No parameter.
* @return  void
*/
void PwrMgr_Init()
{
	//LPS_MODE_Set(LPM_DLPS_MODE);
	//LPS_MODE_Pause();
}


/**
* @brief  Task_Init() contains the initialization of all the tasks.
*
* There are four tasks are initiated.
* Lowerstack task and upperstack task are used by bluetooth stack.
* Application task is task which user application code resides in.
* Emergency task is reserved.
* 
* @param   No parameter.
* @return  void
*/
void Task_Init()
{
	void lowerstack_task_init();
	void upperstack_task_init();
	void emergency_task_init();
	application_task_init();
}


/**
* @brief  main() is the entry of user code.
*
* 
* @param   No parameter.
* @return  void
*/
int main(void)
{
    Board_Init();
    BtStack_Init_Broadcaster();
    BtStack_Init_Gap();
    PwrMgr_Init();
    Task_Init();
    vTaskStartScheduler();

    return 0;
}

