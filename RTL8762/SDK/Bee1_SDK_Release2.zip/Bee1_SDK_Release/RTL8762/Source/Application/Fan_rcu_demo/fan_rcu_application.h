/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      simple_ble_broadcaster_application.h
* @brief     simple_ble_broadcaster app implementation
* @details   simple_ble_broadcaster app implementation
* @author    Shawn
* @date      2014-10-06
* @version   v0.1
* *********************************************************************************************************
*/

#ifndef SIMPLEBLEBROADCASTER_APP_H
#define SIMPLEBLEBROADCASTER_APP_H
#include "bee_message.h"

#ifdef __cplusplus
 extern "C" {
#endif

#include "rtl876x.h"



//extern void AppHandleIODriverMessage(BEE_IO_MSG io_driver_msg_recv);



#ifdef __cplusplus
}
#endif

#endif

