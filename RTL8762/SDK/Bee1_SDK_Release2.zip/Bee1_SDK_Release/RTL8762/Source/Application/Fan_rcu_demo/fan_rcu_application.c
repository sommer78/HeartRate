/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      fan_rcu_application.c
* @brief     fan rcu demo application implementation
* @details   fan rcu demo application implementation
* @author    tifnan_ge
* @date      2015-11-11
* @version   v0.1
* *********************************************************************************************************
*/
#include "rtl876x.h"
#include "application.h"
#include "fan_rcu_application.h"
#include "bee_message.h"
#include "broadcaster.h"
#include "trace.h"
#include <string.h>
#include "rcu.h"

gaprole_States_t gapProfileState = GAPSTATE_INIT;

void broadcaster_HandleBtGapMessage(BEE_IO_MSG *io_driver_msg_recv);


/**
* @brief  All the application events are pre-handled in this function.
*
* All the IO MSGs are sent to this function. 
* Then the event handling function shall be called according to the MSG type.
*
* @param   io_driver_msg_recv  The BEE_IO_MSG from peripherals or BT stack state machine.
* @return  void
*/
void AppHandleIODriverMessage(BEE_IO_MSG io_driver_msg_recv)
{
    UINT16 msgtype = io_driver_msg_recv.IoType;

    switch(msgtype)
    {

        case BT_STATUS_UPDATE:
            {
                broadcaster_HandleBtGapMessage(&io_driver_msg_recv);
            }
            break;
        default:
            break;  
    }
}

/**
* @brief fucntion to handle ble GAP message
*
*
* @param   pBeeIoMsg
* @return  void
*/
void broadcaster_HandleBtGapMessage(BEE_IO_MSG *pBeeIoMsg)
{
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "broadcaster_HandleBtGapMessage subType = %d", 1, pBeeIoMsg->subType);
    BT_STACK_MSG BtStackMsg;
    memcpy(&BtStackMsg, &pBeeIoMsg->parm, sizeof(pBeeIoMsg->parm));

    switch(pBeeIoMsg->subType)
    {
    case BT_MSG_TYPE_CONN_STATE_CHANGE:
    {
        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_CONN_STATE_CHANGE:(%d->%d)", 
                                                                        2, gapProfileState, BtStackMsg.msgData.gapConnStateChange.newState);

        switch ( BtStackMsg.msgData.gapConnStateChange.newState )
        {
        case GAPSTATE_STACK_READY:
            {
              
            }
            break;

        case GAPSTATE_ADVERTISING:
            {
                
            }
            break;
            
        case GAPSTATE_IDLE:
            {
                
            }
            break;    

        default:
            {

            }
            break;

        }
        
        gapProfileState = (gaprole_States_t)BtStackMsg.msgData.gapConnStateChange.newState;

    }
    break;
    
    default:
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "broadcaster_HandleBtGapMessage unknown subtype", 1, pBeeIoMsg->subType);
        
    break;

    }

}

