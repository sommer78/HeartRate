/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     rcu.c
* @brief    rcu demo code.
* @details  none.
* @author   tifnan
* @date     2015-11-12
* @version  v0.1                       
*********************************************************************************************************
*/

#include "rtl876x_rcc.h"
#include "rtl876x_gpio.h"
#include "rtl876x_tim.h"
#include "rcu.h"
#include "broadcaster.h"
#include "rtl876x_gpio.h"
#include "rtl876x_rcc.h"
#include "rtl876x_tim.h"
#include "rtl876x_flash_storage.h"
#include "rtl876x_nvic.h"
#include <string.h>
#include "trace.h"

// GAP - Advertisement data (max size = 31 bytes, though this is
// best kept short to conserve power while advertisting)
uint8_t adv_data[29] =
{
    /* Core spec. Vol. 3, Part C, Chapter 18 */
    /* Flags */
    0x02,            /* length     */
    //XXXXMJMJ 0x01, 0x06,      /* type="flags", data="bit 1: LE General Discoverable Mode", BR/EDR not supp. */
    0x01, 0x05,      /* type="flags", data="bit 1: LE General Discoverable Mode" */
    
    /* Service */
    0x03,           /* length     */
    0x03,           /* type="More 16-bit UUIDs available" */
    0x12,           /* human interface device service*/
    0x18,
    
    /* place holder for Local Name, filled by BT stack. if not present */
    /* BT stack appends Local Name.                                    */
    0x03,           /* length     */
    0x19,           /* type="Appearance" */
    0x80, 0x01,     /* Generic Remote Control */

    /* Manufacturer Specific data */
    0x05,
    0xff,
    0x00,  /* [13]state number/low word */
    0x00,  /* [14]state number/high word */
    0x00,  /* [15]cmd */
    0x00,  /* [16]parameter length, with parameters or not  */
    
    0x0B,           /* length     */
    0x09,           /* type="Complete local name" */
//    0x42, 0x65, 0x65, 0x5F, 0x6D, 0x6F, 0x75, 0x73, 0x65  /* Bee_mouse */
    'B','e','e','_','B','R','O','R', 'C', 'U'  /* Bee_perip */
};

/* when send new command, should ++rcu_state_num */
state_num_store_t state_num;
/* key press flag, 1--power key, 2--direction key, 3--speed up key, 4--speed down key */
volatile uint8_t key_flag = 0;

/**
  * @brief rcu initialization.
  * @param none
  * @return none
  */
void rcu_init(void)
{
    fs_load_vendor_data((void*)&state_num, sizeof(state_num_store_t), 0);

    //firstly boot
    if(state_num.valid0 != 0xEE & state_num.valid1 != 0xBB)
    {   
        state_num.state = 0x0001;
        state_num.valid0 = 0xEE;
        state_num.valid1 = 0xBB;
        //save stat number
        fs_save_vendor_data((void*)&state_num, sizeof(state_num_store_t), 0);
    }
}

/**
  * @brief set command and parameters to advertising data.
  * @param[in] cmd    --comamnd
  * @param[in] length --parameters length  
  * @param[in] para   --parameters
  * @return none
  */
uint8_t rcu_set_cmd(uint8_t cmd, uint8_t len, uint8_t* para)
{
    adv_data[15] = cmd;
    adv_data[16] = (uint8_t)len;

    /* comamnd parameters */
    if(para)
    {
        memcpy(&adv_data[16], para, len);
    }

    return 0;
}

/**
  * @brief update state number.
  * @param none
  * @return none
  */
void rcu_state_num_update(void)
{
    state_num.state++;

    adv_data[13] = (uint8_t)(state_num.state);
    adv_data[14] = (uint8_t)(state_num.state >> 8);

    //save stat number
    fs_save_vendor_data((void*)&state_num, sizeof(state_num_store_t), 0);
}

/**
  * @brief gpio interrupt routine, power key press.
  * @param none
  * @return none
  */
void Gpio25IntrHandler(void)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Gpio25IntrHandler-->power key press......", 0);
    
    GPIO_ClearINTPendingBit(GPIO_GetPin(POWER_KEY));
    GPIO_INTConfig(GPIO_GetPin(POWER_KEY), DISABLE);
    GPIO_MaskINTConfig(GPIO_GetPin(POWER_KEY), ENABLE);

    key_flag = 1;
    //do key debounce
    TIM_Cmd(TIM3, ENABLE);
}

/**
  * @brief gpio interrupt routine, rotation direction key press.
  * @param none
  * @return none
  */
void Gpio2IntrHandler(void)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Gpio2IntrHandler-->rotation direction key press....", 0);
    
    GPIO_ClearINTPendingBit(GPIO_GetPin(ROT_DIR_KEY));
    GPIO_INTConfig(GPIO_GetPin(ROT_DIR_KEY), DISABLE);
    GPIO_MaskINTConfig(GPIO_GetPin(ROT_DIR_KEY), ENABLE);
    
    key_flag = 2;
    TIM_Cmd(TIM3, ENABLE);
}

/**
  * @brief gpio interrupt routine, rotation speed up key press.
  * @param none
  * @return none
  */
void Gpio26IntrHandler(void)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Gpio26IntrHandler-->rotaion speed up key press....", 0);
    
    GPIO_ClearINTPendingBit(GPIO_GetPin(ROT_SPD_UP_KEY));
    GPIO_INTConfig(GPIO_GetPin(ROT_SPD_UP_KEY), DISABLE);
    GPIO_MaskINTConfig(GPIO_GetPin(ROT_SPD_UP_KEY), ENABLE);

    key_flag = 3;
    TIM_Cmd(TIM3, ENABLE);
}

/**
  * @brief gpio interrupt routine, rotation speed down key press.
  * @param none
  * @return none
  */
void Gpio30IntrHandler(void)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Gpio30IntrHandler-->rotaion speed down key press....", 0);
    
    GPIO_ClearINTPendingBit(GPIO_GetPin(ROT_SPD_DOWN_KEY));
    GPIO_INTConfig(GPIO_GetPin(ROT_SPD_DOWN_KEY), DISABLE);
    GPIO_MaskINTConfig(GPIO_GetPin(ROT_SPD_DOWN_KEY), ENABLE);

    key_flag = 4;
    TIM_Cmd(TIM3, ENABLE);
}

/**
  * @brief key press debounce done interrupt routine, send advertising.
  * @param none
  * @return none
  */
void Timer3IntrHandler(void)
{
    if(key_flag == 1)
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Timer3IntrHandler-->power key debounce done....", 0);
        rcu_set_cmd(CMD_POWER, 0, NULL);
    }
    else if(key_flag == 2)
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Timer3IntrHandler-->rotation direction key debounce done....", 0);
        rcu_set_cmd(CMD_ROT_DIR, 0, NULL);
    }
    else if(key_flag == 3)
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Timer3IntrHandler-->rotation speed up key debounce done....", 0);
        rcu_set_cmd(CMD_ROT_SPD_UP, 0, NULL);
    }
    else if(key_flag == 4)
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Timer3IntrHandler-->rotation speed down key debounce done....", 0);
        rcu_set_cmd(CMD_ROT_SPD_DOWN, 0, NULL);
    }
    else
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Timer3IntrHandler-->wrong key press flag: %d", 1, key_flag);
    }

    //key_flag = 0;
    
    //disable debounce timer
    TIM_ClearINT(TIM3);
    TIM_Cmd(TIM3, DISABLE);

    //update state number
    rcu_state_num_update();
    //set advertising data
    broadcaster_SetAdvertisingData(adv_data, sizeof(adv_data));
    //enable advertising
    broadcaster_StartAdvertising();
    
    //tip LED on
    GPIO_ResetBits(GPIO_GetPin(TIP_LED));
    //start advertising timer
    TIM_Cmd(TIM2, ENABLE);
}

/**
  * @brief advertsiing timer readched interrupt routine, stop advertising.
  * @param none
  * @return none
  */
void Timer2IntrHandler(void)
{
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Timer2IntrHandler-->advertising time reach, stop advertising....", 0);
    //stop advertising
    broadcaster_StopAdvertising();
    GPIO_SetBits(GPIO_GetPin(TIP_LED));
    TIM_ClearINT(TIM2);
    TIM_Cmd(TIM2, DISABLE);
    
    //enable gpio interrupt again
    if(key_flag == 1)
    {
        GPIO_ClearINTPendingBit(GPIO_GetPin(ROT_SPD_DOWN_KEY));
        GPIO_INTConfig(GPIO_GetPin(POWER_KEY), ENABLE);
        GPIO_MaskINTConfig(GPIO_GetPin(POWER_KEY), DISABLE);
    }
    else if(key_flag == 2)
    {
        GPIO_ClearINTPendingBit(GPIO_GetPin(ROT_DIR_KEY));
        GPIO_INTConfig(GPIO_GetPin(ROT_DIR_KEY), ENABLE);
        GPIO_MaskINTConfig(GPIO_GetPin(ROT_DIR_KEY), DISABLE);

    }
    else if(key_flag == 3)
    {
        GPIO_ClearINTPendingBit(GPIO_GetPin(ROT_SPD_UP_KEY));
        GPIO_INTConfig(GPIO_GetPin(ROT_SPD_UP_KEY), ENABLE);
        GPIO_MaskINTConfig(GPIO_GetPin(ROT_SPD_UP_KEY), DISABLE);
    }
    else if(key_flag == 4)
    {
        GPIO_ClearINTPendingBit(GPIO_GetPin(ROT_SPD_DOWN_KEY));
        GPIO_INTConfig(GPIO_GetPin(ROT_SPD_DOWN_KEY), ENABLE);
        GPIO_MaskINTConfig(GPIO_GetPin(ROT_SPD_DOWN_KEY), DISABLE);
    }
    else
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Timer3IntrHandler-->wrong key press flag: %d", 1, key_flag);
    }
    
    key_flag = 0;
}
