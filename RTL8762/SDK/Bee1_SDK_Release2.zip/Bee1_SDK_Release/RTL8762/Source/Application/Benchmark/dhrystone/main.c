/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file		main.c
* @brief	This is the entry of user code which the main function resides in.
* @details	
* @author	Serval Li
* @date		2015-05-11
* @version	v0.1
*********************************************************************************************************
*/
#include "rtl876x.h"
#include "rtl_types.h"
#include "rtl876x_rtc.h"

#include "FreeRTOS.h"
#include "task.h"

#include "dhry.h"

static void rtc_init(void)
{
	RTC_Reset();
	RTC_Enable();
	RTC_SetPrescaler(0);
	RTC_SetCOMPValue(0, 32000);
	RTC_EnableCOMP(0);
	RTC_Start();
}

/**
* @brief  main() is the entry of user code.
*
* 
* @param   No parameter.
* @return  void
*/
int main(void)
{
    rtc_init();
    __asm volatile("cpsid i"); /* disable interrupt */
    dhrystone_main();

    __asm("label:\nb label");   /* Halt */

    return 0;
}

