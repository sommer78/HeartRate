/**
**********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     main.c
* @brief    This file provides demo code of Marquee and output PWM waveform on RTL8762A EVB.
* @details
* @author   elliot chen
* @date     2016-1-8
* @version  v1.0
**********************************************************************************************************
* @attention
*
* Attention: Please connect P3_0 to P2_2 if use RTL8762AG or RTL8762AR for marquee demo.
* Because P2_2 is not available in RTL8762AG or RTL8762AR.
* Please refer to document of <<RTL8762A evaluation board introduced V1.1>>.
**********************************************************************************************************
*/

/* Defines ------------------------------------------------------------------*/

/* Pin define for Marquee demo */
#define LED2            		P2_2//P3_0 
#define LED3            		P0_5
#define LED4            		P4_3
#define LED5            		P2_1
#define GPIO_LED2       		GPIO_GetPin(LED2)
#define GPIO_LED3       		GPIO_GetPin(LED3)
#define GPIO_LED4       		GPIO_GetPin(LED4)
#define GPIO_LED5       		GPIO_GetPin(LED5)

/* Pin define for output PWM demo */
#define PWM_CH0        			P4_0
#define PWM_CH1                 P4_1
#define PWM_CH2                 P4_2
#define PWM_CH3                 P3_2

/* Timer which used for PWM to generate clock */
#define TIM_ID                  TIM2
#define TIM_INDEX               2
/* Configure frequency of timer. Calculating formula: F_timer= 10M/(period + 1) = 10M/5000 = 2 KHz*/
#define TIM_PERIOD              (5000-1)

/* Configure frequency of PWM. Calculating formula: F_PWM = F_timer/PWM_CHx_PERIOD = 2KHz/2 = 1KHz ,which x can be 0,1,2,3. */
/* Configure Peroid and duty of PWM */
#define PWM_CH0_PERIOD          2
#define PWM_CH0_DUTY            1
#define PWM_CH1_PERIOD          2
#define PWM_CH1_DUTY            1
#define PWM_CH2_PERIOD          2
#define PWM_CH2_DUTY            1
#define PWM_CH3_PERIOD          2
#define PWM_CH3_DUTY            1

/* Includes ------------------------------------------------------------------*/
#include "rtl876x_rcc.h"
#include "rtl876x_pinmux.h"
#include "rtl876x_gpio.h"
#include "rtl876x_pwm.h"

/* Demo code-----------------------------------------------------------------*/
void RCC_Configuration(void)
{
    /* Configure GPIO and timer clock before */
    RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
	RCC_PeriphClockCmd(APBPeriph_TIMER, APBPeriph_TIMER_CLOCK, ENABLE);
}

void PINMUXConfiguration(void)
{
	/* Configure pinmux before initialization of GPIO , TIM and PWM */
	/* Configure pinmux of LED2,LED4 and LED5 for GPIO function */
    Pinmux_Config(LED2, GPIO_FUN);
	Pinmux_Config(LED3, GPIO_FUN);
	Pinmux_Config(LED4, GPIO_FUN);
	Pinmux_Config(LED5, GPIO_FUN);

	/* Configure pinmux of PWM_CH0,PWM_CH2,PWM_CH3 and PWM_CH4 for PWM function */
	Pinmux_Config(PWM_CH0, timer_pwm0);
    Pinmux_Config(PWM_CH1, timer_pwm1);
    Pinmux_Config(PWM_CH2, timer_pwm2);
    Pinmux_Config(PWM_CH3, timer_pwm3);
}

void PADConfiguration(void)
{
	/* Configure pad before initialization of GPIO , TIM and PWM */
	/* specific information of function can be refer to document of <<RTL8762A peripheral manual>> */
    Pad_Config(LED2, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_HIGH);
	Pad_Config(LED3, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_HIGH);
	Pad_Config(LED4, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_HIGH);
	Pad_Config(LED5, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_HIGH);

	Pad_Config(PWM_CH0, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_HIGH);
    Pad_Config(PWM_CH1, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_HIGH);
    Pad_Config(PWM_CH2, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_HIGH);
    Pad_Config(PWM_CH3, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_HIGH);
	
}

void Peripheral_Init(void)
{
	/* Initialize GPIO module */
    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_InitStruct.GPIO_Pin  = (GPIO_LED2|GPIO_LED3|GPIO_LED4|GPIO_LED5);
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_ITCmd = DISABLE;
    GPIO_Init(&GPIO_InitStruct);

	/* Initialize timer and PWM  module */
	PWM_InitTypeDef PWM_InitStruct;
	TIM_TimeBaseInitTypeDef TIM_InitStruct;
    TIM_StructInit(&TIM_InitStruct);
	TIM_InitStruct.TIM_ClockSrc = TIM_CLOCK_10MHZ;
	TIM_InitStruct.TIM_Period 	= TIM_PERIOD;
	TIM_InitStruct.TIM_Mode 	= TIM_Mode_UserDefine;
	TIM_TimeBaseInit(TIM_ID, &TIM_InitStruct);
	TIM_Cmd(TIM_ID, ENABLE);

	PWM_InitStruct.PWM_Period 	= PWM_CH0_PERIOD;
    PWM_InitStruct.PWM_Duty 	= PWM_CH0_DUTY;
	PWM_InitStruct.PWM_TIMIndex = TIM_INDEX;
	PWM_Init(PWM0, &PWM_InitStruct);
	/* Output PWM waveform from PWM_CH0 pin */
	PWM_Cmd(PWM0, ENABLE);

	PWM_InitStruct.PWM_Period 	= PWM_CH1_PERIOD;
    PWM_InitStruct.PWM_Duty 	= PWM_CH1_DUTY;
	PWM_InitStruct.PWM_TIMIndex = TIM_INDEX;
	PWM_Init(PWM1, &PWM_InitStruct);
	/* Output PWM waveform from PWM_CH1 pin */
	PWM_Cmd(PWM1, ENABLE);

	PWM_InitStruct.PWM_Period 	= PWM_CH2_PERIOD;
    PWM_InitStruct.PWM_Duty 	= PWM_CH2_DUTY;
	PWM_InitStruct.PWM_TIMIndex = TIM_INDEX;
	PWM_Init(PWM2, &PWM_InitStruct);
	/* Output PWM waveform from PWM_CH2 pin */
	PWM_Cmd(PWM2, ENABLE);

	PWM_InitStruct.PWM_Period 	= PWM_CH3_PERIOD;
    PWM_InitStruct.PWM_Duty 	= PWM_CH3_DUTY;
	PWM_InitStruct.PWM_TIMIndex = TIM_INDEX;
	PWM_Init(PWM3, &PWM_InitStruct);
	/* Output PWM waveform from PWM_CH3 pin */
	PWM_Cmd(PWM3, ENABLE);
}

void Marquee_DemoCode(void)
{
	uint32_t delay = 0;

	/* All OFF. LED2 and LED3 pull down. LED4 and LED5 pull up. */
	GPIO_ResetBits(GPIO_LED2);
	GPIO_ResetBits(GPIO_LED3);
	GPIO_SetBits(GPIO_LED4);
	GPIO_SetBits(GPIO_LED5);
	
	while(1)
	{
		/* LED2 ON */
		GPIO_SetBits(GPIO_LED2);
		/* LED5 OFF */
		GPIO_SetBits(GPIO_LED5);
		for(delay=0; delay<0x8ffff; delay++){;}

		/* LED3 ON */
		GPIO_SetBits(GPIO_LED3);
		/* LED2 OFF */
		GPIO_ResetBits(GPIO_LED2);
		for(delay=0; delay<0x8ffff; delay++){;}

		/* LED4 ON */
		GPIO_ResetBits(GPIO_LED4);
		/* LED3 OFF */
    	GPIO_ResetBits(GPIO_LED3);
		for(delay=0; delay<0x8ffff; delay++){;}

		/* LED5 ON */
		GPIO_ResetBits(GPIO_LED5);
		/* LED4 OFF*/
    	GPIO_SetBits(GPIO_LED4);
		for(delay=0; delay<0x8ffff; delay++){;}
	}
}

int main(void)
{
	/* Clocks configuration of GPIO and TIM */
    RCC_Configuration();
	/* PAD configuration */
	PADConfiguration();
	/* Pinmux configuration */
    PINMUXConfiguration();
    /* Initialize GPIO,TIM and PWM module. Output four channels of PWM */
    Peripheral_Init();
	/* Demo of marquee */
	Marquee_DemoCode();
}

