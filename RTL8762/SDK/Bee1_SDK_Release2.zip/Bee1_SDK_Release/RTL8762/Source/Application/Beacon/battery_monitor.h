/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      battery_monitor.h
* @brief     battery_monitor
* @details
* @author    hunter
* @date      2015-06-28
* @version   v0.1
* *********************************************************************************************************
*/
#ifndef __BATTERY_MONITOR__
#define __BATTERY_MONITOR__
#include "bee_message.h"

#ifdef __cplusplus
extern "C" {
#endif


extern void BatteryMonitor_Init(void);










#ifdef __cplusplus
}
#endif

#endif
