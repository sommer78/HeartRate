/*
 *  Routines to access hardware
 *
 *  Copyright (c) 2014 Realtek Semiconductor Corp.
 *
 *  This module is a confidential and proprietary property of RealTek and
 *  possession or use of this module requires written permission of RealTek.
 */


#ifndef _AT_CMD_H_
#define  _AT_CMD_H_

#define AT_CMD_MAX_LENGTH 28

void AtCmdParse(void);
void AtCmdSendResponseOK(void);
void AtCmdSendResponseTimeout(void);
void AtCmdSendResponseConnect(void);
void AtCmdSendResponseDisconnect(void);
void AtCmdSendResponseDisconnectTimeout(void);

#endif

