enum { __FILE_NUM__ = 0 };

/*
 *  Routines to access hardware
 *
 *  Copyright (c) 2014 Realtek Semiconductor Corp.
 *
 *  This module is a confidential and proprietary property of RealTek and
 *  possession or use of this module requires written permission of RealTek.
 */

#include <string.h>
#include "trace.h"
#include "module_param_config.h"
#include "dataTrans_application.h"
#include "profileApi.h"
#include "module_param_profile.h"

uint8_t gModuleParamServiceId = 0xff;
static uint8_t ConfigValue = 0;
static uint8_t Pid[2];

static const TAttribAppl GattModuleParamProfileTable[] =
{
    /*----------------- module param Service -------------------*/
    /* <<Primary Service>>, .. */
    {
        (ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_LE),   /* wFlags     */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_PRIMARY_SERVICE),
            HI_WORD(GATT_UUID_PRIMARY_SERVICE),
            LO_WORD(GATT_UUID_MODULE_PARAM),              /* service UUID */
            HI_WORD(GATT_UUID_MODULE_PARAM)
        },
        UUID_16BIT_SIZE,                            /* bValueLen     */
        NULL,                                       /* pValueContext */
        GATT_PERM_READ                              /* wPermissions  */
    },
    /* Module Name Characteristic */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_READ, /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* Module Name value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHAR_MODULE_NAME),
            HI_WORD(GATT_UUID_CHAR_MODULE_NAME)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_WRITE | GATT_PERM_READ            /* wPermissions*/
    },
    /*Connection interval Characteristic */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_READ, /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*Connection interval  value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHAR_CONN_INTERVAL),
            HI_WORD(GATT_UUID_CHAR_CONN_INTERVAL)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_WRITE | GATT_PERM_READ            /* wPermissions*/
    },
    /*uart baudrate Characteristic */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_READ, /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*uart baudrate value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHAR_UART_BAUDRATE),
            HI_WORD(GATT_UUID_CHAR_UART_BAUDRATE)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_WRITE | GATT_PERM_READ            /* wPermissions*/
    },
    /*remote control Characteristic */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_WRITE,   /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*remote control value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHAR_REMOTE_CONTROL),
            HI_WORD(GATT_UUID_CHAR_REMOTE_CONTROL)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_WRITE              /* wPermissions*/
    },
    /*advertising interval Characteristic */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_READ, /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*advertising interval value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHAR_ADV_INTERVAL),
            HI_WORD(GATT_UUID_CHAR_ADV_INTERVAL)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_WRITE | GATT_PERM_READ            /* wPermissions*/
    },
    /*PID Characteristic */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_READ, /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*PID value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHAR_PID),
            HI_WORD(GATT_UUID_CHAR_PID)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_WRITE | GATT_PERM_READ            /* wPermissions*/
    },
    /*tx power Characteristic */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_READ, /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*tx power value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHAR_TX_POWER),
            HI_WORD(GATT_UUID_CHAR_TX_POWER)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_WRITE | GATT_PERM_READ            /* wPermissions*/
    },
    /*advertising data Characteristic */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_READ, /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*advertising data value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHAR_ADV_DATA),
            HI_WORD(GATT_UUID_CHAR_ADV_DATA)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_WRITE | GATT_PERM_READ            /* wPermissions*/
    },
    /*remote control extend Characteristic */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_WRITE,   /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*remote control extend value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHAR_REMOTE_CONTROL_EXT),
            HI_WORD(GATT_UUID_CHAR_REMOTE_CONTROL_EXT)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_WRITE              /* wPermissions*/
    },
    /*system mode Characteristic */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_WRITE | GATT_CHAR_PROP_READ, /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*system mode value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHAR_SYSTEM_MODE),
            HI_WORD(GATT_UUID_CHAR_SYSTEM_MODE)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_WRITE | GATT_PERM_READ            /* wPermissions*/
    }    
};

TProfileResult ModuleParamAttrWrite(uint8_t ServiceID, uint16_t iAttribIndex,
                       uint16_t wLength, uint8_t * pValue, TGATTDWriteIndPostProc * pWriteIndPostProc)
{
    TProfileResult  wCause  = ProfileResult_Success;
    uint32_t param;
    int16_t tx_power;

    if (!pValue)
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "--> ModuleParamAttrWrite   pValue %p wLength= 0x%x",
                   2,
                   pValue,
                   wLength);
		wCause = ProfileResult_InvalidParameter;
        return wCause;
    }
  
    switch (iAttribIndex)
    {
        case MODULE_PARAM_MODULE_NAME_INDEX:
            if (wLength > DEVICE_NAME_MAX_LENGTH)
            {
                wCause = ProfileResult_InvalidValueSize;
            }
            else
            {
                moduleParam_SetModuleName((char *)pValue, wLength);
            }
            break;
        case MODULE_PARAM_CONN_INTERVAL_INDEX:
            if (wLength > 1)
            {
                wCause = ProfileResult_InvalidValueSize;
            }
            else
            {
                switch (*pValue)
                {
                    case 0:
                        param = 20;
                        break;
                    case 1:
                        param = 50;
                        break;
                    case 2:
                        param = 100;
                        break;
                    case 3:
                        param = 200;
                        break;
                    case 4:
                        param = 300;
                        break;
                    case 5:
                        param = 400;
                        break;
                    case 6:
                        param = 500;
                        break;
                    case 7:
                        param = 1000;
                        break;
                    case 8:
                        param = 2000;
                        break;
                    default:
                        param = 0;
                        break;

                }
                moduleParam_SetConnInterval(param);
            }
            break;
        case MODULE_PARAM_UART_BAUDRATE_INDEX://4
            if (wLength > 1)
            {
                wCause = ProfileResult_InvalidValueSize;
            }
            else
            {
                switch (*pValue)
                {
                    case 0:
                        param = 4800;
                        break;
                    case 1:
                        param = 9600;
                        break;
                    case 2:
                        param = 19200;
                        break;
                    case 3:
                        param = 38400;
                        break;
                    case 4:
                        param = 57600;
                        break;
                    case 5:
                        param = 115200;
                        break;
                    default:
                        param = 0;
                        break;

                }
                moduleParam_SetBaudrate(param);
            }

            break;
        case MODULE_PARAM_REMOTE_CONTROL_INDEX:
            if (wLength > 1)
            {
                wCause = ProfileResult_InvalidValueSize;
            }
            else
            {
                moduleParam_RemoteControl(*pValue);
            }
            break;
        case MODULE_PARAM_ADV_INTERVAL_INDEX:
            if (wLength > 1)
            {
                wCause = ProfileResult_InvalidValueSize;
            }
            else
            {
                switch (*pValue)
                {
                    case 0:
                        param = 2;
                        break;
                    case 1:
                        param = 5;
                        break;
                    case 2:
                        param = 10;
                        break;
                    case 3:
                        param = 15;
                        break;
                    case 4:
                        param = 20;
                        break;
                    case 5:
                        param = 25;
                        break;
                    case 6:
                        param = 30;
                        break;
                    case 7:
                        param = 40;
                        break;
                    case 8:
                        param = 50;
                        break;
                    default:
                        param = 0;
                        break;

                }
                moduleParam_SetAdvInterval(param);
            }
            break;
        case MODULE_PARAM_PID_INDEX:        
            if (wLength > 2)
            {
                wCause = ProfileResult_InvalidValueSize;
            }
            else
            {
                if (wLength == 2)
                {
                    moduleParam_SetPID(*pValue, *(pValue + 1));
                }
            }
            break;
        case MODULE_PARAM_TX_POWER_INDEX:
            if (wLength > 1)
            {
                wCause = ProfileResult_InvalidValueSize;
            }
            else
            {
                switch (*pValue)
                {
                    case 0:
                        tx_power = 4;
                        break;
                    case 1:
                        tx_power = 0;
                        break;
                    case 2:
                        tx_power = -6;
                        break;
                    case 3:
                        tx_power = -23;
                        break;
                    default:
                        tx_power = 0;
                        break;

                }
                moduleParam_SetTxPower(tx_power);
            }

            break;
        case MODULE_PARAM_ADV_DATA_INDEX:
            if (wLength > ADV_DATA_MAX_LENGTH)
            {
                wCause = ProfileResult_InvalidValueSize;
            }
            else
            {
                moduleParam_SetAdvData(pValue, wLength);
            }

            break;
        case MODULE_PARAM_REMOTE_CONTROL_EXT_INDEX:
            if (wLength > 1)
            {
                wCause = ProfileResult_InvalidValueSize;
            }
            else
            {
                moduleParam_RemoteControlExtend(*pValue);
            }
            break;
        case MODULE_PARAM_SYSTEM_MODE_INDEX:
            if (wLength > 1)
            {
                wCause = ProfileResult_InvalidValueSize;
            }
            else
            {
                moduleParam_SetSystemMode(*pValue);
            }
            break;

        default:
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Profile_ModuleParamSetValue not handle iAttribIndex 0x%x\n", 1, iAttribIndex);
            break;
    }  
    return wCause;

}

TProfileResult  ModuleParamAttrRead(uint8_t ServiceID, uint16_t iAttribIndex,
                        uint16_t iOffset, uint16_t * piLength,uint8_t **ppValue)
{
    TProfileResult  wCause  = ProfileResult_Success;
    uint8_t *pValue = NULL;
    *piLength = 0;
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "<-- ModuleParamAttrRead index=%d", 1, iAttribIndex);

    switch (iAttribIndex)
    {
        case MODULE_PARAM_MODULE_NAME_INDEX:
            pValue = gConfigParam->localName.Local_name;
            *piLength = strlen((char *)gConfigParam->localName.Local_name);
            break;
        case MODULE_PARAM_CONN_INTERVAL_INDEX:
            ConfigValue = moduleParam_GetConnIntervalIndex();
            pValue = &ConfigValue;
            *piLength = 1;
            break;
        case MODULE_PARAM_UART_BAUDRATE_INDEX:
            ConfigValue = moduleParam_GetBaudrateIndex();
            pValue = &ConfigValue;
            *piLength = 1;
            break;
        case MODULE_PARAM_ADV_INTERVAL_INDEX:
            ConfigValue = moduleParam_GetAdvIntervalIndex();
            pValue = &ConfigValue;
            *piLength = 1;
            break;
        case MODULE_PARAM_PID_INDEX:
            Pid[0] = gConfigParam->pid.pid[0];
            Pid[1] = gConfigParam->pid.pid[1];
            pValue = Pid;
            *piLength = 2;
            break;
        case MODULE_PARAM_TX_POWER_INDEX:
            ConfigValue = moduleParam_GetTxPowerIndex();
            pValue = &ConfigValue;
            *piLength = 1;
            break;
        case MODULE_PARAM_ADV_DATA_INDEX:
            pValue = gConfigParam->advData.adv_data;
            *piLength = gConfigParam->advData.data_length;
            break;
        case MODULE_PARAM_SYSTEM_MODE_INDEX:
            ConfigValue = gConfigParam->systemMode.system_mode;
            pValue = &ConfigValue;
            *piLength = 1;
            break;

        default:
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Profile_ModuleParamGetValue not handle iAttribIndex 0x%x\n", 1, iAttribIndex);
            wCause = ProfileResult_AttrNotFound;
            break;
    }
    *ppValue = pValue;
    return wCause;
}

// Battery Service Callbacks
CONST gattServiceCBs_t 
moduleParamCBs =
{
    ModuleParamAttrRead,  // Read callback function pointer
    ModuleParamAttrWrite, // Write callback function pointer
    NULL  // Authorization callback function pointer
};

void Module_param_AddService(void* pFunc)
{
    if(FALSE == ProfileAPI_AddService(&gModuleParamServiceId,
                                 (uint8_t*)GattModuleParamProfileTable,
                                 sizeof(GattModuleParamProfileTable),
                                 moduleParamCBs))
		{
			DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "DataTrans_AddService: ServiceId %d",1,gModuleParamServiceId);
			gModuleParamServiceId = 0xff;
		}
}
