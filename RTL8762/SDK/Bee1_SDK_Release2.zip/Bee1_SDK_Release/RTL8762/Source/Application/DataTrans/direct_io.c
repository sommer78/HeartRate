enum { __FILE_NUM__ = 0 };

/**
*********************************************************************************************************
*               Copyright(c) 2014, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     direct_io.c
* @brief    IO function and init for testing profiles.
* @details  IO function and init for testing profiles.
* @author
* @date     2015-03-19
* @version  v0.1
*********************************************************************************************************
*/

/* for freertos interface */
#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>
/* for bee uart io driver interface */
#include "rtl_types.h"
#include "rtl876x_uart.h"
//#include "hal_gpio.h"
#include "rtl876x_pwm.h"
#include "rtl876x_ir.h"
#include "rtl876x_tim.h"
#include "rtl876x_rtc.h"
#include "direct_io.h"
#include "direct_io_profile.h"
#include "module_param_config.h"
#include "blueapi.h"
#include "profileApi.h"
#include "rtl876x_gpio.h"
#include "rtl876x_pinmux.h"
#include "rtl_endian.h"
/* for test profile self definitions */
PwmParaStruct gPwmPara;
IrParaStruct gIrPara;
GpioParaStruct gGpioPara;

TimerHandle_t PWM_Timer = NULL;
uint8_t IS_GPIO_SEND = 0;

#define PWM0_GTIMER_ID 2
#define PWM1_GTIMER_ID 3
#define PWM2_GTIMER_ID 4
#define PWM3_GTIMER_ID 5
#define PWM4_GTIMER_ID 6 //7


UINT32 PWM0_Duty_Value = 20000;
//SRAM_OFF_BF_BSS_SECTION
UINT32 PWM1_Duty_Value = 40000;
//SRAM_OFF_BF_BSS_SECTION
UINT32 PWM2_Duty_Value = 60000;
//SRAM_OFF_BF_BSS_SECTION
UINT32 PWM3_Duty_Value = 200000;
//SRAM_OFF_BF_BSS_SECTION
UINT32 PWM0_Period_Value = 1000000;
//SRAM_OFF_BF_BSS_SECTION
UINT32 PWM1_Period_Value = 1000000;
//SRAM_OFF_BF_BSS_SECTION
UINT32 PWM2_Period_Value = 1000000;
//SRAM_OFF_BF_BSS_SECTION
UINT32 PWM3_Period_Value = 1000000;

UINT32 MIN_Period_32Khz_Value = 64000 * 2; // 128000 ps ---> 128us --> 0.128ms
//SRAM_OFF_BF_BSS_SECTION
UINT32 MIN_Duty_32Khz_Value = 64000;
//SRAM_OFF_BF_BSS_SECTION
UINT32 MAX_Period_32Khz_Value = 4096000000; // 4.096s
//SRAM_OFF_BF_BSS_SECTION
UINT32 MAX_Duty_32Khz_Value = 64000;


UINT32 MIN_Period_10Mhz_Value = 400; //0.25us
//SRAM_OFF_BF_BSS_SECTION
UINT32 MIN_Duty_10Mhz_Value = 200;
//SRAM_OFF_BF_BSS_SECTION
UINT32 MAX_Period_10Mhz_Value = 13107000; // 200ps * 65535
//SRAM_OFF_BF_BSS_SECTION
UINT32 MAX_Duty_10Mhz_Value = 200;

UINT16 gFrequency = 0x8235;   // 150Hz   500~65535   0x8235
UINT8 gDuty0 = 0x66;   // 32/255   0~FF
UINT8 gDuty1 = 0x33;   // 51/255   0~FF
UINT8 gDuty2 = 0xAA;   // 170/255   0~FF
UINT8 gDuty3 = 0xcc;   // 204/255   0~FF
void TimerHandle(void);
UINT32 temp_count;

void IoParaInit(void)
{
    gPwmPara.PwmAllChCfg  = 0x01;//All High
    gPwmPara.PwmSigChCfg  = 0xFFFFFFFF;//AllHigh
    gPwmPara.PwmFrequency = 0x8235;//150HZ
    gPwmPara.PwmDelay     = 0x0;//no delay
    gGpioPara.GpioCfg     = 0x0;
    gGpioPara.GpioIn      = 0x3F;
}
void PWM_Callback(TimerHandle_t pxTimer )
{
    //  TickType_t xNewPeriod;
    //lArrayIndex = ( int32_t ) pvTimerGetTimerID( pxTimer );
    if ( xTimerIsTimerActive( pxTimer ) != pdFALSE ) // or more simply and equivalently "if( xTimerIsTimerActive( xTimer ) )"
    {
        // xTimer is already active - delete it.
        DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "xTimer is already active - delete it", 0);
        // xTimerDelete( pxTimer,0);
    }
    else
    {
        modulePwmSignalChange();
        //DBG_BUFFER(MODULE_OS, LEVEL_ERROR, "PwmDelay is 234567 0x%x\n",1,gPwmPara.PwmFrequency);
    }
    //xTimerStop(KEY0_Timer, 0xFFFF);

}
void PWM_Init(void)
{
    PWM_ADAPTER PWM_0;
    PWM_ADAPTER PWM_1;
    PWM_ADAPTER PWM_2;
    PWM_ADAPTER PWM_3;
    //int tmp;

    PWM_0.timerId               = PWM0_GTIMER_ID;
    PWM_0.pwm_period_length     = 200 * gPwmPara.PwmFrequency; //MIN_Period_32Khz_Value*8;            //  1000us, 1Khz

    gDuty0 = gPwmPara.PwmSigChCfg >> 24;
    PWM_0.pwm_duty_cycle_length = PWM_0.pwm_period_length * gDuty0 / 255; //  0us
    //PWM_0.PWMTimerClkSrc        = TIMER_CLOCK_SRC_32KHZ;
    PWM_0.PWMTimerClkSrc        = TIMER_CLOCK_SRC_10MHZ;
    PWM_0.pwm_selection         = PWM_SEL_PWM0;
    PWM_0.pwm_pin_assignment.gpio_group = GPIO_GROUP_B;
    PWM_0.pwm_pin_assignment.gpio_pin_index = 3;
    PWM_Initialize(&PWM_0);
    PWM_Enable(&PWM_0);
    //DBG_BUFFER(MODULE_APP,LEVEL_INFO,"PWM init OK",0);

    PWM_1.timerId               = PWM1_GTIMER_ID;
    PWM_1.pwm_period_length     = 200 * gPwmPara.PwmFrequency; //  1000us, 1Khz
    gDuty1 = gPwmPara.PwmSigChCfg >> 16;
    PWM_1.pwm_duty_cycle_length = PWM_1.pwm_period_length * gDuty1 / 255;   //  0us
    PWM_1.PWMTimerClkSrc        = TIMER_CLOCK_SRC_10MHZ;
    PWM_1.pwm_selection         = PWM_SEL_PWM1;
    PWM_1.pwm_pin_assignment.gpio_group = GPIO_GROUP_B;
    PWM_1.pwm_pin_assignment.gpio_pin_index = 4;
    PWM_Initialize(&PWM_1);
    PWM_Enable(&PWM_1);

    // Change PWM period
    /*PWM_0.pwm_period_length     = 100*gFrequency;;            //  1000us, 1Khz
    PWM_0.pwm_duty_cycle_length = 50*gFrequency;  //  0us
    PWM_ChangParameter(&PWM_0);*/

    PWM_2.timerId               = PWM2_GTIMER_ID;
    PWM_2.pwm_period_length     = 200 * gPwmPara.PwmFrequency;   //  1000us, 1Khz
    gDuty2 = gPwmPara.PwmSigChCfg >> 8;
    PWM_2.pwm_duty_cycle_length = PWM_2.pwm_period_length * gDuty2 / 255;   //  0us
    PWM_2.PWMTimerClkSrc        = TIMER_CLOCK_SRC_10MHZ;
    PWM_2.pwm_selection         = PWM_SEL_PWM2;
    PWM_2.pwm_pin_assignment.gpio_group = GPIO_GROUP_B;
    PWM_2.pwm_pin_assignment.gpio_pin_index = 5;
    PWM_Initialize(&PWM_2);
    PWM_Enable(&PWM_2);

    PWM_3.timerId               = PWM3_GTIMER_ID;
    PWM_3.pwm_period_length     = 200 * gPwmPara.PwmFrequency;   //  1000us, 1Khz
    gDuty3 = gPwmPara.PwmSigChCfg ;
    PWM_3.pwm_duty_cycle_length = PWM_3.pwm_period_length * gDuty3 / 255;   //  0us
    PWM_3.PWMTimerClkSrc        = TIMER_CLOCK_SRC_10MHZ;
    PWM_3.pwm_selection         = PWM_SEL_PWM3;
    PWM_3.pwm_pin_assignment.gpio_group = GPIO_GROUP_B;
    PWM_3.pwm_pin_assignment.gpio_pin_index = 6;
    PWM_Initialize(&PWM_3);
    PWM_Enable(&PWM_3);

    PWM_Timer = xTimerCreate("PWM_Timer",       // Just a text name, not used by the kernel.
                             ( ((gPwmPara.PwmDelay + 1) * 100) / portTICK_RATE_MS ), // The timer period in ticks. KEY_TIMEOUT_PERIOD = Interval_time +Debounce_time +2ms
                             pdFAIL,                // The timers will auto-reload themselves when they expire.
                             (void *)1,      // Assign each timer a unique id equal to its array index.
                             (TimerCallbackFunction_t)PWM_Callback  // Each timer calls the same callback when it expires.
                            );


}
void modulePwmInit(void)
{
    PWM_ADAPTER PWM_0;
    PWM_ADAPTER PWM_1;
    PWM_ADAPTER PWM_2;
    PWM_ADAPTER PWM_3;
    //int tmp;

    PWM_0.timerId               = PWM0_GTIMER_ID;
    PWM_0.pwm_period_length     = 200 * gPwmPara.PwmFrequency; //MIN_Period_32Khz_Value*8;            //  1000us, 1Khz
    if (gPwmPara.PwmAllChCfg == 0x1)
    {
        gDuty0 = 255;
        gDuty1 = 255;
        gDuty2 = 255;
        gDuty3 = 255;
    }
    else if (gPwmPara.PwmAllChCfg == 0x0)
    {
        gDuty0 = 0;
        gDuty1 = 0;
        gDuty2 = 0;
        gDuty3 = 0;
    }
    else if (gPwmPara.PwmAllChCfg == 0x2)
    {
        gDuty0 = gPwmPara.PwmSigChCfg >> 24;
        gDuty1 = gPwmPara.PwmSigChCfg >> 16;
        gDuty2 = gPwmPara.PwmSigChCfg >> 8;
        gDuty3 = gPwmPara.PwmSigChCfg ;
    }
    else
    {
    }
    PWM_0.pwm_duty_cycle_length = PWM_0.pwm_period_length * gDuty0 / 255; //  0us
    //PWM_0.PWMTimerClkSrc        = TIMER_CLOCK_SRC_32KHZ;
    PWM_0.PWMTimerClkSrc        = TIMER_CLOCK_SRC_10MHZ;
    PWM_0.pwm_selection         = PWM_SEL_PWM0;
    PWM_0.pwm_pin_assignment.gpio_group = GPIO_GROUP_B;
    PWM_0.pwm_pin_assignment.gpio_pin_index = 3;
    PWM_Initialize(&PWM_0);
    PWM_Enable(&PWM_0);
    //DBG_BUFFER(MODULE_APP,LEVEL_INFO,"PWM init OK",0);

    PWM_1.timerId               = PWM1_GTIMER_ID;
    PWM_1.pwm_period_length     = 200 * gPwmPara.PwmFrequency; //  1000us, 1Khz
    //gDuty1 = gPwmPara.PwmSigChCfg >>16;
    PWM_1.pwm_duty_cycle_length = PWM_1.pwm_period_length * gDuty1 / 255;   //  0us
    PWM_1.PWMTimerClkSrc        = TIMER_CLOCK_SRC_10MHZ;
    PWM_1.pwm_selection         = PWM_SEL_PWM1;
    PWM_1.pwm_pin_assignment.gpio_group = GPIO_GROUP_B;
    PWM_1.pwm_pin_assignment.gpio_pin_index = 4;
    PWM_Initialize(&PWM_1);
    PWM_Enable(&PWM_1);

    // Change PWM period
    /*PWM_0.pwm_period_length     = 100*gFrequency;;            //  1000us, 1Khz
    PWM_0.pwm_duty_cycle_length = 50*gFrequency;  //  0us
    PWM_ChangParameter(&PWM_0);*/

    PWM_2.timerId               = PWM2_GTIMER_ID;
    PWM_2.pwm_period_length     = 200 * gPwmPara.PwmFrequency;   //  1000us, 1Khz
    //gDuty2 = gPwmPara.PwmSigChCfg >>8;
    PWM_2.pwm_duty_cycle_length = PWM_2.pwm_period_length * gDuty2 / 255;   //  0us
    PWM_2.PWMTimerClkSrc        = TIMER_CLOCK_SRC_10MHZ;
    PWM_2.pwm_selection         = PWM_SEL_PWM2;
    PWM_2.pwm_pin_assignment.gpio_group = GPIO_GROUP_B;
    PWM_2.pwm_pin_assignment.gpio_pin_index = 5;
    PWM_Initialize(&PWM_2);
    PWM_Enable(&PWM_2);

    PWM_3.timerId               = PWM3_GTIMER_ID;
    PWM_3.pwm_period_length     = 200 * gPwmPara.PwmFrequency;   //  1000us, 1Khz
    //gDuty3 = gPwmPara.PwmSigChCfg ;
    PWM_3.pwm_duty_cycle_length = PWM_3.pwm_period_length * gDuty3 / 255;   //  0us
    PWM_3.PWMTimerClkSrc        = TIMER_CLOCK_SRC_10MHZ;
    PWM_3.pwm_selection         = PWM_SEL_PWM3;
    PWM_3.pwm_pin_assignment.gpio_group = GPIO_GROUP_B;
    PWM_3.pwm_pin_assignment.gpio_pin_index = 6;
    PWM_Initialize(&PWM_3);
    PWM_Enable(&PWM_3);
}
//void modulePwmSigCfg(void)
void modulePwmSignalChange(void)
{
    //if(gPwmPara.PwmDelay == 0)
    //{
    PWM_ADAPTER PWM_0;
    PWM_ADAPTER PWM_1;
    PWM_ADAPTER PWM_2;
    PWM_ADAPTER PWM_3;
    gDuty0 = gPwmPara.PwmSigChCfg >> 24;
    gDuty1 = gPwmPara.PwmSigChCfg >> 16;
    gDuty2 = gPwmPara.PwmSigChCfg >> 8;
    gDuty3 = gPwmPara.PwmSigChCfg ;

    PWM_0.timerId               = PWM0_GTIMER_ID;
    PWM_0.pwm_period_length     = 200 * gPwmPara.PwmFrequency;
    PWM_0.pwm_duty_cycle_length = PWM_0.pwm_period_length * gDuty0 / 255; //  0us
    PWM_0.PWMTimerClkSrc        = TIMER_CLOCK_SRC_10MHZ;
    PWM_0.pwm_selection         = PWM_SEL_PWM0;
    PWM_0.pwm_pin_assignment.gpio_group = GPIO_GROUP_B;
    PWM_0.pwm_pin_assignment.gpio_pin_index = 3;
    PWM_ChangParameter(&PWM_0);

    PWM_1.timerId               = PWM1_GTIMER_ID;
    PWM_1.pwm_period_length     = 200 * gPwmPara.PwmFrequency;
    PWM_1.pwm_duty_cycle_length = PWM_1.pwm_period_length * gDuty1 / 255; //  0us
    PWM_1.PWMTimerClkSrc        = TIMER_CLOCK_SRC_10MHZ;
    PWM_1.pwm_selection         = PWM_SEL_PWM1;
    PWM_1.pwm_pin_assignment.gpio_group = GPIO_GROUP_B;
    PWM_1.pwm_pin_assignment.gpio_pin_index = 4;
    PWM_ChangParameter(&PWM_1);

    PWM_2.timerId               = PWM2_GTIMER_ID;
    PWM_2.pwm_period_length     = 200 * gPwmPara.PwmFrequency;
    PWM_2.pwm_duty_cycle_length = PWM_2.pwm_period_length * gDuty2 / 255; //  0us
    PWM_2.PWMTimerClkSrc        = TIMER_CLOCK_SRC_10MHZ;
    PWM_2.pwm_selection         = PWM_SEL_PWM2;
    PWM_2.pwm_pin_assignment.gpio_group = GPIO_GROUP_B;
    PWM_2.pwm_pin_assignment.gpio_pin_index = 5;
    PWM_ChangParameter(&PWM_2);

    PWM_3.timerId               = PWM3_GTIMER_ID;
    PWM_3.pwm_period_length     = 200 * gPwmPara.PwmFrequency;
    PWM_3.pwm_duty_cycle_length = PWM_3.pwm_period_length * gDuty3 / 255; //  0us
    PWM_3.PWMTimerClkSrc        = TIMER_CLOCK_SRC_10MHZ;
    PWM_3.pwm_selection         = PWM_SEL_PWM3;
    PWM_3.pwm_pin_assignment.gpio_group = GPIO_GROUP_B;
    PWM_3.pwm_pin_assignment.gpio_pin_index = 6;
    PWM_ChangParameter(&PWM_3);
    /*}
    else
    {
        uint32_t nDelay = gPwmPara.PwmDelay;
        nDelay = (nDelay*100)/portTICK_RATE_MS;
        xTimerChangePeriod(PWM_Timer,nDelay ,0);
    }*/
}

const Pin_Assignment IR_Test_pin_assignment[2] =
{
    {GPIO_GROUP_E, 4, GPIO_PULL_MODE_NO_PULL},  // C9 ,39
    {GPIO_GROUP_E, 5, GPIO_PULL_MODE_NO_PULL},  // C9 ,40 RX
};


IR_DATA_CB ir_rx_cb_local_verify(VOID *Data)
{
    DBG_DIRECT("Got IR RX callback");
    UINT8 index = 0;

    DBG_DIRECT("IR result = 0x%x", ((PBEE_MSG_BLK)Data)->action_result);
    //index = ((PBEE_MSG_BLK)Data)->action_result;
    if (((PBEE_MSG_BLK)Data)->action_result == IRDA_SUCCEED)
    {
        for (index = 0; index < 4; index++)
        {
            DBG_DIRECT("data = 0x%x", ((IRDA_BUF *)(((PBEE_MSG_BLK)Data)->pBuf))->Code[index]);
        }
        gIrPara.IrAdd = ((IRDA_BUF *)(((PBEE_MSG_BLK)Data)->pBuf))->Code[0];
        gIrPara.IrCmd = ((IRDA_BUF *)(((PBEE_MSG_BLK)Data)->pBuf))->Code[2];
        ProfileAPI_SendData(gIRServiceId, IR_RX_INDEX, &(gIrPara.IrAdd), sizeof(uint16_t));
        //gIrPara.IrCmd = ((UINT8)(((PBEE_MSG_BLK)Data)->pBuf))->Code[2];

    }
    //else
    //{
    //   DBG_DIRECT("Got wrong data");
    //}
    //DumpPinStatus();
    IR_Stop_RX();
    IRDA_hw_DeInit(&IR_Test_pin_assignment);
    Init_IR_RX_With_Callback();
}

VOID Init_IR_RX_With_Callback(VOID)
{
    DBG_DIRECT(">> VerifyIR_RX_With_HAL");
    IRDA_TRX_STRUCT sIR_RX;
    sIR_RX.DutyCycle = 2;
    sIR_RX.Freq_kHZ  = 38;
    sIR_RX.Inverse   = 1;
    sIR_RX.ReqNumber = 0xA;
    sIR_RX.IR_mode   = MODE_NEC;
    sIR_RX.RxStartMaskTime = 0x180;
    sIR_RX.RxEndtMaskTime  = 0x23a;
    sIR_RX.EnableRXStartManually = FALSE;
    sIR_RX.Data_length     = MAX_IRDA_BUF_SIZ;
    sIR_RX.IR_TRX_mode     = IR_RX_MODE;
    sIR_RX.p_irda_pin_assignment =  (Pin_Assignment *)IR_Test_pin_assignment;

    IRDA_hw_Init(&sIR_RX);
    IR_Set_Pin(&IR_Test_pin_assignment);
    IRDA_Set_RX_Callback(ir_rx_cb_local_verify);

    //DumpPinStatus();
    IR_Start_RX();
    //DumpIRRegister();
    //  trialTimes22++;
    //  DBG_DIRECT(" VerifyIR_RX_With_HAL trialTimes = 0x%x", trialTimes22);
    DBG_DIRECT("<< VerifyIR_RX_With_HAL");
}
IR_DATA_CB ir_tx_cb_local_verify(VOID *Data)
{
    DBG_DIRECT("Got IR TX callback");
}

void Init_IR_TX_With_Callback(void)
{
    DBG_DIRECT(">> VerifyIR_TX_WithHal");
//      static unsigned char keycode =0;
    IRDA_TRX_STRUCT sIR_Tx;
    IR_KEY_STRUCT   sIR_Key_Info;
    sIR_Tx.DutyCycle = 2;
    sIR_Tx.Freq_kHZ  = 38;
    sIR_Tx.Inverse   = 0;
    sIR_Tx.ReqNumber = 15;
    sIR_Tx.IR_mode   = MODE_NEC;
    sIR_Tx.RxStartMaskTime = 1;
    sIR_Tx.RxEndtMaskTime  = 20;
    sIR_Tx.IR_TRX_mode     = IR_TX_MODE;
    sIR_Tx.p_irda_pin_assignment =  (Pin_Assignment *)IR_Test_pin_assignment;
    sIR_Key_Info.IRMode = MODE_NEC;
    sIR_Key_Info.IR_Key_Name = IR_KEY_POWER;
    IRDA_hw_DeInit(&IR_Test_pin_assignment);
    //DBG_DIRECT(" >> VerifyIR_TX_WithHal, IRDA_hw_DeInit");
    //DumpPinStatus();
    //DBG_DIRECT(" << VerifyIR_TX_WithHal, IRDA_hw_DeInit");
    IRDA_hw_Init(&sIR_Tx);
    IR_Set_Pin(&IR_Test_pin_assignment);

    //IRDA_Set_TX_Callback(ir_tx_cb_local_verify);
    //DumpIRRegister();
    //DumpPinStatus();

    UINT16 index = 0;
//    UINT32 count = 0;

    DBG_DIRECT(">> Send IR key");
    index++;
//DumpPinStatus();
    //sIR_Key_Info.IR_Key_Name = IR_KEY_POWER;
    sIR_Key_Info.IR_Key_Name = IR_KEY_POWER;
    sIR_Key_Info.IRKEY[0] = gIrPara.IrAdd ;//0;//address
    sIR_Key_Info.IRKEY[1] = gIrPara.IrCmd ;//keycode;
    //keycode++;
    IR_SendKey(&sIR_Key_Info);

    DBG_DIRECT("<< Send IR key");

    DBG_DIRECT("<< VerifyIR_TX_WithHal");
}

void IR_Init(void)
{
    //Init_IR_RX_With_Callback();
    //Init_IR_TX_With_Callback();
    //Init_IR_RX_With_Callback();
}

void GPIOInterHandler(void);
/**
* @brief  GPIO Interrupt handler
*
*
* @return  void
*/
void Gpio16IntrHandler()
{
    GPIOInterHandler();
}
void Gpio17IntrHandler()
{
    GPIOInterHandler();
}
void Gpio18IntrHandler()
{
    GPIOInterHandler();
}
void Gpio19IntrHandler()
{
    GPIOInterHandler();
}
void Gpio20IntrHandler()
{
    GPIOInterHandler();
}
void Gpio21IntrHandler()
{
    GPIOInterHandler();
}
void GPIOInterHandler()
{
    uint32_t value32, i;

    value32 = GPIO_GetINTStatus();
    for (i = 16; i < 22; i++)
    {
        if (value32 & GPIO_Bit(i))
        {
            GPIO_DisableIntByIndex(GPIO_Num(i));
            GPIO_ClearIntByIndex(GPIO_Num(i));
            if (GPIO_ReadInputDataBit(i))
            {
                DBG_DIRECT("HIGH LEVEL%d\r\n", i);

                RTL_GPIO->INTPOLARITY &= ~GPIO_Bit(i);
            }
            else
            {
                DBG_DIRECT("LOW LEVEL%d\r\n", i);
                RTL_GPIO->INTPOLARITY = (RTL_GPIO->INTPOLARITY & (~GPIO_Bit(i)))
                                        | GPIO_Bit(i);
            }
            value32 = GPIO_ReadInputData();
            value32 >>= 16;
            //gGpioPara.GpioIn = value32;
            if (IS_GPIO_SEND)
            {
                ProfileAPI_SendData(gGPIOServiceId, GPIO_IN_INDEX, (UINT8 *)&value32, sizeof(uint8_t));
            }
            RTL_GPIO->INTEN = (RTL_GPIO->INTEN & (~GPIO_Bit(i)))
                              | GPIO_Bit(i);
        }
    }
}

void IO_Init(void)
{
    GPIO_InitTypeDef GPIO_Param;        /* Define GPIO parameter structure. KEY Beep LED is configed as GPIO. */

    GPIO_StructInit(&GPIO_Param);
    GPIO_Param.GPIO_Pin = GPIO_Bit(IO_6) | GPIO_Bit(IO_7);
    GPIO_Param.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_Param.GPIO_OType = GPIO_OType_PP;
    GPIO_Param.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Param.INTConfig.INT_Enabler = GPIO_INT_DISABLE;
    //GPIO_Param.INTConfig.INT_Level = GPIO_INT_LEVEL_SENSITIVE;
    //GPIO_Param.INTConfig.INT_Polarity = GPIO_INT_POLARITY_ACTIVE_LOW;
    GPIO_Init(&GPIO_Param);

    GPIO_StructInit(&GPIO_Param);
    GPIO_Param.GPIO_Pin = GPIO_Bit(IO_0) | GPIO_Bit(IO_1) | GPIO_Bit(IO_2) \
                          | GPIO_Bit(IO_3) | GPIO_Bit(IO_4) | GPIO_Bit(IO_5) ;
    GPIO_Param.GPIO_Mode = GPIO_Mode_IN;
    GPIO_Param.GPIO_OType = GPIO_OType_PP;
    GPIO_Param.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Param.INTConfig.INT_Enabler = GPIO_INT_ENABLE;
    GPIO_Param.INTConfig.INT_Level = GPIO_INT_LEVEL_SENSITIVE;
    GPIO_Param.INTConfig.INT_Polarity = GPIO_INT_POLARITY_ACTIVE_LOW;
    GPIO_Init(&GPIO_Param);
    for (uint32_t i = 16; i < 22; i++)
    {
        if (GPIO_ReadInputDataBit(i))
        {
            RTL_GPIO->INTPOLARITY &= ~GPIO_Bit(i);
        }
        else
        {
            RTL_GPIO->INTPOLARITY = (RTL_GPIO->INTPOLARITY & (~GPIO_Bit(i)))
                                    | GPIO_Bit(i);
        }
    }
    /* Enable Interrupt (Peripheral, CPU NVIC) */
    {
        HAL_WRITE32(0x40008000, 0x04, 0x0001001E);
        HAL_WRITE32(0x40008000, 0x08, 0x00000000);
        HAL_WRITE32(0x40008000, 0x0C, 0x0001001E);

        /*  GPIO2~GPIO31 IRQ    */
        NVIC_ClearPendingIRQ(PERIPHERAL_IRQ);
        NVIC_SetPriority(PERIPHERAL_IRQ, 0);
        NVIC_EnableIRQ(PERIPHERAL_IRQ);
    }
    /*Pad_Config(IO_0, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_LOW);//Ĭ����ʾ��
    Pad_Config(IO_1, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_LOW);//Ĭ����ʾ��
    Pad_Config(IO_2, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_LOW);//Ĭ����ʾ��
    Pad_Config(IO_3, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_LOW);//Ĭ����ʾ��
    Pad_Config(IO_4, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_LOW);//Ĭ����ʾ��
    Pad_Config(IO_5, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_LOW);//Ĭ����ʾ��


    RTL_GPIO->DATADIR = GPIO_Bit(IO_0) | GPIO_Bit(IO_1) | GPIO_Bit(IO_2) \
                                            | GPIO_Bit(IO_3) | GPIO_Bit(IO_4) | GPIO_Bit(IO_5) ;

    Pad_Config(IO_0, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);//Ĭ����ʾ��
    Pad_Config(IO_1, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);//Ĭ����ʾ��
    Pad_Config(IO_2, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);//Ĭ����ʾ��
    Pad_Config(IO_3, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);//Ĭ����ʾ��
    Pad_Config(IO_4, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);//Ĭ����ʾ��
    Pad_Config(IO_5, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);//Ĭ����ʾ��
    RTL_GPIO->DATADIR = RTL_GPIO->DATADIR&(~(GPIO_Bit(IO_0) | GPIO_Bit(IO_1) | GPIO_Bit(IO_2) \
                                            | GPIO_Bit(IO_3) | GPIO_Bit(IO_4) | GPIO_Bit(IO_5)));


    while(1)
    {
        GPIO_ResetBits(IO_0);
        GPIO_SetBits(IO_0);
    }*/
}
//gGpioPara.GpioCfg
void moduleGpioCfg(void)
{
    uint32_t i;
    for (i = 0; i < 6; i++)
    {
        if ((gGpioPara.GpioCfg >> i) & 0x01) //���״̬
        {
            Pad_Config(i + 16, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_LOW);
            RTL_GPIO->DATADIR |= GPIO_Bit(i + 16);
        }
        else
        {
            Pad_Config(i + 16, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE, PAD_OUT_LOW);
            RTL_GPIO->DATADIR = RTL_GPIO->DATADIR & (~(GPIO_Bit(i + 16))) ;
            if (GPIO_ReadInputDataBit(i + 16))
            {
                RTL_GPIO->INTPOLARITY &= ~GPIO_Bit(i + 16);
            }
            else
            {
                RTL_GPIO->INTPOLARITY = (RTL_GPIO->INTPOLARITY & (~GPIO_Bit(i + 16)))
                                        | GPIO_Bit(i + 16);
            }
        }
    }
}
void moduleGpioOut(void)
{
    uint32_t i;
    for (i = 0; i < 8; i++)
    {
        if ((gGpioPara.GpioCfg >> i) & 0x01) //���״̬
        {
            if ((gGpioPara.GpioOut >> i) & 0x01)
            {
                GPIO_SetBits(i + 16);
            }
            else
            {
                GPIO_ResetBits(i + 16);
            }
        }
    }
}
//period 500hz   duty 50%
UINT16 gFrequency4 = 10;   // 150Hz   500~65535   0x8235
UINT8  gDuty4 = 1;
UINT32 temp;
#define TIMER_REG_BASE              0x40002000
#define HAL_TIMER_READ32(addr)            (*((volatile UINT32*)(TIMER_REG_BASE + addr)))
void TimerHandle()
{
    //DBG_DIRECT("TimerHandleUser_DifferentUint\n");

    // if (temp_count > 0xFFFF) {
    //     HalTimerDis(TEST_TIMER_ID);
    // }
    // else {
    //HalTimerDumpReg(0);
    // }

//GPIO_Write(GPIO_GROUP_A, 1, 0);
//GPIO_Write(GPIO_GROUP_A, 1, 1);
    if (temp_count == 5) //duty
    {
        RTL_GPIO->DATAOUT &= ~BIT(15);//GPIO_Write(GPIO_GROUP_B, 7, 0);
    }
    else if (temp_count == 50) //peroid
    {
        temp_count = 0;
        RTL_GPIO->DATAOUT |= BIT(15);//GPIO_Write(GPIO_GROUP_B, 7, 1);
    }
    temp_count++;
    HalTimerIrqClear(PWM4_GTIMER_ID);
    //  #define TIMER_EOI_OFF               0x0c
//#define TIMER_INT_STATUS_OFF        0x10
//#define TIMER_INTERVAL              0x14
    //temp = HAL_TIMER_READ32(0x84);//(0x78 + 0xc);

    //HAL_READ32(TIMER_REG_BASE, addr)

}
/*
void GPIO_SetBits(uint32_t GPIO_Index)
{

    RTL_GPIO->DATAOUT |= BIT(GPIO_Index);
}

void GPIO_ResetBits(uint32_t GPIO_Index)
{
    RTL_GPIO->DATAOUT &= ~BIT(GPIO_Index);
}*/

UINT32 current_pin_status;
UINT8 active_mode;


UINT8 hh, mm, ss;
VOID MyRTCCB(UINT32 event)
{
    //DBG_DIRECT("event = 0x%x", event);
    //Hal_RTC_SetComparator(RTC_COMPARATOR_0, 0xFFFF, TRUE);
    /*HAL_WRITE32(0x40000000,
                       0x100,
                       (HAL_READ32(0x40000000, 0x100) & (~BIT(0))) );
    HAL_WRITE32(0x40000000,
                        0x100,
                        (HAL_READ32(0x40000000, 0x100) |  BIT(2)));
     HAL_WRITE32(0x40000000,
                        0x100,
                        (HAL_READ32(0x40000000, 0x100) |  BIT(0)));*/
    //UINT32 cnt = HAL_READ32(0x40000000, 0x124);
    //cnt = HAL_READ32(0x40000000, 0x124);
    //cnt = HAL_READ32(0x40000000, 0x124);
    //cnt = HAL_READ32(0x40000000, 0x124);
    //DBG_DIRECT("cnt is %d",cnt);
    ss++;

    if (ss >= 60)
    {
        mm++;
        ss = 0;
    }

    if (mm >= 60)
    {
        hh++;
        mm = 0;
    }

    DBG_DIRECT("Current time is: %d: %d: %d", hh, mm, ss);
}

VOID VerifyRTC_With_HAL(VOID)
{
    RTC_ADAPTER rtc_adapter;
    rtc_adapter.rtc_enabler = RTC_STOP;
    Hal_RTC_Init(&rtc_adapter);

    rtc_adapter.rtc_enabler = RTC_START;

    //rtc_adapter.rtc_clock_source = RTC_CLOCK_SOURCE_32768;
    rtc_adapter.rtc_prescalar_value = 0x1;
    Hal_RTC_Init(&rtc_adapter);
    Hal_RTC_RegisterCallback(MyRTCCB, RTC_COMPARATOR_0, TRUE);
    Hal_RTC_SetComparator(RTC_COMPARATOR_0, 0x7FFF, TRUE, TRUE);
    Hal_RTC_Enable_SystemWakeup(TRUE);
    //DumpRTCReg();

    hh = 0;
    mm = 0;
    ss = 0;
}


#include "tsmc_eflash.h"

#define EFLASH_PATCH        FMC_MAIN
#define EFLASH_PATCH_SIZE   40*1024
#define EFLASH_USER         EFLASH_PATCH+EFLASH_PATCH_SIZE
#define EFLASH_USER_SIZE    100*1024
#define EFLASH_PAGE_SIZE    0x800  //2048

#define EFLASH_TSET_ADDR    EFLASH_USER + EFLASH_USER_SIZE - EFLASH_PAGE_SIZE //Locate in last page of user area
#define SECTOR_SIZE         256
#define SECTOR_NUM_OF_PAGE  8

unsigned char sector_offset = 0;

uint32_t FMC_Writer_Sector(uint32_t u32Addr, uint32_t *pData)
{
    uint32_t i;
    uint32_t result;
    uint32_t r_data;

    for (i = 0; i < SECTOR_SIZE / 4; i++)
    {
        result = FMC_Write(u32Addr + i * 4, *(pData + i));
        if (result)
        {
            return result;
        }
        r_data = FMC_Read(u32Addr + i * 4);
        if (r_data != *(pData + i))
        {
            return FAIL;
        }
    }
    return SUCCESS;
}

UINT32 eflashTest(void)
{
    uint32_t result;
    uint32_t wBuff[SECTOR_SIZE / 4];
    for (int i = 0; i < SECTOR_SIZE / 4; i++)
    {
        wBuff[i] = i * 0x55aa3313;
    }
    if (sector_offset == 0)
    {
        result = FMC_Erase_Page(EFLASH_TSET_ADDR);
        if (result)
        {
            return result;
        }
    }
    result = FMC_Writer_Sector(EFLASH_TSET_ADDR + SECTOR_SIZE * sector_offset, wBuff);
    if (result)
    {
        return result;
    }
    else
    {
        sector_offset += 1;
    }
    if (sector_offset == SECTOR_NUM_OF_PAGE)
    {
        sector_offset = 0;
    }
    return SUCCESS;
}
