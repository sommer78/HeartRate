enum { __FILE_NUM__ = 0 };

/*
 *  Routines to access hardware
 *
 *  Copyright (c) 2014 Realtek Semiconductor Corp.
 *
 *  This module is a confidential and proprietary property of RealTek and
 *  possession or use of this module requires written permission of RealTek.
 */

#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>
#include <timers.h>
#include "blueapi.h"
#include "dlps_platform.h"
#include <string.h>

#include "profileAPI.h"

#include "app_queue.h"
#include "timers.h"
#include "bee_message.h"
#include "peripheral.h"
#include "gap.h"
#include "gapbondmgr.h"

#include "module_param_config.h"
#include "dataTrans_application.h"
#include "dataTrans_uart.h"
#include "dataTrans_profile.h"
#include "dev_info_profile.h"


/****************************************************************************/
/* Test Profile task macros                                                       */
/****************************************************************************/

#define TX_HANDLE_PRIORITY          (tskIDLE_PRIORITY + 1)   /* Task priorities. */
#define TX_HANDLE_STACK_SIZE            256
#define MAX_NUMBER_OF_TX_MESSAGE        TX_PACKET_COUNT

P_APP_TCB g_AppCB;


TimerHandle_t TimersUartDataRx;
TimerHandle_t TimersUartBaudrateChange;

bool dataTrans_getSendBufferFromRxBuffer(uint16_t len);
bool dataTrans_getCmdBufferFromRxBuffer(uint16_t len);


/****************************************************************************/
/* RX DATA handle                                                          */
/****************************************************************************/
void TimerUartDataRxCallback(TimerHandle_t pxTimer )
{
    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "TimerUartDataRxCallback", 0);
    if ( xTimerIsTimerActive( pxTimer ) != pdFALSE )
    {
        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "xTimer is already active - delete it", 0);
        // xTimerDelete( pxTimer,0);
    }
    else
    {
        if (g_AppCB->rxBufferDataLength == 0)
        {
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "TimerUartDataRxCallback len = 0", 0);
            return;
        }
        if (g_AppCB->gapProfileState == GAPSTATE_CONNECTED)
        {
            if (g_AppCB->isReceivingAtCmd)
            {
                if (g_AppCB->rxBufferReadOffset != g_AppCB->rxBufferCmdOffset)
                {
                    uint16_t temp = 0;
                    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "TimerUartDataRxCallback: p_uart_tcb->rxBufferReadOffset != p_uart_tcb->rxBufferCmdOffset", 0);
                    if (g_AppCB->rxBufferReadOffset > g_AppCB->rxBufferCmdOffset)
                    {
                        temp = UART_RX_BUFFER_LENGTH - g_AppCB->rxBufferReadOffset + g_AppCB->rxBufferCmdOffset;
                        g_AppCB->rxBufferDataLength -= temp;
                        g_AppCB->rxBufferReadOffset = g_AppCB->rxBufferCmdOffset;
                    }
                    else
                    {
                        temp =  g_AppCB->rxBufferCmdOffset - g_AppCB->rxBufferReadOffset;
                        g_AppCB->rxBufferDataLength -= temp;
                        g_AppCB->rxBufferReadOffset = g_AppCB->rxBufferCmdOffset;
                    }
                }

                uint16_t len = g_AppCB->rxBufferDataLength;
                if (len > AT_CMD_MAX_LENGTH)
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "TimerUartDataRxCallback: AT cmd too long (%d)", 1, len);
                    g_AppCB->isReceivingAtCmd = false;
                    g_AppCB->rxBufferDataLength = 0;
                    g_AppCB->rxBufferReadOffset = g_AppCB->rxBufferWriteOffsetOld;
                }
                else
                {
                    //complete AT cmd
                    if (dataTrans_getCmdBufferFromRxBuffer(len))
                    {
                        g_AppCB->isReceivingAtCmd = false;
                        AtCmdParse();
                    }
                }
            }
            else
            {
                uint16_t len = 0;
                for (; g_AppCB->rxBufferDataLength != 0;)
                {
                    if (g_AppCB->rxBufferDataLength >= DATA_TRANSMIT_DATA_PACKET_MAX_LENGTH)
                        len = DATA_TRANSMIT_DATA_PACKET_MAX_LENGTH;
                    else
                        len = g_AppCB->rxBufferDataLength;

                    if (dataTrans_getSendBufferFromRxBuffer(len))
                    {

                    }
                    else
                    {
                        return;
                    }
                }
            }
            Profile_DataTransSendData();
        }
        else
        {
            taskENTER_CRITICAL();
            if (!g_AppCB->isReceivingAtCmd)
            {
                g_AppCB->rxBufferDataLength = 0;
                g_AppCB->rxBufferReadOffset = g_AppCB->rxBufferWriteOffsetOld;
            }
            taskEXIT_CRITICAL();

            if (g_AppCB->isReceivingAtCmd)
            {
                uint16_t len = g_AppCB->rxBufferDataLength;
                if (len > AT_CMD_MAX_LENGTH)
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "TimerUartDataRxCallback: AT cmd too long (%d)", 1, len);
                    g_AppCB->isReceivingAtCmd = false;
                    g_AppCB->rxBufferDataLength = 0;
                    g_AppCB->rxBufferReadOffset = g_AppCB->rxBufferWriteOffsetOld;
                }
                else
                {
                    //complete AT cmd
                    if (dataTrans_getCmdBufferFromRxBuffer(len))
                    {
                        g_AppCB->isReceivingAtCmd = false;
                        AtCmdParse();
                    }
                }
            }
        }

    }
}

static void dataTrans_handleUartRX(bool isRxTimeout)
{
    if (g_AppCB->rxBufferDataLength == 0)
    {
        return;
    }

    if (g_AppCB->gapProfileState == GAPSTATE_CONNECTED)
    {
        if (g_AppCB->isReceivingAtCmd)
        {
            if (g_AppCB->rxBufferReadOffset != g_AppCB->rxBufferCmdOffset)
            {
                uint16_t temp = 0;
                DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "dataTrans_handleUartRX:connected p_uart_tcb->rxBufferReadOffset != p_uart_tcb->rxBufferCmdOffset", 0);
                if (g_AppCB->rxBufferReadOffset > g_AppCB->rxBufferCmdOffset)
                {
                    temp = UART_RX_BUFFER_LENGTH - g_AppCB->rxBufferReadOffset + g_AppCB->rxBufferCmdOffset;
                }
                else
                {
                    temp =  g_AppCB->rxBufferCmdOffset - g_AppCB->rxBufferReadOffset;
                }
                g_AppCB->rxBufferDataLength -= temp;
                g_AppCB->rxBufferReadOffset = g_AppCB->rxBufferCmdOffset;
            }

            {
                uint16_t len = g_AppCB->rxBufferDataLength;
                if (len > AT_CMD_MAX_LENGTH)
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "dataTrans_handleUartRX: AT cmd too long (%d)", 1, len);
                    g_AppCB->isReceivingAtCmd = false;
                    g_AppCB->rxBufferDataLength = 0;
                    g_AppCB->rxBufferReadOffset = g_AppCB->rxBufferWriteOffsetOld;
                }
                else if (len != UartRxTriggerLevel)
                {
                    //complete AT cmd
                    if (dataTrans_getCmdBufferFromRxBuffer(len))
                    {
                        g_AppCB->isReceivingAtCmd = false;
                        AtCmdParse();
                    }
                }
                else
                {

                }
            }
        }
        else
        {
            uint16_t len = 0;
            if (isRxTimeout)
            {
                for (; g_AppCB->rxBufferDataLength != 0;)
                {
                    if (g_AppCB->rxBufferDataLength >= DATA_TRANSMIT_DATA_PACKET_MAX_LENGTH)
                        len = DATA_TRANSMIT_DATA_PACKET_MAX_LENGTH;
                    else
                        len = g_AppCB->rxBufferDataLength;

                    if (dataTrans_getSendBufferFromRxBuffer(len))
                    {

                    }
                    else
                    {
                        return;
                    }
                }

            }
            else
            {
                for (; g_AppCB->rxBufferDataLength >= DATA_TRANSMIT_DATA_PACKET_MAX_LENGTH;)
                {
                    len = DATA_TRANSMIT_DATA_PACKET_MAX_LENGTH;
                    if (dataTrans_getSendBufferFromRxBuffer(len))
                    {

                    }
                    else
                    {
                        return;
                    }
                }
            }

        }
        Profile_DataTransSendData();
    }
    else
    {
        taskENTER_CRITICAL();
        if (!g_AppCB->isReceivingAtCmd)
        {
            g_AppCB->rxBufferDataLength = 0;
            g_AppCB->rxBufferReadOffset = g_AppCB->rxBufferWriteOffsetOld;
        }
        taskEXIT_CRITICAL();
        if (g_AppCB->isReceivingAtCmd)
        {
            if (g_AppCB->rxBufferReadOffset != g_AppCB->rxBufferCmdOffset)
            {
                uint16_t temp = 0;
                DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "dataTrans_handleUartRX: p_uart_tcb->rxBufferReadOffset != p_uart_tcb->rxBufferCmdOffset", 0);
                if (g_AppCB->rxBufferReadOffset > g_AppCB->rxBufferCmdOffset)
                {
                    temp = UART_RX_BUFFER_LENGTH - g_AppCB->rxBufferReadOffset + g_AppCB->rxBufferCmdOffset;
                    g_AppCB->rxBufferDataLength -= temp;
                    g_AppCB->rxBufferReadOffset = g_AppCB->rxBufferCmdOffset;
                }
                else
                {
                    temp =  g_AppCB->rxBufferCmdOffset - g_AppCB->rxBufferReadOffset;
                    g_AppCB->rxBufferDataLength -= temp;
                    g_AppCB->rxBufferReadOffset = g_AppCB->rxBufferCmdOffset;
                }
            }


            {
                uint16_t len = g_AppCB->rxBufferDataLength;
                if (len > AT_CMD_MAX_LENGTH)
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "dataTrans_handleUartRX: AT cmd too long (%d)", 1, len);
                    g_AppCB->isReceivingAtCmd = false;
                    g_AppCB->rxBufferDataLength = 0;
                    g_AppCB->rxBufferReadOffset = g_AppCB->rxBufferWriteOffsetOld;
                }
                else if (len != UartRxTriggerLevel)
                {
                    //complete AT cmd
                    if (dataTrans_getCmdBufferFromRxBuffer(len))
                    {
                        g_AppCB->isReceivingAtCmd = false;
                        AtCmdParse();
                    }
                }
                else
                {

                }

            }
        }
        else
        {
            return;
        }
    }
}

bool dataTrans_getSendBufferFromRxBuffer(uint16_t len)
{
    PTxAppData pTxData = NULL;

    if ((len == 0) || (len > g_AppCB->rxBufferDataLength))
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "dataTrans_getSendBufferFromRxBuffer: length is invalid", 0);
        return FALSE;
    }

    pTxData = AppQueueOut(&g_AppCB->txAppDataQueueFree);
    if (pTxData != NULL)
    {
        pTxData->length = len;
        if (g_AppCB->rxBufferReadOffset + len <= UART_RX_BUFFER_LENGTH)
        {
            memcpy(pTxData->send_buffer, g_AppCB->rxBuffer + g_AppCB->rxBufferReadOffset, len);
            g_AppCB->rxBufferReadOffset += len;
        }
        else
        {
            uint16_t len1 = UART_RX_BUFFER_LENGTH - g_AppCB->rxBufferReadOffset;
            memcpy(pTxData->send_buffer, g_AppCB->rxBuffer + g_AppCB->rxBufferReadOffset, len1);
            g_AppCB->rxBufferReadOffset = 0;
            memcpy(pTxData->send_buffer + len1, g_AppCB->rxBuffer + g_AppCB->rxBufferReadOffset, len - len1);
            g_AppCB->rxBufferReadOffset += len - len1;
        }
        taskENTER_CRITICAL();
        g_AppCB->rxBufferDataLength -= len;
        taskEXIT_CRITICAL();
        AppQueueIn(&g_AppCB->txAppDataQueue, pTxData);
        return true;
    }
    else
    {
        Profile_DataTransSendData();
        DBG_BUFFER(MODULE_APP, LEVEL_TRACE, "dataTrans_getSendBufferFromRxBuffer: txAppDataQueueFree is empty", 0);
        return false;
    }


}

bool dataTrans_getCmdBufferFromRxBuffer(uint16_t len)
{
    if ((len == 0) || (len > g_AppCB->rxBufferDataLength))
    {
        return FALSE;
    }

    g_AppCB->atCmdLength = len;
    if (g_AppCB->rxBufferReadOffset + len <= UART_RX_BUFFER_LENGTH)
    {
        memcpy(g_AppCB->atCmdBuffer, g_AppCB->rxBuffer + g_AppCB->rxBufferReadOffset, len);
        g_AppCB->rxBufferReadOffset += len;
    }
    else
    {
        uint16_t len1 = UART_RX_BUFFER_LENGTH - g_AppCB->rxBufferReadOffset;
        memcpy(g_AppCB->atCmdBuffer, g_AppCB->rxBuffer + g_AppCB->rxBufferReadOffset, len1);
        g_AppCB->rxBufferReadOffset = 0;
        memcpy(g_AppCB->atCmdBuffer + len1, g_AppCB->rxBuffer + g_AppCB->rxBufferReadOffset, len - len1);
        g_AppCB->rxBufferReadOffset += len - len1;
    }
    taskENTER_CRITICAL();
    g_AppCB->rxBufferDataLength -= len;
    taskEXIT_CRITICAL();
    return true;
}



/****************************************************************************/
/* GAP Message handle and profile message handle                                                          */
/****************************************************************************/
void peripheral_HandleBtGapMessage(BEE_IO_MSG *pBeeIoMsg)
{
    BT_STACK_MSG BtStackMsg;
    memcpy(&BtStackMsg, &pBeeIoMsg->parm, sizeof(pBeeIoMsg->parm));

    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "peripheral_HandleBtGapMessage subType = %d", 1, pBeeIoMsg->subType);

    switch (pBeeIoMsg->subType)
    {
        case BT_MSG_TYPE_CONN_STATE_CHANGE:
        {
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_CONN_STATE_CHANGE:(%d->%d)",
                       2, g_AppCB->gapProfileState, BtStackMsg.msgData.gapConnStateChange.newState);


            switch ( BtStackMsg.msgData.gapConnStateChange.newState )
            {
                case GAPSTATE_IDLE_NO_ADV_NO_CONN:
                {
                    g_AppCB->tx_service_cccd_enable = FALSE;
                    if (g_AppCB->gapProfileState == GAPSTATE_CONNECTED)
                    {
                        uint8_t disc_reason;
                        peripheralGetGapParameter(GAPPRRA_DISCONNECTED_REASON, &disc_reason);
                        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "peripheral_HandleBtGapStateChangeEvt: disc_reason = %d", 1, disc_reason);
                        if (disc_reason == blueAPI_CauseConnectionDisconnect)
                        {
                            AtCmdSendResponseDisconnect();
                        }
                        else
                        {
                            AtCmdSendResponseDisconnectTimeout();
                        }
                        peripheral_StartAdvertising();
                    }
                    else if (g_AppCB->gapProfileState == GAPSTATE_ADVERTISING)
                    {
                        if (gConfigParam->is_update_adv)
                        {
                            peripheral_StartAdvertising();
                        }
                    }
                    else
                    {
                    }

                }
                break;

                case GAPSTATE_ADVERTISING:
                {

                }
                break;


                case GAPSTATE_CONNECTED:
                {
                    g_AppCB->gapProfileState = (gaprole_States_t)BtStackMsg.msgData.gapConnStateChange.newState;
                    peripheralGetGapParameter(GAPPRRA_MAXTPDUDSCREDITS, &g_AppCB->wDsCredits);
                    AtCmdSendResponseOK();
                    moduleParam_SetConnInterval(20);
                }
                break;

                case GAPSTATE_CONNECTED_ADV:
                {

                }
                break;

                default:
                {

                }
                break;

            }

            g_AppCB->gapProfileState = (gaprole_States_t)BtStackMsg.msgData.gapConnStateChange.newState;

        }
        break;

        case BT_MSG_TYPE_BOND_STATE_CHANGE:
        {
            switch (BtStackMsg.msgData.gapBondStateChange.newState)
            {
                case GAPBOND_PAIRING_STATE_STARTED:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(GAPBOND_PAIRING_STATE_STARTED)", 0);
                }
                break;

                case GAPBOND_PAIRING_STATE_COMPLETE:
                {

                }
                break;

                case GAPBOND_PAIRING_STATE_BONDED:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(GAPBOND_PAIRING_STATE_BONDED)", 0);
                    //GAPRole_SendUpdateParam( 0x80, 0x80, 0, 500, GAPROLE_RESEND_PARAM_UPDATE );
                }
                break;

                default:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(unknown newstate: %d)", 1, BtStackMsg.msgData.gapBondStateChange.newState);
                }
                break;
            }

        }
        break;

        case BT_MSG_TYPE_BOND_PASSKEY_DISPLAY:
        {

        }
        break;

        case BT_MSG_TYPE_BOND_PASSKEY_INPUT:
        {
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_PASSKEY_INPUT", 0);
            GAPBondMgr_InputPassKey();
        }
        break;

        case BT_MSG_TYPE_BOND_OOB_INPUT:
        {
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_OOB_INPUT", 0);
            GAPBondMgr_InputOobData();
        }
        break;

        case BT_MSG_TYPE_ENCRYPT_STATE_CHANGE:
        {
            switch (BtStackMsg.msgData.gapEncryptStateChange.newState)
            {
                case GAPBOND_ENCRYPT_STATE_ENABLED:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "GAPBOND_ENCRYPT_STATE_ENABLED", 0);
                    //GAPRole_SendUpdateParam( 0x80, 0x80, 0, 500, GAPROLE_RESEND_PARAM_UPDATE );
                }
                break;

                case GAPBOND_ENCRYPT_STATE_DISABLED:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "GAPBOND_ENCRYPT_STATE_DISABLED", 0);
                }
                break;

                default:
                    break;
            }
        }
        break;
        case BT_MSG_TYPE_CONN_PARA_UPDATE_CHANGE:
            if (BtStackMsg.msgData.gapConnParaUpdateChange.status == 0)
            {
                uint16_t conn_interval = 0;
                //success
                if (gConfigParam->is_conn_update)
                {
                    AtCmdSendResponseOK();
                    gConfigParam->is_conn_update = FALSE;
                }
                else
                {
                }
                peripheralGetGapParameter(GAPPRRA_CONN_INTERVAL, &conn_interval);
                DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "BT_MSG_TYPE_CONN_PARA_UPDATE_CHANGE 0x%x", 1, conn_interval);
                gConfigParam->conn_interval = conn_interval * 5 / 4;
            }
            else
            {
                //fail
                if (gConfigParam->is_conn_update)
                {
                    AtCmdSendResponseTimeout();
                    gConfigParam->is_conn_update = FALSE;
                }
                else
                {
                }
            }

            break;
        default:
            DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "peripheral_HandleBtGapMessage unknown subtype", 1, pBeeIoMsg->subType);

            break;

    }
}

void AppHandleGATTCallback(uint8_t serviceID,void* pData)
{
	if(serviceID ==ProfileAPI_ServiceUndefined)
	{
		TEventInfoCBs_t*pPara = (TEventInfoCBs_t*)pData;  
        switch(pPara->eventId)
		{
		    case PROFILE_EVT_SRV_REG_COMPLETE:// srv register result event. 
			    DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "profile callback PROFILE_EVT_SRV_REG_COMPLETE\n", 0);
			    {
				    //DeviceInformationUpdate();
				    uint8_t     LocalBd[BLUE_API_BD_SIZE];
				    char SystemID[8]        = {0, 1, 2, 0, 0, 3, 4, 5};
                    peripheralGetGapParameter(GAPPARA_BD_ADDR, &LocalBd);
                    SystemID[0] = LocalBd[5];
                    SystemID[1] = LocalBd[4];
                    SystemID[2] = LocalBd[3];
                    SystemID[5] = LocalBd[2];
                    SystemID[6] = LocalBd[1];
                    SystemID[7] = LocalBd[0];
				    DIS_SetParameter(DIS_PARAM_SYSTEM_ID, 8, SystemID);
                    peripheral_Init_StartAdvertising();
			    }
			    break;
			case PROFILE_EVT_SEND_DATA_COMPLETE:
			    g_AppCB->wDsCredits = pPara->sParas[0];
                Profile_DataTransSendData();
				break;
		}
	}
}

/****************************************************************************/
/* Message handle                                                                    */
/****************************************************************************/
void AppHandleIODriverMessage(BEE_IO_MSG io_driver_msg_recv)
{
    uint16_t msgtype = io_driver_msg_recv.IoType;

    switch (msgtype)
    {
        case IO_UART_MSG_TYPE:
            if (io_driver_msg_recv.subType == MSG_UART_RX)
            {
                xTimerReset(TimersUartDataRx, 0);
                dataTrans_handleUartRX(false);
                break;
            }
            else if (io_driver_msg_recv.subType == MSG_UART_RX_TIMEOUT)
            {
                xTimerStop(TimersUartDataRx, 0);
                dataTrans_handleUartRX(true);
                break;
            }
        case BT_STATUS_UPDATE:
        {
            peripheral_HandleBtGapMessage(&io_driver_msg_recv);
        }
        break;
        default:
            break;
    }
}

/****************************************************************************/
/* application Init                                                                */
/****************************************************************************/
static void TimerInit(void)
{
    uint16_t time = 2;
    if(gConfigParam->baudrate.baudrate == 4800)
    {
        time = 4;
    }
    else if(gConfigParam->baudrate.baudrate == 9600)
    {
        time = 3;
    }
    else
    {
        time = 2;
    }
    
    TimersUartDataRx = xTimerCreate("TimersUartDataRx", time, pdFALSE, ( void *) 5, TimerUartDataRxCallback);

    if ( TimersUartDataRx == NULL )
    {
        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "TimerInit TimersUartDataRx init failed", 0);
    }
    TimersUartBaudrateChange = xTimerCreate("TimersUartChange", 200, pdFALSE, ( void *) 6, TimerUartBaudrateChangeCallback);

    if ( TimersUartBaudrateChange == NULL )
    {
        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "TimerInit TimersUartBaudrateChange init failed", 0);
    }
}


static void TxUartQueueInit(void)
{
    uint8_t i = 0;
    uint8_t tx_queue_size = TX_PACKET_COUNT;
    PTxData pTxData = g_AppCB->txUartDataBuffer;
    g_AppCB->txUartDataQueueFree.ElementCount = 0;
    g_AppCB->txUartDataQueueFree.First = NULL;
    g_AppCB->txUartDataQueueFree.Last = NULL;

    for ( i = 0; i < tx_queue_size; i++ )
    {
        AppQueueIn(&g_AppCB->txUartDataQueueFree, pTxData);
        pTxData++;
    }
}

static void TxAppQueueInit(void)
{
    uint8_t i = 0;
    uint8_t send_queue_size = TX_APP_PACKET_COUNT;
    PTxAppData pTxData = g_AppCB->txAppDataBuffer;
    g_AppCB->txAppDataQueueFree.ElementCount = 0;
    g_AppCB->txAppDataQueueFree.First = NULL;
    g_AppCB->txAppDataQueueFree.Last = NULL;
    g_AppCB->txAppDataQueue.ElementCount = 0;
    g_AppCB->txAppDataQueue.First = NULL;
    g_AppCB->txAppDataQueue.Last = NULL;
    for ( i = 0; i < send_queue_size; i++ )
    {
        AppQueueIn(&g_AppCB->txAppDataQueueFree, pTxData);
        pTxData++;
    }
}

void ApplicationInit( void )
{

    g_AppCB->QueueHandleTxData  = xQueueCreate(MAX_NUMBER_OF_TX_MESSAGE, sizeof(PTxData));
    TxUartQueueInit();
    TxAppQueueInit();
    TimerInit();
    xTaskCreate(TxHandleTask, "TxHandle", TX_HANDLE_STACK_SIZE / sizeof(portSTACK_TYPE), NULL, TX_HANDLE_PRIORITY, &g_AppCB->txAssistHandle);
}


