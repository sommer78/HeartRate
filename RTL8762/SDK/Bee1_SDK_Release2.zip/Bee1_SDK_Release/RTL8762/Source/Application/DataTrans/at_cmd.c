enum { __FILE_NUM__ = 0 };

/*
 *  Routines to access hardware
 *
 *  Copyright (c) 2014 Realtek Semiconductor Corp.
 *
 *  This module is a confidential and proprietary property of RealTek and
 *  possession or use of this module requires written permission of RealTek.
 */


#include "trace.h"
#include "dataTrans_uart.h"
#include <stdio.h>
#include <string.h>
#include "module_param_config.h"
#include "at_cmd.h"
#include "dataTrans_application.h"

#define AT_CMD_HEADER_LENGTH 4
#define AT_CMD_RST_LENGTH 19
#define AT_CMD_MAC_LENGTH 9
#define AT_CMD_PID_LENGTH 10

const char AtCmdHeader[AT_CMD_HEADER_LENGTH] = {'T', 'T', 'M', ':'};
const char AtCmdResponseOK[] = "TTM:OK\r\n";
const char AtCmdResponseERR[] = "TTM:ERP\r\n";
const char AtCmdResponseTimeout[] = "TTM:TIMEOUT\r\n";
const char AtCmdResponseBPSSet[] = "TTM:BPS SET AFTER 2S ...\r\n";
const char AtCmdResponseMAC[] = "TTM:MAC-";
const char AtCmdResponseConn[] = "TTM:CONNECT\r\n";
const char AtCmdResponseDisconn[] = "TTM:DISCONNECT\r\n";
const char AtCmdResponseDisconnTimeout[] = "TTM:DISCONNECT FOR TIMEOUT\r\n";
const char AtCmdRST[] = "TTM:RST-SYSTEMRESET";
const char AtCmdMAC[] = "TTM:MAC-?";



static void AtCmdSendResponse(const char *p_resp, uint16_t len)
{
    PTxData pTxData = NULL;

    pTxData = AppQueueOut(&g_AppCB->txUartDataQueueFree);
    if (pTxData != NULL)
    {
        memcpy(pTxData->tx_buffer, p_resp, len);
        pTxData->length = len;
        if (xQueueSend(g_AppCB->QueueHandleTxData, &pTxData, 0) == errQUEUE_FULL)
        {
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "AtCmdSendResponse:send data failed\n", 0);
            AppQueueIn(&g_AppCB->txUartDataQueueFree, pTxData);
            return;
        }
    }
    else
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "AtCmdSendResponse: queue is full\n", 0);
        return;
    }

}

void AtCmdSendResponseOK()
{
    AtCmdSendResponse(AtCmdResponseOK, strlen(AtCmdResponseOK));
}

void AtCmdSendResponseERR()
{
    AtCmdSendResponse(AtCmdResponseERR, strlen(AtCmdResponseERR));
}

void AtCmdSendResponseTimeout()
{
    AtCmdSendResponse(AtCmdResponseTimeout, strlen(AtCmdResponseTimeout));
}

void AtCmdSendResponseConnect()
{
    AtCmdSendResponse(AtCmdResponseConn, strlen(AtCmdResponseConn));
}

void AtCmdSendResponseDisconnect()
{
    AtCmdSendResponse(AtCmdResponseDisconn, strlen(AtCmdResponseDisconn));
}

void AtCmdSendResponseDisconnectTimeout()
{
    AtCmdSendResponse(AtCmdResponseDisconnTimeout, strlen(AtCmdResponseDisconnTimeout));
}


static void AtCmdHandleMAC(void)
{
    PTxData pTxData = NULL;
    uint16_t pos = 0;
    uint8_t     LocalBd[BLUE_API_BD_SIZE];
    char bdStr[20];
    peripheralGetGapParameter(GAPPARA_BD_ADDR, &LocalBd);
    sprintf(bdStr, "%02X%02X%02X%02X%02X%02X", LocalBd[5], LocalBd[4], LocalBd[3], LocalBd[2], LocalBd[1], LocalBd[0]);
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "AtCmdHandleMAC", 0);

    pTxData = AppQueueOut(&g_AppCB->txUartDataQueueFree);
    if (pTxData != NULL)
    {
        memcpy(pTxData->tx_buffer, AtCmdResponseMAC, strlen(AtCmdResponseMAC));
        pos += strlen(AtCmdResponseMAC);
        memcpy(pTxData->tx_buffer + pos, bdStr, strlen(bdStr));
        pos += strlen(bdStr);
        pTxData->tx_buffer[pos] = '\r';
        pos++;
        pTxData->tx_buffer[pos] = '\n';
        pos++;
        pTxData->length = pos;
        if (xQueueSend(g_AppCB->QueueHandleTxData, &pTxData, 0) == errQUEUE_FULL)
        {
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "AtCmdHandleMAC:send data failed\n", 0);
            AppQueueIn(&g_AppCB->txUartDataQueueFree, pTxData);
            return;
        }
    }
    else
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "AtCmdHandleMAC: queue is full\n", 0);
        return;
    }
}

static int Atoi(const char *str)
{
    int res = 0, begin = 0;
    bool minus = false;
    while (*str != '\0')
    {
        if (begin == 0 && (('0' <= *str && *str <= '9') || *str == '-') )
        {
            begin = 1;
            if (*str == '-')
            {
                minus = true;
                str++;
            }
        }
        else if ( begin == 1 && (*str < '0' || *str > '9') )
            break;
        if (begin == 1)
            res = res * 10 + (*str - '0');
        str++;
    }
    return minus ? -res : res;
}

void AtCmdParse(void)
{
    PTxData pTxData = NULL;
    uint16_t pos = 0;
    int16_t param;
    uint16_t len;
    bool isRespErr = TRUE;

    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "AtCmdParse", 0);

    if (g_AppCB->atCmdLength < AT_CMD_HEADER_LENGTH)
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "AtCmdParse cmd too short %d", 1, g_AppCB->atCmdLength);
        return;
    }
    if (memcmp(g_AppCB->atCmdBuffer, AtCmdHeader, AT_CMD_HEADER_LENGTH) != 0)
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "AtCmdParse: not at cmd", 0);
        return;
    }
    pos += AT_CMD_HEADER_LENGTH;
    pTxData = AppQueueOut(&g_AppCB->txUartDataQueueFree);
    if (pTxData != NULL)
    {
        memcpy(pTxData->tx_buffer, g_AppCB->atCmdBuffer, g_AppCB->atCmdLength);
        pTxData->length = g_AppCB->atCmdLength;
        if (xQueueSend(g_AppCB->QueueHandleTxData, &pTxData, 0) == errQUEUE_FULL)
        {
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "AtCmdParse:send data failed\n", 0);
            AppQueueIn(&g_AppCB->txUartDataQueueFree, pTxData);
            return;
        }
    }
    else
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "AtCmdParse: queue is full\n", 0);
        return;
    }

    //parse the AT cmd
    switch (g_AppCB->atCmdBuffer[pos])
    {
        case 'A':
            pos++;
            if (g_AppCB->atCmdBuffer[pos] == 'D')
            {
                pos++;
                if (g_AppCB->atCmdBuffer[pos] == 'P')
                {
                    pos++;
                    pos++;
                    param = Atoi(g_AppCB->atCmdBuffer + pos);
                    if (moduleParam_SetAdvInterval(param)) //AT cmd: ADP
                    {
                        isRespErr = FALSE;
                        AtCmdSendResponseOK();
                    }
                }
                else if (g_AppCB->atCmdBuffer[pos++] == 'D')
                {
                    pos++;
                    len = g_AppCB->atCmdLength - pos;
                    if (moduleParam_SetAdvData((uint8_t *)g_AppCB->atCmdBuffer + pos, len)) //AT cmd: ADD
                    {
                        isRespErr = FALSE;
                        AtCmdSendResponseOK();
                    }
                }
            }
            break;
        case 'B':
            pos++;
            if ((g_AppCB->atCmdBuffer[pos++] == 'P') && (g_AppCB->atCmdBuffer[pos++] == 'S')
                    && (g_AppCB->atCmdBuffer[pos++] == '-'))
            {
                int param1;
                g_AppCB->atCmdBuffer[g_AppCB->atCmdLength] = '\0';
                param1 = Atoi(g_AppCB->atCmdBuffer + pos);
                if (moduleParam_SetBaudrate(param1)) //AT cmd: BPS
                {
                    AtCmdSendResponse(AtCmdResponseBPSSet, strlen(AtCmdResponseBPSSet));
                    isRespErr = FALSE;
                }
            }
            break;
        case 'C':
            pos++;
            if (g_AppCB->atCmdBuffer[pos] == 'I')
            {
                pos++;
                if ((g_AppCB->atCmdBuffer[pos++] == 'T') && (g_AppCB->atCmdBuffer[pos++] == '-')
                        && (g_AppCB->atCmdBuffer[g_AppCB->atCmdLength - 2] == 'm')
                        && (g_AppCB->atCmdBuffer[g_AppCB->atCmdLength - 1] == 's'))
                {
                    param = (uint16_t)Atoi(g_AppCB->atCmdBuffer + pos);
                    if (moduleParam_SetConnInterval(param)) //AT cmd: CIT
                    {
                        gConfigParam->is_conn_update = TRUE;
                        isRespErr = FALSE;
                    }
                }

            }
            else if (g_AppCB->atCmdBuffer[pos] == 'D')
            {
                pos++;
                if ((g_AppCB->atCmdBuffer[pos++] == 'L') && (g_AppCB->atCmdBuffer[pos++] == '-')
                        && (g_AppCB->atCmdBuffer[g_AppCB->atCmdLength - 2] == 'm')
                        && (g_AppCB->atCmdBuffer[g_AppCB->atCmdLength - 1] == 's'))
                {
                    param = (uint16_t)Atoi(g_AppCB->atCmdBuffer + pos);
                    if (moduleParam_SetTxDelay(param)) //AT cmd: CDL
                    {
                        isRespErr = FALSE;
                        AtCmdSendResponseOK();
                    }
                }
            }
            break;

        case 'R'://RST
            pos++;
            if (g_AppCB->atCmdBuffer[pos] == 'S')
            {
                if (g_AppCB->atCmdLength >= AT_CMD_RST_LENGTH)
                {
                    if (memcmp(g_AppCB->atCmdBuffer, AtCmdRST, AT_CMD_RST_LENGTH) == 0)
                    {
                        moduleParam_SetSystemReset();
                        isRespErr = FALSE;
                    }
                }
            }
            else if (g_AppCB->atCmdBuffer[pos] == 'E')
            {
                pos++;
                if ((g_AppCB->atCmdBuffer[pos++] == 'N') && (g_AppCB->atCmdBuffer[pos++] == '-'))
                {
                    len = g_AppCB->atCmdLength - pos;
                    if (moduleParam_SetModuleName(g_AppCB->atCmdBuffer + pos, len)) //AT cmd: REN
                    {
                        isRespErr = FALSE;
                        AtCmdSendResponseOK();
                    }
                }
            }

            break;

        case 'M'://MAC
            if (g_AppCB->atCmdLength >= AT_CMD_MAC_LENGTH)
            {
                if (memcmp(g_AppCB->atCmdBuffer, AtCmdMAC, AT_CMD_MAC_LENGTH) == 0)
                {
                    AtCmdHandleMAC();
                    isRespErr = FALSE;
                }
            }
            break;
        case 'P':
            pos++;
            if ((g_AppCB->atCmdBuffer[pos++] == 'I') && (g_AppCB->atCmdBuffer[pos++] == 'D') && (g_AppCB->atCmdBuffer[pos++] == '-'))
            {
                if (g_AppCB->atCmdLength == AT_CMD_PID_LENGTH)
                {
                    char byte1 = g_AppCB->atCmdBuffer[pos++];
                    char byte2 = g_AppCB->atCmdBuffer[pos++];
                    moduleParam_SetPID(byte1, byte2);
                    isRespErr = FALSE;
                    AtCmdSendResponseOK();
                }
            }
            break;
        case 'T':
            pos++;
            if ((g_AppCB->atCmdBuffer[pos++] == 'P') && (g_AppCB->atCmdBuffer[pos++] == 'L') && (g_AppCB->atCmdBuffer[pos++] == '-'))
            {
                param = Atoi(g_AppCB->atCmdBuffer + pos);
                if (moduleParam_SetTxPower(param))
                {
                    isRespErr = FALSE;
                }
            }
            break;
        default:
            break;
    }
    if (isRespErr)
    {
        AtCmdSendResponseERR();
    }

}


