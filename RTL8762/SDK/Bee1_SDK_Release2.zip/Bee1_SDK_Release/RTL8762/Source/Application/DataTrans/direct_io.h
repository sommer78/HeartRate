/*********************************************************************************************************
*               Copyright(c) 2014, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     direct_io.h
* @brief    IO function and init for testing profiles.
* @details  IO function and init for testing profiles.
* @author
* @date     2015-04-02
* @version  v0.1
*********************************************************************************************************
*/

#ifndef _DIRECT_IO_H_
#define _DIRECT_IO_H_
#include "rtl_types.h"
//#include <core_cm0.h>                               /*!< Cortex-M0 processor and core peripherals                              */
//#include "system_RTL876X.h"                           /*!< RTL876X System                                                          */
#include <stdint.h>
/**
  * @brief General purpose input and output. (GPIO)
  */

//#define RTL_GPIO_BASE             0x40001000UL
//#define RTL_GPIO                        ((RTL_GPIO_Type           *) RTL_GPIO_BASE)
#define IO_0   P2_0
#define IO_1   P2_1
#define IO_2   P2_2
#define IO_3   P2_3
#define IO_4   P2_4
#define IO_5   P2_5
#define IO_6   P2_6
#define IO_7   P2_7
void IoParaInit(void);
void PWM_Init(void);
void modulePwmInit(void);
void moduleGpioCfg(void);
void moduleGpioOut(void);
//void modulePwmSigCfg(void);
void modulePwmSignalChange(void);
void IO_Init(void);
void IR_Init(void);
VOID Init_IR_RX_With_Callback(VOID);
void Init_IR_TX_With_Callback(void);

extern uint8_t IS_GPIO_SEND;
#endif
