/*
 *  Routines to access hardware
 *
 *  Copyright (c) 2014 Realtek Semiconductor Corp.
 *
 *  This module is a confidential and proprietary property of RealTek and
 *  possession or use of this module requires written permission of RealTek.
 */


#ifndef _DIRECT_IO_PROFILE_H_
#define  _DIRECT_IO_PROFILE_H_


#define GATT_UUID_PWM                               0xFFB0
#define GATT_UUID_ALL_CHANNEL_CFG       0xFFB1
#define GATT_UUID_SINGLE_CHANNEL_SET  0xFFB2
#define GATT_UUID_FREQUENCY           0xFFB3
#define GATT_UUID_DELAY_TIME          0xFFB4
#define PWM_ALL_CHANNEL_CFG_INDEX    2
#define PWM_SINGLE_CHANNEL_SET_INDEX 4
#define PWM_FREQUENCY_INDEX          6
#define PWM_DELAY_TIME               8


#define GATT_UUID_IR                0xFF80
#define GATT_UUID_IR_TX         0xFF81
#define GATT_UUID_IR_RX         0xFF82
#define IR_TX_INDEX             2
#define IR_RX_INDEX                 4

#define GATT_UUID_GPIO              0xFFF0

#define GATT_UUID_GPIO_CFG      0xFFF1
#define GATT_UUID_GPIO_OUT      0xFFF2
#define GATT_UUID_GPIO_IN       0xFFF3

//#define GATT_UUID_GPIO6_TOG1  0xFFF4
//#define GATT_UUID_GPIO6_TOG2  0xFFF5
//#define GATT_UUID_GPIO7_TOG1  0xFFF6
//#define GATT_UUID_GPIO7_TOG2  0xFFF7

//#define GATT_UUID_GPIO4_PRE_WIDTH  0xFFF8
//#define GATT_UUID_GPIO5_PRE_WIDTH  0xFFF9

#define GPIO_CFG_INDEX              2
#define GPIO_OUT_INDEX                  4
#define GPIO_IN_INDEX                   6
//#define GPIO6_TOG1_INDEX              9
//#define GPIO6_TOG2_INDEX              0xB

extern uint8_t gPWMServiceId;
extern uint8_t gIRServiceId;
extern uint8_t gGPIOServiceId;
void Direct_io_AddService(void* pFunc);

#endif

