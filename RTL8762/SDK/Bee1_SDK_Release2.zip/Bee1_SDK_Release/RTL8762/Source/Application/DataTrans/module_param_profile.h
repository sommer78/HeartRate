/*
 *  Routines to access hardware
 *
 *  Copyright (c) 2014 Realtek Semiconductor Corp.
 *
 *  This module is a confidential and proprietary property of RealTek and
 *  possession or use of this module requires written permission of RealTek.
 */


#ifndef _MODULE_PARAAM_PROFILE_H_
#define  _MODULE_PARAAM_PROFILE_H_

#define GATT_UUID_MODULE_PARAM  0xFF90
#define GATT_UUID_CHAR_MODULE_NAME 0xFF91
#define GATT_UUID_CHAR_CONN_INTERVAL  0xFF92
#define GATT_UUID_CHAR_UART_BAUDRATE 0xFF93
#define GATT_UUID_CHAR_REMOTE_CONTROL 0xFF94
#define GATT_UUID_CHAR_ADV_INTERVAL 0xFF95
#define GATT_UUID_CHAR_PID 0xFF96
#define GATT_UUID_CHAR_TX_POWER 0xFF97
#define GATT_UUID_CHAR_ADV_DATA 0xFF98
#define GATT_UUID_CHAR_REMOTE_CONTROL_EXT 0xFF99
#define GATT_UUID_CHAR_SYSTEM_MODE 0xFF9A
#define MODULE_PARAM_MODULE_NAME_INDEX 2
#define MODULE_PARAM_CONN_INTERVAL_INDEX 4
#define MODULE_PARAM_UART_BAUDRATE_INDEX 6
#define MODULE_PARAM_REMOTE_CONTROL_INDEX 8
#define MODULE_PARAM_ADV_INTERVAL_INDEX 10
#define MODULE_PARAM_PID_INDEX 12
#define MODULE_PARAM_TX_POWER_INDEX 14
#define MODULE_PARAM_ADV_DATA_INDEX 16
#define MODULE_PARAM_REMOTE_CONTROL_EXT_INDEX 18
#define MODULE_PARAM_SYSTEM_MODE_INDEX 20

void Module_param_AddService(void* pFunc);

#endif

