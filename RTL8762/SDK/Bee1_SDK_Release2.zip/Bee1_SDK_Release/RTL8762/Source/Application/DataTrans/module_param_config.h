
#ifndef _MUDULE_PARAM_CONFIG_H_
#define  _MUDULE_PARAM_CONFIG_H_

#include "rtl876x_flash_storage.h"
#include "rtl_types.h"
#include "freeRTOS.h"
#include "timers.h"

#define MODULE_PARAM_SYSTEM_MODE_MASK 0x01
#define MODULE_PARAM_SYSTEM_MODE_PULSE 0x01
#define MODULE_PARAM_SYSTEM_MODE_LEVEL 0x00
#define ADV_DATA_MAX_LENGTH 16
#define DEVICE_NAME_MAX_LENGTH 16

typedef struct
{
    uint32_t  baudrate;
} baudrate_struct;

typedef struct
{
    uint16_t  adv_interval;
    uint8_t   padding[2];
} adv_interval_struct;

typedef struct
{
    uint8_t data_length;
    uint8_t padding[3];
    uint8_t adv_data[16];
} adv_data_struct;

typedef struct
{
    uint8_t padding[2];
    uint8_t pid[2];
} pid_struct;

typedef struct
{
    uint32_t delay;
} tx_delay_struct;

typedef struct
{
    uint8_t system_mode;
    uint8_t padding[3];
} system_mode_struct;

typedef struct
{
    Local_name_struct localName;
    bool is_conn_update;
    uint16_t conn_interval;
    uint16_t conn_interval_update;
    baudrate_struct baudrate;
    adv_interval_struct advInterval;
    adv_data_struct advData;
    pid_struct      pid;
    tx_delay_struct txDelay;
    system_mode_struct systemMode;
    int16_t  tx_power;
    bool is_update_adv;
} ConfigParamStruct;

typedef struct
{
    uint32_t PwmSigChCfg;
    uint16_t PwmFrequency;
    uint16_t PwmDelay;
    uint8_t  PwmAllChCfg;
} PwmParaStruct;

typedef struct
{
    uint8_t  IrAdd;
    uint8_t  IrCmd;
} IrParaStruct;

typedef struct
{
    uint8_t  GpioCfg;
    uint8_t  GpioOut;
    uint8_t  GpioIn;
} GpioParaStruct;
extern ConfigParamStruct *gConfigParam;

void moduleParam_LoadFromFlash(void);
void moduleParam_InitAdvData(void);
void moduleParam_ShallowRestore(void);
void moduleParam_DeepRestore(void);


void moduleParam_RemoteControl(uint8_t param);
void moduleParam_RemoteControlExtend(uint8_t param);
void moduleParam_SetSystemMode(uint8_t param);
bool moduleParam_SetConnInterval(uint16_t param);
bool moduleParam_SetModuleName(char *p_adv, uint16_t len);
bool moduleParam_SetBaudrate(int param);
void moduleParam_SetSystemReset(void);
bool moduleParam_SetAdvInterval(uint16_t param);
bool moduleParam_SetAdvData(uint8_t *p_adv, uint16_t len);
void moduleParam_SetPID(char byte1, char byte2);
bool moduleParam_SetTxPower(int16_t param);
bool moduleParam_SetTxDelay(uint16_t param);

uint8_t moduleParam_GetConnIntervalIndex(void);
uint8_t moduleParam_GetBaudrateIndex(void);
uint8_t moduleParam_GetAdvIntervalIndex(void);
uint8_t moduleParam_GetTxPowerIndex(void);



#endif
