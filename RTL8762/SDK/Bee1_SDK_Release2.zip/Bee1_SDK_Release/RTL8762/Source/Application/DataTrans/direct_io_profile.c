enum { __FILE_NUM__ = 0 };

/*
 *  Routines to access hardware
 *
 *  Copyright (c) 2014 Realtek Semiconductor Corp.
 *
 *  This module is a confidential and proprietary property of RealTek and
 *  possession or use of this module requires written permission of RealTek.
 */

#include <string.h>
#include "trace.h"


#include "rtl_string.h"
#include "dataTrans_application.h"
#include "profileApi.h"
#include "direct_io.h"
#include "rtl876x_gpio.h"
#include "module_param_config.h"
#include "direct_io_profile.h"

uint8_t gPWMServiceId = 0xff;
uint8_t gIRServiceId = 0xff;
uint8_t gGPIOServiceId = 0xff;
extern PwmParaStruct gPwmPara;
extern IrParaStruct gIrPara;
extern GpioParaStruct gGpioPara;
extern TimerHandle_t PWM_Timer;

/*#define GATT_UUID_PWM                                 0xFFB0
#define GATT_UUID_ALL_CHANNEL_CFG       0xFFB1
#define GATT_UUID_SINGLE_CHANNEL_SET  0xFFB2
#define GATT_UUID_FREQUENCY           0xFFB3
#define GATT_UUID_DELAY_TIME          0xFFB4 */

const TAttribAppl GattPwmProfileTable[] =
{
    /*0000----------------- gattdPwm Service -------------------*/
    {
        (ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_LE | ATTRIB_FLAG_BR_EDR), /* wFlags     */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_PRIMARY_SERVICE),
            HI_WORD(GATT_UUID_PRIMARY_SERVICE),
            LO_WORD(GATT_UUID_PWM),    /* service UUID */
            HI_WORD(GATT_UUID_PWM)
        },
        UUID_16BIT_SIZE,                            /* bValueLen     */
        NULL,                                       /* pValueContext */
        GATT_PERM_READ                              /* wPermissions  */
    },
    /*1111----------------------------------------------------------------------------------------*/
    /* GATT_UUID_ALL_CHANNEL_CFG */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE,            /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*2222GATT_UUID_ALL_CHANNEL_CFG value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_ALL_CHANNEL_CFG),
            HI_WORD(GATT_UUID_ALL_CHANNEL_CFG)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_WRITE | GATT_PERM_READ                           /* wPermissions */
    },
    /*----------------------------------------------------------------------------------------*/
    /*3333GATT_UUID_SINGLE_CHANNEL_SET */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE,            /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*4444GATT_UUID_SINGLE_CHANNEL_SET value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_SINGLE_CHANNEL_SET),
            HI_WORD(GATT_UUID_SINGLE_CHANNEL_SET)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_WRITE | GATT_PERM_READ                           /* wPermissions */
    },
    /*----------------------------------------------------------------------------------------*/
    /*5555GATT_UUID_FREQUENCY */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE,            /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*6666GATT_UUID_FREQUENCY value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_FREQUENCY),
            HI_WORD(GATT_UUID_FREQUENCY)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_WRITE | GATT_PERM_READ                           /* wPermissions */
    },
    /*----------------------------------------------------------------------------------------*/
    /*7777GATT_UUID_DELAY_TIME */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE,            /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*8888GATT_UUID_DELAY_TIME value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_DELAY_TIME),
            HI_WORD(GATT_UUID_DELAY_TIME)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_WRITE | GATT_PERM_READ                           /* wPermissions */
    },
};


/*#define GATT_UUID_IR          0xFF80
#define GATT_UUID_IR_TX         0xFF81
#define GATT_UUID_IR_RX         0xFF82*/

const TAttribAppl GattIrProfileTable[] =
{
    /*0000----------------- gattdIR Service -------------------*/
    {
        (ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_LE | ATTRIB_FLAG_BR_EDR), /* wFlags     */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_PRIMARY_SERVICE),
            HI_WORD(GATT_UUID_PRIMARY_SERVICE),
            LO_WORD(GATT_UUID_IR),    /* service UUID */
            HI_WORD(GATT_UUID_IR)
        },
        UUID_16BIT_SIZE,                            /* bValueLen     */
        NULL,                                       /* pValueContext */
        GATT_PERM_READ                              /* wPermissions  */
    },
    /*1111----------------------------------------------------------------------------------------*/
    /* GATT_UUID_IR_TX */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_WRITE_NO_RSP,              /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*2222GATT_UUID_IR_TX value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_IR_TX),
            HI_WORD(GATT_UUID_IR_TX)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_WRITE                             /* wPermissions */
    },
    /*----------------------------------------------------------------------------------------*/
    /*3333GATT_UUID_IR_RX */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_NOTIFY,              /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*4444GATT_UUID_IR_RX value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_IR_RX),
            HI_WORD(GATT_UUID_IR_RX)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_READ                             /* wPermissions */
    },
    /* 5555555  client characteristic configuration */
    {
        ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_CCCD_APPL,                   /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHAR_CLIENT_CONFIG),
            HI_WORD(GATT_UUID_CHAR_CLIENT_CONFIG),
            /* NOTE: this value has an instantiation for each client, a write to */
            /* this attribute does not modify this default value:                */
            LO_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT), /* client char. config. bit field */
            HI_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT)
        },
        2,                                          /* bValueLen */
        NULL,
        (GATT_PERM_READ | GATT_PERM_WRITE)          /* wPermissions */
    }
};

const TAttribAppl GattGpioProfileTable[] =
{
    /*0000----------------- gattdGPIO Service -------------------*/
    {
        (ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_LE | ATTRIB_FLAG_BR_EDR), /* wFlags     */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_PRIMARY_SERVICE),
            HI_WORD(GATT_UUID_PRIMARY_SERVICE),
            LO_WORD(GATT_UUID_GPIO),    /* service UUID */
            HI_WORD(GATT_UUID_GPIO)
        },
        UUID_16BIT_SIZE,                            /* bValueLen     */
        NULL,                                       /* pValueContext */
        GATT_PERM_READ                              /* wPermissions  */
    },
    /*1111----------------------------------------------------------------------------------------*/
    /* GATT_UUID_GPIO_CFG */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE,              /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*2222GATT_UUID_GPIO_CFG value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_GPIO_CFG),
            HI_WORD(GATT_UUID_GPIO_CFG)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_READ | GATT_PERM_WRITE                             /* wPermissions */
    },
    /*----------------------------------------------------------------------------------------*/
    /*3333GATT_UUID_GPIO_OUT */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_WRITE_NO_RSP,              /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*4444GATT_UUID_GPIO_CFG value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_GPIO_OUT),
            HI_WORD(GATT_UUID_GPIO_OUT)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_WRITE                             /* wPermissions */
    },

    /*----------------------------------------------------------------------------------------*/
    /*55555GATT_UUID_GPIO_IN */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_NOTIFY | GATT_CHAR_PROP_READ,              /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*6666GATT_UUID_GPIO_IN  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_GPIO_IN),
            HI_WORD(GATT_UUID_GPIO_IN)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_READ                             /* wPermissions */
    },
    /* 77777  client characteristic configuration */
    {
        ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_CCCD_APPL,                   /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHAR_CLIENT_CONFIG),
            HI_WORD(GATT_UUID_CHAR_CLIENT_CONFIG),
            /* NOTE: this value has an instantiation for each client, a write to */
            /* this attribute does not modify this default value:                */
            LO_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT), /* client char. config. bit field */
            HI_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT)
        },
        2,                                          /* bValueLen */
        NULL,
        (GATT_PERM_READ | GATT_PERM_WRITE)          /* wPermissions */
    },
#if 0
    /*8888----------------------------------------------------------------------------------------*/
    /* GATT_UUID_GPIO6_TOG1 */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE,              /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*9999GATT_UUID_GPIO6_TOG1 value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_GPIO6_TOG1),
            HI_WORD(GATT_UUID_GPIO6_TOG1)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_READ | GATT_PERM_WRITE                             /* wPermissions */
    },
    /*AAAA----------------------------------------------------------------------------------------*/
    /* GATT_UUID_GPIO6_TOG2 */
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE,              /* characteristic properties */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*BBBB GATT_UUID_GPIO6_TOG2 value  */
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_GPIO6_TOG2),
            HI_WORD(GATT_UUID_GPIO6_TOG2)
        },
        0,                                          /* variable size */
        NULL,
        GATT_PERM_READ | GATT_PERM_WRITE                             /* wPermissions */
    },
#endif
};


//PwmParaStruct gPwmPara;
uint16_t Profile_PwmSetValue(int32_t iAttribIndex, uint16_t wLength, uint8_t *pValue)
{
    uint16_t wCause = GATT_SUCCESS;;

    switch (iAttribIndex)
    {
        case PWM_ALL_CHANNEL_CFG_INDEX:
            if (wLength != 0x1)
            {
                wCause = ATT_ERR | ATT_ERR_INVALID_VALUE_SIZE;
            }
            else
            {
                gPwmPara.PwmAllChCfg = *pValue;
                modulePwmInit();
                //moduleParam_SetModuleName((char*)pValue,wLength);
            }
            break;

        case PWM_SINGLE_CHANNEL_SET_INDEX:
            if (wLength != 0x4)
            {
                wCause = ATT_ERR | ATT_ERR_INVALID_VALUE_SIZE;
            }
            else
            {
                //gPwmPara.PwmSigChCfg = *((uint32_t *)pValue);
                gPwmPara.PwmSigChCfg = *(pValue + 3);
                gPwmPara.PwmSigChCfg <<= 8;
                gPwmPara.PwmSigChCfg |= *(pValue + 2);
                gPwmPara.PwmSigChCfg <<= 8;
                gPwmPara.PwmSigChCfg |= *(pValue + 1);
                gPwmPara.PwmSigChCfg <<= 8;
                gPwmPara.PwmSigChCfg |= *pValue;
                //modulePwmSigCfg();
                if (gPwmPara.PwmDelay == 0)
                {
                    modulePwmSignalChange();
                }
                else
                {
                    uint32_t nDelay = gPwmPara.PwmDelay;
                    nDelay = (nDelay * 100) / portTICK_RATE_MS;
                    xTimerChangePeriod(PWM_Timer, nDelay , 0);
                }

            }
            break;
        case PWM_FREQUENCY_INDEX:
            if (wLength != 2)
            {
                wCause = ATT_ERR | ATT_ERR_INVALID_VALUE_SIZE;
            }
            else
            {
                //gPwmPara.PwmFrequency = *pValue;
                gPwmPara.PwmFrequency  = *(pValue + 1);
                gPwmPara.PwmFrequency <<= 8;
                gPwmPara.PwmFrequency |= *pValue;
                if (gPwmPara.PwmDelay == 0)
                {
                    modulePwmSignalChange();
                }
                else
                {
                    uint32_t nDelay = gPwmPara.PwmDelay;
                    nDelay = (nDelay * 100) / portTICK_RATE_MS;
                    xTimerChangePeriod(PWM_Timer, nDelay , 0);
                }
                //  modulePwmSignalChange();
                //modulePwmFrequency();
            }

            break;
        case PWM_DELAY_TIME:
            if (wLength != 2 )
            {
                wCause = ATT_ERR | ATT_ERR_INVALID_VALUE_SIZE;
            }
            else
            {
                gPwmPara.PwmDelay = *(pValue + 1);
                gPwmPara.PwmDelay <<= 8;
                gPwmPara.PwmDelay |= *pValue;
                //moduleParam_RemoteControl(*pValue);
                DBG_BUFFER(MODULE_OS, LEVEL_ERROR, "PwmDelay is 2 0x%x\n", 1, gPwmPara.PwmFrequency);
            }
            break;

        default:
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Profile_PwmSetValue not handle iAttribIndex 0x%x\n", 1, iAttribIndex);
            break;
    }

    return wCause;
}
uint16_t Profile_IRSetValue(int32_t iAttribIndex, uint16_t wLength, uint8_t *pValue)
{
    uint16_t wCause = GATT_SUCCESS;;

    switch (iAttribIndex)
    {
        case PWM_ALL_CHANNEL_CFG_INDEX:
            if (wLength != 0x2)
            {
                wCause = ATT_ERR | ATT_ERR_INVALID_VALUE_SIZE;
            }
            else
            {
                gIrPara.IrAdd = *pValue;
                gIrPara.IrCmd = *(pValue + 1);
                //  gPwmPara.PwmAllChCfg = *pValue;
                //  modulePwmInit();
                Init_IR_TX_With_Callback();
            }
            break;
        default:
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Profile_PwmSetValue not handle iAttribIndex 0x%x\n", 1, iAttribIndex);
            break;
    }
    return wCause;
}

uint16_t Profile_GPIOSetValue(int32_t iAttribIndex, uint16_t wLength, uint8_t *pValue)
{
    uint16_t wCause = GATT_SUCCESS;;

    switch (iAttribIndex)
    {
        case GPIO_CFG_INDEX:
            if (wLength != 0x1)
            {
                wCause = ATT_ERR | ATT_ERR_INVALID_VALUE_SIZE;
            }
            else
            {
                gGpioPara.GpioCfg = *pValue;
                moduleGpioCfg();
                //  modulePwmInit();
                //Init_IR_TX_With_Callback();
            }
            break;
        case GPIO_OUT_INDEX:
            if (wLength != 0x1)
            {
                wCause = ATT_ERR | ATT_ERR_INVALID_VALUE_SIZE;
            }
            else
            {
                gGpioPara.GpioOut = *pValue;
                //  modulePwmInit();
                //Init_IR_TX_With_Callback();
                moduleGpioOut();
                DBG_BUFFER(MODULE_OS, LEVEL_ERROR, "GpioOut is  0x%x\n", 1, gGpioPara.GpioOut);
            }
            break;
        default:
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Profile_PwmSetValue not handle iAttribIndex 0x%x\n", 1, iAttribIndex);
            break;
    }
    return wCause;
}
uint8_t   *Profile_PwmGetValue( INT32 iAttribIndex, INT32 iOffset, INT32 *piLength)
{
    uint8_t *pValue = NULL;
    *piLength = 0;

    switch (iAttribIndex)
    {
        case PWM_ALL_CHANNEL_CFG_INDEX:
            pValue = (uint8_t *) & (gPwmPara.PwmAllChCfg);
            *piLength = 1;
            break;
        case PWM_SINGLE_CHANNEL_SET_INDEX:
            pValue = (uint8_t *)&gPwmPara.PwmSigChCfg;
            *piLength = 4;
            break;
        case PWM_FREQUENCY_INDEX:
            pValue = (uint8_t *)&gPwmPara.PwmFrequency;
            *piLength = 2;
            break;
        case PWM_DELAY_TIME:
            pValue = (uint8_t *)&gPwmPara.PwmDelay;
            *piLength = 2;
            break;


        default:
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Profile_PwmGetValue not handle iAttribIndex 0x%x\n", 1, iAttribIndex);
            break;
    }

    return pValue;

}

uint8_t   *Profile_GpioGetValue( INT32 iAttribIndex, INT32 iOffset, INT32 *piLength)
{
    uint8_t *pValue = NULL;
    *piLength = 0;
    uint32_t value32;

    switch (iAttribIndex)
    {
        case GPIO_CFG_INDEX:
            pValue = (uint8_t *) & (gGpioPara.GpioCfg);
            *piLength = 1;
            break;

        case GPIO_IN_INDEX:
            value32 = GPIO_ReadInputData();
            value32 >>= 16;
            gGpioPara.GpioIn = value32;
            pValue = (uint8_t *) & (gGpioPara.GpioIn);
            *piLength = 1;
            break;


        default:
            DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "Profile_GpioGetValue not handle iAttribIndex 0x%x\n", 1, iAttribIndex);
            break;
    }

    return pValue;

}

TProfileResult  DirectIOAttrRead(uint8_t ServiceID, uint16_t iAttribIndex,
                        uint16_t iOffset, uint16_t * piLength,uint8_t **ppValue)
{
    TProfileResult  wCause  = ProfileResult_Success;
    uint8_t *pValue = NULL;
    DBG_BUFFER(MODULE_PROFILE, LEVEL_INFO, "<-- DirectIOAttrRead index=%d", 1, iAttribIndex);
    if ( ServiceID == gPWMServiceId)
    {
        pValue = Profile_PwmGetValue(iAttribIndex, iOffset, piLength);
    }
    else if (ServiceID == gGPIOServiceId)
    {
        pValue = Profile_GpioGetValue(iAttribIndex, iOffset, piLength);
    }
    *ppValue = pValue;
    return wCause;
}

TProfileResult DirectIOAttrWrite(uint8_t ServiceID, uint16_t iAttribIndex,
                       uint16_t wLength, uint8_t * pValue,TGATTDWriteIndPostProc * pWriteIndPostProc)
{
    TProfileResult  wCause  = ProfileResult_Success;

    if (!pValue)
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "--> DirectIOAttrWrite   pValue %p wLength= 0x%x",
                   2,
                   pValue,
                   wLength);
		wCause = ProfileResult_InvalidParameter;
        return wCause;
    }

    if ( ServiceID == gPWMServiceId) //iAttribIndex == XXXX_INDEX
    {
        wCause = Profile_PwmSetValue(iAttribIndex, wLength, pValue);
    }
    else if (ServiceID == gIRServiceId)
    {
        wCause = Profile_IRSetValue(iAttribIndex, wLength, pValue);
    }
    else if (ServiceID == gGPIOServiceId)
    {
        wCause = Profile_GPIOSetValue(iAttribIndex, wLength, pValue);
    }
    return wCause;
}

void DirectIOCccdUpdate(uint8_t ServiceId, uint16_t Index, uint16_t wCCCBits)
{
    DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, " DirectIOCccdUpdate ServiceId = %d ,wAttribIndex is %d", 2, ServiceId, Index);
    if ( ServiceId == gIRServiceId &&  Index == (IR_RX_INDEX + 1)) //+1 = config
    {
        if (wCCCBits & GATT_CCCD_NOTIFICATION_BIT)
        {   // enable notification
            //KEY_SEND_FLAG = 1;
            //uint8_t value_to_send = 2;
            Init_IR_RX_With_Callback();
            //ProfileAPI_SendData(blueAPI_ServiceIR,IR_RX_INDEX,&value_to_send,sizeof(uint8_t));
        }
        else
        {   // disable notification.
            //KEY_SEND_FLAG = 0;
        }
        return;
    }
    else if ( ServiceId == gGPIOServiceId &&  Index == (GPIO_IN_INDEX + 1)) //+1 = config
    {
        if (wCCCBits & GATT_CCCD_NOTIFICATION_BIT)
        {   // enable notification
            //KEY_SEND_FLAG = 1;
            //uint8_t value_to_send = 2;
            //Init_IR_RX_With_Callback();
            //ProfileAPI_SendData(blueAPI_ServiceGPIO,GPIO_IN_INDEX,&value_to_send,sizeof(uint8_t));
            IS_GPIO_SEND = 1;
        }
        else
        {   // disable notification.
            IS_GPIO_SEND    = 0;
        }
        return;
    }
    return;
}
/*********************************************************************
 * PROFILE CALLBACKS
 */
CONST gattServiceCBs_t 
directIOCBs =
{
    DirectIOAttrRead,  // Read callback function pointer
    DirectIOAttrWrite, // Write callback function pointer
    DirectIOCccdUpdate  // Authorization callback function pointer
};
void Direct_io_AddService(void* pFunc)
{
    if(FALSE == ProfileAPI_AddService(&gPWMServiceId,
                                 (uint8_t*)GattPwmProfileTable,
                                 sizeof(GattPwmProfileTable),
                                 directIOCBs))
		{
			DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "PWM Service: ServiceId %d",1,gPWMServiceId);
			gPWMServiceId = 0xff;
		}
	if(FALSE == ProfileAPI_AddService(&gIRServiceId,
                                 (uint8_t*)GattIrProfileTable,
                                 sizeof(GattIrProfileTable),
                                 directIOCBs))
		{
			DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "IR Service: ServiceId %d",1,gIRServiceId);
			gIRServiceId = 0xff;
		}
	if(FALSE == ProfileAPI_AddService(&gGPIOServiceId,
                                 (uint8_t*)GattGpioProfileTable,
                                 sizeof(GattGpioProfileTable),
                                 directIOCBs))
		{
			DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "GPIO Service: ServiceId %d",1,gGPIOServiceId);
			gGPIOServiceId = 0xff;
		}
}

