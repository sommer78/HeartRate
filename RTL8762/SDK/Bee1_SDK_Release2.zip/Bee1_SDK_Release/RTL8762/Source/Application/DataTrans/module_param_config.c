enum { __FILE_NUM__ = 0 };
#include "module_param_config.h"
#include "flash_translation_layer.h"
#include <string.h>
#include "trace.h"
#include "rtl876x.h"

#include "core_cm0.h"
#include "dataTrans_application.h"

#define IMPLEMENT_SAVE_LOAD_TYPE_OFFSET(type,offset_value)\
    enum { type##_OFFSET = offset_value};\
    enum { type##_SIZE   = sizeof(type)};\
    uint32_t imp_fs_save_##type(type* pdata)\
    {\
        return Save_To_Storage(pdata, type##_OFFSET, type##_SIZE);\
    }\
    uint32_t imp_fs_load_##type(type* pdata)\
    {\
        uint32_t has_error =  Load_From_Storage(pdata, type##_OFFSET, type##_SIZE);\
        if(has_error) memset(pdata, 0, sizeof(type));\
        return has_error; \
    }

IMPLEMENT_SAVE_LOAD_TYPE_OFFSET(baudrate_struct, 204);
IMPLEMENT_SAVE_LOAD_TYPE_OFFSET(adv_interval_struct, 208);
IMPLEMENT_SAVE_LOAD_TYPE_OFFSET(adv_data_struct, 212);
IMPLEMENT_SAVE_LOAD_TYPE_OFFSET(pid_struct, 232);
IMPLEMENT_SAVE_LOAD_TYPE_OFFSET(tx_delay_struct, 236);
IMPLEMENT_SAVE_LOAD_TYPE_OFFSET(system_mode_struct, 240);

ConfigParamStruct ConfigParam;
ConfigParamStruct *gConfigParam = &ConfigParam;

const char defaultDeviceName[] = "Reltek";

extern void delayMS(uint32_t t);

uint32_t fs_save_baudrate_struct(baudrate_struct *pdata)
{


    return imp_fs_save_baudrate_struct(pdata);
}

uint32_t fs_load_baudrate_struct(baudrate_struct *pdata)
{


    return imp_fs_load_baudrate_struct(pdata);
}

uint32_t fs_save_adv_interval_struct(adv_interval_struct *pdata)
{


    return imp_fs_save_adv_interval_struct(pdata);
}

uint32_t fs_load_adv_interval_struct(adv_interval_struct *pdata)
{


    return imp_fs_load_adv_interval_struct(pdata);
}

uint32_t fs_save_adv_data_struct(adv_data_struct *pdata)
{


    return imp_fs_save_adv_data_struct(pdata);
}

uint32_t fs_load_adv_data_struct(adv_data_struct *pdata)
{


    return imp_fs_load_adv_data_struct(pdata);
}

uint32_t fs_save_pid_struct(pid_struct *pdata)
{


    return imp_fs_save_pid_struct(pdata);
}

uint32_t fs_load_pid_struct(pid_struct *pdata)
{


    return imp_fs_load_pid_struct(pdata);
}

uint32_t fs_save_tx_delay_struct(tx_delay_struct *pdata)
{


    return imp_fs_save_tx_delay_struct(pdata);
}

uint32_t fs_load_tx_delay_struct(tx_delay_struct *pdata)
{


    return imp_fs_load_tx_delay_struct(pdata);
}

uint32_t fs_save_system_mode_struct(system_mode_struct *pdata)
{


    return imp_fs_save_system_mode_struct(pdata);
}

uint32_t fs_load_system_mode_struct(system_mode_struct *pdata)
{


    return imp_fs_load_system_mode_struct(pdata);
}

#if 0
void vTimerResetCallback(TimerHandle_t pxTimer )
{

    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "vTimerResetCallback", 0);
    module_param_set_system_reset();
}
#endif

#define ADV_DATA_MANUFACTURER_DATA_LENGTH_INDEX 11
#define ADV_DATA_MANUFACTURER_DATA_PID_INDEX 13
#define ADV_DATA_MANUFACTURER_DATA_INDEX 15
#define ADV_DATA_DEFAULT_LENGTH 22
#define ADV_DATA_FIX_DATA_LENGTH 15   //"flags" "short local name"


// GAP - Advertisement data (max size = 31 bytes, though this is
// best kept short to conserve power while advertisting)
static uint8_t AdvData[31] =//31
{
    /* Core spec. Vol. 3, Part C, Chapter 18 */
    /* Flags */
    0x02,            /* length     */
    //XXXXMJMJ 0x01, 0x06,      /* type="flags", data="bit 1: LE General Discoverable Mode", BR/EDR not supp. */
    0x01, 0x05,      /* type="flags", data="bit 1: LE General Discoverable Mode" */
    /* place holder for Local Name, filled by BT stack. if not present */
    /* BT stack appends Local Name.                                    */
    0x07,           /* length     */
    0x08,           /* type="short local name" */
    'R', 'e', 'l', 't', 'e', 'k', /* ProfileTester */
    /*0x0A,
    0xFF,
    0x00,0x00,
    0x00,0x00,0x00,0x00,
    0x00,
    0x00,0x00*/
};

static uint16_t AdvDataLength;
// GAP - SCAN RSP data (max size = 31 bytes)
static uint8_t scanRspData[4] =
{
    0x03,           /* length     */
    0x03,           /* type="More 16-bit UUIDs available" */
    0xE1,
    0xFF,
};

void moduleParam_LoadFromFlash()
{
    fs_load_Local_name_struct(&gConfigParam->localName);
    if (strlen((char *)gConfigParam->localName.Local_name) == 0)
    {
        memcpy(gConfigParam->localName.Local_name, defaultDeviceName , strlen(defaultDeviceName) + 1);
        fs_save_Local_name_struct(&gConfigParam->localName);
    }
    fs_load_baudrate_struct(&gConfigParam->baudrate);
    if (gConfigParam->baudrate.baudrate == 0)
    {
        gConfigParam->baudrate.baudrate = 9600;
        fs_save_baudrate_struct(&gConfigParam->baudrate);
    }
    fs_load_adv_interval_struct(&gConfigParam->advInterval);
    if (gConfigParam->advInterval.adv_interval == 0)
    {
        gConfigParam->advInterval.adv_interval = 2;
        fs_save_adv_interval_struct(&gConfigParam->advInterval);
    }
    fs_load_adv_data_struct(&gConfigParam->advData);
    fs_load_pid_struct(&gConfigParam->pid);
    fs_load_tx_delay_struct(&gConfigParam->txDelay);
    fs_load_system_mode_struct(&gConfigParam->systemMode);
    gConfigParam->conn_interval = 0;
    gConfigParam->conn_interval_update = 20;
}

void moduleParam_InitAdvData(void)
{
    AdvData[ADV_DATA_MANUFACTURER_DATA_PID_INDEX] = gConfigParam->pid.pid[0];
    AdvData[ADV_DATA_MANUFACTURER_DATA_PID_INDEX + 1] = gConfigParam->pid.pid[1];
    if (gConfigParam->advData.data_length == 0)
    {
        //use default adv
        AdvData[ADV_DATA_MANUFACTURER_DATA_LENGTH_INDEX] = 0x0A;
        AdvDataLength = ADV_DATA_DEFAULT_LENGTH;
    }
    else
    {
        memcpy(AdvData + ADV_DATA_MANUFACTURER_DATA_INDEX, gConfigParam->advData.adv_data, gConfigParam->advData.data_length);
        AdvData[ADV_DATA_MANUFACTURER_DATA_LENGTH_INDEX] = 3 + gConfigParam->advData.data_length;
        AdvDataLength = ADV_DATA_FIX_DATA_LENGTH + gConfigParam->advData.data_length;
        //use setting adv
    }

    peripheralSetGapParameter( GAPPRRA_SCAN_RSP_DATA, sizeof ( scanRspData ), scanRspData );
    peripheralSetGapParameter( GAPPRRA_ADVERT_DATA, AdvDataLength, AdvData);
}

void moduleParam_ShallowRestore()
{
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "moduleParam_ShallowRestore", 0);
    //key restore
    //PWM restore
    //IO restore
    moduleParam_SetSystemReset();
}
void moduleParam_DeepRestore()
{
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "moduleParam_DeepRestore", 0);
    //key restore
    //PWM restore
    //IO restore
    gConfigParam->baudrate.baudrate = 9600;
    memcpy(gConfigParam->localName.Local_name, defaultDeviceName , strlen(defaultDeviceName) + 1); //fixme
    gConfigParam->advInterval.adv_interval = 2;
    gConfigParam->advData.data_length = 0;
    memset(gConfigParam->advData.adv_data, 0 , ADV_DATA_MAX_LENGTH);
    gConfigParam->pid.pid[0] = 0;
    gConfigParam->pid.pid[1] = 0;
    gConfigParam->txDelay.delay = 0;
    gConfigParam->systemMode.system_mode = 0;
    fs_save_Local_name_struct(&gConfigParam->localName);
    fs_save_baudrate_struct(&gConfigParam->baudrate);
    fs_save_adv_interval_struct(&gConfigParam->advInterval);
    fs_save_adv_data_struct(&gConfigParam->advData);
    fs_save_pid_struct(&gConfigParam->pid);
    fs_save_tx_delay_struct(&gConfigParam->txDelay);
    fs_save_system_mode_struct(&gConfigParam->systemMode);
    //xTimerStart(xTimersReset,0);
    moduleParam_SetSystemReset();
}

void moduleParam_RemoteControl(uint8_t param)
{
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "moduleParam_RemoteControl: %d", 1, param);
    switch (param)
    {
        case 0x55:
            moduleParam_SetSystemReset();
            break;
        case 0x35:
            moduleParam_ShallowRestore();
            break;
        case 0x36:
            moduleParam_DeepRestore();
            break;
        default:
            break;
    }

}

void moduleParam_RemoteControlExtend(uint8_t param)
{
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "moduleParam_RemoteControlExtend: %d", 1, param);
    switch (param)
    {
        case 0x01://fixme:io config save control
            break;
        case 0x02://fixme:remot close device control
            break;
        case 0x04://fixme
            peripheral_Disconnect();
            break;
        default:
            break;
    }

}

void moduleParam_SetSystemMode(uint8_t param)
{
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "module_param_remote_control_extend: %d", 1, param);
    uint8_t mode = param & MODULE_PARAM_SYSTEM_MODE_MASK;
    if (gConfigParam->systemMode.system_mode != mode)
    {
        gConfigParam->systemMode.system_mode = mode;
        fs_load_system_mode_struct(&gConfigParam->systemMode);
    }
    switch (mode)
    {
        case MODULE_PARAM_SYSTEM_MODE_LEVEL://fixme
            break;
        case MODULE_PARAM_SYSTEM_MODE_PULSE://fixme
            break;
        default:
            break;
    }

}

bool moduleParam_SetConnInterval(uint16_t param)
{
    uint16_t desired_min_interval;
    uint16_t desired_max_interval;
    uint16_t desired_slave_latency;
    uint16_t desired_conn_timeout;

    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "moduleParam_SetConnInterval: %d", 1, param);
    if ((g_AppCB->gapProfileState != GAPSTATE_CONNECTED) && (g_AppCB->gapProfileState != GAPSTATE_CONNECTED_ADV))
    {
        return FALSE;
    }

    if ((param == 20) || (param == 50) || (param == 100) || (param == 200) || (param == 300) || (param == 400) || (param == 500) || (param == 1000) || (param == 1500) || (param == 2000))
    {
        gConfigParam->conn_interval_update = param;
        if (param == 20)
        {
            desired_max_interval = 0x10;
            desired_min_interval = 0x08;
        }
        else
        {
            desired_max_interval = gConfigParam->conn_interval_update * 4 / 5;
            desired_min_interval = desired_max_interval - 10;
        }
        desired_slave_latency = 0;
        desired_conn_timeout = 500;

        peripheralSetGapParameter( GAPPRRA_MIN_CONN_INTERVAL, sizeof( uint16_t ), &desired_min_interval );
        peripheralSetGapParameter( GAPPRRA_MAX_CONN_INTERVAL, sizeof( uint16_t ), &desired_max_interval );
        peripheralSetGapParameter( GAPPRRA_SLAVE_LATENCY, sizeof( uint16_t ), &desired_slave_latency );
        peripheralSetGapParameter( GAPPRRA_TIMEOUT_MULTIPLIER, sizeof( uint16_t ), &desired_conn_timeout );
        peripheral_SendUpdateParam();

    }
    else
    {
        return FALSE;
    }

    return TRUE;

}

uint8_t moduleParam_GetConnIntervalIndex(void)
{
    uint8_t param = 0;

    switch (gConfigParam->conn_interval)
    {
        case 20:
            param = 0;
            break;
        case 50:
            param = 1;
            break;
        case 100:
            param = 2;
            break;
        case 200:
            param = 3;
            break;
        case 300:
            param = 4;
            break;
        case 400:
            param = 5;
            break;
        case 500:
            param = 6;
            break;
        case 1000:
            param = 7;
            break;
        case 2000:
            param = 8;
            break;
        default:
            param = 9;//fixme
            break;

    }
    return param;
}


bool moduleParam_SetModuleName(char *p_adv, uint16_t len)
{
    Local_name_struct local_name;
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "moduleParam_SetModuleName: len=%d", 1, len);
    if (len > DEVICE_NAME_MAX_LENGTH)
    {
        return FALSE;
    }
    if (p_adv[len] != '\0')
    {
        p_adv[len] = '\0';
        len++;
    }
    if (memcmp(gConfigParam->localName.Local_name, p_adv, len) != 0)
    {
        memcpy(local_name.Local_name, p_adv, len + 1);
        fs_save_Local_name_struct(&local_name);
    }
    return TRUE;
}

bool moduleParam_SetBaudrate(int param)
{
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "moduleParam_SetBaudrate: %d", 1, param);
    if ( (param == 4800) || (param == 9600) || (param == 19200) || (param == 38400) || (param == 57600) || (param == 115200))
    {
        if (gConfigParam->baudrate.baudrate != param)
        {
            gConfigParam->baudrate.baudrate = param;
            fs_save_baudrate_struct(&gConfigParam->baudrate);
            xTimerStart(TimersUartBaudrateChange, 0);
        }

    }
    else
    {
        return FALSE;
    }
    return TRUE;

}

uint8_t moduleParam_GetBaudrateIndex(void)
{
    uint8_t param = 0;

    switch (gConfigParam->baudrate.baudrate)
    {
        case 4800:
            param = 0;
            break;
        case 9600:
            param = 1;
            break;
        case 19200:
            param = 2;
            break;
        case 38400:
            param = 3;
            break;
        case 57600:
            param = 4;
            break;
        case 115200:
            param = 5;
            break;
        default:
            param = 6;//fixme
            break;

    }
    return param;
}

void moduleParam_SetSystemReset(void)
{
    NVIC_SystemReset();
}

bool moduleParam_SetAdvInterval(uint16_t param)
{
    adv_interval_struct adv_inter;
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "moduleParam_SetAdvInterval: %d", 1, param);
    if ( (param == 2) || (param == 5) || (param == 10) || (param == 15) || (param == 20) || (param == 25)
            || (param == 30) || (param == 40) || (param == 50))
    {
        if (gConfigParam->advInterval.adv_interval != param)
        {
            adv_inter.adv_interval = param;
            fs_save_adv_interval_struct(&adv_inter);
        }
    }
    else
    {
        return FALSE;
    }
    return TRUE;

}

uint8_t moduleParam_GetAdvIntervalIndex(void)
{
    uint8_t param = 0;

    switch (gConfigParam->advInterval.adv_interval)
    {
        case 2:
            param = 0;
            break;
        case 5:
            param = 1;
            break;
        case 10:
            param = 2;
            break;
        case 15:
            param = 3;
            break;
        case 20:
            param = 4;
            break;
        case 25:
            param = 5;
            break;
        case 30:
            param = 6;
            break;
        case 40:
            param = 7;
            break;
        case 50:
            param = 8;
            break;
        default:
            param = 9;//fixme
            break;

    }
    return param;
}

bool moduleParam_SetAdvData(uint8_t *p_adv, uint16_t len)
{
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "moduleParam_SetAdvData: len=%d", 1, len);
    if (len > ADV_DATA_MAX_LENGTH)
    {
        return FALSE;
    }
    if (gConfigParam->advData.data_length != len)
    {
        gConfigParam->advData.data_length = len;
        memcpy(gConfigParam->advData.adv_data, p_adv, len);
        fs_save_adv_data_struct(&gConfigParam->advData);
        gConfigParam->is_update_adv = TRUE;
    }
    else
    {
        if (memcmp(gConfigParam->advData.adv_data, p_adv, len) != 0)
        {
            gConfigParam->advData.data_length = len;
            memcpy(gConfigParam->advData.adv_data, p_adv, len);
            fs_save_adv_data_struct(&gConfigParam->advData);
            gConfigParam->is_update_adv = TRUE;
        }
    }
    if (gConfigParam->is_update_adv)
    {
        moduleParam_InitAdvData();

        if (g_AppCB->gapProfileState == GAPSTATE_ADVERTISING)
        {
            peripheral_StopAdvertising();
        }
        else
        {
            gConfigParam->is_update_adv = FALSE;

        }

    }
    return TRUE;
}

void moduleParam_SetPID(char byte1, char byte2)
{
    pid_struct pid;
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "moduleParam_SetPID: %02x %02x ", 2, byte1, byte2);
    if ((gConfigParam->pid.pid[0] != byte1) || (gConfigParam->pid.pid[1] != byte2))
    {
        pid.pid[0] = byte1;
        pid.pid[1] = byte2;
        fs_save_pid_struct(&pid);
    }
}

bool moduleParam_SetTxPower(int16_t param)
{
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "moduleParam_SetTxPower: %d", 1, param);
    if ( (param == 0) || (param == 4) || (param == -6) || (param == -23))
    {
        gConfigParam->tx_power = param;

    }
    else
    {
        return FALSE;
    }
    return TRUE;

}

uint8_t moduleParam_GetTxPowerIndex(void)
{
    uint8_t param = 0;

    switch (gConfigParam->tx_power)
    {
        case 4:
            param = 0;
            break;
        case 0:
            param = 1;
            break;
        case -6:
            param = 2;
            break;
        case -23:
            param = 3;
            break;
        default:
            param = 4;//fixme
            break;
    }
    return param;
}


bool moduleParam_SetTxDelay(uint16_t param)
{
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "at_cmd_handle_CDL: %d", 1, param);
    if ( (param == 0) || (param == 2) || (param == 5) || (param == 10) || (param == 15) || (param == 20) || (param == 25))
    {
        if (gConfigParam->txDelay.delay != param)
        {
            gConfigParam->txDelay.delay = param;
            fs_save_tx_delay_struct(&gConfigParam->txDelay);
        }
    }
    else
    {
        return FALSE;
    }
    return TRUE;
}


