#define VERSION_MAJOR           1   
#define VERSION_MINOR           0   
#define VERSION_REVISION        7291
#define NUM3STR(a,b,c)        #a "." #b "." #c
#define VERSIONBUILDSTR(a,b,c)    NUM3STR(a,b,c)   
#define FILE_VERSION_STR        VERSIONBUILDSTR(VERSION_MAJOR,VERSION_MINOR,VERSION_REVISION)     
#define SRC_TIME "2015/09/15 09:35:22"      
#define BUILDING_TIME "2015/09/15 11:07:02"   
