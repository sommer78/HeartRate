#ifndef __DEVICE_NAME_H_
#define __DEVICE_NAME_H_
#define RTL8762AX_VB
#endif 
