/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      SimpleBLEPeripheral_application.c
* @brief     Simple BLE Peripheral demo application implementation
* @details   Simple BLE Peripheral demo application implementation
* @author    ranhui
* @date      2015-03-27
* @version   v0.2
* *********************************************************************************************************
*/
#include "rtl876x.h"
#include "application.h"
#include "SimpleBLEPeripheral_application.h"
#include "bee_message.h"
#include "trace.h"
#include "peripheral.h"
#include "gap.h"
#include "gapbondmgr.h"
#include <string.h>
#include "profileApi.h"
#include "simple_ble_service.h"

// gap state
gaprole_States_t gapProfileState = GAPSTATE_INIT;

extern uint8_t gSimpleProfileServiceId;

void peripheral_HandleBtGapMessage(BEE_IO_MSG  *pBeeIoMsg);


/******************************************************************
 * @fn          AppHandleIODriverMessage
 * @brief      All the application events are pre-handled in this function.
 *                All the IO MSGs are sent to this function, Then the event handling function
 *                shall be called according to the MSG type.
 *
 * @param    io_driver_msg_recv  - bee io msg data
 * @return     void
 */
void AppHandleIODriverMessage(BEE_IO_MSG io_driver_msg_recv)
{
    UINT16 msgtype = io_driver_msg_recv.IoType;

    switch (msgtype)
    {

        case BT_STATUS_UPDATE:
            {
                peripheral_HandleBtGapMessage(&io_driver_msg_recv);
            }
            break;
        default:
            break;
    }
}

/******************************************************************
 * @fn          peripheral_HandleBtGapStateChangeEvt
 * @brief      All the gaprole_States_t events are pre-handled in this function.
 *                Then the event handling function shall be called according to the newState.
 *
 * @param    newState  - new gap state
 * @return     void
 */
void peripheral_HandleBtGapStateChangeEvt(uint8_t newState)
{

    switch ( newState )
    {
        //connection is disconnected or idle with no advertising
        case GAPSTATE_IDLE_NO_ADV_NO_CONN:
            {
                if (gapProfileState == GAPSTATE_CONNECTED)
                {
                    uint8_t disc_reason;
                    peripheralGetGapParameter(GAPPRRA_DISCONNECTED_REASON, &disc_reason);
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "peripheral_HandleBtGapStateChangeEvt: disc_reason = %d", 1, disc_reason);
                    peripheral_StartAdvertising();
                }
            }
            break;
        //device is advertising
        case GAPSTATE_ADVERTISING:
            {

            }
            break;

        //device is connected
        case GAPSTATE_CONNECTED:
            {

            }
            break;

        //device is connected and advertising
        case GAPSTATE_CONNECTED_ADV:
            {

            }
            break;

        //error comes here
        default:
            {

            }
            break;

    }

    gapProfileState = (gaprole_States_t)newState;
}

/******************************************************************
 * @fn          peripheral_HandleBtGapBondStateChangeEvt
 * @brief      All the bonding state change  events are pre-handled in this function.
 *                Then the event handling function shall be called according to the newState.
 *
 * @param    newState  - new bonding state
 * @return     void
 */
void peripheral_HandleBtGapBondStateChangeEvt(uint8_t newState, uint8_t status)
{

    switch (newState)
    {
        case GAPBOND_PAIRING_STATE_STARTED:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(GAPBOND_PAIRING_STATE_STARTED)", 0);
            }
            break;

        case GAPBOND_PAIRING_STATE_COMPLETE:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(GAPBOND_PAIRING_STATE_COMPLETE)", 0);
                if (status == 0)
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE pair success", 0);
                }
                else
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "BT_MSG_TYPE_BOND_STATE_CHANGE pair failed", 0);
                }
            }
            break;

        case GAPBOND_PAIRING_STATE_BONDED:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(GAPBOND_PAIRING_STATE_BONDED)", 0);
            }
            break;

        default:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(unknown newstate: %d)", 1, newState);
            }
            break;
    }

}

/******************************************************************
 * @fn          peripheral_HandleBtGapEncryptStateChangeEvt
 * @brief      All the encrypt state change  events are handled in this function.
 *                Then the event handling function shall be called according to the status.
 *
 * @param    newState  - new encryption state
 * @return     void
 */
void peripheral_HandleBtGapEncryptStateChangeEvt(uint8_t newState)
{
    switch (newState)
    {
        case GAPBOND_ENCRYPT_STATE_ENABLED:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "GAPBOND_ENCRYPT_STATE_ENABLED", 0);
            }
            break;

        case GAPBOND_ENCRYPT_STATE_DISABLED:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "GAPBOND_ENCRYPT_STATE_DISABLED", 0);
            }
            break;

        default:
            break;
    }
}

/******************************************************************
 * @fn          peripheral_HandleBtGapConnParaChangeEvt
 * @brief      All the connection parameter update change  events are pre-handled in this function.
 *                Then the event handling function shall be called according to the status.
 *
 * @param    status  - connection parameter result, 0 - success, otherwise fail.
 * @return     void
 */
void peripheral_HandleBtGapConnParaChangeEvt(uint8_t status)
{
    if (status == 0)
    {
        uint16_t con_interval;
        uint16_t conn_slave_latency;
        uint16_t conn_supervision_timeout;

        peripheralGetGapParameter(GAPPRRA_CONN_INTERVAL, &con_interval);
        peripheralGetGapParameter(GAPPRRA_CONN_LATENCY, &conn_slave_latency);
        peripheralGetGapParameter(GAPPRRA_CONN_TIMEOUT, &conn_supervision_timeout);

        DBG_BUFFER(MODULE_APP, LEVEL_INFO,
                   "BT_MSG_TYPE_CONN_PARA_UPDATE_CHANGE success, con_interval = 0x%x, conn_slave_latency = 0x%x, conn_supervision_timeout = 0x%x",
                   3, con_interval, conn_slave_latency, conn_supervision_timeout);
    }
    else
    {
        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_CONN_PARA_UPDATE_CHANGE failed, status = %d",
                   1, status);

    }
}

/******************************************************************
 * @fn          peripheral_HandleBtGapMessage
 * @brief      All the bt gap msg  events are pre-handled in this function.
 *                Then the event handling function shall be called according to the subType
 *                of BEE_IO_MSG.
 *
 * @param    pBeeIoMsg  - pointer to bee io msg
 * @return     void
 */
void peripheral_HandleBtGapMessage(BEE_IO_MSG  *pBeeIoMsg)
{
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "peripheral_HandleBtGapMessage subType = %d", 1, pBeeIoMsg->subType);
    BT_STACK_MSG BtStackMsg;
    memcpy(&BtStackMsg, &pBeeIoMsg->parm, sizeof(pBeeIoMsg->parm));

    switch (pBeeIoMsg->subType)
    {
        case BT_MSG_TYPE_CONN_STATE_CHANGE:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_CONN_STATE_CHANGE:(%d->%d)",
                           2, gapProfileState, BtStackMsg.msgData.gapConnStateChange.newState);

                peripheral_HandleBtGapStateChangeEvt(BtStackMsg.msgData.gapConnStateChange.newState);
            }
            break;

        case BT_MSG_TYPE_BOND_STATE_CHANGE:
            {
                peripheral_HandleBtGapBondStateChangeEvt(BtStackMsg.msgData.gapBondStateChange.newState,
                        BtStackMsg.msgData.gapBondStateChange.status);
            }
            break;

        case BT_MSG_TYPE_BOND_PASSKEY_DISPLAY:
            {
                uint32_t displayValue = 0;
                GAPBondMgr_GetParameter(GAPBOND_PASSKEY, &displayValue);
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_PASSKEY_DISPLAY: %d", 1, displayValue);
            }
            break;

        case BT_MSG_TYPE_BOND_PASSKEY_INPUT:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_PASSKEY_INPUT", 0);

                uint32_t passKey = 888888;
                GAPBondMgr_SetParameter(GAPBOND_PASSKEY, sizeof(passKey), &passKey);
                GAPBondMgr_InputPassKey();
            }
            break;

        case BT_MSG_TYPE_BOND_OOB_INPUT:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_OOB_INPUT", 0);
                uint8_t ooBData[KEYLEN] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
                GAPBondMgr_SetParameter(GAPBOND_OOB_DATA, KEYLEN, ooBData);
                GAPBondMgr_InputOobData();
            }
            break;

        case BT_MSG_TYPE_ENCRYPT_STATE_CHANGE:
            {
                peripheral_HandleBtGapEncryptStateChangeEvt(BtStackMsg.msgData.gapEncryptStateChange.newState);
            }
            break;

        case BT_MSG_TYPE_CONN_PARA_UPDATE_CHANGE:
            {
                peripheral_HandleBtGapConnParaChangeEvt(BtStackMsg.msgData.gapConnParaUpdateChange.status);
            }
            break;

        default:
            DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "peripheral_HandleBtGapMessage unknown subtype", 1, pBeeIoMsg->subType);

            break;

    }

}

/******************************************************************
 * @fn          AppProfileCallback
 * @brief      All the bt profile callbacks are handled in this function.
 *                Then the event handling function shall be called according to the serviceID
 *                of BEE_IO_MSG.
 *
 * @param    serviceID  -  service id of profile
 * @param    pData  - pointer to callback data
 * @return     void
 */
TAppResult AppProfileCallback(uint8_t serviceID, void *pData)
{
    TAppResult appResult = AppResult_Success;
    if (serviceID == ProfileAPI_ServiceUndefined)
    {
        TEventInfoCBs_t *pPara = (TEventInfoCBs_t *)pData;
        switch (pPara->eventId)
        {
            case PROFILE_EVT_SRV_REG_COMPLETE:// srv register result event.
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "profile callback PROFILE_EVT_SRV_REG_COMPLETE\n", 0);
                {
                    peripheral_Init_StartAdvertising();
                }
                break;

            default:
                break;
        }
    }
    else  if (serviceID == gSimpleProfileServiceId)
    {
        TSIMP_CALLBACK_DATA *pSimpCallbackData = (TSIMP_CALLBACK_DATA *)pData;
        switch (pSimpCallbackData->msg_type)
        {
            case SERVICE_CALLBACK_TYPE_INDIFICATION_NOTIFICATION:
                {
                    DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "SERVICE_CALLBACK_TYPE_INDIFICATION_NOTIFICATION\n", 0);
                    switch (pSimpCallbackData->msg_data.notification_indification_index)
                    {
                        case SIMP_NOTIFY_INDICATE_V3_ENABLE:
                            {
                                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "SIMP_NOTIFY_INDICATE_V3_ENABLE\n", 0);
                            }
                            break;

                        case SIMP_NOTIFY_INDICATE_V3_DISABLE:
                            {
                                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "SIMP_NOTIFY_INDICATE_V3_DISABLE\n", 0);
                            }
                            break;
                        case SIMP_NOTIFY_INDICATE_V4_ENABLE:
                            {
                                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "SIMP_NOTIFY_INDICATE_V4_ENABLE\n", 0);
                            }
                            break;
                        case SIMP_NOTIFY_INDICATE_V4_DISABLE:
                            {
                                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "SIMP_NOTIFY_INDICATE_V4_DISABLE\n", 0);
                            }
                            break;
                        case SIMP_NOTIFY_INDICATE_V5_ENABLE:
                            {
                                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "SIMP_NOTIFY_INDICATE_V5_ENABLE\n", 0);
                            }
                            break;
                        case SIMP_NOTIFY_INDICATE_V5_DISABLE:
                            {
                                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "SIMP_NOTIFY_INDICATE_V5_DISABLE\n", 0);
                            }
                            break;
                    }
                }
                break;


            case SERVICE_CALLBACK_TYPE_READ_CHAR_VALUE:
                {
                    DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "SERVICE_CALLBACK_TYPE_READ_CHAR_VALUE\n", 0);
                    if (pSimpCallbackData->msg_data.read_value_index == SIMP_READ_V1)
                    {
                        uint8_t value1 = 0x88;
                        DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "SIMP_READ_V1: 0x%x\n", 1, value1);
                        SimpBleService_SetParameter(SIMPLE_BLE_SERVICE_PARAM_V1_READ_CHAR_VAL, 1, &value1);
                    }
                }
                break;
            case SERVICE_CALLBACK_TYPE_WRITE_CHAR_VALUE:
                {
                    DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "SERVICE_CALLBACK_TYPE_WRITE_CHAR_VALUE\n", 0);
                    switch (pSimpCallbackData->msg_data.write.opcode)
                    {
                        case SIMP_WRITE_V2:
                            {
                                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "SIMP_WRITE_V2: value = 0x%x\n", 1, pSimpCallbackData->msg_data.write.value);
                            }
                            break;
                        case SIMP_WRITE_V5_OPCODE_SET_CHAR_INDICATE_VAL:
                            {
                                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "SIMP_WRITE_V5_OPCODE_SET_CHAR_INDICATE_VAL: value = 0x%x\n", 1, pSimpCallbackData->msg_data.write.value);
                            }
                            break;
                        case SIMP_WRITE_V5_OPCODE_SET_CHAR_NOTIFY_VAL:
                            {
                                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "SIMP_WRITE_V5_OPCODE_SET_CHAR_NOTIFY_VAL: value = 0x%x\n", 1, pSimpCallbackData->msg_data.write.value);
                            }
                            break;
                        default:
                            break;
                    }
                }
                break;

            default:
                break;
        }
    }
    return appResult;
}


