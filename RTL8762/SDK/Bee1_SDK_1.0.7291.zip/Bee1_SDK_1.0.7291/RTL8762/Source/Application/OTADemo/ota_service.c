/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     ota_service.c
* @brief
* @details
* @author   hunter_shuai
* @date     14-July-2015
* @version  v1.0.0
******************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2015 Realtek Semiconductor Corporation</center></h2>
******************************************************************************
*/

#include "trace.h"
#include "endialig.h"
#include "FreeRTOS.h"
#include "gatt.h"
#include "profileApi.h"
#include "ota_service.h"



/********************************************************************************************************
* local static variables defined here, only used in this source file.
********************************************************************************************************/
/**<  Function pointer used to send event to application from BWPS extended profile. */
/**<  Initiated in BWPSExtended_AddService. */
pfnAPPHandleInfoCB_t pfnOTAExtendedCB = NULL;


/**< @brief  profile/service definition.
*   here is an example of OTA service table
*   including Write
*/
const TAttribAppl gattExtendedServiceTable[] =
{
    /*--------------------------BWPS(bee wristband private protocol) Service ---------------------------*/
    /* <<Primary Service>>, .. 0*/
    {
        (ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_LE),  /* wFlags     */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_PRIMARY_SERVICE),
            HI_WORD(GATT_UUID_PRIMARY_SERVICE),
            LO_WORD(GATT_UUID_OTA_SERVICE),               /* service UUID */
            HI_WORD(GATT_UUID_OTA_SERVICE)
        },
        UUID_16BIT_SIZE,                           /* bValueLen     */
        NULL,                                       /* pValueContext */
        GATT_PERM_READ                              /* wPermissions  */
    },

    /* <<Characteristic>>, .. 1*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_WRITE,                    /* characteristic properties */
            //XXXXMJMJ GATT_CHAR_PROP_INDICATE,                  /* characteristic properties */
            /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },
    /*  OTA characteristic value 8*/
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHAR_OTA),
            HI_WORD(GATT_UUID_CHAR_OTA),
        },
        2,                                          /* variable size */
        (void *)NULL,
        GATT_PERM_READ | GATT_PERM_WRITE            /* wPermissions */
    },
};




/**
 * @brief write characteristic data from service.
 *
 * @param ServiceID          ServiceID to be written.
 * @param iAttribIndex       Attribute index of characteristic.
 * @param wLength            length of value to be written.
 * @param pValue             value to be written.
 * @return Profile procedure result
*/
TProfileResult  OTAServiceAttrWriteCb(uint8_t ServiceId, uint16_t iAttribIndex, uint16_t wLength, uint8_t *pValue, TGATTDWriteIndPostProc *pWriteIndPostProc)
{
    TOTA_CALLBACK_DATA callback_data;
    TProfileResult  wCause = ProfileResult_Success;

    if (BLE_SERVICE_CHAR_OTA_INDEX == iAttribIndex)
    {
        /* Make sure written value size is valid. */
        if ( (wLength != 2 * sizeof(uint8_t)) || (pValue == NULL) )
        {
            wCause  = ProfileResult_InvalidValueSize;
        }
        else
        {
            /* Notify Application. */
            callback_data.msg_type = SERVICE_CALLBACK_TYPE_WRITE_CHAR_VALUE;
            callback_data.msg_data.write.opcode = OTA_WRITE_CHAR_VAL;
            callback_data.msg_data.write.value = pValue[0];

            if (pfnOTAExtendedCB)
            {
                pfnOTAExtendedCB(ServiceId, (void *)&callback_data);
            }
        }
    }

    else
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "--> OTA_AttrWrite Error  iAttribIndex = 0x%x wLength=%d",
                   2,
                   iAttribIndex,
                   wLength);
        wCause = ProfileResult_AttrNotFound;
    }
    return wCause;

}



/**
 * @brief OTA ble Service Callbacks.
*/
CONST gattServiceCBs_t OTAServiceCBs =
{
    NULL,                   // Read callback function pointer
    OTAServiceAttrWriteCb,  // Write callback function pointer
    NULL                    // CCCD update callback function pointer
};

/**
 * @brief  add OTA ble service to application.
 *
 * @param  pFunc          pointer of app callback function called by profile.
 * @return service ID auto generated by profile layer.
 * @retval ServiceId
*/
uint8_t OTAService_AddService(void *pFunc)
{
    uint8_t ServiceId;
    if (FALSE == ProfileAPI_AddService(&ServiceId,
                                       (uint8_t *)gattExtendedServiceTable,
                                       sizeof(gattExtendedServiceTable),
                                       OTAServiceCBs))
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "OTAService_AddService: ServiceId %d", 1, ServiceId);
        ServiceId = 0xff;
        return ServiceId;
    }
    pfnOTAExtendedCB = (pfnAPPHandleInfoCB_t)pFunc;
    return ServiceId;
}

