/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     wristband_application.h
* @brief
* @details
* @author   hunter_shuai
* @date     19-June-2015
* @version  v1.0.0
******************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2015 Realtek Semiconductor Corporation</center></h2>
******************************************************************************
*/

#ifndef _WRISTBAND_APPLICATION__
#define _WRISTBAND_APPLICATION__


#ifdef __cplusplus
extern "C" {
#endif

#include "rtl876x.h"
#include "bee_message.h"
#include "profileApi.h"

extern void AppHandleIODriverMessage(BEE_IO_MSG io_driver_msg_recv);
extern TAppResult AppHandleGATTCallback(uint8_t serviceID, void *pData);


#ifdef __cplusplus
}
#endif

#endif

