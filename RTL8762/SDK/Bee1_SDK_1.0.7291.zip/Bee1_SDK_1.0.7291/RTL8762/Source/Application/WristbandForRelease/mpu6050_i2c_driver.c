/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     mpu6050_i2c_driver.c
* @brief    this is driver file of MPU6050
* @details
* @author   hunter_shuai
* @date     27-June-2015
* @version  v1.0.0
******************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2015 Realtek Semiconductor Corporation</center></h2>
******************************************************************************
*/


#include "mpu6050_i2c_driver.h"
#include "rtl876x_i2c.h"
#include "stdint.h"
#include "stdio.h"
#include "rtl_delay.h"
#include "trace.h"
#include "wristband_error.h"



/**
  * @brief  MPU6050_ReadReg
  * @param  reg     register address
  * @param  pData   pointer to read value
  * @retval bool
  */
bool MPU6050_ReadReg(uint8_t reg, uint8_t *pData)
{
    if (SET == I2C_RepeatRead(I2C0, &reg, 1, pData, 1))
    {
        return true;
    }
    else
    {
        return false;
    }
}


/**
  * @brief  MPU6050_WriteReg
  * @param  reg     write address
  * @param  data    data value to be written
  * @retval void
  */
void MPU6050_WriteReg(uint8_t write_addr, uint8_t data)
{
    uint8_t buf[2] = {write_addr, data};
    I2C_MasterWrite(I2C0, buf, 2);
}


/**
  * @brief  MPU6050_Init, use this function to config MPU6050
  * @param  void
  * @retval void
  */
void MPU6050_Init(void)
{
    ASSERT(MPU6050_VerifyID());
    MPU6050_WriteReg(PWR_MGMT_1, 0x00);
    MPU6050_WriteReg(SMPLRT_DIV, 0x50);  //Gyroscope Output Rate / (1 + SMPLRT_DIV) ,Gyroscope Output Rate=8kHZ(DLPF=0,7 else Rate=1KHZ)
    MPU6050_WriteReg(CONFIG, 0x07);      //DLPF=6
    MPU6050_WriteReg(GYRO_CONFIG, 0x00); //
    MPU6050_WriteReg(ACCEL_CONFIG, 0x10);//set fullsacle to +/- 8g
    MPU6050_WriteReg(INT_EN, 0x11);      //open overflow interrupt
    MPU6050_WriteReg(INT_PIN_CFG, 0xC0);
    MPU6050_WriteReg(USER_CTRL, BIT_FIFO_RST);
    MPU6050_WriteReg(USER_CTRL, BIT_FIFO_EN);
    MPU6050_WriteReg(FIFO_EN, 0x08);
}


/**
  * @brief  MPU6050_ReadAcc, read accelermeter 3-axis data
  * @param  ACC_DATA    pointer to acc data
  * @retval void
  */
void MPU6050_ReadAcc(int32_t *ACC_DATA)
{
    uint8_t data_high;
    uint8_t data_low;

    /*read Acc data*/
    MPU6050_ReadReg(ACCEL_XOUT_H, &data_high);
    MPU6050_ReadReg(ACCEL_XOUT_L, &data_low);
    ACC_DATA[0] = (data_high << 8) | data_low;       //

    MPU6050_ReadReg(ACCEL_YOUT_H, &data_high);
    MPU6050_ReadReg(ACCEL_YOUT_H, &data_low);
    ACC_DATA[1] = (data_high << 8) | data_low;       //

    MPU6050_ReadReg(ACCEL_ZOUT_H, &data_high);
    MPU6050_ReadReg(ACCEL_ZOUT_H, &data_low);
    ACC_DATA[2] = (data_high << 8) | data_low;       //
}


/**
  * @brief  MPU6050_ReadGyro, read gyro 3-axis data
  * @param  GYRO_DATA   pointer to gyro data
  * @retval void
  */
void MPU6050_ReadGyro(int32_t *GYRO_DATA)
{
    uint8_t data_high;
    uint8_t data_low;
    /*read Gyro data*/
    MPU6050_ReadReg(GYRO_XOUT_H, &data_high);
    MPU6050_ReadReg(GYRO_XOUT_L, &data_low);
    GYRO_DATA[0] = (data_high << 8) | data_low;      //

    MPU6050_ReadReg(GYRO_YOUT_H, &data_high);
    MPU6050_ReadReg(GYRO_YOUT_L, &data_low);
    GYRO_DATA[1] = (data_high << 8) | data_low;      //

    MPU6050_ReadReg(GYRO_ZOUT_H, &data_high);
    MPU6050_ReadReg(GYRO_ZOUT_L, &data_low);
    GYRO_DATA[2] = (data_high << 8) | data_low;      //

}

/**
  * @brief  verify MPU6050 sensor id
  * @param  void
  * @retval bool
  */
bool MPU6050_VerifyID(void)
{
    uint8_t id;
    MPU6050_ReadReg(WHO_AM_I, &id);
    if (MPU6050_ID == id)
    {
        return true;
    }
    return false;
}

/**
  * @brief  MPU6050_ReadIntStatus
  * @param  void
  * @retval uint8_t return INT register flag
  */
uint8_t MPU6050_ReadIntStatus(void)
{
    uint8_t status;
    MPU6050_ReadReg(INT_STATUS, &status);
    return status;
}


/**
 *  @brief      Get one unparsed packet from the FIFO.
 *  This function should be used if the packet is to be parsed elsewhere.
 *  @param[in]  length  Length of one FIFO packet.
 *  @param[in]  data    FIFO packet.
 *  @param[in]  more    Number of remaining packets.
 *  @retval     int     read FIFO state: 0 success, -1 length error, -2 FIFO overflow
 *
 */
int MPU6050_ReadFIFOStream(uint16_t length, uint8_t *data, unsigned char *more)
{
    unsigned char tmp[2];
    unsigned short fifo_count;

    MPU6050_ReadReg(FIFO_COUNT_H, &tmp[0]);
    MPU6050_ReadReg(FIFO_COUNT_L, &tmp[1]);

    fifo_count = (tmp[0] << 8) | tmp[1];

    //DBG_BUFFER(MODULE_APP,LEVEL_TRACE,"fifo_count:%d \r\n",1,fifo_count);

    if (fifo_count < length)
    {
        more[0] = 0;
        return -1;
    }
    if ((10 * fifo_count) > (5 * MPU6050_MaxFIFOLength))
    {
        /* FIFO is 50% full, better check overflow bit. */
        MPU6050_ReadReg(INT_STATUS, &tmp[0]);
        if (tmp[0] & BIT_FIFO_OVERFLOW)
        {
            DBG_BUFFER(MODULE_APP, LEVEL_TRACE, "FIFO overflow \r\n", 0);

            MPU6050_ResetFIFO();
            return -2;
        }
    }
    for (int i = 0; i < length; i++)
    {
        MPU6050_ReadReg(FIFO_R_W, &data[i]);
    }

    more[0] = fifo_count / length - 1;
    return 0;
}


/**
 *  @brief      Get one unparsed packet from the FIFO.
 *  This function should be used if the packet is to be parsed elsewhere.
 *  @param[in]  length  Length of one FIFO packet.
 *  @param[in]  accData pointer to FIFO packet.
 */
void MPU6050_ReadFIFOData(uint8_t *pack_length, AxesRaw_t *accData)
{
    uint8_t i = 0;
    uint8_t more;
    uint8_t data[6];
    do
    {
        MPU6050_ReadFIFOStream(6, data, &more);
        accData[i].AXIS_X = data[0] << 8 | data[1];
        accData[i].AXIS_Y = data[2] << 8 | data[3];
        accData[i].AXIS_Z = data[4] << 8 | data[5];
        i++;
    } while (more != 0 & i < 32);

    *pack_length = i;
}





/**
 *  @brief  Reset FIFO read/write pointers.
 *  @param  void
 *  @return void
 */
void MPU6050_ResetFIFO(void)
{
    MPU6050_WriteReg(INT_EN, 0);

    MPU6050_WriteReg(FIFO_EN, 0);

    MPU6050_WriteReg(USER_CTRL, 0);

    MPU6050_WriteReg(USER_CTRL, BIT_FIFO_RST);

    MPU6050_WriteReg(USER_CTRL, BIT_FIFO_EN);
    delayMS(10);
    MPU6050_WriteReg(FIFO_EN, 0x08);

    MPU6050_WriteReg(INT_EN, BIT_FIFO_OVERFLOW | BIT_DATA_RDY_EN);
}








