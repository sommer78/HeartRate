/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     step_counter.h
* @brief
* @details
* @author   hunter_shuai
* @date     19-June-2015
* @version  v1.0.0
******************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2015 Realtek Semiconductor Corporation</center></h2>
******************************************************************************
*/

#ifndef _STEP_COUNTER_H_
#define _STEP_COUNTER_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"
#include "rtl_types.h"
#include "health_algorithm.h"

#define SENSOR_INTERVAL 280     //uint:ms
#define SENSOR_TIMER_ID 1
#define DEFAULT_STEP_TASK     10000              /**<default task 10000 steps>*/


uint32_t RestartHealthAlgorithm(void);
bool IsAlgorithmStarted(void);
void ResetHealthAlgorithmData(void);
uint8_t GetSportsMode(void);
void SetDailyTargetAchieved(bool value);
bool GetDailyTargetAchieved(void);
uint32_t StartHealthAlgorithm(void);
void StopHealthAlgorithm(void);
void CreateSensorTimer(void);
void StartSensorTimer(void);
void SensorTimeoutMsgHandle(void );
void SensorIntMsgHandler(void);


uint32_t GetDailyTarget(void);
int SetDailyTarget(uint32_t target);
void SetGlobalStepCountsToday(uint32_t steps);
void SetGlobalDistanceCountsToday(uint32_t dis);
void SetGlobalCaloryCountsToday(uint32_t cal);
uint32_t GetGlobalStepCountsToday(void);
uint32_t GetGlobalCaloryCountsToday(void);
uint32_t GetGlobalDistanceCountsToday(void);
userprofile_union_t *GetUserProfile(void);
int SetUserProfile(userprofile_union_t *profile);




/*for "assert" debug*/
#define DPRINTF(...) DBG_DIRECT(__VA_ARGS__)
#define ASSERT(x) if(!(x)) { DPRINTF("Assert(%s) fail in %s,%d\n", #x,__FILE__, __LINE__, 3); while(1) {;}}


#ifdef __cplusplus
}
#endif


#endif

