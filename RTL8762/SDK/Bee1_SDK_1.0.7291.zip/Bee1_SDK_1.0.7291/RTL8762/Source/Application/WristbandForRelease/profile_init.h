/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     profile_init.h
* @brief
* @details
* @author   hunter_shuai
* @date           19-June-2015
* @version  v1.0.0
******************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2015 Realtek Semiconductor Corporation</center></h2>
******************************************************************************
*/

#ifndef _PROFILE_INIT_H
#define _PROFILE_INIT_H

#ifdef __cplusplus
extern "C" {
#endif

extern void WristbandStartAdv(void);
extern void WristbandStopAdv(void);
extern void WristbandEnablePairing(void);
extern void WristbandDisconnectBLE(void);

#ifdef __cplusplus
}
#endif

#endif /* _PROFILE_INIT_H */

