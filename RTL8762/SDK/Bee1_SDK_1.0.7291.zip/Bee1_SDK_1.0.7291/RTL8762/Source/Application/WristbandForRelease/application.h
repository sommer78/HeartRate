/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     application.h
* @brief
* @details
* @author   hunter_shuai
* @date            19-June-2015
* @version  v1.0.0
******************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2015 Realtek Semiconductor Corporation</center></h2>
******************************************************************************
*/

#ifndef _APPLICATION_H_
#define _APPLICATION_H_


#ifdef  __cplusplus
extern "C" {
#endif      /* __cplusplus */


#include "rtl_types.h"


extern void application_task_init(void);



#ifdef  __cplusplus
}
#endif      /*  __cplusplus */


#endif

