/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     step_counter.c
* @brief
* @details
* @author   hunter_shuai
* @date     19-June-2015
* @version  v1.0.0
******************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2015 Realtek Semiconductor Corporation</center></h2>
******************************************************************************
*/

#include "step_counter.h"
#include "board.h"
#include "lis3dh_i2c_driver.h"
#include "stdlib.h"
#include "trace.h"
#include "FreeRTOS.h"
#include "timers.h"
#include "os.h"
#include "hal_i2c_acc.h"
#include <string.h>
#include "wristband_error.h"
#include "basic_op.h"

extern AxesRaw_t accData[32];

/*static  parameter for pedometer */
//static xTimerHandle sensor_timer = NULL;
static bool algorithm_started = false;
static bool daily_target_achieved = false;
static uint16_t stationary = 0;
static uint16_t walking = 0;
static uint16_t running = 0;
static uint16_t maxMode = 0;
static uint32_t   global_step_counts_today = 0;
static uint32_t   global_distance_counts_today = 0;
static uint32_t   global_calory_counts_today = 0;
static uint32_t   daily_step_target = DEFAULT_STEP_TASK;
//static bool       daily_target_changed = false;
static userprofile_union_t user_profile = {0};


/**
  * @brief  handle sport event when health algorithm call back sport information
  *
  * @param  NewInfo    pointer to algorithm call back formated information
  * @return void
  */
static void HandleSportEvent(RtkPedoInfo_t *NewInfo)
{
    if (NewInfo->wNewSteps > 0)
    {
        SetGlobalStepCountsToday(GetGlobalStepCountsToday() + NewInfo->wNewSteps);

        if (NewInfo->wNewDistance > 0)
        {
            SetGlobalDistanceCountsToday(GetGlobalDistanceCountsToday() + NewInfo->wNewDistance);
        }

        if (NewInfo->wNewCalories > 0)
        {
            SetGlobalCaloryCountsToday(GetGlobalCaloryCountsToday() + NewInfo->wNewCalories);
        }

        DBG_BUFFER(MODULE_APP, LEVEL_TRACE, "-----g_step:%d \r\n", 1, GetGlobalStepCountsToday());

        switch (NewInfo->Activity)
        {
            case STEP_MODE_STATIONARY :
                stationary ++;
                break;
            case STEP_MODE_WALKING:
                walking ++;
                break;
            case STEP_MODE_RUNNING:
                running ++;
                break;
            default:
                break;
        }

        if ( GetGlobalStepCountsToday() >= GetDailyTarget() && !daily_target_achieved)
        {
            daily_target_achieved = true;
        }

        else if ( GetGlobalStepCountsToday() < GetDailyTarget() )
        {
            daily_target_achieved = false;
        }
    }
}


/**
  * @brief  health algorithm call back function
  *
  * @param  NewInfo  pointer to algorithm call back formated information
  * @return void
  */
static void HealthAlgorithmCallback(RtkPedoInfo_t *NewInfo)
{
    // use wNewSteps, wNewDistance, Activity, wNewSpeed, wNewCalories
    // to implement application

    if (NewInfo != NULL)
    {

#ifdef STEP_DEBUG
        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "@cb %d dbg=%d g=%d t=%d", 4, NewInfo->wNewSteps, NewInfo->dwStepsDebug,
                   GetGlobalStepCountsToday(), tmp_algo_info.wNewSteps);
#endif
        HandleSportEvent(NewInfo);
    }
    else
    {
        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "error: algorithm callback failed...", 0);
    }
}



bool IsAlgorithmStarted(void)
{
    return algorithm_started;
}

/**
  * @brief  end algorithm running
  *
  * @param  void
  * @return void
  */
void StopHealthAlgorithm(void)
{
    algorithm_started = false;
    RtkEndPedoAlgo();
}


/**
  * @brief  end algorithm running
  * before start health algorithm, the<userprofile>should be set, if not, algorithm will config with default value
  *
  * @param  void
  * @return sucess or not
  */
uint32_t StartHealthAlgorithm(void)
{
    RTStatus_t err_code = RT_SUCCESS;
    userprofile_union_t *user_profile = GetUserProfile();

    if (algorithm_started == true)
    {
        StopHealthAlgorithm();
    }

    /** initialize health algorithm **/
    // init algorithm and register call back function
    err_code = RtkInitPedoAlgo(user_profile, (health_algorithm_cb)HealthAlgorithmCallback);
    ASSERT(err_code == RT_SUCCESS);

    algorithm_started = true;
    return RT_SUCCESS;
}

/**
  * @brief  restart health algorithm
  *
  *
  * @param  void
  * @return void
  */
uint32_t RestartHealthAlgorithm(void)
{
    algorithm_started = true;
    return RtkResetPedoAlgo(25, GetUserProfile());
}

/**
  * @brief  reset health algorithm related data
  *
  *
  * @param  void
  * @return void
  */
void ResetHealthAlgorithmData(void)
{
    stationary = walking = running = 0;

    SetGlobalStepCountsToday(0);
    SetGlobalCaloryCountsToday(0);
    SetGlobalDistanceCountsToday(0);
}




#if FEATURE_SENSOR_LIS3DH
/**
  * @brief  handle sensor interrupt message
  *
  *
  * @param  void
  * @return void
  */
void SensorIntMsgHandler(void)
{
    RTStatus_t error_no;
    uint8_t transfer_size;
    RtkAccelData_t In[1];
    int32_t acc_ii = 0;  // modified by duncan

    hal_acc_GetFifoData(&transfer_size);

    for (; acc_ii < transfer_size; acc_ii ++)
    {
        // MUST guarantee accData is Q4.11 !!!
        // full scale set to +/-8G, Q12 --> algorithm needs Q11
        In->wXAccel = shr(accData[acc_ii].AXIS_X, 1);  // for FS 8g
        In->wYAccel = shr(accData[acc_ii].AXIS_Y, 1);
        In->wZAccel = shr(accData[acc_ii].AXIS_Z, 1);
        In->InputType = DATA_IN;
        if (acc_ii % 4 == 0 && true == algorithm_started )
        {
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, \
                       "[t=%d][%d] accX:%d,accY:%d,accZ:%d", 5, transfer_size, acc_ii, In->wXAccel, In->wYAccel, In->wZAccel);
            error_no = RtkPedoProcess(In);
            ASSERT(RT_CAL_COMPLETE == error_no);
        }
    }
}
#endif



#if FEATURE_SENSOR_MPU6050


/**
  * @brief  sensor timeout os interrupt entry
  *
  *
  * @param  void
  * @return void
  */
static void SensorTimeout(void)
{
    BEE_IO_MSG msg;
    /*construct BEE_IO_MSG to sent to IO queue*/
    msg.IoType = IO_WRISTBNAD_MSG_TYPE;
    msg.subType = MSG_OS_TIMEROUT_SENSOR;

    if (!SendMessage(&msg))
    {
        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "sensor timeout message send to queue fail!\n", 0);
    }
}

/**
  * @brief  handle sensor timeout delivered message
  *
  *
  * @param  void
  * @return void
  */
void SensorTimeoutMsgHandle(void )
{
    RTStatus_t error_no;
    uint8_t transfer_size;
    RtkAccelData_t In[1];
    int32_t acc_ii = 0;  // modified by duncan

    hal_acc_GetFifoData(&transfer_size);

    for (; acc_ii < transfer_size; acc_ii ++)
    {
        // MUST guarantee accData is Q4.11 !!!
        // full scale set to +/-8G, Q12 --> algorithm needs Q11
        In->wXAccel = shr(accData[acc_ii].AXIS_X, 1);  // for FS 8g
        In->wYAccel = shr(accData[acc_ii].AXIS_Y, 1);
        In->wZAccel = shr(accData[acc_ii].AXIS_Z, 1);
        In->InputType = DATA_IN;
        if (acc_ii % 4 == 0 && true == algorithm_started )
        {
            DBG_BUFFER(MODULE_APP, LEVEL_INFO, \
                       "[t=%d][%d] accX:%d,accY:%d,accZ:%d", 5, transfer_size, acc_ii, In->wXAccel, In->wYAccel, In->wZAccel);
            error_no = RtkPedoProcess(In);
            ASSERT(RT_CAL_COMPLETE == error_no);
        }
    }
}


/**
  * @brief  create sensor os timer
  *
  *
  * @param[in]  void
  * @return     void
  */
void CreateSensorTimer(void)
{
    if (sensor_timer == NULL)
    {
        sensor_timer = xTimerCreate(
                           "sensor_timer",                         // Just a text name, not used by the kernel.
                           (SENSOR_INTERVAL / portTICK_RATE_MS),   // The timer period in ticks.
                           pdPASS,                                 // The timers will auto-reload themselves when they expire.
                           (void *)SENSOR_TIMER_ID,                // Assign each timer a unique id equal to its array index.
                           (TimerCallbackFunction_t)SensorTimeout
                       );
        if (sensor_timer == NULL)
        {
            DBG_BUFFER(MODULE_UPPERSTACK, LEVEL_ERROR, " ***sensor_timer fail\n\n", 0);
        }
    }
}

/**
  * @brief  start sensor os timer
  *
  *
  * @param[in]  void
  * @return     void
  */
void StartSensorTimer(void)
{
    xTimerStart(sensor_timer, 0);
}
#endif




uint8_t GetSportsMode(void)
{
    uint8_t sportMode;

    maxMode = stationary > walking ? stationary : walking; //STEP_MODE_WALK_SLOW;
    maxMode = maxMode > running ? maxMode : running;

    if (maxMode == stationary)
    {
        sportMode = STEP_MODE_STATIONARY;
    }
    else if (maxMode == walking)
    {
        sportMode = STEP_MODE_WALKING;
    }
    else
    {
        sportMode = STEP_MODE_RUNNING;
    }
    return sportMode;
}


userprofile_union_t *GetUserProfile(void)
{
    return &user_profile;
}

int SetUserProfile(userprofile_union_t *profile)
{
    if (NULL == profile)
    {
        return -1;
    }

    memcpy(&user_profile, profile, sizeof(userprofile_union_t));

    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "s%d a:%d h:%d w:%d\r\n", 4, user_profile.bit_field.is_male,
               user_profile.bit_field.age_year, user_profile.bit_field.height_cm, user_profile.bit_field.weight_kg);

    return 0;
}




void SetDailyTargetAchieved(bool value)
{
    daily_target_achieved = value;
}

bool GetDailyTargetAchieved(void)
{
    return daily_target_achieved;
}

uint32_t GetDailyTarget(void)
{
    return daily_step_target;

}

#if 0
int SetDailyTarget(uint32_t target)
{
    if (target != daily_step_target)
    {
        daily_step_target = target;
        daily_target_changed = true;
    }

    return 0;
}
#endif

void SetGlobalStepCountsToday(uint32_t steps)
{
    global_step_counts_today = steps;
}

void SetGlobalDistanceCountsToday(uint32_t dis)
{
    global_distance_counts_today = dis;
}

void SetGlobalCaloryCountsToday(uint32_t cal)
{
    global_calory_counts_today = cal;
}


uint32_t GetGlobalStepCountsToday(void)
{
    return global_step_counts_today;
}

uint32_t GetGlobalCaloryCountsToday(void)
{
    return global_calory_counts_today;
}

uint32_t GetGlobalDistanceCountsToday(void)
{
    return global_distance_counts_today;
}







