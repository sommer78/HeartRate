/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     wristband_application.c
* @brief
* @details
* @author   hunter_shuai
* @date     19-June-2015
* @version  v1.0.0
******************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2015 Realtek Semiconductor Corporation</center></h2>
******************************************************************************
*/

#include "rtl876x.h"
#include "wristband_application.h"
#include "bee_message.h"
#include "trace.h"
#include "bee_message.h"
#include "peripheral.h"
#include "gapbondmgr.h"
#include "profileAPI.h"
#include <string.h>
#include "os.h"
#include "profile_init.h"
#include "stdio.h"
#include "bas.h"
#include "dis.h"
#include "step_counter.h"
#include "board.h"

void peripheral_HandleBtGapMessage(BEE_IO_MSG  *pBeeIoMsg);

/*extern service id*/
extern uint8_t gBASServiceId;
extern uint8_t gDISServiceId;
extern uint8_t gBWPSServiceId;
extern uint8_t gBASBatteryLevel;


gaprole_States_t gapProfileState = GAPSTATE_INIT;
BOOL IsAbleToSendAction = FALSE;
BOOL IsBeenPaired = FALSE;



/**
* @brief  All the application events are pre-handled in this function.
*
* All the IO MSGs are sent to this function.
* Then the event handling function shall be called according to the MSG type.
*
* @param   msg  The BEE_IO_MSG from peripherals or BT stack state machine.
* @return  void
*/
static void wristband_HandleIoMessage(BEE_IO_MSG *msg)
{
    switch (msg->subType)
    {
#if FEATURE_SENSOR_MPU6050

        case MSG_OS_TIMEROUT_SENSOR:
            /* handle message in step_counter module*/
            SensorTimeoutMsgHandle();

            break;
#endif

#if FEATURE_SENSOR_LIS3DH

        case MSG_SENSOR_INT:
            SensorIntMsgHandler();

            break;
#endif
        default:

            break;
    }
}

/**
* @brief  All the application events are pre-handled in this function.
*
* All the IO MSGs are sent to this function.
* Then the event handling function shall be called according to the MSG type.
*
* @param   io_driver_msg_recv  The BEE_IO_MSG from peripherals or BT stack state machine.
* @return  void
*/
void AppHandleIODriverMessage(BEE_IO_MSG io_driver_msg_recv)
{
    UINT16 msgtype = io_driver_msg_recv.IoType;

    switch (msgtype)
    {
        case BT_STATUS_UPDATE:
            {
                peripheral_HandleBtGapMessage(&io_driver_msg_recv);
            }
            break;

        case IO_WRISTBNAD_MSG_TYPE:
            {
                wristband_HandleIoMessage(&io_driver_msg_recv);
            }
            break;

        default:
            break;
    }
}


void peripheral_HandleBtGapStateChangeEvt(uint8_t newState)
{

    switch ( newState )
    {
        case GAPSTATE_STACK_READY:
            {
                if (gapProfileState == GAPSTATE_CONNECTED)
                {
                    uint8_t disc_reason;
                    peripheralGetGapParameter(GAPPRRA_DISCONNECTED_REASON, &disc_reason);
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "peripheral_HandleBtGapStateChangeEvt: disc_reason = %d", 1, disc_reason);
                    peripheral_StartAdvertising();
                }
            }
            break;

        case GAPSTATE_ADVERTISING:
            {

            }
            break;

        case GAPSTATE_CONNECTED:
            {

            }
            break;

        case GAPSTATE_CONNECTED_ADV:
            {

            }
            break;

        default:
            {

            }
            break;

    }

    gapProfileState = (gaprole_States_t)newState;
}

void peripheral_HandleBtGapBondStateChangeEvt(uint8_t newState)
{

    switch (newState)
    {
        case GAPBOND_PAIRING_STATE_STARTED:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(GAPBOND_PAIRING_STATE_STARTED)", 0);
            }
            break;

        case GAPBOND_PAIRING_STATE_COMPLETE:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(GAPBOND_PAIRING_STATE_COMPLETE)", 0);
                /* mark being paired & able to send action*/
                IsAbleToSendAction = TRUE;
                IsBeenPaired = TRUE;
            }
            break;

        case GAPBOND_PAIRING_STATE_BONDED:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(GAPBOND_PAIRING_STATE_BONDED)", 0);
            }
            break;

        default:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(unknown newstate: %d)", 1, newState);
            }
            break;
    }

}


void peripheral_HandleBtGapEncryptStateChangeEvt(uint8_t newState)
{
    switch (newState)
    {
        case GAPBOND_ENCRYPT_STATE_ENABLED:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "GAPBOND_ENCRYPT_STATE_ENABLED", 0);
            }
            break;

        case GAPBOND_ENCRYPT_STATE_DISABLED:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "GAPBOND_ENCRYPT_STATE_DISABLED", 0);
            }
            break;

        default:
            break;
    }
}


void peripheral_HandleBtGapConnParaChangeEvt(uint8_t status)
{
    if (status == 0)
    {
        uint16_t con_interval;
        uint16_t conn_slave_latency;
        uint16_t conn_supervision_timeout;

        peripheralGetGapParameter(GAPPRRA_CONN_INTERVAL, &con_interval);
        peripheralGetGapParameter(GAPPRRA_CONN_LATENCY, &conn_slave_latency);
        peripheralGetGapParameter(GAPPRRA_CONN_TIMEOUT, &conn_supervision_timeout);

        DBG_BUFFER(MODULE_APP, LEVEL_INFO,
                   "BT_MSG_TYPE_CONN_PARA_UPDATE_CHANGE success, con_interval = 0x%x, conn_slave_latency = 0x%x, conn_supervision_timeout = 0x%x",
                   3, con_interval, conn_slave_latency, conn_supervision_timeout);
    }
    else
    {
        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_CONN_PARA_UPDATE_CHANGE failed, status = %d",
                   1, status);

    }
}


/**
* @brief
*
*
* @param pBtStackMsg
* @return  void
*/
void peripheral_HandleBtGapMessage(BEE_IO_MSG  *pBeeIoMsg)
{
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "peripheral_HandleBtGapMessage subType = %d", 1, pBeeIoMsg->subType);
    BT_STACK_MSG BtStackMsg;
    memcpy(&BtStackMsg, &pBeeIoMsg->parm, sizeof(pBeeIoMsg->parm));


    switch (pBeeIoMsg->subType)
    {
        case BT_MSG_TYPE_CONN_STATE_CHANGE:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_CONN_STATE_CHANGE:(%d->%d)",
                           2, gapProfileState, BtStackMsg.msgData.gapConnStateChange.newState);

                switch ( BtStackMsg.msgData.gapConnStateChange.newState )
                {
                    case GAPSTATE_IDLE_NO_ADV_NO_CONN:
                        {
                            if (gapProfileState == GAPSTATE_CONNECTED)
                            {
                                uint8_t disc_reason;
                                peripheralGetGapParameter(GAPPRRA_DISCONNECTED_REASON, &disc_reason);
                                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "peripheral_HandleBtGapMessage: disc_reason = %d", 1, disc_reason);
                                IsAbleToSendAction = FALSE;
                                IsBeenPaired = FALSE;
                                /* restart Advertising */
                                WristbandStartAdv();
                            }
                        }
                        break;

                    case GAPSTATE_ADVERTISING:
                        {

                        }
                        break;


                    case GAPSTATE_CONNECTED:
                        {
                            IsAbleToSendAction = TRUE;
                        }
                        break;

                    case GAPSTATE_CONNECTED_ADV:
                        {

                        }
                        break;

                    default:
                        {

                        }
                        break;

                }

                gapProfileState = (gaprole_States_t)BtStackMsg.msgData.gapConnStateChange.newState;

            }
            break;

        case BT_MSG_TYPE_BOND_STATE_CHANGE:
            {
                switch (BtStackMsg.msgData.gapBondStateChange.newState)
                {
                    case GAPBOND_PAIRING_STATE_STARTED:
                        {
                            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(GAPBOND_PAIRING_STATE_STARTED)", 0);
                        }
                        break;

                    case GAPBOND_PAIRING_STATE_COMPLETE:
                        {
                            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(GAPBOND_PAIRING_STATE_COMPLETE)", 0);

#if AUTO_RECONNECT_DEBUG
                            if (autoReconnect_Timer != NULL)
                            {
                                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO,  "stop autoReconnect_Timer", 0);
                                //xTimerStop(autoReconnect_Timer, 0);
                                xTimerDelete(autoReconnect_Timer, 0);
                                autoReconnect_Timer = NULL;
                            }
#endif
                        }
                        break;

                    case GAPBOND_PAIRING_STATE_BONDED:
                        {
                            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(GAPBOND_PAIRING_STATE_BONDED)", 0);
                        }
                        break;

                    default:
                        {
                            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(unknown newstate: %d)", 1, BtStackMsg.msgData.gapBondStateChange.newState);
                        }
                        break;
                }

            }
            break;

        case BT_MSG_TYPE_BOND_PASSKEY_DISPLAY:
            {
                uint32_t displayValue = 0;
                peripheralGetGapParameter(GAPBOND_PASSKEY, &displayValue);
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_PASSKEY_DISPLAY: %d", 1, displayValue);
            }
            break;

        case BT_MSG_TYPE_BOND_PASSKEY_INPUT:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_PASSKEY_INPUT", 0);

                uint32_t passKey = 888888;
                peripheralSetGapParameter(GAPBOND_PASSKEY, sizeof(passKey), &passKey);
                GAPBondMgr_InputPassKey();
            }
            break;

        case BT_MSG_TYPE_BOND_OOB_INPUT:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_OOB_INPUT", 0);
                uint8_t ooBData[KEYLEN] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
                peripheralSetGapParameter(GAPBOND_OOB_DATA, KEYLEN, ooBData);
                GAPBondMgr_InputOobData();
            }
            break;

        case BT_MSG_TYPE_ENCRYPT_STATE_CHANGE:
            {
                switch (BtStackMsg.msgData.gapEncryptStateChange.newState)
                {
                    case GAPBOND_ENCRYPT_STATE_ENABLED:
                        {
                            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "GAPBOND_ENCRYPT_STATE_ENABLED", 0);
                        }
                        break;

                    case GAPBOND_ENCRYPT_STATE_DISABLED:
                        {
                            DBG_BUFFER(MODULE_APP, LEVEL_INFO, "GAPBOND_ENCRYPT_STATE_DISABLED", 0);
                        }
                        break;

                    default:
                        break;
                }
            }
            break;

        case BT_MSG_TYPE_CONN_PARA_UPDATE_CHANGE:
            {
                if (BtStackMsg.msgData.gapConnParaUpdateChange.status == 0)
                {
                    uint16_t con_interval;
                    uint16_t conn_slave_latency;
                    uint16_t conn_supervision_timeout;

                    peripheralGetGapParameter(GAPPRRA_CONN_INTERVAL, &con_interval);
                    peripheralGetGapParameter(GAPPRRA_CONN_LATENCY, &conn_slave_latency);
                    peripheralGetGapParameter(GAPPRRA_CONN_TIMEOUT, &conn_supervision_timeout);

                    DBG_BUFFER(MODULE_APP, LEVEL_INFO,
                               "BT_MSG_TYPE_CONN_PARA_UPDATE_CHANGE success, con_interval = 0x%x, conn_slave_latency = 0x%x, conn_supervision_timeout = 0x%x",
                               3, con_interval, conn_slave_latency, conn_supervision_timeout);
                }
                else
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_CONN_PARA_UPDATE_CHANGE failed, status = %d",
                               1, BtStackMsg.msgData.gapConnParaUpdateChange.status);

                }
            }
            break;

        default:
            DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "peripheral_HandleBtGapMessage unknown subtype", 1, pBeeIoMsg->subType);

            break;

    }
}


TAppResult AppHandleGATTCallback(uint8_t serviceID, void *pData)
{
    TAppResult appResult = AppResult_Success;

    if (serviceID == ProfileAPI_ServiceUndefined)
    {
        TEventInfoCBs_t *pPara = (TEventInfoCBs_t *)pData;
        switch (pPara->eventId)
        {
            case PROFILE_EVT_SRV_REG_COMPLETE:
                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "profile callback PROFILE_EVT_SRV_REG_COMPLETE\n", 0);
                {
                    peripheral_StartAdvertising();
                }
                break;
            case PROFILE_EVT_SEND_DATA_COMPLETE:

                break;
        }
    }

    else if (gBASServiceId == serviceID)
    {
        TBAS_CALLBACK_DATA *pBasCallbackData = (TBAS_CALLBACK_DATA *)pData;
        switch (pBasCallbackData->msg_type)
        {
            case SERVICE_CALLBACK_TYPE_INDIFICATION_NOTIFICATION:
                {
                    if (pBasCallbackData->msg_data.notification_indification_index == BAS_NOTIFY_BATTERY_LEVEL_ENABLE)
                    {
                        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "profile callback BAS_NOTIFY_BATTERY_LEVEL_ENABLE\n", 0);
                    }
                    else if (pBasCallbackData->msg_data.notification_indification_index == BAS_NOTIFY_BATTERY_LEVEL_DISABLE)
                    {

                    }
                }
                break;
            case SERVICE_CALLBACK_TYPE_READ_CHAR_VALUE:
                {
                    BAS_SetParameter(BAS_PARAM_BATTERY_LEVEL, 1, &gBASBatteryLevel);
                }

                break;
            default:
                break;
        }
    }

    else if (gDISServiceId == serviceID)
    {
        TDIS_CALLBACK_DATA *pDisCallbackData = (TDIS_CALLBACK_DATA *)pData;
        switch (pDisCallbackData->msg_type)
        {   //
            case SERVICE_CALLBACK_TYPE_READ_CHAR_VALUE:
                {
                    if (pDisCallbackData->msg_data.read_value_index == DIS_READ_MANU_NAME_INDEX)
                    {
                        const uint8_t DISManufacturerName[] = "Realtek BT";
                        DIS_SetParameter(DIS_PARAM_MANUFACTURER_NAME,
                                         sizeof(DISManufacturerName),
                                         (void *)DISManufacturerName);
                    }
                    else if (pDisCallbackData->msg_data.read_value_index == DIS_READ_MODEL_NUM_INDEX)
                    {
                        const uint8_t DISModelNumber[] = "Model Nbr 0.9";
                        DIS_SetParameter(DIS_PARAM_MODEL_NUMBER,
                                         sizeof(DISModelNumber),
                                         (void *)DISModelNumber);
                    }
                    else if (pDisCallbackData->msg_data.read_value_index == DIS_READ_SERIAL_NUM_INDEX)
                    {
                        const uint8_t DISSerialNumber[] = "RTKBeeSerialNum";
                        DIS_SetParameter(DIS_PARAM_SERIAL_NUMBER,
                                         sizeof(DISSerialNumber),
                                         (void *)DISSerialNumber);

                    }
                    else if (pDisCallbackData->msg_data.read_value_index == DIS_READ_HARDWARE_REV_INDEX)
                    {
                        const uint8_t DISHardwareRev[] = "RTKBeeHardwareRev";
                        DIS_SetParameter(DIS_PARAM_HARDWARE_REVISION,
                                         sizeof(DISHardwareRev),
                                         (void *)DISHardwareRev);
                    }
                    else if (pDisCallbackData->msg_data.read_value_index == DIS_READ_FIRMWARE_REV_INDEX)
                    {
                        const uint8_t DISFirmwareRev[] = "RTKBeeFirmwareRev";
                        DIS_SetParameter(DIS_PARAM_FIRMWARE_REVISION,
                                         sizeof(DISFirmwareRev),
                                         (void *)DISFirmwareRev);
                    }
                    else if (pDisCallbackData->msg_data.read_value_index == DIS_READ_SOFTWARE_REV_INDEX)
                    {
                        const uint8_t DISSoftwareRev[] = "RTKBeeSoftwareRev";
                        DIS_SetParameter(DIS_PARAM_SOFTWARE_REVISION,
                                         sizeof(DISSoftwareRev),
                                         (void *)DISSoftwareRev);
                    }
                    else if (pDisCallbackData->msg_data.read_value_index == DIS_READ_SYSTEM_ID_INDEX)
                    {
                        uint8_t DISSystemID[DIS_SYSTEM_ID_LENGTH] = {0, 1, 2, 0, 0, 3, 4, 5};
                        DIS_SetParameter(DIS_PARAM_SYSTEM_ID,
                                         sizeof(DISSystemID),
                                         DISSystemID);

                    }
                    else if (pDisCallbackData->msg_data.read_value_index == DIS_READ_IEEE_CERT_STR_INDEX)
                    {
                        const uint8_t DISIEEEDataList[] = "RTKBeeIEEEDatalist";
                        DIS_SetParameter(DIS_PARAM_IEEE_DATA_LIST,
                                         sizeof(DISIEEEDataList),
                                         (void *)DISIEEEDataList);
                    }
                    else if (pDisCallbackData->msg_data.read_value_index == DIS_READ_PNP_ID_INDEX)
                    {
                        uint8_t DISPnpID[DIS_PNP_ID_LENGTH] = {0};
                        DIS_SetParameter(DIS_PARAM_PNP_ID,
                                         sizeof(DISPnpID),
                                         DISPnpID);
                    }
                }

                break;
            default:
                break;
        }
    }
    return appResult;
}


