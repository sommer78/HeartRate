/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     wristband_service.c
* @brief    wristband_service implementation
* @details  wristband_service implementation
* @author   hunter_shuai
* @date     19-June-2015
* @version  v1.0.0
******************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2015 Realtek Semiconductor Corporation</center></h2>
******************************************************************************
*/

#include "wristband_service.h"
#include "profileApi.h"
#include "trace.h"
#include "os.h"
#include "ota_api.h"

/**<  Function pointer used to send event to application from wristband extended service. */
/**<  Initiated in WrsitbandExtended_AddService. */
pfnAPPHandleInfoCB_t pfnWrsitbandExtendedCB = NULL;


/**< @brief  profile/service definition.
*   here is an example of wristband service table
*
*/
const TAttribAppl gattExtendedServiceTable[] =
{
    /*--------------------------wristband Service ---------------------------*/
    /* <<Primary Service>>, .. 0*/
    {
        (ATTRIB_FLAG_VALUE_INCL | ATTRIB_FLAG_LE),  /* wFlags     */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_PRIMARY_SERVICE),
            HI_WORD(GATT_UUID_PRIMARY_SERVICE),
            LO_WORD(BLE_UUID_WRISTBAND_SERVICE),           /* service UUID */
            HI_WORD(BLE_UUID_WRISTBAND_SERVICE)
        },
        UUID_16BIT_SIZE,                            /* bValueLen     */
        NULL,                                       /* pValueContext */
        GATT_PERM_READ                              /* wPermissions  */
    },

    /* <<Characteristic>>, .. 1*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_WRITE,                    /* characteristic properties */
            //XXXXMJMJ GATT_CHAR_PROP_INDICATE,                  /* characteristic properties */
            /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*  Tx characteristic value 2*/
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(BLE_UUID_WRISTBAND_TX_CHARACTERISTIC),
            HI_WORD(BLE_UUID_WRISTBAND_TX_CHARACTERISTIC),
        },
        2,                                          /* variable size */
        (void *)NULL,
        GATT_PERM_READ | GATT_PERM_WRITE            /* wPermissions */
    },

    /* <<Characteristic>>, .. 3*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_READ | GATT_CHAR_PROP_WRITE_NO_RSP | GATT_CHAR_PROP_NOTIFY, /* characteristic properties */
            /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /* <<RX Characteristic>>, .. 4*/
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(BLE_UUID_WRISTBAND_RX_CHARACTERISTIC),
            HI_WORD(BLE_UUID_WRISTBAND_RX_CHARACTERISTIC),
        },
        2,                                          /* variable size */
        (void *)NULL,
        GATT_PERM_READ | GATT_PERM_WRITE            /* wPermissions */
    },

    /* client characteristic configuration 5*/
    {
        (ATTRIB_FLAG_VALUE_INCL |                   /* wFlags */
        ATTRIB_FLAG_CCCD_APPL),
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHAR_CLIENT_CONFIG),
            HI_WORD(GATT_UUID_CHAR_CLIENT_CONFIG),
            /* NOTE: this value has an instantiation for each client, a write to */
            /* this attribute does not modify this default value:                */
            LO_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT), /* client char. config. bit field */
            HI_WORD(GATT_CLIENT_CHAR_CONFIG_DEFAULT)
        },
        2,                                          /* bValueLen */
        NULL,
        (GATT_PERM_READ | GATT_PERM_WRITE)          /* wPermissions */
    },

    /* <<Characteristic>>, .. 6*/
    {
        ATTRIB_FLAG_VALUE_INCL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(GATT_UUID_CHARACTERISTIC),
            HI_WORD(GATT_UUID_CHARACTERISTIC),
            GATT_CHAR_PROP_WRITE,                    /* characteristic properties */
            //XXXXMJMJ GATT_CHAR_PROP_INDICATE,                  /* characteristic properties */
            /* characteristic UUID not needed here, is UUID of next attrib. */
        },
        1,                                          /* bValueLen */
        NULL,
        GATT_PERM_READ                              /* wPermissions */
    },

    /*  Tx characteristic value 7*/
    {
        ATTRIB_FLAG_VALUE_APPL,                     /* wFlags */
        {   /* bTypeValue */
            LO_WORD(OTA_UUID_UPDATE_CHARACTERISTIC),
            HI_WORD(OTA_UUID_UPDATE_CHARACTERISTIC),
        },
        2,                                          /* variable size */
        (void *)NULL,
        GATT_PERM_READ | GATT_PERM_WRITE            /* wPermissions */
    },
};



/**
 * @brief read characteristic data from service.
 *
 * @param ServiceId          ServiceID of characteristic data.
 * @param iAttribIndex       Attribute index of getting characteristic data.
 * @param iOffset            Used for Blob Read.
 * @param piLength           length of getting characteristic data.
 * @param ppValue            data got from service.
 * @return  Profile procedure result
*/
TProfileResult   WrsitbandServiceAttrReadCb( uint8_t ServiceId, uint16_t iAttribIndex, uint16_t iOffset, uint16_t *piLength, uint8_t **ppValue )
{
    TProfileResult  wCause  = ProfileResult_Success;

    //hanlde wristband Read message here...

    return ( wCause );
}


/**
 * @brief write characteristic data from service.
 *
 * @param ServiceID          ServiceID to be written.
 * @param iAttribIndex       Attribute index of characteristic.
 * @param wLength            length of value to be written.
 * @param pValue             value to be written.
 * @return Profile procedure result
*/
TProfileResult  WrsitbandServiceAttrWriteCb(uint8_t ServiceId, uint16_t iAttribIndex, uint16_t wLength, uint8_t *pValue, TGATTDWriteIndPostProc *pWriteIndPostProc)
{
    TProfileResult  wCause  = ProfileResult_Success;

    //handle wristband Write message here...

    return ( wCause );

}


/**
 * @brief  update CCCD bits from stack.
 *
 * @param  ServiceId      Service ID.
 * @param  Index          Attribute index of characteristic data.
 * @param  wCCCBits       CCCD bits from stack.
 * @return  None
*/
void WrsitbandServiceCccdUpdateCb(uint8_t serviceId, uint16_t Index, uint16_t wCCCBits)
{
    //handle wristband CCCD message here...
    return;
}


/**
 * @brief Beacon ble Service Callbacks.
*/
CONST gattServiceCBs_t WrsitbandServiceCBs =
{
    WrsitbandServiceAttrReadCb,   // Read callback function pointer
    WrsitbandServiceAttrWriteCb,  // Write callback function pointer
    WrsitbandServiceCccdUpdateCb  // CCCD update callback function pointer
};

/**
 * @brief add wristband ble service to application.
 *
 * @param  pFunc      pointer of app callback function called by profile.
 * @return  service ID auto generated by profile layer.
 * @retval  ServiceId
*/
uint8_t WristbandExtended_AddService(void *pFunc)
{
    uint8_t ServiceId;
    if (FALSE == ProfileAPI_AddService(&ServiceId,
                                       (uint8_t *)gattExtendedServiceTable,
                                       sizeof(gattExtendedServiceTable),
                                       WrsitbandServiceCBs))
    {
        DBG_BUFFER(MODULE_PROFILE, LEVEL_ERROR, "WrsitbandService_AddService: ServiceId %d", 1, ServiceId);
        ServiceId = 0xff;
        return ServiceId;
    }
    pfnWrsitbandExtendedCB = (pfnAPPHandleInfoCB_t)pFunc;
    return ServiceId;
}


