/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     wristband_service.h
* @brief
* @details
* @author   hunter_shuai
* @date     19-June-2015
* @version  v1.0.0
******************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2015 Realtek Semiconductor Corporation</center></h2>
******************************************************************************
*/


#ifndef __WRISTBAND_SERVICE_H__
#define __WRISTBAND_SERVICE_H__

#include <stdint.h>
#include "rtl_types.h"
#include "profileApi.h"

#ifdef __cplusplus
extern "C" {
#endif


/* UUID for wristband defined here, the value is an example */
#define BLE_UUID_WRISTBAND_SERVICE           0xFF01
#define BLE_UUID_WRISTBAND_TX_CHARACTERISTIC 0xFF02
#define BLE_UUID_WRISTBAND_RX_CHARACTERISTIC 0xFF03
#define OTA_UUID_UPDATE_CHARACTERISTIC  0xFF04

/*index number of each characteristic in the gattExtendedServiceTable(defined in wristband_service.c)*/
#define WRISTBAND_INDEX_MAX                      0x08
#define GATT_SRV_WRISTBAND_TX_INDEX              0x02
#define GATT_SRV_WRISTBAND_RX_INDEX              0x04
#define GATT_SRV_WRISTBAND_CCCD_INDEX            0x05
#define GATT_SRV_OTA_INDEX                       0x07

/** Write content */
typedef struct _TWRISTBAND_WRITE_MSG {
    uint8_t opcode;
    uint8_t value;
} TWRISTBAND_WRITE_MSG;

/** Message content: @ref WRISTBAND_Upstream_Message */
typedef union _TWRISTBAND_UPSTREAM_MSG_DATA
{
    uint8_t notification_indification_index;
    uint8_t read_value_index;
    TWRISTBAND_WRITE_MSG write;
} TWRISTBAND_UPSTREAM_MSG_DATA;


/* wristband service data to inform application*/
typedef struct _TWRISTBAND_CALLBACK_DATA
{
    TSERVICE_CALLBACK_TYPE          msg_type;                    /**<  @brief EventId defined upper */
    TWRISTBAND_UPSTREAM_MSG_DATA    msg_data;
} TWRISTBAND_CALLBACK_DATA;

/* add wristband service to application */
extern uint8_t  WristbandExtended_AddService(void *pFunc);


#ifdef __cplusplus
}
#endif

#endif // __WRISTBANDMETER_SERVICE_H__

/** @} */

