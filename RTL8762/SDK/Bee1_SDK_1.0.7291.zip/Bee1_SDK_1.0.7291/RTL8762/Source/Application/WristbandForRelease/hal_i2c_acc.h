/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     hal_i2c_acc.h
* @brief
* @details
* @author   hunter_shuai
* @date         19-June-2015
* @version  v1.0.0
******************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2015 Realtek Semiconductor Corporation</center></h2>
******************************************************************************
*/

#ifndef __HAL_I2C_ACC_H__
#define __HAL_I2C_ACC_H__

#ifdef __cplusplus
extern "C" {
#endif



#include "rtl_delay.h"
#include "trace.h"


typedef struct
{
    int16_t AXIS_X;
    int16_t AXIS_Y;
    int16_t AXIS_Z;
}
AxesRaw_t;


/*extern function */
extern void hal_acc_init(void);
extern void hal_acc_PowerDown(void);
extern void hal_acc_enable(void);
extern void hal_acc_GetFifoData(uint8_t *val);
extern void hal_acc_reset(void);
extern void hal_acc_ExitDlps(void);
extern void SensorIntMsgHandler(void);



#ifdef __cplusplus
}
#endif

/*lint --flb "Leave library region" */
#endif


