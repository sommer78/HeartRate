/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     mpu6050_i2c_driver.h
* @brief    this is the main file of pedometer project
* @details
* @author   hunter_shuai
* @date     27-June-2015
* @version  v1.0.0
******************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2015 Realtek Semiconductor Corporation</center></h2>
******************************************************************************
*/


#ifndef __MPU6050_I2C_DRIVER_H__
#define __MPU6050_I2C_DRIVER_H__


#include "stdint.h"
#include "rtl_types.h"
#include "hal_i2c_acc.h"

/****************************************
* internal config address
****************************************/
#define SMPLRT_DIV              0x19    //sample rate��0x07(125Hz)
#define CONFIG                  0x1A    //low pass filter frequency��0x06(5Hz)
#define GYRO_CONFIG             0x1B    //Gyro self test,common:0x18(non self test��2000deg/s)
#define ACCEL_CONFIG            0x1C    //Acc self test config,common:0x01

//Free Fall Acceleration Threshold
#define FF_THR                  0x1D
//Free Fall Duration
#define FF_DUR                  0x1E
//Motion Detection Threshold
#define MOT_THR                 0x1F
//Motion Detection Duration
#define MOT_DUR                 0x20
//Zero Motion Detection Threshold
#define ZRMOT_THR               0x20
//Zero Motion Detection Duration
#define ZRMOT_DUR               0x20

#define FIFO_EN                 0x23
/*Interrupt configuration*/
/*-----------------------------------*/
#define INT_PIN_CFG             0x37    //INT Pin / Bypass Enable Configuration 
#define INT_EN                  0x38
#define INT_STATUS              0x3A
/*-----------------------------------*/

/*ACC & Gyro & temp register*/
/*-----------------------------------*/
#define ACCEL_XOUT_H            0x3B
#define ACCEL_XOUT_L            0x3C
#define ACCEL_YOUT_H            0x3D
#define ACCEL_YOUT_L            0x3E
#define ACCEL_ZOUT_H            0x3F
#define ACCEL_ZOUT_L            0x40
#define TEMP_OUT_H              0x41
#define TEMP_OUT_L              0x42
#define GYRO_XOUT_H             0x43
#define GYRO_XOUT_L             0x44
#define GYRO_YOUT_H             0x45
#define GYRO_YOUT_L             0x46
#define GYRO_ZOUT_H             0x47
#define GYRO_ZOUT_L             0x48
/*-----------------------------------*/
#define USER_CTRL               0x6A
#define PWR_MGMT_1              0x6B
#define WHO_AM_I                0x75

#define FIFO_COUNT_H            0x72
#define FIFO_COUNT_L            0x73
#define FIFO_R_W                0x74

#define MPU6050_Addr            0x68    //AD0 connected to GND
#define MPU6050_ID              0x68
#define MPU6050_MaxFIFOLength   1024


/*sensor register bit operation*/
#define BIT_FIFO_EN         (0x40)
#define BIT_DMP_EN          (0x80)
#define BIT_FIFO_RST        (0x04)
#define BIT_DMP_RST         (0x08)
#define BIT_FIFO_OVERFLOW   (0x10)
#define BIT_DATA_RDY_EN     (0x01)
#define BIT_DMP_INT_EN      (0x02)
#define BIT_MOT_INT_EN      (0x40)
#define BITS_FSR            (0x18)
#define BITS_LPF            (0x07)
#define BITS_CLK            (0x07)
#define BIT_RESET           (0x80)
#define BIT_SLEEP           (0x40)
#define BIT_S0_DELAY_EN     (0x01)
#define BIT_S2_DELAY_EN     (0x04)
#define BITS_SLAVE_LENGTH   (0x0F)
#define BIT_SLAVE_BYTE_SW   (0x40)
#define BIT_SLAVE_GROUP     (0x10)
#define BIT_SLAVE_EN        (0x80)
#define BIT_I2C_READ        (0x80)
#define BITS_I2C_MASTER_DLY (0x1F)
#define BIT_AUX_IF_EN       (0x20)
#define BIT_ACTL            (0x80)
#define BIT_LATCH_EN        (0x20)
#define BIT_ANY_RD_CLR      (0x10)
#define BIT_BYPASS_EN       (0x02)
#define BIT_LPA_CYCLE       (0x20)
#define BIT_STBY_XA         (0x20)
#define BIT_STBY_YA         (0x10)
#define BIT_STBY_ZA         (0x08)
#define BIT_STBY_XG         (0x04)
#define BIT_STBY_YG         (0x02)
#define BIT_STBY_ZG         (0x01)
#define BIT_STBY_XYZA       (BIT_STBY_XA | BIT_STBY_YA | BIT_STBY_ZA)
#define BIT_STBY_XYZG       (BIT_STBY_XG | BIT_STBY_YG | BIT_STBY_ZG)

/*extern function*/
void MPU6050_Init(void);
void MPU6050_ReadAcc(int32_t *ACC_DATA);
void MPU6050_ReadGyro(int32_t *GYRO_DATA);
bool MPU6050_VerifyID(void);
uint8_t MPU6050_ReadIntStatus(void);
void MPU6050_ResetFIFO(void);
int MPU6050_ReadFIFOStream(uint16_t length, uint8_t *data, unsigned char *more);
void MPU6050_ReadFIFOData(uint8_t *pack_length, AxesRaw_t *accData);
bool MPU6050_ReadReg(uint8_t reg, uint8_t *pData);

#endif
