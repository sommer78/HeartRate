
/**
 @brief Global Error definitions
*/

/* Header guard */
#ifndef __RTL_ERROR_H__
#define __RTL_ERROR_H__


#include "rtl876x.h"
#include "trace.h"

/** @defgroup RTL_ERRORS_BASE Error Codes Base number definitions
 * @{ */
#define RTL_ERROR_BASE_NUM      (0x0)       ///< Global error base
/** @} */

#define RTL_SUCCESS                           (RTL_ERROR_BASE_NUM + 0)  ///< Successful command
#define RTL_ERROR_INTERNAL                    (RTL_ERROR_BASE_NUM + 1)  ///< Internal Error
#define RTL_ERROR_NO_MEM                      (RTL_ERROR_BASE_NUM + 2)  ///< No Memory for operation
#define RTL_ERROR_NOT_FOUND                   (RTL_ERROR_BASE_NUM + 3)  ///< Not found
#define RTL_ERROR_NOT_SUPPORTED               (RTL_ERROR_BASE_NUM + 4)  ///< Not supported
#define RTL_ERROR_INVALID_PARAM               (RTL_ERROR_BASE_NUM + 5)  ///< Invalid Parameter
#define RTL_ERROR_INVALID_STATE               (RTL_ERROR_BASE_NUM + 6)  ///< Invalid state, operation disallowed in this state
#define RTL_ERROR_INVALID_LENGTH              (RTL_ERROR_BASE_NUM + 7)  ///< Invalid Length
#define RTL_ERROR_INVALID_FLAGS               (RTL_ERROR_BASE_NUM + 8) ///< Invalid Flags
#define RTL_ERROR_INVALID_DATA                (RTL_ERROR_BASE_NUM + 9) ///< Invalid Data
#define RTL_ERROR_DATA_SIZE                   (RTL_ERROR_BASE_NUM + 10) ///< Data size exceeds limit
#define RTL_ERROR_TIMEOUT                     (RTL_ERROR_BASE_NUM + 11) ///< Operation timed out
#define RTL_ERROR_NULL                        (RTL_ERROR_BASE_NUM + 12) ///< Null Pointer
#define RTL_ERROR_FORBIDDEN                   (RTL_ERROR_BASE_NUM + 13) ///< Forbidden Operation
#define RTL_ERROR_INVALID_ADDR                (RTL_ERROR_BASE_NUM + 14) ///< Bad Memory Address
#define RTL_ERROR_BUSY                        (RTL_ERROR_BASE_NUM + 15) ///< Busy


/*for "assert" debug*/
#define DPRINTF(...) DBG_DIRECT(__VA_ARGS__)
#define ASSERT(x) if(!(x)) { DPRINTF("Assert(%s) fail in %s,%d\n", #x,__FILE__, __LINE__, 3); while(1) {;}}

#endif // RTL_ERROR_H__

/**
  @}
*/

