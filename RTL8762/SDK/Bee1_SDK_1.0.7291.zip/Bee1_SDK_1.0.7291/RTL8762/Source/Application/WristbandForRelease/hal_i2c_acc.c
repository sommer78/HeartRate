/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     hal_i2c_acc.c
* @brief
* @details
* @author   hunter_shuai
* @date     19-June-2015
* @version  v1.0.0
******************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2015 Realtek Semiconductor Corporation</center></h2>
******************************************************************************
*/

#include "hal_i2c_acc.h"
#include "board.h"
#include "step_counter.h"
#include "rtl876x_i2c.h"
#include "os.h"
#include "rtl876x_gpio.h"
#include "rtl876x_nvic.h"
#include "rtl876x_rcc.h"

#if FEATURE_SENSOR_LIS3DH
#include "lis3dh_i2c_driver.h"
#endif

#if FEATURE_SENSOR_MPU6050
#include "mpu6050_i2c_driver.h"
#endif

#define FIFO_STREAM_MODE


/* used for store ACC fifo 3-axis data*/
//AxesRaw_t accData[ACC_DATA_LEN];
AxesRaw_t accData[32];

/**
*@brief     accelermeter reset function, reset accelermeter related working register
*@parameter void
*@return    void
*/



/**
*@brief     pull fifo data from accelermeter
*@parameter pointer to the data byte length pulled from fifo
*@return    void
*/
void hal_acc_GetFifoData(uint8_t *val)
{
#if FEATURE_SENSOR_LIS3DH
    LIS3DH_GetFifoData(val, accData);
#endif
#if FEATURE_SENSOR_MPU6050
    MPU6050_ReadFIFOData(val, accData);
#endif

}



/**
*@brief     hal acc init function
*@parameter void
*@return    void
*/
void hal_acc_init(void)
{
#if FEATURE_SENSOR_LIS3DH
    GPIO_InitTypeDef lis3dh_int2_Param;
    GPIO_StructInit(&lis3dh_int2_Param);
    RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
    lis3dh_int2_Param.GPIO_Pin = GPIO_GetPin(SENSOR_INT_PIN) ;
    lis3dh_int2_Param.GPIO_Mode = GPIO_Mode_IN;
    lis3dh_int2_Param.GPIO_ITPolarity = GPIO_INT_POLARITY_ACTIVE_HIGH;
    lis3dh_int2_Param.GPIO_ITTrigger = GPIO_INT_Trigger_EDGE;
    lis3dh_int2_Param.GPIO_ITCmd = ENABLE;
    GPIO_Init(&lis3dh_int2_Param);
    GPIO_INTConfig(GPIO_GetPin(SENSOR_INT_PIN), ENABLE);

    NVIC_InitTypeDef NVIC_InitStruct;
    NVIC_InitStruct.NVIC_IRQChannel = SENSOR_INT_IRQ;
    NVIC_InitStruct.NVIC_IRQChannelPriority = 0;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStruct);

    I2C_InitTypeDef  I2C_InitStructure;
    I2C_DeInit(I2C0);
    RCC_PeriphClockCmd(APBPeriph_I2C0, APBPeriph_I2C0_CLOCK, ENABLE);
    /* I2C configuration */
    I2C_InitStructure.I2C_ClockSpeed = 400000;
    I2C_InitStructure.I2C_DeviveMode = I2C_DeviveMode_Master;
    I2C_InitStructure.I2C_AddressMode = I2C_AddressMode_7BIT;
    I2C_InitStructure.I2C_SlaveAddress = 0x18;
    I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;

    /* I2C module Initialize */
    I2C_Init(I2C0, &I2C_InitStructure);
    /* I2C Peripheral Enable */
    I2C_Cmd(I2C0, ENABLE);
    I2C_SetSlaveAddress(I2C0, 0x18);

    /* LIS3DH initilization */
    LIS3DH_Init();
#endif

#if FEATURE_SENSOR_MPU6050 //for MPU6050 

    I2C_InitTypeDef  I2C_InitStructure;
    I2C_DeInit(I2C0);
    RCC_PeriphClockCmd(APBPeriph_I2C0, APBPeriph_I2C0_CLOCK, ENABLE);
    /* I2C configuration */
    I2C_InitStructure.I2C_ClockSpeed = 400000;
    I2C_InitStructure.I2C_DeviveMode = I2C_DeviveMode_Master;
    I2C_InitStructure.I2C_AddressMode = I2C_AddressMode_7BIT;
    I2C_InitStructure.I2C_SlaveAddress = MPU6050_Addr;
    I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;

    /* I2C module Initialize */
    I2C_Init(I2C0, &I2C_InitStructure);
    /* I2C Peripheral Enable */
    I2C_Cmd(I2C0, ENABLE);
    I2C_SetSlaveAddress(I2C0, MPU6050_Addr);

    /* initialization */
    MPU6050_Init();

#endif
}


/**
*@brief     when exit from DLPS, call this function to re-config accelermeter
*@parameter void
*@return    void
*/
void hal_acc_ExitDlps(void)
{
#if FEATURE_SENSOR_LIS3DH
    LIS3DH_Init();

#endif

#if FEATURE_SENSOR_MPU6050

    MPU6050_Init();
#endif
}

#if FEATURE_SENSOR_LIS3DH
void Gpio17IntrHandler()
{
    BEE_IO_MSG msg;
    long xHigherPriorityTaskWoken;
    //uint8_t status;
    GPIO_INTConfig(GPIO_GetPin(SENSOR_INT_PIN), DISABLE);

    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "sensor interrupt", 0);

    /*construct BEE_IO_MSG to sent to IO queue*/
    msg.IoType = IO_WRISTBNAD_MSG_TYPE;
    msg.subType = MSG_SENSOR_INT;

    if (!SendMessageFromISR(&msg, &xHigherPriorityTaskWoken))
    {
        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "sensor int triggered message send to queue fail!\n", 0);
    }
    portEND_SWITCHING_ISR(xHigherPriorityTaskWoken);


    GPIO_ClearINTPendingBit(GPIO_GetPin(SENSOR_INT_PIN));
    GPIO_INTConfig(GPIO_GetPin(SENSOR_INT_PIN), ENABLE);
}
#endif


