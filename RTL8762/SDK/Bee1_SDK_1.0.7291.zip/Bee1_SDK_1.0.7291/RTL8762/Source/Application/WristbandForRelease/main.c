/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     main.c
* @brief    this is the main file of pedometer project
* @details
* @author   hunter_shuai
* @date     19-June-2015
* @version  v1.0.0
******************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2015 Realtek Semiconductor Corporation</center></h2>
******************************************************************************
*/

#include "rtl876x.h"
#include "FreeRTOS.h"
#include "task.h"
#include "application.h"

#include "profile_init.h"
#include "dlps_platform.h"

#include "peripheral.h"
#include "gap.h"
#include "gapbondmgr.h"

#include "profileApi.h"
#include "simpleBLEPeripheral.h"

#include "step_counter.h"
#include "board.h"
#include "hal_i2c_acc.h"
#include "rtl876x_io_dlps.h"
#include "rtl876x_pinmux.h"
#include "dis.h"
#include "bas.h"
#include "wristband_application.h"
#include "wristband_service.h"

/*
********************************************************
* parameter for btstack
*
*
*********************************************************
*/

// What is the advertising interval when device is discoverable (units of 625us, 160=100ms)
#define DEFAULT_ADVERTISING_INTERVAL_MIN            0x83  //0x20 /* 20ms */
#define DEFAULT_ADVERTISING_INTERVAL_MAX            0x83  //0x30 /* 30ms */
#define DEFAULT_DISCOVERABLE_MODE                   GAP_ADTYPE_FLAGS_GENERAL

// Minimum connection interval (units of 1.25ms, 80=100ms) if automatic parameter update request is enabled
#define DEFAULT_DESIRED_MIN_CONN_INTERVAL     100
// Maximum connection interval (units of 1.25ms, 800=1000ms) if automatic parameter update request is enabled
#define DEFAULT_DESIRED_MAX_CONN_INTERVAL     800
// Slave latency to use if automatic parameter update request is enabled
#define DEFAULT_DESIRED_SLAVE_LATENCY         0
// Supervision timeout value (units of 10ms, 1000=10s) if automatic parameter update request is enabled
#define DEFAULT_DESIRED_CONN_TIMEOUT          1000


// GAP - SCAN RSP data (max size = 31 bytes)
static uint8_t scanRspData[] =
{
    0x03,           /* length     */
    0x03,           /* type="More 16-bit UUIDs available" */
    0x12,
    0x18,
    /* place holder for Local Name, filled by BT stack. if not present */
    /* BT stack appends Local Name.                                    */
    0x03,           /* length     */
    0x19,           /* type="Appearance" */
    0x42, 0x0c,     /* wrist worn */
};

// GAP - Advertisement data (max size = 31 bytes, though this is
// best kept short to conserve power while advertisting)
static uint8_t advertData[] =
{
    /* Core spec. Vol. 3, Part C, Chapter 18 */
    /* Flags */
    0x02,           /* length     */
    0x01, 0x05,     /* type="flags", data="bit 1: LE General Discoverable Mode" */
    /* Service */
    0x03,           /* length     */
    0x02,           /* type="More 16-bit UUIDs available" */
    0x01,
    0xff,
    /* place holder for Local Name, filled by BT stack. if not present */
    /* BT stack appends Local Name.                                    */
    0x03,           /* length     */
    0x19,           /* type="Appearance" */
    0x42, 0x0c,     /* Wrist worn */
    0x0e,           /* length     */
    0x09,           /* type="Complete local name" */
    'B', 'e', 'e', '_', 'w', 'r', 'i', 's', 't', 'b', 'a', 'n', 'd' /* Bee_wristband */
};



void BtStack_Init_Gap()
{
    //device name and device appearance
    uint8_t DeviceName[GAP_DEVICE_NAME_LEN] = "Bee_wristband";
    uint16_t Appearance = GAP_GATT_APPEARANCE_UNKNOWN;

    //default start adv when bt stack initialized
    uint8_t  advEnableDefault = TRUE;

    //advertising parameters
    uint8_t  advEventType = GAP_ADTYPE_ADV_IND;
    uint8_t  advDirectType = PEER_ADDRTYPE_PUBLIC;
    uint8_t  advDirectAddr[B_ADDR_LEN] = {0};
    uint8_t  advChanMap = GAP_ADVCHAN_ALL;
    uint8_t  advFilterPolicy = GAP_FILTER_POLICY_ALL;
    uint16_t advIntMin = DEFAULT_ADVERTISING_INTERVAL_MIN;
    uint16_t advIntMax = DEFAULT_ADVERTISING_INTERVAL_MIN;

    //connection update parameters
    uint16_t desired_min_interval = DEFAULT_DESIRED_MIN_CONN_INTERVAL;
    uint16_t desired_max_interval = DEFAULT_DESIRED_MAX_CONN_INTERVAL;
    uint16_t desired_slave_latency = DEFAULT_DESIRED_SLAVE_LATENCY;
    uint16_t desired_conn_timeout = DEFAULT_DESIRED_CONN_TIMEOUT;

    //GAP Bond Manager parameters
    uint8_t pairMode = GAPBOND_PAIRING_MODE_PAIRABLE;
    uint8_t mitm = GAPBOND_AUTH_NO_MITM_YES_BOND;//GAPBOND_AUTH_YES_MITM_YES_BOND; hunter
    uint8_t ioCap = GAPBOND_IO_CAP_NO_INPUT_NO_OUTPUT;
    uint8_t oobEnable = FALSE;
    uint32_t passkey = 0; // passkey "000000"

    uint8_t bUseFixedPasskey = TRUE;

    //Set device name and device appearance
    peripheralSetGapParameter(GAPPRRA_DEVICE_NAME, GAP_DEVICE_NAME_LEN, DeviceName);
    peripheralSetGapParameter(GAPPRRA_APPEARANCE, sizeof(Appearance), &Appearance);

    peripheralSetGapParameter( GAPPRRA_ADV_ENABLE_DEFAULT, sizeof ( advEnableDefault ), &advEnableDefault );

    //Set advertising parameters
    peripheralSetGapParameter( GAPPRRA_ADV_EVENT_TYPE, sizeof ( advEventType ), &advEventType );
    peripheralSetGapParameter( GAPPRRA_ADV_DIRECT_ADDR_TYPE, sizeof ( advDirectType ), &advDirectType );
    peripheralSetGapParameter( GAPPRRA_ADV_DIRECT_ADDR, sizeof ( advDirectAddr ), advDirectAddr );
    peripheralSetGapParameter( GAPPRRA_ADV_CHANNEL_MAP, sizeof ( advChanMap ), &advChanMap );
    peripheralSetGapParameter( GAPPRRA_ADV_FILTER_POLICY, sizeof ( advFilterPolicy ), &advFilterPolicy );

    peripheralSetGapParameter(GAPPRRA_ADV_INTERVAL_MIN, sizeof(advIntMin), &advIntMin);
    peripheralSetGapParameter(GAPPRRA_ADV_INTERVAL_MAX, sizeof(advIntMax), &advIntMax);


    peripheralSetGapParameter( GAPPRRA_ADVERT_DATA, sizeof( advertData ), advertData );
    peripheralSetGapParameter( GAPPRRA_SCAN_RSP_DATA, sizeof ( scanRspData ), scanRspData );

    //set connection update parameters
    peripheralSetGapParameter( GAPPRRA_MIN_CONN_INTERVAL, sizeof( uint16_t ), &desired_min_interval );
    peripheralSetGapParameter( GAPPRRA_MAX_CONN_INTERVAL, sizeof( uint16_t ), &desired_max_interval );
    peripheralSetGapParameter( GAPPRRA_SLAVE_LATENCY, sizeof( uint16_t ), &desired_slave_latency );
    peripheralSetGapParameter( GAPPRRA_TIMEOUT_MULTIPLIER, sizeof( uint16_t ), &desired_conn_timeout );

    // Setup the GAP Bond Manager
    GAPBondMgr_SetParameter( GAPBOND_PAIRING_MODE, sizeof ( uint8_t ), &pairMode );
    GAPBondMgr_SetParameter( GAPBOND_MITM_PROTECTION, sizeof ( uint8_t ), &mitm );
    GAPBondMgr_SetParameter( GAPBOND_IO_CAPABILITIES, sizeof ( uint8_t ), &ioCap );
    GAPBondMgr_SetParameter( GAPBOND_OOB_ENABLED, sizeof ( uint8_t ), &oobEnable );

    GAPBondMgr_SetParameter( GAPBOND_PASSKEY, sizeof ( uint32_t ), &passkey );
    GAPBondMgr_SetParameter( GAPBOND_FIXED_PASSKEY_ENABLE, sizeof ( uint8_t ), &bUseFixedPasskey);
}

/* wrisbtand application related services' ID. */
uint8_t gBASServiceId;
uint8_t gDISServiceId;
uint8_t gWristbandServiceId;
uint8_t gBASBatteryLevel = 0;



void BtProfile_Init(void)
{
    uint8_t battery_level = 100;
    gBASServiceId = BAS_AddService(AppHandleGATTCallback);
    gDISServiceId = DIS_AddService(AppHandleGATTCallback);
    gWristbandServiceId = WristbandExtended_AddService(AppHandleGATTCallback);
    BAS_SetParameter(BAS_PARAM_BATTERY_LEVEL, sizeof(battery_level), &battery_level);
    ProfileAPI_RegisterCB((pfnAPPHandleInfoCB_t)AppHandleGATTCallback);
}


/**
* @brief  Board_Init() contains the initialization of pinmux settings and pad settings.
*
* All the pinmux settings and pad settings shall be initiated in this function.
* But if legacy driver is used, the initialization of pinmux setting and pad setting
* should be peformed with the IO initializing.
*
* @param  No parameter.
* @return  void
*/
void Board_Init()
{
    /* sensor Pinmux & Pad setting*/
    {
        Pinmux_Config(SENSOR_I2C_SCL, I2C0_CLK);
        Pinmux_Config(SENSOR_I2C_SDA, I2C0_DAT);

        Pad_Config(SENSOR_I2C_SCL, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
        Pad_Config(SENSOR_I2C_SDA, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);

#if FEATURE_SENSOR_LIS3DH
        /*int pin setting*/
        Pinmux_Config(SENSOR_INT_PIN, GPIO_FUN);
        Pad_Config(SENSOR_INT_PIN, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
        System_WakeUp_Pin_Enable(SENSOR_INT_PIN, 0);
#endif
    }
}



/**
* @brief  Driver_Init() contains the initialization of peripherals.
*
* Both new architecture driver and legacy driver initialization method can be used.
*
* @param   No parameter.
* @return  void
*/
void Driver_Init()
{
    /* initialize and enable accelermeter */
    hal_acc_init();

    /* start health algorithm */
    StartHealthAlgorithm();
#if FEATURE_SENSOR_MPU6050
    /* create & start sensor timer */
    CreateSensorTimer();
    StartSensorTimer();
#endif
}


/**
* @brief   Wristband Exit DLPS callback function
* @param   No parameter.
* @return  void
*/
void Wristband_ExitDLPS(void)
{
    /* reconfig sensor i2c pad */
    Pad_Config(SENSOR_I2C_SCL, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
    Pad_Config(SENSOR_I2C_SDA, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
    /* reconfig sensor int pad*/
    Pinmux_Config(SENSOR_INT_PIN, GPIO_FUN);
    Pad_Config(SENSOR_INT_PIN, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
    /* reconfig accelermeter register */
    hal_acc_ExitDlps();
}

void Wristband_EnterDLPS(void)
{
    Pad_Config(SENSOR_INT_PIN, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_ENABLE, PAD_OUT_HIGH);
}



/**
* @brief  PwrMgr_Init() contains the setting about power mode.
*
* @param   No parameter.
* @return  void
*/
void PwrMgr_Init()
{
#if CONFIG_DLPS_EN
    DLPS_IO_Register();
    DLPS_IO_RegUserDlpsEnterCb(Wristband_EnterDLPS);
    DLPS_IO_RegUserDlpsExitCb(Wristband_ExitDLPS);
    LPS_MODE_Set(LPM_DLPS_MODE);
#endif
}


/**
* @brief  Task_Init() contains the initialization of all the tasks.
*
* There are four tasks are initiated.
* Lowerstack task and upperstack task are used by bluetooth stack.
* Application task is task which user application code resides in.
* Emergency task is reserved.
*
* @param   No parameter.
* @return  void
*/
void Task_Init()
{
    void lowerstack_task_init();
    void upperstack_task_init();
    void emergency_task_init();
    application_task_init();
}


/**
* @brief  main() is the entry of user code.
*
*
* @param   No parameter.
* @return  void
*/
int main(void)
{
    BtStack_Init_Peripheral();
    BtStack_Init_Gap();
    BtProfile_Init();
    PwrMgr_Init();
    Task_Init();
    vTaskStartScheduler();

    return 0;
}



