/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     health_algorithm.h
* @brief
* @details
* @author   Duncan
* @date     19-June-2015
* @version  v1.0.0
******************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2015 Realtek Semiconductor Corporation</center></h2>
******************************************************************************
*/


#ifndef _HEALTH_ALGORITHM_H_
#define _HEALTH_ALGORITHM_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"
//#include "rtl_types.h"


#define ALGORITHM_V2        // for tap misjudge
#define ALGORITHM_V3        // for fine tune the distance

// =======================================================================
// alpha definition
// =======================================================================
#define AFA0                (0x0400)    // Q15, 1/32
#define ONE_MINUS_AFA0      (0x7C00)    // Q15, (1-1/32)=0.96875
#define AFA1                (0x0400)    // Q15, 1/32
#define ONE_MINUS_AFA1      (0x7C00)    // Q15
#define AFA2                (0x4000)    // Q16(unsigned), 1/4
#define ONE_MINUS_AFA2      (0xC000)    // Q16, 0.75

#define AFA3                (0x1000)    // Q14, 1/4
#define ONE_MINUS_AFA3      (0x6000)    // Q15
#define AFA4                (0x2000)    // Q15, 1/4
#define ONE_MINUS_AFA4      (0x6000)    // Q15

// =======================================================================
#define LHPF_BUFF_LEN       (4)         // For decision threshold. If necessary, please do not change 
#define HIT_HISTORY_LEN     (5)         // Hit state history buffer size. If necessary, please do not change 
#define DEC_CNT_DISTANCE    (6)         // If necessary, please do not change 
#ifdef ALGORITHM_V2
#define LEN_FSM_1           (8)         // The number of successive hit state
#else
#define LEN_FSM_1           (6)         // The number of successive hit state 
#endif  /* ALGORITHM_V2 */

#define MET_LEN             (8)         // Met table size. If necessary, please do not change 
#define TOLERANCE           (10)        // A time tolerance of the state 1
#define INVERT_LEN_FSM_1    (0X2AAA)    // Q16(1/6), fsm1_hit_thd_mean/LEN_FSM_1. If necessary, please do not change
#define FSM1_THD            (0x0333)    // Q3.12(0.2). 
#ifdef ALGORITHM_V2
#define FSM2_BUFF_THD       (0x019A)    // Q3.12(0.1), Compared with fsm1_hit_thd_mean 
#else
#define FSM2_BUFF_THD       (0x00F6)    // Q3.12(0.06), Compared with fsm1_hit_thd_mean 
#endif  /* ALGORITHM_V2 */

#define ACTIVITY_RUN_THD    (0x2400)    // Q3.12(2.25), compared with afa_dff
#define INVERT_1P2          (0x00D5)    // 1/1.2, Q8.8. If necessary, please do not change
#define ORD_1P4             (0x0166)    // 1.4, Q8.8. If necessary, please do not change

#ifdef ALGORITHM_V2
//#define STD_THRESHOLD       (0x011F)    // Q3.12(0.07)
//#define STD_THRESHOLD       (0x012B)    // Q3.12(0.073)
//#define STD_THRESHOLD       (0x0123)    // Q3.12(0.071)
//#define STD_THRESHOLD       (0x010A)    // Q3.12(0.065)
//#define STD_THRESHOLD       (0x148)     // 0.08
//#define STD_THRESHOLD       (0x00F6)    // 0.06
//#define STD_THRESHOLD       (0x00CD)    // Q3.12(0.05)
#define STD_THRESHOLD       (0x00C5)    // Q3.12(0.048)
//==================================
//#define DEC_AVG_RET_TIME    (0x01B3)  // Q8 (1.7)
//#define DEC_AVG_RET_TIME    (0x01CD)  // Q8 (1.8)
#define DEC_AVG_RET_TIME    (0x0200)  // Q8 (2.0). The time threshold of the return back to state 1

#else
#define STD_THRESHOLD       (0x00CD)    // Q3.12(0.05)
#define DEC_AVG_RET_TIME    (0x02B3)  // Q8 (2.7)
#endif  /* ALGORITHM_V2 */

#define DEC_THD_RATIO       (0x599A)    // Q15 (0.7)
#define FIXRATIO_1P2        (0x0133)    // Q8.8 (1.2)
#define FIXRATIO_1          (0x0100)    // Q8.8 (1)

#define STEP_1P5            (0x0018)    // Q4(1.5). If necessary, please do not change
#define STEP_2P5            (0x0028)    // Q4(2.5). If necessary, please do not change
#define INVERT_RATE         (0x049C)    // Q15. If necessary, please do not change
#define INVERT_RATE_2       (0X238E)    // Q15 (1000/3600). If necessary, please do not change

/* The stride calculation based on the following curve */
#ifdef ALGORITHM_V3
#define STRIDE_SLOPE_1      (0xFFE4)    // Q10.5 (-0.9)
#define STRIDE_SLOPE_2      (0xFFD0)    // Q10.5 (-1.5)
#define STRIDE_SLOPE_3      (0xFFEA)    // Q10.5 (-0.7)
#define STRIDE_OFFSET_1     (0x041A)    // Q8.8(4.1)
#define STRIDE_OFFSET_2     (0x04CD)    // Q8.8(4.8)
#define STRIDE_OFFSET_3     (0x039A)    // Q8.8(3.6)
#else
#define STRIDE_SLOPE_1      (0xFFE0)    // Q10.5 (-1)
#define STRIDE_SLOPE_2      (0xFFCD)    // Q10.5 (-1.6)
#define STRIDE_SLOPE_3      (0xFFE6)    // Q10.5 (-0.8)
#define STRIDE_OFFSET_1     (0x0480)    // Q8.8(4.5)
#define STRIDE_OFFSET_2     (0x0533)    // Q8.8(5.2)
#define STRIDE_OFFSET_3     (0x0400)    // Q8.8(4)

#endif /* ALGORITHM_V3 */

#define SLOPE_ZONE_2        (20)        // Q3 (2.5). If necessary, please do not change
#define SLOPE_ZONE_1        (12)        // Q3 (1.5). If necessary, please do not change


#define DEFAULT_HIGHT_CM  (170)
#define DEFAULT_WEIGHT_KG  (65)
#define DEFAULT_AGE   (25)
#define DEFAULT_GENDER   1
#define GENDER_MALE   1
#define GENDER_FEMALE  0

typedef struct
{
uint32_t reserved   :
    5;  /*reserved bit */
uint32_t weight_kg     :
    10; /* accuracy: 0.5 kg,  Q9.1, 0~512.5 kg*/
uint32_t height_cm      :
    9;  /* hight accuracy : 0.5 m, Q8.1, 0~256.5 cm*/
uint32_t age_year        :
    7;  /*age 0~127*/
uint32_t is_male     :
    1;  /*0: female, 1: male*/
}
userprofile_bit_field_type_t;

typedef union {
    uint32_t data;
    userprofile_bit_field_type_t bit_field;
} userprofile_union_t;




typedef enum RtkInType {
    DATA_IN,    /* input type data*/
    COMPOSITE   /* composite of 3-axis data type*/
} RtkInType_t;




typedef struct {            /*RTK Pedometer Input Parameters.*/
    RtkInType_t InputType;  /* Default: DATA_IN*/
    int16_t wXAccel;            /* - X axis acceleration, Q4.11*/
    int16_t wYAccel;            /* - Y axis acceleration, Q4.11*/
    int16_t wZAccel;            /* - Z axis acceleration, Q4.11*/
    int16_t wCompositeIn;   /* - sqrt(x^2+y^2+z^2), Q4.11*/
    uint32_t TimeStamp;     /* - reserved*/
} RtkAccelData_t;


typedef enum RtkPedState {/*RTK Pedometer Step State.*/
    STEP_MODE_STATIONARY,   /*- User is stationary.*/
    STEP_MODE_WALKING,      /*- User is walking.    */
    STEP_MODE_RUNNING       /*- User is running.    */
} RtkPedState_t;




typedef struct RtkPedoInfo {    /*RTK Pedometer Information.*/
    uint16_t wNewSteps;         /*- The new steps since last time it was triggered*/
    uint16_t wNewDistance;      /*- wNewDistance,  Q12.4,  Unit: cm*/
    RtkPedState_t Activity;     /*- Please see the mRtkPedState_t*/
    uint16_t wNewSpeed;         /*- Fixed-point format is Q8.8, its unit is (km/hour)*/
    uint16_t wNewCalories;      /*- The unit is cal*/
    /*below is used for debug*/
    uint32_t dwStepsDebug;
    uint32_t dwDistanceDebug;
    uint32_t dwCaloriesDebug;
    uint32_t dwCallBackCnt;
} RtkPedoInfo_t;

typedef void (* health_algorithm_cb)(RtkPedoInfo_t *NewInfo);


/** RTK API results.
    *
    * This enumeration is used to symbolize the possible results of
    * invoking RTK library functions.
    */
typedef enum RTStatus {
    RT_SUCCESS,
    RT_FAILURE,
    RT_CALLBACK_FAILURE,
    RT_NULL_DATA_PTR,
    RT_CAL_COMPLETE,
    RT_MEM_ALLOCATE_FAILURE,
    RT_ALREADY_OPEN,
    RT_ALREADY_CLOSED,
    RT_UNKNOWN_DATA_TYPE,
    RT_INVALID_CFG,
    RT_NOT_SUPPPORT
} RTStatus_t;



/**
    * @brief    before call any other function ,you need to call RtkInitPedoAlgo() first.
    *             Initialization of variables of the pedometer algorithm  and register callback function
    *
    * @param UserProfile      pointer to user profile
    * @param HealthAlgoFunc  registered health algorithm callback function
    *
    * @return RTStatus_t
    *   the return value can be any one of the following value:
    *       @RT_SUCCESS,
    *       @RT_FAILURE,
    *       @RT_CALLBACK_FAILURE,
    *       @RT_NULL_DATA_PTR,
    *       @RT_CAL_COMPLETE,
    *       @RT_MEM_ALLOCATE_FAILURE,
    *       @RT_ALREADY_OPEN,
    *       @RT_ALREADY_CLOSED,
    *       @RT_UNKNOWN_DATA_TYPE,
    *       @RT_INVALID_CFG,
    *       @RT_NOT_SUPPPORT
    */
RTStatus_t RtkInitPedoAlgo(userprofile_union_t *UserProfile, health_algorithm_cb HealthAlgoFunc);




/**
    * @brief    Reset variables of the pedometer algorithm
    *
    * @param dwSampleRate sensor data sample rate in HZ (algorithm support 25Hz only now)
    * @param Profile    user profile pointer
    *
    * @return RTStatus_t
    *   the return value can be any one of the following value:
    *       @RT_SUCCESS,
    *       @RT_FAILURE,
    *       @RT_CALLBACK_FAILURE,
    *       @RT_NULL_DATA_PTR,
    *       @RT_CAL_COMPLETE,
    *       @RT_MEM_ALLOCATE_FAILURE,
    *       @RT_ALREADY_OPEN,
    *       @RT_ALREADY_CLOSED,
    *       @RT_UNKNOWN_DATA_TYPE,
    *       @RT_INVALID_CFG,
    *       @RT_NOT_SUPPPORT
    */
RTStatus_t RtkResetPedoAlgo(uint32_t dwSampleRate, userprofile_union_t *Profile);



/**
    * @brief    Finalize algorithm by call this function.
    *
    * @param void
    *
    * @return RTStatus_t
    *   the return value can be any one of the following value:
    *       @RT_SUCCESS,
    *       @RT_FAILURE,
    *   @RT_CALLBACK_FAILURE,
    *       @RT_NULL_DATA_PTR,
    *       @RT_CAL_COMPLETE,
    *       @RT_MEM_ALLOCATE_FAILURE,
    *       @RT_ALREADY_OPEN,
    *       @RT_ALREADY_CLOSED,
    *       @RT_UNKNOWN_DATA_TYPE,
    *       @RT_INVALID_CFG,
    *       @RT_NOT_SUPPPORT
    */
RTStatus_t RtkEndPedoAlgo(void);


/**
    * @brief    Pass the accelermeter sensor data into algorithm.
    *
    * @param AccData    accelermeter format data
    *
    * @return RTStatus_t
    *   the return value can be any one of the following value:
    *       @RT_SUCCESS,
    *       @RT_FAILURE,
    *   @RT_CALLBACK_FAILURE,
    *       @RT_NULL_DATA_PTR,
    *       @RT_CAL_COMPLETE,
    *       @RT_MEM_ALLOCATE_FAILURE,
    *       @RT_ALREADY_OPEN,
    *       @RT_ALREADY_CLOSED,
    *       @RT_UNKNOWN_DATA_TYPE,
    *       @RT_INVALID_CFG,
    *       @RT_NOT_SUPPPORT
    */
RTStatus_t RtkPedoProcess(RtkAccelData_t *AccData);




#ifdef __cplusplus
}
#endif


#endif


