/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      keyboard_application.c
* @brief     keyboard application implementation
* @details   keyboard application implementation
* @author    Elliot Chen
* @date      2015-07-16
* @version   v1.0
* *********************************************************************************************************
*/

/* Includes ------------------------------------------------------------------*/
#include "rtl876x.h"
#include "board.h"
#include "application.h"
#include "keyboard_application.h"
#include "bee_message.h"
#include "trace.h"
#include "profile_init.h"
#include "bee_message.h"
#include "peripheral.h"
#include "gap.h"
#include "gapbondmgr.h"
#include <string.h>
#include "sps.h"
#include "dis.h"
#include "bas.h"
#include "hids_keyboard.h"
#include "profileApi.h"
#include "dlps_platform.h"
#include "rtl876x_tim.h"
#include "keyscan.h"

/* Reference varibales statement ----------------------------------------------*/
extern uint8_t gHIDServiceId;
extern uint8_t gBASServiceId;
extern uint8_t gDISServiceId;
extern uint8_t gSPSServiceId;
extern BOOL allowedKeyboardEnterDlps;

/* Keypad key mapping ---------------------------------------------------------*/
/* VK_DELETE key is equal to Backspace key, VK_UNDEFINED_16 key is equal to CapsLock key */
const UINT8 Keyboard_Keymap[KEYBOARD_KEYPAD_ROW_SIZE][KEYBOARD_KEYPAD_COLUMN_SIZE] =
{   {VK_NUMLOCK, VK_RETURN,      VK_9,           VK_8},
    {VK_7,       VK_6,           VK_5,           VK_4},
    {VK_3,       VK_2,           VK_1,           VK_0},
    {VK_DELETE,  VK_A,           VK_B,           VK_UNDEFINED_16},
};

/* Global variables defines -----------------------------------------------------------*/
uint8_t gProtocolMode;
uint8_t gSuspendMode;
uint8_t gBASBatteryLevel = 0;
gaprole_States_t gapProfileState = GAPSTATE_INIT;

/* store passkey for keyboard */
PassKey_TypeDef passKeyStructure = {0, 0, FALSE};
/* store status of keyboard */
BOOL IsAbleToSendAction = FALSE;
BOOL IsKeyboardEnabled = FALSE;

uint8_t protocolmode = REPORT_PROCOCOL_MODE;
uint8_t suspendMode = ENTER_SUSPEND_MODE;
uint8_t KeyboardData = HID_OUTPUT_TYPE;

/* Function declaration -------------------------------------------------*/
void Keyboard_HandleButtonEvent(BEE_IO_MSG io_driver_msg_recv);
void Keyboard_HandleKeyEvent(BEE_IO_MSG io_driver_msg_recv);
void peripheral_HandleBtGapMessage(BEE_IO_MSG  *pBeeIoMsg);
void ChangeInterval(uint16_t interval_min, uint16_t interval_max);
static uint32_t Keyboard_GetPassKey(BEE_IO_MSG io_driver_msg_recv);

/**
* @brief  All the application events are pre-handled in this function.
*
* All the IO MSGs are sent to this function.
* Then the event handling function shall be called according to the MSG type.
*
* @param   io_driver_msg_recv  The BEE_IO_MSG from peripherals or BT stack state machine.
* @return  void
*/
void AppHandleIODriverMessage(BEE_IO_MSG io_driver_msg_recv)
{
    UINT16 msgtype = io_driver_msg_recv.IoType;

    switch (msgtype)
    {
#if ENABLE_SWITCH_BUTTON
        case IO_KEYBOARD_BUTTON_MSG_TYPE:
            {
                if (IsAbleToSendAction && IsKeyboardEnabled)
                {
                    Keyboard_HandleButtonEvent(io_driver_msg_recv);
                }
                break;
            }
#endif
        case IO_KEYSCAN_MSG_TYPE:
            {
                if (io_driver_msg_recv.subType == MSG_KEYSCAN_RX_PKT)
                {
                    if (IsAbleToSendAction && IsKeyboardEnabled)
                    {
                        Keyboard_HandleKeyEvent(io_driver_msg_recv);
                    }
                    else
                    {
                        if (passKeyStructure.isAbleInput == TRUE)
                        {
                            Keyboard_GetPassKey(io_driver_msg_recv);
                        }
                        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "passKeyStructure.isAbleInput = 0x%x\n", 1,
                                   passKeyStructure.isAbleInput);
                    }
                }
                else if (io_driver_msg_recv.subType == MSG_KEYSCAN_ALLKEYRELEASE)
                {
                    if (IsAbleToSendAction && IsKeyboardEnabled)
                    {
                        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "Key Release\n", 0);
                        //send release message to BT
                        uint8_t KeyboardSendData[8] = {0x0, 0x00, 0x00, 0x0, 0x0, 0x0, 0x0, 0x0};
                        ProfileAPI_SendData(gHIDServiceId,
                                            GATT_SRV_HID_KB_INPUT_INDEX,
                                            (uint8_t *)KeyboardSendData,
                                            sizeof(KeyboardSendData));
                    }
                    else
                    {
                        //key release for inputting passkey
                        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "Key Release which input passkey\n", 0);
                    }
                }
                break;
            }
        case BT_STATUS_UPDATE:
            {
                peripheral_HandleBtGapMessage(&io_driver_msg_recv);
                break;
            }
        case APP_TIMER_MSG:
            {
                if (io_driver_msg_recv.subType == TIMER_DLPS)
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "DLPS Timer timeout\n", 0);
                    allowedKeyboardEnterDlps = true;
                }
                break;
            }
        default:
            {
                break;
            }
    }
}

/**
* @brief
*
*
* @param   io_driver_msg_recv
* @return  void
*/
void Keyboard_HandleButtonEvent(BEE_IO_MSG io_driver_msg_recv)
{
    if (io_driver_msg_recv.subType == KEYBOARD_SWITCH_BTN_PRESS)
    {
        DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "Switch Button Press\n", 0);
        peripheral_Disconnect();
        GAPBondMgr_EraseAllBondings();
        KeyboardEnablePairing();
    }
    if (io_driver_msg_recv.subType == KEYBOARD_SWITCH_BTN_RELEASE)
    {
        //KeyboardEnablePairing();
        DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "Switch Button Release\n", 0);
    }
}

/**
* @brief  Handle to key event
*
*
* @param   io_driver_msg_recv  The BEE_IO_MSG from peripherals or BT stack state machine.
* @return  void
*/
void Keyboard_HandleKeyEvent(BEE_IO_MSG io_driver_msg_recv)
{
    UINT32 i;
    UINT8 keyCode;
    KEYSCAN_DATA_STRUCT *pKey_Data = io_driver_msg_recv.pBuf;
    uint8_t KeyboardSendData[8] = {0x00, 0x00, 0x00, 0x0, 0x0, 0x0, 0x0, 0x0};

    for (i = 0; i < pKey_Data->Length; i++)
    {
        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "%d/%d: (row, column) = (%d, %d) n", 4, i + 1, pKey_Data->Length, pKey_Data->key[i].row, pKey_Data->key[i].column);
        keyCode = Keyboard_Keymap[pKey_Data->key[i].row][pKey_Data->key[i].column];

        switch (keyCode)
        {
            case VK_0:
                {
                    KeyboardSendData[2] = 0x27;//0x62
                    ProfileAPI_SendData(gHIDServiceId,
                                        GATT_SRV_HID_KB_INPUT_INDEX,
                                        (uint8_t *)KeyboardSendData,
                                        sizeof(KeyboardSendData));
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "VK_0\n\n", 0);
                    break;
                }
            case VK_1:
                {
                    KeyboardSendData[2] = 0x1E;//0x59
                    ProfileAPI_SendData(gHIDServiceId,
                                        GATT_SRV_HID_KB_INPUT_INDEX,
                                        (uint8_t *)KeyboardSendData,
                                        sizeof(KeyboardSendData));
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "VK_1\n\n", 0);
                    break;
                }
            case VK_2:
                {
                    KeyboardSendData[2] = 0x1F;//0x5A
                    ProfileAPI_SendData(gHIDServiceId,
                                        GATT_SRV_HID_KB_INPUT_INDEX,
                                        (uint8_t *)KeyboardSendData,
                                        sizeof(KeyboardSendData));
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "VK_2\n\n", 0);
                    break;
                }
            case VK_3:
                {
                    KeyboardSendData[2] = 0x20;//0x5B
                    ProfileAPI_SendData(gHIDServiceId,
                                        GATT_SRV_HID_KB_INPUT_INDEX,
                                        (uint8_t *)KeyboardSendData,
                                        sizeof(KeyboardSendData));
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "VK_3\n\n", 0);
                    break;
                }

            case VK_4:
                {
                    KeyboardSendData[2] = 0x21;//0x5C
                    ProfileAPI_SendData(gHIDServiceId,
                                        GATT_SRV_HID_KB_INPUT_INDEX,
                                        (uint8_t *)KeyboardSendData,
                                        sizeof(KeyboardSendData));
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "VK_4\n\n", 0);
                    break;
                }
            case VK_5:
                {
                    KeyboardSendData[2] = 0x22;//0x5D
                    ProfileAPI_SendData(gHIDServiceId,
                                        GATT_SRV_HID_KB_INPUT_INDEX,
                                        (uint8_t *)KeyboardSendData,
                                        sizeof(KeyboardSendData));
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "VK_5\n\n", 0);
                    break;
                }
            case VK_6:
                {
                    KeyboardSendData[2] = 0x23;//0x5E
                    ProfileAPI_SendData(gHIDServiceId,
                                        GATT_SRV_HID_KB_INPUT_INDEX,
                                        (uint8_t *)KeyboardSendData,
                                        sizeof(KeyboardSendData));
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "VK_6\n\n", 0);
                    break;
                }
            case VK_7:
                {
                    KeyboardSendData[2] = 0x24;//0x5F
                    ProfileAPI_SendData(gHIDServiceId,
                                        GATT_SRV_HID_KB_INPUT_INDEX,
                                        (uint8_t *)KeyboardSendData,
                                        sizeof(KeyboardSendData));
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "VK_7\n\n", 0);
                    break;
                }
            case VK_8:
                {
                    KeyboardSendData[2] = 0x25;//0x60
                    ProfileAPI_SendData(gHIDServiceId,
                                        GATT_SRV_HID_KB_INPUT_INDEX,
                                        (uint8_t *)KeyboardSendData,
                                        sizeof(KeyboardSendData));
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "VK_8\n\n", 0);
                    break;
                }
            case VK_9:
                {
                    KeyboardSendData[2] = 0x26;//0x61
                    ProfileAPI_SendData(gHIDServiceId,
                                        GATT_SRV_HID_KB_INPUT_INDEX,
                                        (uint8_t *)KeyboardSendData,
                                        sizeof(KeyboardSendData));
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "VK_9\n\n", 0);
                    break;
                }
            case VK_A:
                {
                    KeyboardSendData[2] = 0x04;
                    ProfileAPI_SendData(gHIDServiceId,
                                        GATT_SRV_HID_KB_INPUT_INDEX,
                                        (uint8_t *)KeyboardSendData,
                                        sizeof(KeyboardSendData));
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "VK_A\n\n", 0);
                    break;
                }
            case VK_B:
                {
                    KeyboardSendData[2] = 0x05;
                    ProfileAPI_SendData(gHIDServiceId,
                                        GATT_SRV_HID_KB_INPUT_INDEX,
                                        (uint8_t *)KeyboardSendData,
                                        sizeof(KeyboardSendData));
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "VK_B\n\n", 0);
                    break;
                }
            case VK_UNDEFINED_16:
                {
                    //send value of CapsLock
                    KeyboardSendData[2] = 0x39;
                    ProfileAPI_SendData(gHIDServiceId,
                                        GATT_SRV_HID_KB_INPUT_INDEX,
                                        (uint8_t *)KeyboardSendData,
                                        sizeof(KeyboardSendData));
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "VK_CapsLock\n\n", 0);
                    break;
                }
            case VK_NUMLOCK:
                {
                    KeyboardSendData[2] = 0x53;
                    ProfileAPI_SendData(gHIDServiceId,
                                        GATT_SRV_HID_KB_INPUT_INDEX,
                                        (uint8_t *)KeyboardSendData,
                                        sizeof(KeyboardSendData));
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "VK_NUMLOCK\n\n", 0);
                    break;
                }
            case VK_RETURN:
                {
                    KeyboardSendData[2] = 0x28;
                    ProfileAPI_SendData(gHIDServiceId,
                                        GATT_SRV_HID_KB_INPUT_INDEX,
                                        (uint8_t *)KeyboardSendData,
                                        sizeof(KeyboardSendData));
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "VK_RETURN\n\n", 0);
                    break;
                }
            case VK_DELETE:
                {
                    //send value of Backspace key
                    KeyboardSendData[2] = 0x2A;
                    ProfileAPI_SendData(gHIDServiceId,
                                        GATT_SRV_HID_KB_INPUT_INDEX,
                                        (uint8_t *)KeyboardSendData,
                                        sizeof(KeyboardSendData));
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "VK_DELETE\n\n", 0);
                    break;
                }

            default:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "Unknown key keyCode: 0x%x\n\n", 1, keyCode);
                    break;
                }
        }
    }
}

/******************************************************************
 * @fn          peripheral_HandleBtGapStateChangeEvt
 * @brief      All the gaprole_States_t events are pre-handled in this function.
 *                Then the event handling function shall be called according to the newState.
 *
 * @param    newState  - new gap state
 * @return     void
 */
void peripheral_HandleBtGapStateChangeEvt(uint8_t newState)
{
    switch (newState)
    {
        case GAPSTATE_IDLE_NO_ADV_NO_CONN:
            {
                IsAbleToSendAction = FALSE;
                IsKeyboardEnabled = FALSE;
                if (gapProfileState == GAPSTATE_CONNECTED)
                {
                    uint8_t disc_reason;
                    peripheralGetGapParameter(GAPPRRA_DISCONNECTED_REASON, &disc_reason);
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "peripheral_HandleBtGapMessage: disc_reason = %d", 1, disc_reason);
                    KeyboardStartAdv();
                }
                else
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "peripheral_HandleBtGapMessage: gapProfileState = %d", 1, gapProfileState);
                }
                break;
            }
        case GAPSTATE_ADVERTISING:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "peripheral_HandleBtGapMessage state: GAPSTATE_ADVERTISING", 0);
                break;
            }
        case GAPSTATE_CONNECTED:
            {
                //ChangeInterval(0x08, 0x08);
                break;
            }
        case GAPSTATE_CONNECTED_ADV:
            {
                break;
            }
        default:
            {
                break;
            }
    }
    gapProfileState = (gaprole_States_t)newState;
}

/******************************************************************
 * @fn          peripheral_HandleBtGapBondStateChangeEvt
 * @brief      All the bonding state change  events are pre-handled in this function.
 *                Then the event handling function shall be called according to the newState.
 *
 * @param    newState  - new bonding state
 * @return     void
 */
void peripheral_HandleBtGapBondStateChangeEvt(uint8_t newState, uint8_t status)
{
    switch (newState)
    {
        case GAPBOND_PAIRING_STATE_STARTED:
            {
                IsAbleToSendAction = false;
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(GAPBOND_PAIRING_STATE_STARTED)", 0);
                break;
            }
        case GAPBOND_PAIRING_STATE_COMPLETE:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(GAPBOND_PAIRING_STATE_COMPLETE)", 0);

                if (status == 0)
                {
                    /* disable passkey input function */
                    passKeyStructure.isAbleInput = FALSE;

                    /* enable Keyboard sending key value */
                    IsAbleToSendAction = TRUE;
                    ChangeInterval(0x08, 0x08);
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE pair success", 0);
                }
                else
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "BT_MSG_TYPE_BOND_STATE_CHANGE pair failed", 0);
                }
                break;
            }
        case GAPBOND_PAIRING_STATE_BONDED:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(GAPBOND_PAIRING_STATE_BONDED)", 0);
                break;
            }
        default:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_STATE_CHANGE:(unknown newstate: %d)", 1, newState);
                break;
            }
    }
}

/******************************************************************
 * @fn          peripheral_HandleBtGapEncryptStateChangeEvt
 * @brief      All the encrypt state change  events are handled in this function.
 *                Then the event handling function shall be called according to the status.
 *
 * @param    newState  - new encryption state
 * @return     void
 */
void peripheral_HandleBtGapEncryptStateChangeEvt(uint8_t newState)
{
    switch (newState)
    {
        case GAPBOND_ENCRYPT_STATE_ENABLED:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "GAPBOND_ENCRYPT_STATE_ENABLED", 0);
                break;
            }
        case GAPBOND_ENCRYPT_STATE_DISABLED:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "GAPBOND_ENCRYPT_STATE_DISABLED", 0);
                break;
            }
        default:
            {
                break;
            }
    }
}

/******************************************************************
 * @fn          peripheral_HandleBtGapConnParaChangeEvt
 * @brief      All the connection parameter update change  events are pre-handled in this function.
 *                Then the event handling function shall be called according to the status.
 *
 * @param    status  - connection parameter result, 0 - success, otherwise fail.
 * @return     void
 */
void peripheral_HandleBtGapConnParaChangeEvt(uint8_t status)
{
    if (status == 0)
    {
        uint16_t con_interval;
        uint16_t conn_slave_latency;
        uint16_t conn_supervision_timeout;

        peripheralGetGapParameter(GAPPRRA_CONN_INTERVAL, &con_interval);
        peripheralGetGapParameter(GAPPRRA_CONN_LATENCY, &conn_slave_latency);
        peripheralGetGapParameter(GAPPRRA_CONN_TIMEOUT, &conn_supervision_timeout);

        DBG_BUFFER(MODULE_APP, LEVEL_INFO, \
                   "BT_MSG_TYPE_CONN_PARA_UPDATE_CHANGE success, con_interval = 0x%x, conn_slave_latency = 0x%x,\
                    conn_supervision_timeout = 0x%x", \
                   3, con_interval, conn_slave_latency, conn_supervision_timeout);
    }
    else
    {
        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_CONN_PARA_UPDATE_CHANGE failed, status = %d", \
                   1, status);

    }
}

void PassKey_HandleKeyData(uint8_t key_num, PassKey_TypeDef *pPassKeyStructure)
{
    if (key_num < 10)
    {
        if (passKeyStructure.passKeyCnt < 6)
        {
            pPassKeyStructure->passKeyValue = pPassKeyStructure->passKeyValue * 10;
            pPassKeyStructure->passKeyValue += key_num;
            pPassKeyStructure->passKeyCnt++;
        }
    }
    else if (key_num == 10)
    {
        //delete the last input key value
        pPassKeyStructure->passKeyValue = (pPassKeyStructure->passKeyValue) / 10;
        if (pPassKeyStructure->passKeyCnt > 0)
        {
            pPassKeyStructure->passKeyCnt--;
        }
    }
}

uint32_t Keyboard_GetPassKey(BEE_IO_MSG io_driver_msg_recv)
{
    UINT32 i;
    UINT8 keyCode;
    KEYSCAN_DATA_STRUCT *pKey_Data = io_driver_msg_recv.pBuf;

    for (i = 0; i < pKey_Data->Length; i++)
    {
        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "%d/%d: (row, column) = (%d, %d) n", 4, i + 1, pKey_Data->Length, pKey_Data->key[i].row, pKey_Data->key[i].column);
        keyCode = Keyboard_Keymap[pKey_Data->key[i].row][pKey_Data->key[i].column];

        switch (keyCode)
        {
            case VK_0:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "passKey = VK_0\n\n", 0);
                    PassKey_HandleKeyData(0, &passKeyStructure);
                    break;
                }
            case VK_1:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "passKey = VK_1\n\n", 0);
                    PassKey_HandleKeyData(1, &passKeyStructure);
                    break;
                }
            case VK_2:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "passKey = VK_2\n\n", 0);
                    PassKey_HandleKeyData(2, &passKeyStructure);
                    break;
                }
            case VK_3:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "passKey = VK_3\n\n", 0);
                    PassKey_HandleKeyData(3, &passKeyStructure);
                    break;
                }
            case VK_4:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "passKey = VK_4\n\n", 0);
                    PassKey_HandleKeyData(4, &passKeyStructure);
                    break;
                }
            case VK_5:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "passKey = VK_5\n\n", 0);
                    PassKey_HandleKeyData(5, &passKeyStructure);
                    break;
                }

            case VK_6:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "passKey =  VK_6\n\n", 0);
                    PassKey_HandleKeyData(6, &passKeyStructure);
                    break;
                }
            case VK_7:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "passKey = VK_7\n\n", 0);
                    PassKey_HandleKeyData(7, &passKeyStructure);
                    break;
                }
            case VK_8:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "passKey = VK_8\n\n", 0);
                    PassKey_HandleKeyData(8, &passKeyStructure);
                    break;
                }
            case VK_9:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "passKey = VK_9\n\n", 0);
                    PassKey_HandleKeyData(9, &passKeyStructure);
                    break;
                }
            case VK_RETURN:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "passKey = VK_RETURN\n\n", 0);
                    if (passKeyStructure.passKeyCnt == 6)
                    {
                        GAPBondMgr_SetParameter(GAPBOND_PASSKEY, sizeof(passKeyStructure.passKeyValue), &passKeyStructure.passKeyValue);
                        GAPBondMgr_InputPassKey();
                    }
                    else
                    {
                        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "Error: The passkey length is not equal to six, please input again.\n", 0);
                    }
                    // clear passkey data
                    passKeyStructure.passKeyValue = 0;
                    passKeyStructure.passKeyCnt = 0;

                    break;
                }

            case VK_DELETE:
                {
                    PassKey_HandleKeyData(10, &passKeyStructure);
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "Delete the last input key value\n\n", 0);
                    break;
                }

            default:
                {
                    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "Invalid Passkey keyCode: 0x%x\n\n", 1, keyCode);
                    break;
                }
        }
    }
}

/******************************************************************
 * @fn          peripheral_HandleBtGapMessage
 * @brief      All the bt gap msg  events are pre-handled in this function.
 *                Then the event handling function shall be called according to the subType
 *                of BEE_IO_MSG.
 *
 * @param    pBeeIoMsg  - pointer to bee io msg
 * @return     void
 */
void peripheral_HandleBtGapMessage(BEE_IO_MSG  *pBeeIoMsg)
{
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "peripheral_HandleBtGapMessage subType = %d", 1, pBeeIoMsg->subType);
    BT_STACK_MSG BtStackMsg;
    memcpy(&BtStackMsg, &pBeeIoMsg->parm, sizeof(pBeeIoMsg->parm));

    switch (pBeeIoMsg->subType)
    {
        case BT_MSG_TYPE_CONN_STATE_CHANGE:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_CONN_STATE_CHANGE:(%d->%d)",
                           2, gapProfileState, BtStackMsg.msgData.gapConnStateChange.newState);

                peripheral_HandleBtGapStateChangeEvt(BtStackMsg.msgData.gapConnStateChange.newState);
                break;
            }
        case BT_MSG_TYPE_BOND_STATE_CHANGE:
            {
                peripheral_HandleBtGapBondStateChangeEvt(BtStackMsg.msgData.gapBondStateChange.newState,
                        BtStackMsg.msgData.gapBondStateChange.status);
                break;
            }
        case BT_MSG_TYPE_BOND_PASSKEY_DISPLAY:
            {
                uint32_t displayValue = 0;
                GAPBondMgr_GetParameter(GAPBOND_PASSKEY, &displayValue);
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_PASSKEY_DISPLAY: %d", 1, displayValue);
                break;
            }
        case BT_MSG_TYPE_BOND_PASSKEY_INPUT:
            {
                /* enable to input passkey */
                passKeyStructure.passKeyValue = 0;
                passKeyStructure.passKeyCnt = 0;
                passKeyStructure.isAbleInput = TRUE;
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_PASSKEY_INPUT", 0);
                break;
            }
        case BT_MSG_TYPE_BOND_OOB_INPUT:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_INFO, "BT_MSG_TYPE_BOND_OOB_INPUT", 0);
                uint8_t ooBData[KEYLEN] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
                GAPBondMgr_SetParameter(GAPBOND_OOB_DATA, KEYLEN, ooBData);
                GAPBondMgr_InputOobData();
                break;
            }
        case BT_MSG_TYPE_ENCRYPT_STATE_CHANGE:
            {
                peripheral_HandleBtGapEncryptStateChangeEvt(BtStackMsg.msgData.gapEncryptStateChange.newState);
                break;
            }
        case BT_MSG_TYPE_CONN_PARA_UPDATE_CHANGE:
            {
                peripheral_HandleBtGapConnParaChangeEvt(BtStackMsg.msgData.gapConnParaUpdateChange.status);
                break;
            }
        default:
            {
                DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "peripheral_HandleBtGapMessage unknown subtype", 1, pBeeIoMsg->subType);
                break;
            }
    }
}

TAppResult AppProfileCallback(uint8_t serviceID, void *pData)
{
    TAppResult appResult = AppResult_Success;
    uint16_t sRetValue = 0;
    if (serviceID == ProfileAPI_ServiceUndefined)
    {
        TEventInfoCBs_t *pPara = (TEventInfoCBs_t *)pData;
        switch (pPara->eventId)
        {
            case PROFILE_EVT_SRV_REG_COMPLETE:// srv register result event.
                {
                    DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "profile callback PROFILE_SRV_REGISTER_RESULT_EVT\n", 0);
                    peripheral_Init_StartAdvertising();
                    break;
                }
            case PROFILE_EVT_SEND_DATA_COMPLETE:
                {
                    uint16_t wCredits = pPara->sParas[0];
                    DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "profile callback PROFILE_EVT_SEND_DATA_COMPLETE\n", 0);
                    break;
                }
            default:
                {
                    break;
                }
        }
    }
    else if (serviceID == gHIDServiceId)
    {
        THID_CALLBACK_DATA *pHidCallback_data = (THID_CALLBACK_DATA *)pData;

        switch (pHidCallback_data->msg_type )
        {
            case SERVICE_CALLBACK_TYPE_INDIFICATION_NOTIFICATION:
                {
                    switch (pHidCallback_data->msg_data.notification_indification_index)
                    {
                        case HID_NOTIFY_INDICATE_KB_ENABLE:
                            {
                                IsKeyboardEnabled = TRUE;
                                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "HID_NOTIFY_INDICATE_KB_ENABLE!!", 0);
                                break;
                            }
                        case HID_NOTIFY_INDICATE_KB_DISABLE:
                            {
                                IsAbleToSendAction = FALSE;
                                IsKeyboardEnabled = FALSE;
                                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "HID_NOTIFY_INDICATE_KB_DISABLE!!", 0);
                                break;
                            }
                        default:
                            {
                                break;
                            }
                    }
                    break;
                }
            case SERVICE_CALLBACK_TYPE_READ_CHAR_VALUE:
                {
                    switch (pHidCallback_data->msg_data.notification_indification_index)
                    {
                        case HIDS_READ_PARAM_PROTOCOL_MODE:
                            {
                                HIDS_SetParameter(HIDS_READ_PARAM_PROTOCOL_MODE, sizeof(protocolmode), (void *)&protocolmode);
                                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "HIDS_READ_PARAM_PROTOCOL_MODE!!", 0);
                                break;
                            }
                        case HIDS_READ_PARAM_SUSPEND_MODE:
                            {
                                HIDS_SetParameter(HIDS_READ_PARAM_SUSPEND_MODE, sizeof(suspendMode), (void *)&suspendMode);
                                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "HIDS_READ_PARAM_SUSPEND_MODE!!", 0);
                                break;
                            }
                        case HIDS_READ_PARAM_REPORT:
                            {
                                //HIDS_SetParameter(HIDS_READ_PARAM_REPORT,sizeof(KeyboardData),(void*)&KeyboardData);
                                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "HIDS_READ_PARAM_REPORT!!", 0);
                                break;
                            }
                        case HID_READ_OUTPUT_KEYBOARD:
                            {
                                //HIDS_SetParameter(HID_READ_OUTPUT_KEYBOARD,sizeof(KeyboardData),&KeyboardData);
                                DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "HID_READ_OUTPUT_KEYBOARD!!", 0);
                                break;
                            }
                        default:
                            {
                                break;
                            }
                    }
                    break;
                }

            case SERVICE_CALLBACK_TYPE_WRITE_CHAR_VALUE:
                {
                    if (pHidCallback_data->msg_data.write.write_type == HID_WRITE_PROTOCOL_MODE)
                    {
                        gProtocolMode = pHidCallback_data->msg_data.write.write_parameter.protocol_mode;
                        DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_ERROR, "HID_WRITE_PROTOCOL MODE %d\n", 1, gProtocolMode);
                    }

                    if (pHidCallback_data->msg_data.write.write_type == HID_WRITE_SUSPEND_MODE)
                    {
                        gSuspendMode = pHidCallback_data->msg_data.write.write_parameter.suspend_mode;
                        DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_ERROR, "HID_WRITE_suspend MODE %d\n", 1, gSuspendMode);
                    }
                    break;
                }
            default:
                {
                    break;
                }

        }
    }
    else if (serviceID == gBASServiceId)
    {
        TBAS_CALLBACK_DATA *pBasCallbackData = (TBAS_CALLBACK_DATA *)pData;
        switch (pBasCallbackData->msg_type)
        {
            case SERVICE_CALLBACK_TYPE_INDIFICATION_NOTIFICATION:
                {
                    if (pBasCallbackData->msg_data.notification_indification_index == BAS_NOTIFY_BATTERY_LEVEL_ENABLE)
                    {
                        DBG_BUFFER(MODULE_APP, LEVEL_INFO, "profile callback BAS_NOTIFY_BATTERY_LEVEL_ENABLE\n", 0);
                    }
                    else if (pBasCallbackData->msg_data.notification_indification_index == BAS_NOTIFY_BATTERY_LEVEL_DISABLE)
                    {

                    }
                    break;
                }
            case SERVICE_CALLBACK_TYPE_READ_CHAR_VALUE:
                {
                    BAS_SetParameter(BAS_PARAM_BATTERY_LEVEL, 1, &gBASBatteryLevel);
                    break;
                }
            default:
                {
                    break;
                }
        }
    }
    else if (serviceID == gDISServiceId)
    {

    }
    else if (serviceID == gSPSServiceId)
    {
        TSPS_CALLBACK_DATA *pSpsCallbackData  = (TSPS_CALLBACK_DATA *)pData;

        switch (pSpsCallbackData->msg_type)
        {
            case SERVICE_CALLBACK_TYPE_INDIFICATION_NOTIFICATION:
                {
                    if (pSpsCallbackData->msg_data.notification_indification_index == SPS_NOTIFY_INDICATE_SCAN_REFRESH_ENABLE)
                    {

                    }
                    else if (pSpsCallbackData->msg_data.notification_indification_index == SPS_NOTIFY_INDICATE_SCAN_REFRESH_DISABLE)
                    {

                    }
                    break;
                }
            case SERVICE_CALLBACK_TYPE_WRITE_CHAR_VALUE:
                {
                    if (pSpsCallbackData->msg_data.write.write_type == SPS_WRITE_SCAN_INTERVAL_WINDOW)
                    {
                        uint16_t scanInterval = pSpsCallbackData->msg_data.write.write_parameter.scan.scan_interval;
                        uint16_t scanWindow = pSpsCallbackData->msg_data.write.write_parameter.scan.scan_window;
                    }
                    break;
                }
            default:
                {
                    break;
                }
        }
    }
    else if (serviceID == gDISServiceId)
    {
        TDIS_CALLBACK_DATA *pDisCallbackData = (TDIS_CALLBACK_DATA *)pData;
        switch (pDisCallbackData->msg_type)
        {
            case SERVICE_CALLBACK_TYPE_READ_CHAR_VALUE:
                {
                    if (pDisCallbackData->msg_data.read_value_index == DIS_READ_MANU_NAME_INDEX)
                    {
                        const uint8_t DISManufacturerName[] = "Realtek BT";
                        DIS_SetParameter(DIS_PARAM_MANUFACTURER_NAME,
                                         sizeof(DISManufacturerName),
                                         (void *)DISManufacturerName);

                    }
                    else if (pDisCallbackData->msg_data.read_value_index == DIS_READ_MODEL_NUM_INDEX)
                    {
                        const uint8_t DISModelNumber[] = "Model Nbr 0.9";
                        DIS_SetParameter(DIS_PARAM_MODEL_NUMBER,
                                         sizeof(DISModelNumber),
                                         (void *)DISModelNumber);
                    }
                    else if (pDisCallbackData->msg_data.read_value_index == DIS_READ_SERIAL_NUM_INDEX)
                    {
                        const uint8_t DISSerialNumber[] = "RTKBeeSerialNum";
                        DIS_SetParameter(DIS_PARAM_SERIAL_NUMBER,
                                         sizeof(DISSerialNumber),
                                         (void *)DISSerialNumber);

                    }
                    else if (pDisCallbackData->msg_data.read_value_index == DIS_READ_HARDWARE_REV_INDEX)
                    {
                        const uint8_t DISHardwareRev[] = "RTKBeeHardwareRev";
                        DIS_SetParameter(DIS_PARAM_HARDWARE_REVISION,
                                         sizeof(DISHardwareRev),
                                         (void *)DISHardwareRev);
                    }
                    else if (pDisCallbackData->msg_data.read_value_index == DIS_READ_FIRMWARE_REV_INDEX)
                    {
                        const uint8_t DISFirmwareRev[] = "RTKBeeFirmwareRev";
                        DIS_SetParameter(DIS_PARAM_FIRMWARE_REVISION,
                                         sizeof(DISFirmwareRev),
                                         (void *)DISFirmwareRev);
                    }
                    else if (pDisCallbackData->msg_data.read_value_index == DIS_READ_SOFTWARE_REV_INDEX)
                    {
                        const uint8_t DISSoftwareRev[] = "RTKBeeSoftwareRev";
                        DIS_SetParameter(DIS_PARAM_SOFTWARE_REVISION,
                                         sizeof(DISSoftwareRev),
                                         (void *)DISSoftwareRev);
                    }
                    else if (pDisCallbackData->msg_data.read_value_index == DIS_READ_SYSTEM_ID_INDEX)
                    {
                        uint8_t DISSystemID[DIS_SYSTEM_ID_LENGTH] = {0, 1, 2, 0, 0, 3, 4, 5};
                        DIS_SetParameter(DIS_PARAM_SYSTEM_ID,
                                         sizeof(DISSystemID),
                                         DISSystemID);

                    }
                    else if (pDisCallbackData->msg_data.read_value_index == DIS_READ_IEEE_CERT_STR_INDEX)
                    {
                        const uint8_t DISIEEEDataList[] = "RTKBeeIEEEDatalist";
                        DIS_SetParameter(DIS_PARAM_IEEE_DATA_LIST,
                                         sizeof(DISIEEEDataList),
                                         DISIEEEDataList);
                    }
                    else if (pDisCallbackData->msg_data.read_value_index == DIS_READ_PNP_ID_INDEX)
                    {
                        uint8_t DISPnpID[DIS_PNP_ID_LENGTH] = {0};
                        DIS_SetParameter(DIS_PARAM_PNP_ID,
                                         sizeof(DISPnpID),
                                         DISPnpID);
                    }
                    break;
                }
            default:
                {
                    break;
                }
        }
    }
    return appResult;
}

void ChangeInterval(uint16_t interval_min, uint16_t interval_max)
{
    uint16_t desired_min_interval = interval_min;
    uint16_t desired_max_interval = interval_max;
    uint16_t desired_slave_latency = 10;
    uint16_t desired_conn_timeout = 500;

    peripheralSetGapParameter( GAPPRRA_MIN_CONN_INTERVAL, sizeof( uint16_t ), &desired_min_interval );
    peripheralSetGapParameter( GAPPRRA_MAX_CONN_INTERVAL, sizeof( uint16_t ), &desired_max_interval );
    peripheralSetGapParameter( GAPPRRA_SLAVE_LATENCY, sizeof( uint16_t ), &desired_slave_latency );
    peripheralSetGapParameter( GAPPRRA_TIMEOUT_MULTIPLIER, sizeof( uint16_t ), &desired_conn_timeout );
    peripheral_SendUpdateParam();

    DBG_BUFFER(MODULE_DRIVERTASK, LEVEL_INFO, "current_interval = %d\n", 1, interval_min);
}
