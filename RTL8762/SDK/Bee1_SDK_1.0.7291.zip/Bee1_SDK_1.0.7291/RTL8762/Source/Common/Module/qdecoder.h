/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      qdecoder.h
* @brief
* @details
* @author    Chuanguo Xue
* @date      2015-3-27
* @version   v0.1
* *********************************************************************************************************
*/


#ifndef _QDECODER_H
#define _QDECODER_H

#ifdef __cplusplus
extern "C" {
#endif

#include "rtl876x.h"
#include "rtl876x_bitfields.h"

#define BIT_MASK            0x1
#define BIT_SHIFT_X_MASK    12
#define BIT_MASK_X_MASK         0x1
#define BIT_X_MASK          (BIT_MASK_X_MASK<< BIT_SHIFT_X_MASK)
#define BIT_INVC_X_MASK     (~(BIT_MASK_X_MASK << BIT_SHIFT_X_MASK))

#define BIT_SHIFT_Y_MASK    13
#define BIT_MASK_Y_MASK         0x1
#define BIT_Y_MASK          (BIT_MASK_Y_MASK<< BIT_SHIFT_Y_MASK)
#define BIT_INVC_Y_MASK     (~(BIT_MASK_Y_MASK << BIT_SHIFT_Y_MASK))

#define BIT_SHIFT_Z_MASK    14
#define BIT_MASK_Z_MASK         0x1
#define BIT_Z_MASK          (BIT_MASK_Z_MASK<< BIT_SHIFT_Z_MASK)
#define BIT_INVC_Z_MASK     (~(BIT_MASK_Z_MASK << BIT_SHIFT_Z_MASK))

#define BIT_SHIFT_X_INT     16
#define BIT_MASK_X_INT      0x1
#define BIT_X_CLEAR             (BIT_MASK_X_INT<< BIT_SHIFT_X_INT)

#define BIT_SHIFT_Y_INT     17
#define BIT_MASK_Y_INT      0x1
#define BIT_Y_CLEAR             (BIT_MASK_Y_INT<< BIT_SHIFT_Y_INT)

#define BIT_SHIFT_Z_INT     18
#define BIT_MASK_Z_INT      0x1
#define BIT_Z_CLEAR             (BIT_MASK_Z_INT<< BIT_SHIFT_Z_INT)

#define BIT_CLEAR_X_UPFLOW      BIT3
#define BIT_CLEAR_Y_UPFLOW      BIT4
#define BIT_CLEAR_Z_UPFLOW      BIT5

#define BIT_CLEAR_X_DOWNFLOW        BIT15
#define BIT_CLEAR_Y_DOWNFLOW        BIT16
#define BIT_CLEAR_Z_DOWNFLOW        BIT17

#define BIT_CLEAR_X_ILLEGAL         BIT6
#define BIT_CLEAR_Y_ILLEGAL         BIT7
#define BIT_CLEAR_Z_ILLEGAL         BIT8


typedef struct _QDEC_DATA_STRUCT_
{
    UINT8 X_Interrupt_Status;
    UINT8 Y_Interrupt_Status;
    UINT8 Z_Interrupt_Status;
    UINT32 X_Counter;
    UINT32 Y_Counter;
    UINT32 Z_Counter;
} QDEC_DATA_STRUCT, *pQDEC_DATA_STRUCT;


typedef struct _QDEC_CONFIG_STRUCT_
{
    UINT8 X_Axis_enable;
    UINT8 X_Axis_dounce_enable;
    UINT8 Y_Axis_enable;
    UINT8 Y_Axis_dounce_enable;
    UINT8 Z_Axis_enable;
    UINT8 Z_Axis_dounce_enable;
    UINT8 interrupt1_enable;
    UINT8 interrupt2_enable;
    UINT8 interrupt2_bitnum;
    UINT8 interrupt3_enable;
    UINT8 interrupt3_timer;
    UINT32 Sample_rate_Hz;
    UINT32 Debounce_Interval_us;
} QDEC_CONFIG_STRUCT;


extern void RTL_QDec_Init(QDEC_CONFIG_STRUCT * QDec_Param);
extern void RTL_QDec_StructInit(QDEC_CONFIG_STRUCT * QDec_Param);

#ifdef __cplusplus
}
#endif

#endif /* _QDECODER_H */

