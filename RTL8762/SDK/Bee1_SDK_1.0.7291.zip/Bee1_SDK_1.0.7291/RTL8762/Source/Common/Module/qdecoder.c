/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     qdecoder.c
* @brief
* @details
* @author   Chuanguo Xue
* @date     2015-04-17
* @version  v0.1
*********************************************************************************************************
*/
#include "rtl876x.h"
#include "board.h"
#include "rtl876x_bitfields.h"
#include "qdecoder.h"
#include "bee_message.h"
#include <string.h>
#include "trace.h"
#include "os.h"
#include "rtl876x_qdec.h"

extern BOOL allowedMouseEnterDlps;

//#define DEFAULT_QDECODE_DEBOUNCE_INTERVAL 5500    //us
//#define DEFAULT_QDECODE_SAMPLE_RATE       128000  //Hz

void QdecodeIntrHandler()
{
    long xHigherPriorityTaskWoken = pdFALSE;

    /* Mask interrupt */
    //QDEC->REG_CR1 = QDEC->REG_CR1 | BIT_X_MASK | BIT_Y_MASK | BIT_Z_MASK;
    QDEC_INTMask(QDEC, QDEC_AXIS_Y, ENABLE);
    
    allowedMouseEnterDlps = false;
    /* Disable DLPS_Timer */
    DLPS_Timer->ControlReg &= ~(BIT(0));
    /* 5s */
    DLPS_Timer->LoadCount = 50000000;
    /* Enable DLPS_Timer */
    DLPS_Timer->ControlReg |= BIT(0);

    // send message to IO driver
    BEE_IO_MSG rtl_qdecode_msg;
    rtl_qdecode_msg.IoType = IO_QDECODE_MSG_TYPE;
    rtl_qdecode_msg.parm = QDEC->REG_SR_Y;

    if (!SendMessageFromISR(&rtl_qdecode_msg, &xHigherPriorityTaskWoken))
    {
        DBG_BUFFER(MODULE_QDECODE, LEVEL_ERROR, " ***Quad decoder SendQueue fail(MSG).\n", 0);
    }

    portEND_SWITCHING_ISR(xHigherPriorityTaskWoken);

    /* Clear & enable interrupt */
    /*QDEC->REG_CR1 = (QDEC->REG_CR1 & (~(0x7 << 12)))
                        | BIT_X_CLEAR | BIT_Y_CLEAR | BIT_Z_CLEAR;*/
    QDEC_ClearINTPendingBit(QDEC, QDEC_FLAG_INT_Y);
    QDEC_INTMask(QDEC, QDEC_AXIS_Y, DISABLE);
}

