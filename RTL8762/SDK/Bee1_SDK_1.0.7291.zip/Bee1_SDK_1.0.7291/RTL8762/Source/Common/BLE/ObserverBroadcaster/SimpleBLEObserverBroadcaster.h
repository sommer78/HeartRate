
#ifndef SIMPLEBLEOBSERVERBROADCASTER_H
#define SIMPLEBLEOBSERVERBROADCASTER_H


#include "gap.h"
#include "bee_message.h"
#ifdef __cplusplus
extern "C"
{
#endif

extern void BtStack_Init_ob(void);

#ifdef __cplusplus
}
#endif

#endif /* SIMPLEBLEBROADCASTER_H */
