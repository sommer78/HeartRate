
#ifndef SIMPLEBLEPERIPHERAL_H
#define SIMPLEBLEPERIPHERAL_H


#include "gap.h"
#include "bee_message.h"
#ifdef __cplusplus
extern "C"
{
#endif

/******************************************************************
 * @fn          Initial peripheral role
 * @brief      Initialize of gap periopheral role 
 *
 * @return     void
 */
extern void BtStack_Init_Peripheral(void);

#ifdef __cplusplus
}
#endif

#endif /* SIMPLEBLEPERIPHERAL_H */
