#ifndef _SIMPEL_BEL_CENTRAL_API_H_
#define _SIMPEL_BEL_CENTRAL_API_H_



bool central_StartBtStack(void);
bool central_HandleBlueAPIMessage( PBlueAPI_UsMessage pMsg );
void centralBlueAPIMessageCB(PBlueAPI_UsMessage pMsg);


#endif
