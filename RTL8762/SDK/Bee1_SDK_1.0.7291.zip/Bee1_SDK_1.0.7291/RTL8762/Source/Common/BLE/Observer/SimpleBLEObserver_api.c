enum { __FILE_NUM__ = 0 };

#include "gap.h"

bool observer_StartBtStack()
{
    return GAP_StartBtStack();
}

