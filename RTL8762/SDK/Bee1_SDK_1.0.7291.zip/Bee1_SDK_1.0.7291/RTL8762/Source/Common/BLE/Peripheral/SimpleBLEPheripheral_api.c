enum { __FILE_NUM__ = 0 };
/*
#include "blueapi_types.h"
#include <blueapi.h>
#include <string.h>
#include "dlps_platform.h"
#include "trace.h"
#include "portable.h"
#include "SimpleBLEPheripheral_api.h"
*/
#include "gap.h"

/******************************************************************
 * @fn         peripheral_StartBtStack
 * @brief      Start bt stack 
 *
 * @return     bool
 */
bool peripheral_StartBtStack()
{
    return GAP_StartBtStack();
}

