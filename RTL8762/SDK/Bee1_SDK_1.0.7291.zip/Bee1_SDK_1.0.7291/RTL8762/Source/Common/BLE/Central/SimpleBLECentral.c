enum { __FILE_NUM__ = 0 };


#include "central.h"
#include "gapbondmgr.h"

#include "simpleBLECentral.h"
#include "bee_message.h"
#include <string.h>
#include "FreeRTOS.h"
#include "queue.h"

extern xQueueHandle hEventQueueHandle;
extern xQueueHandle hIoQueueHandle;


static void centralStateNotificationCB( gaprole_States_t newState );
static void centralConnParaUpdateCB(uint16_t connHandle, uint8_t status);


static void centralPasskeyEntryDisplayCB(uint16_t connHandle, uint32_t displayValue);
static void centralPasskeyEntryKeyboardInputCB(uint16_t connHandle);
static void centralOobInputCB(uint16_t connHandle);
static void centralPairStateCB( uint16_t connHandle, uint8_t state, uint8_t status );
static void centralEncryptStateCB(uint16_t connectionHandle, uint8_t  state);


// GAP Bond Manager Callbacks
static gapBondCBs_t simpleBLECentral_BondMgrCBs =
{
    centralPasskeyEntryDisplayCB,
    centralPasskeyEntryKeyboardInputCB,
    centralOobInputCB,
    centralPairStateCB,
    centralEncryptStateCB
};



static void central_sendBtMsgToApp(BEE_IO_MSG *pBeeMsgBlk)
{

    portBASE_TYPE SendQueueResult;
    uint8_t Event = 0;

    SendQueueResult = xQueueSend(hIoQueueHandle, pBeeMsgBlk, 0xFFFF);
    if (SendQueueResult != pdPASS)
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "central_sendBtMsgToApp fail2", 1, SendQueueResult);
    }

    Event = EVENT_NEWIODRIVER_TO_APP;
    SendQueueResult = xQueueSend(hEventQueueHandle, &Event, 0xFFFF);
    if (SendQueueResult != pdPASS)
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "central_sendBtMsgToApp fail", 1, SendQueueResult);
    }

}


static void centralStateNotificationCB( gaprole_States_t newState )
{

    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "centralStateNotificationCB newState=0x%x", 1, newState);

    {
        BEE_IO_MSG bee_io_msg;
        BT_STACK_MSG btGapMsg;

        bee_io_msg.IoType = BT_STATUS_UPDATE;
        bee_io_msg.subType = BT_MSG_TYPE_CONN_STATE_CHANGE;
        btGapMsg.msgData.gapConnStateChange.newState = newState;

        memcpy(&bee_io_msg.parm, &btGapMsg, sizeof(bee_io_msg.parm));



        central_sendBtMsgToApp(&bee_io_msg);

    }



}

static void centralConnParaUpdateCB(uint16_t connHandle, uint8_t status)
{
	BEE_IO_MSG bee_io_msg;
    BT_STACK_MSG btGapMsg;
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "centralConnParaUpdateCB connHandle=0x%x, status=%d", 2, connHandle, status);

    bee_io_msg.IoType = BT_STATUS_UPDATE;
    bee_io_msg.subType = BT_MSG_TYPE_CONN_PARA_UPDATE_CHANGE;
    btGapMsg.msgData.gapConnParaUpdateChange.connHandle = connHandle;
    btGapMsg.msgData.gapConnParaUpdateChange.status = status;

    memcpy(&bee_io_msg.parm, &btGapMsg, sizeof(bee_io_msg.parm));

    central_sendBtMsgToApp(&bee_io_msg);
}


static void centralPasskeyEntryDisplayCB(uint16_t connHandle, uint32_t displayValue)
{
	BEE_IO_MSG bee_io_msg;
    BT_STACK_MSG btGapMsg;
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "centralPasskeyEntryDisplayCB: %d", 1, displayValue);


    bee_io_msg.IoType = BT_STATUS_UPDATE;
    bee_io_msg.subType = BT_MSG_TYPE_BOND_PASSKEY_DISPLAY;
    btGapMsg.msgData.gapBondPasskeyDisplay.connHandle = connHandle;


    memcpy(&bee_io_msg.parm, &btGapMsg, sizeof(bee_io_msg.parm));

    central_sendBtMsgToApp(&bee_io_msg);
}

static void centralPasskeyEntryKeyboardInputCB(uint16_t connHandle)
{
	BEE_IO_MSG bee_io_msg;
    BT_STACK_MSG btGapMsg;
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "centralPasskeyEntryKeyboardInputCB", 0);


    bee_io_msg.IoType = BT_STATUS_UPDATE;
    bee_io_msg.subType = BT_MSG_TYPE_BOND_PASSKEY_INPUT;
    btGapMsg.msgData.gapBondPasskeyInput.connHandle = connHandle;

    memcpy(&bee_io_msg.parm, &btGapMsg, sizeof(bee_io_msg.parm));

    central_sendBtMsgToApp(&bee_io_msg);
}
static void centralOobInputCB(uint16_t connHandle)
{
	BEE_IO_MSG bee_io_msg;
    BT_STACK_MSG btGapMsg;
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "centralOobInputCB", 0);


    bee_io_msg.IoType = BT_STATUS_UPDATE;
    bee_io_msg.subType = BT_MSG_TYPE_BOND_OOB_INPUT;
    btGapMsg.msgData.gapBondOobInput.connHandle = connHandle;

    memcpy(&bee_io_msg.parm, &btGapMsg, sizeof(bee_io_msg.parm));

    central_sendBtMsgToApp(&bee_io_msg);

}

static void centralPairStateCB( uint16_t connHandle, uint8_t state, uint8_t status )
{
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "centralPairStateCB connHandle=0x%x, state = %d, status = %d", 3, connHandle, state, status);

    BEE_IO_MSG bee_io_msg;
    BT_STACK_MSG btGapMsg;

    bee_io_msg.IoType = BT_STATUS_UPDATE;
    bee_io_msg.subType = BT_MSG_TYPE_BOND_STATE_CHANGE;
    btGapMsg.msgData.gapBondStateChange.connHandle = connHandle;
    btGapMsg.msgData.gapBondStateChange.newState = state;

    memcpy(&bee_io_msg.parm, &btGapMsg, sizeof(bee_io_msg.parm));

    central_sendBtMsgToApp(&bee_io_msg);
}

static void centralEncryptStateCB(uint16_t connHandle, uint8_t  state)
{
	BEE_IO_MSG bee_io_msg;
    BT_STACK_MSG btGapMsg;
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "centralEncryptStateCB connHandle=0x%x, state = %d", 2, connHandle, state);


    bee_io_msg.IoType = BT_STATUS_UPDATE;
    bee_io_msg.subType = BT_MSG_TYPE_ENCRYPT_STATE_CHANGE;
    btGapMsg.msgData.gapEncryptStateChange.connHandle = connHandle;
    btGapMsg.msgData.gapEncryptStateChange.newState = state;

    memcpy(&bee_io_msg.parm, &btGapMsg, sizeof(bee_io_msg.parm));

    central_sendBtMsgToApp(&bee_io_msg);

}


void BtStack_Init_Central(void)
{
    central_RegisterDeviceStateChangeCB( &centralStateNotificationCB );
    central_RegisterAppCBs(&centralConnParaUpdateCB);
    central_GapParaInit();
    GAPBondMgr_ParaInit();
    GAPBondMgr_Register( &simpleBLECentral_BondMgrCBs );
}



