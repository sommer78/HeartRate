#ifndef SIMPLEBLEOBSERVERBROADCASTER_API_H
#define SIMPLEBLEOBSERVERBROADCASTER_API_H



bool ob_StartBtStack(void);
bool ob_HandleBlueAPIMessage( PBlueAPI_UsMessage pMsg );

void obBlueAPIMessageCB(PBlueAPI_UsMessage pMsg);

#endif
