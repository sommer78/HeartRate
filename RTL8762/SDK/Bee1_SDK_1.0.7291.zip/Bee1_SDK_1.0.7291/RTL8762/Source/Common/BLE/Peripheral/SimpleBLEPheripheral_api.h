#ifndef SIMPLEBLEPERIPHERAL_API_H_
#define SIMPLEBLEPERIPHERAL_API_H_


/******************************************************************
 * @fn         peripheral_StartBtStack
 * @brief      Start bt stack 
 *
 * @return     bool
 */
extern bool peripheral_StartBtStack(void);


#endif
