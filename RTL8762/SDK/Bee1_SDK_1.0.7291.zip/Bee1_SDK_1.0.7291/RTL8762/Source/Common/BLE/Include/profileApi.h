/**
*****************************************************************************************
*     Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
  * @file     profileApi.h
  * @brief    Head file for profile structure.
  * @details  User can take advantage of theses structs and functions to implement specific service.
  * @author   Lilly_he
  * @date     2014-06-26
  * @version  v1.0
  * *************************************************************************************
  */

/* Define to prevent recursive inclusion */
#ifndef __PROFILE_API_H
#define __PROFILE_API_H
    
#ifdef  __cplusplus
    extern "C" {
#endif      /* __cplusplus */

/* Add Includes here */
#include "profileConfig.h"
#include "rtl_types.h"
#include "endialig.h"
#include <blueapi_types.h>
#include <bterrcod.h>
#include <gatt.h>

/** @addtogroup RTK_Profile_Module RTK Profile Module
  * @{
  */

/** @defgroup Profile_Common Profile Common
  * @brief Common Part of Profile, both service and client
  * @{
  */

/** @defgroup Profile_Common_Exported_Types Profile Common Exported Types
  * @brief  types that other.c files may use all defined here
  * @{
  */

/** @defgroup TProfileResult TProfileResult
  * @brief  profile procedure return results
  * @{
  */
typedef enum
{
    ProfileResult_Success               = ATT_OK,   /**< Profile procedure success. */
    ProfileResult_InvalidOffset         = (ATT_ERR | ATT_ERR_INVALID_OFFSET),   /**< Read/Write value offset invalid. */
    ProfileResult_InvalidValueSize      = (ATT_ERR | ATT_ERR_INVALID_VALUE_SIZE),   /**< Read/Write value size invalid. */
    ProfileResult_InvalidParameter      = (ATT_ERR | ATT_ERR_INVALID_PDU),  /**< Read/Write value parameter invalid. */
    ProfileResult_AttrNotFound          = (ATT_ERR | ATT_ERR_ATTR_NOT_FOUND),   /**< Profile procedure attribute not found. */
    ProfileResult_AttrNotLong           = (ATT_ERR | ATT_ERR_ATTR_NOT_LONG),    /**< Profile procedure attribute is not long characteristic. */
    ProfileResult_OutOfResource         = (ATT_ERR | ATT_ERR_INSUFFICIENT_RESOURCES),   /**< Profile procedure no enough resource(RAM...). */
    ProfileResult_Unlikely              = (ATT_ERR | ATT_ERR_UNLIKELY), /**< Profile procedure unlikely result. */
    ProfileResult_AppErr                = (ATT_ERR | ATT_ERR_MIN_APPLIC_CODE),   /**< Profile procedure min application code. */
    ProfileResult_PreWrQueueFull        = (ATT_ERR | ATT_ERR_PREPARE_QUEUE_FULL),    /**< Profile procedure app a. */
    ProfileResult_AplicationErr         = (ATT_ERR | ATT_ERR_MIN_APPLIC_CODE),    /**< Profile procedure application error */
    ProfileResult_AppErr_CccdImproperlyConfigured = (ATT_ERR|ATT_ERR_CCCD_IMPROPERLY_CONFIGURED), /**< CCCD improperly configured. */
    ProfileResult_AppErr_ProcAlreadyInProgress = (ATT_ERR|ATT_ERR_PROC_ALREADY_IN_PROGRESS), /**< Procedure already in progress. */
    ProfileResult_AppErr_Pending = APP_ERR,
    ProfileResult_AppErr_Have_Confirm = APP_ERR| 0x01
} TProfileResult;
/** @} End of TProfileResult */

/** @defgroup TAppResult TAppResult
  * @brief  profile procedure application return results
  * @{
  */
typedef enum
{
    AppResult_Success         = 0,
    AppResult_Pending         = 1,
    //for prepare write & execute write
    AppResult_PreWrQueueFull  = ProfileResult_PreWrQueueFull,
    AppResult_AplicationErr   = ProfileResult_AplicationErr,
    AppResult_InvalidOffset   = ProfileResult_InvalidOffset,
    AppResult_InvalidValueSize = ProfileResult_InvalidValueSize,
    AppResult_InvalidParameter = ProfileResult_InvalidParameter,
    AppResult_HaveConfirm      = ProfileResult_AppErr_Have_Confirm,
    AppResult_UnknownError   
} TAppResult;
/** @} End of TAppResult */

/** @} End of Profile_Common_Exported_Types */

/** @} End of Profile_Common */

/** @} End of RTK_Profile_Module */


/** @addtogroup RTK_Profile_Module RTK Profile Module
  * @{
  */

/** @defgroup GATT_Service_Common GATT Service Common
  * @brief Common Part of Service
  * @{
  */

/** @defgroup Service_Common_Exported_Constants Service Common Exported Constants
  * @brief macros that other .c files may use all defined here
  * @{
  */

/** @defgroup CCCD_Bits CCCD Bits
  * @brief  CCCD related bits mask definition.
  * @{
  */
#define GATT_CCCD_NOTIFICATION_BIT              (1) /**< @brief Notification Bit in GATT. 1:Enable; 0:Disable */
#define GATT_CCCD_INDICATION_BIT                (1<<1) /**< @brief Indication Bit in GATT */
/** @} */

/** @defgroup Callback_Events Callback Events
  * @brief Callback events, used to notify application from profile layer.
  * @{
  */
#define PROFILE_EVT_SRV_REG_COMPLETE            0x01
#define PROFILE_EVT_SEND_DATA_COMPLETE          0x02
/** @} */

/** @defgroup General_Service_ID General Service ID
  * @brief service ID for general profile events.
  * @{
  */
#define ProfileAPI_ServiceUndefined             0xff
/** @} */

///@cond
/** @brief Max parameters of profile event to inform application. */
#define PROFILE_MAX_INFO_PARAM                  0x01
///@endcond

/** @} End of Service_Common_Exported_Constants */

/** @defgroup Service_Common_Exported_Types Service Common Exported Types
  * @brief  types that other.c files may use all defined here
  * @{
  */

///@cond
/** @brief common service related data */
typedef struct _GATTDService
{
    bool         Used;
    uint8_t      ServiceIDx;
    void *       pServiceHandle;  /**< service handle provided by GATT server */
} TGATTDService, * PGATTDService;
///@endcond

/** @defgroup TEventInfoCBs_t TEventInfoCBs_t
  * @brief data for profile to inform application.
  * @{
  */
typedef struct _TEventInfoCBs_t
{
    uint8_t     eventId;                    /**<  @brief EventId defined upper */
    uint16_t    sParas[PROFILE_MAX_INFO_PARAM]; /**<  @brief automatically parsed parameters */
} TEventInfoCBs_t;
/** @} End of TEventInfoCBs_t */

/** @defgroup TSERVICE_CALLBACK_TYPE TSERVICE_CALLBACK_TYPE
  * @brief event type to inform app.
  * @{
  */
typedef enum _TSERVICE_CALLBACK_TYPE
{
    SERVICE_CALLBACK_TYPE_INDIFICATION_NOTIFICATION = 1, /**< CCCD update event */
    SERVICE_CALLBACK_TYPE_READ_CHAR_VALUE = 2, /**< client read event */
    SERVICE_CALLBACK_TYPE_WRITE_CHAR_VALUE = 3 /**< client write event */
} TSERVICE_CALLBACK_TYPE;
/** @} End of TSERVICE_CALLBACK_TYPE */

/** @defgroup TGATTDWriteIndPostProc TGATTDWriteIndPostProc
  * @brief call back function to execute some post procedure after handle write request from client.
  * @{
  */
typedef void (* TGATTDWriteIndPostProc)(uint8_t serviceID, uint16_t wLength, uint8_t * pValue);
/** @} End of TGATTDWriteIndPostProc */

///@cond
/** @brief Specific service related callback function type definition. */
typedef TProfileResult (*pfnGATTReadAttrCB_t)(uint8_t ServiceId, uint16_t iAttribIndex, uint16_t iOffset, uint16_t * piLength, uint8_t **ppValue );
typedef TProfileResult(*pfnGATTWriteAttrCB_t)(uint8_t ServiceId, uint16_t iAttribIndex,
        uint16_t wLength, uint8_t * pValue , TGATTDWriteIndPostProc * pWriteIndPostProc);
typedef TAppResult(*pfnGATTPreWriteAttrCB_t)(uint8_t ServiceId, uint16_t handle, uint16_t iAttribIndex,
        uint16_t wLength, uint8_t * pValue , uint16_t offset);
typedef TAppResult(*pfnGATTExeWriteAttrCB_t)(uint8_t flag, uint16_t* handle);
typedef void (*pfnGATTUpdateCCCD_t)(uint8_t ServiceId, uint16_t wAttribIndex, uint16_t wCCCBits);
///@endcond

/** @defgroup pfnAPPHandleInfoCB_t pfnAPPHandleInfoCB_t
  * @brief function ponter Type used to general Call back, to send events to application.
  * @{
  */
typedef TAppResult (*pfnAPPHandleInfoCB_t)(uint8_t serviceId, void*pPara);
/** @} End of pfnAPPHandleInfoCB_t */

/** @defgroup gattServiceCBs_t gattServiceCBs_t
  * @brief service related callback functions struct.
  * @{
  */
typedef struct
{
    pfnGATTReadAttrCB_t pfnReadAttrCB;          //!< Read callback function pointer
    pfnGATTWriteAttrCB_t pfnWriteAttrCB;        //!< Write callback function pointer
    pfnGATTUpdateCCCD_t pfnUpdateCccdCB;        //!< update cccd callback function pointer
} gattServiceCBs_t;
/** @} End of gattServiceCBs_t */

///@cond
/** @brief prepare write and execute write callback functions struct
*   @note these two callback functions are provided by App, not specific service!
*/
typedef struct
{
    pfnGATTPreWriteAttrCB_t pfnPreWriteAttrCB;  //!< Prepare write callback function pointer
    pfnGATTExeWriteAttrCB_t pfnExeWriteAttrCB;      //!< Execute write callback function pointer
}gattPreExeWrCB_t;

/** @brief service related information, which maybe used when register to profile */
typedef struct
{
    uint8_t* pAttrTbl;
    uint16_t Length;
    TGATTDService    Service;
    gattServiceCBs_t cbInfo;
} gattServiceInfos_t;
///@endcond

/** @} End of Service_Common_Exported_Types */

/** @defgroup Service_Common_Exported_Functions Service Common Exported Functions
  * @brief functions that other .c files may use all defined here
  * @{
  */
extern TProfileResult  ProfileAPI_GetProfileResult(TAppResult appResult);
extern bool ProfileAPI_AttribValueReadConf(uint8_t ServiceIdx,
                         uint16_t wAttribIndex,
                         uint8_t* pData,
                         uint16_t     wLength);
extern bool ProfileAPI_ExeWriteConf(void);
extern void ProfileAPI_RegisterCB(pfnAPPHandleInfoCB_t pFunc);
extern void ProfileAPI_RegisterPreExeWrCB(gattPreExeWrCB_t pFunc);
extern bool ProfileAPI_SendData(uint8_t ServiceId, uint16_t Index, uint8_t* pData, uint16_t dataLen);
extern bool ProfileAPI_AddService(uint8_t* outServiceId, uint8_t* pDB, uint16_t Length, CONST gattServiceCBs_t cCBs);
/* just for homekit */
#if PROFILE_SUPPORT_HOMEKIT
void Profile_SetHomekitPairingServiceId(uint8_t id);
void Profile_RegHomekitPsPreExeWrCb(gattPreExeWrCB_t cb);
#endif
/** @} End of Service_Common_Exported_Functions */

/** @} End of GATT_Service_Common */

/** @} End of RTK_Profile_Module */

#ifdef  __cplusplus
}
#endif      /*  __cplusplus */

#endif /* !defined (__PROFILE_API_H) */
