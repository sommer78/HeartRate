
#ifndef _SIMPLE_BLE_CENTRAL_H_
#define _SIMPLE_BLE_CENTRAL_H_


#include "gap.h"
#include "bee_message.h"
#ifdef __cplusplus
extern "C"
{
#endif

/*
 * Task Initialization for the BLE Peripheral Application
 */
extern void BtStack_Init_Central(void);

extern void SimpleBLEPeripheral_Init(void);

/*
 * Task Event Processor for the BLE Peripheral Application
 */
extern void central_HandleIODriverMessage(BEE_IO_MSG io_driver_msg_recv);

#ifdef __cplusplus
}
#endif

#endif /* SIMPLEBLEPERIPHERAL_H */
