enum { __FILE_NUM__ = 0 };


#include "FreeRTOS.h"
#include "queue.h"
#include "mesh_common.h"
#include "bee_message.h"
#include <string.h>
#include "simpleBLEObserverBroadcaster.h"
#include "observer_broadcaster.h"

extern xQueueHandle hEventQueueHandle;
extern xQueueHandle h;
extern xQueueHandle hIoQueueHandle;

static void obStateNotificationCB( gaprole_States_t newState );

static void ob_sendBtMsgToApp(BEE_IO_MSG *pBeeMsgBlk)
{
    portBASE_TYPE SendQueueResult;
    uint8_t Event = 0;

    SendQueueResult = xQueueSend(hIoQueueHandle, pBeeMsgBlk, 0xFFFF);
    if (SendQueueResult != pdPASS)
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "broadcaster_sendBtMsgToApp fail2", 1, SendQueueResult);
    }

    Event = EVENT_NEWIODRIVER_TO_APP;
    SendQueueResult = xQueueSend(hEventQueueHandle, &Event, 0xFFFF);
    if (SendQueueResult != pdPASS)
    {
        DBG_BUFFER(MODULE_APP, LEVEL_ERROR, "broadcaster_sendBtMsgToApp fail", 1, SendQueueResult);
    }

}

static void obStateNotificationCB( gaprole_States_t newState )
{
    TMeshQueueMsg mesh_queue_msg;
	BEE_IO_MSG bee_io_msg;
    
	BT_STACK_MSG btGapMsg;
    btGapMsg.msgData.gapConnStateChange.newState = newState;

    mesh_queue_msg.type = MESH_BT_STATUS_UPDATE;
    mesh_queue_msg.sub_type = BT_MSG_TYPE_CONN_STATE_CHANGE;
    memcpy(&mesh_queue_msg.parm, &btGapMsg, sizeof(bee_io_msg.parm));
    MeshSendQueueMessage(&mesh_queue_msg);
    
	bee_io_msg.IoType = BT_STATUS_UPDATE;
	bee_io_msg.subType = BT_MSG_TYPE_CONN_STATE_CHANGE;
	memcpy(&bee_io_msg.parm, &btGapMsg, sizeof(bee_io_msg.parm));
	ob_sendBtMsgToApp(&bee_io_msg);
}

void BtStack_Init_ob(void)
{
    ob_RegisterDeviceStateChangeCB( &obStateNotificationCB );
    ob_GapParaInit();
}
