/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      rtl876x_pwm.h
* @brief     
* @details   
* @author    elliot chen
* @date      2015-05-15
* @version   v0.1
* *********************************************************************************************************
*/

#ifndef __RTL876X_PWM_H
#define __RTL876X_PWM_H

#ifdef __cpluspuls
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "rtl876x.h"
#include "rtl876x_bitfields.h"
#include "rtl876x_tim.h"

/** @addtogroup RTK_Periph_Driver
  * @{
  */
  
/** @addtogroup PWM PWM
  * @{
  */ 

/** @defgroup PWM_Exported_Types PWM Exported Types
  * @{
  */

/** 
  * @brief  PWM Init structure definition
  */
typedef struct
{
    uint16_t PWM_TIMIndex;          /*!< Specifies the clock index.
                                      This parameter can be a value of 0 to 7 */
                                    
    uint32_t PWM_Duty;              /*!< Specifies the on-duty duration of PWM pulse */

    uint32_t PWM_Period;            /*!< Specifies the the period of PWM pulse. */
    
} PWM_InitTypeDef;

/**
  * @}
  */ 

/** @defgroup PWM_Exported_constants PWM Exported Constants 
  * @{
  */

#define IS_PWM_ALL_PERIPH(PERIPH) (((PERIPH) == PWM0) || \
                                   ((PERIPH) == PWM1) || \
                                   ((PERIPH) == PWM2) || \
                                   ((PERIPH) == PWM3))
/**
  * @}
  */  

/** @defgroup PWM_Exported_Functions PWM Exported Functions
  * @{
  */

void PWM_Init(PWM_TypeDef* PWMx, PWM_InitTypeDef* PWM_InitStruct);
void PWM_Cmd(PWM_TypeDef* PWMx, FunctionalState NewState);

#ifdef __cplusplus
}
#endif

#endif /*__RTL876X_PWM_H*/

/** 
  * @}
  */
  
/** 
  * @}
  */

/** 
  * @}
  */

/******************* (C) COPYRIGHT 2015 Realtek Semiconductor Corporation *****END OF FILE****/

