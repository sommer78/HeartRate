/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     rtl876x_rtc.c
* @brief    This file provides all the RTC firmware functions.
* @details
* @author   Chuanguo Xue
* @date     2015-04-27
* @version  v0.1
*********************************************************************************************************
*/
#include "rtl876x.h"
#include "rtl876x_bitfields.h"
#include "rtl_endian.h"
#include "legacyperiphapi.h"
#include "rtl876x_rtc.h"

/**
  * @brief  Reset RTC.
  * @param  None.
  * @retval None
  */
void RTC_Reset(void)
{
     *((uint32_t *)0x40000014) |= BIT(9);
    bee_aon_gp_write(0x1D, bee_aon_gp_read(0x1D)&(~BIT(4)));
    RTC->SR_OFF |= BIT(31);
    
    RTC->CR0 = 0x9C;            //Default using internal 32kHz LFOSC
    RTC->CR1 = 0x00;
    RTC->SR = 0xFFFFFFFF;
    RTC->RTC_PRESCALER = 0x00;
    RTC->COMP0 = 0x00;
    RTC->COMP1 = 0x00;
    RTC->COMP2 = 0x00;
    RTC->COMP3 = 0x00;
    RTC->LPCOMP_CMP = 0x00;

    RTC->SR_OFF = 0xFFFFFFFF;
    RTC->SR_OFF &= ~BIT(31);

    *((uint32_t *)0x40000014) &= ~BIT(9);
    bee_aon_gp_write(0x1D, bee_aon_gp_read(0x1D)|BIT(4));
}

/**
  * @brief  Set RTC comparator value.
  * @param  COMPNum: the comparator number.
  * @param  COMPValue: the comparator value to be set.
  * @retval None
  */
void RTC_SetCOMPValue(uint8_t COMPNum, uint32_t COMPValue)
{
    switch(COMPNum)
    {
        case 0:
            RTC->COMP0 = COMPValue;
            break;
        case 1:
            RTC->COMP1 = COMPValue;
            break;
        case 2:
            RTC->COMP2 = COMPValue;
            break;
        case 3:
            RTC->COMP3 = COMPValue;
            break;
        default:
            break;
    }
}

/**
  * @brief  Get RTC comparator value.
  * @param  COMPNum: the comparator number.
  * @retval the comparator value.
  */
uint32_t RTC_GetCOMPValue(uint8_t COMPNum)
{
    uint32_t COMPValue;
    switch(COMPNum)
    {
        case 0:
            COMPValue = RTC->COMP0;
            break;
        case 1:
            COMPValue = RTC->COMP1;
            break;
        case 2:
            COMPValue = RTC->COMP2;
            break;
        case 3:
            COMPValue = RTC->COMP3;
            break;
        default:
            break;
    }
    return COMPValue;
}

/**
  * @brief  Enables or disables the specified RTC interrupts.
  * @param  RTCx: RTC peripheral
  * @param  RTC_IT: specifies the RTC interrupt source to be enabled or disabled. 
  *   This parameter can be any combination of the following values:
  *     @arg RTC_INT_TICK: RTC tick interrupt
  *     @arg RTC_INT_OVF: RT counter overflow interrupt
  *     @arg RTC_INT_LPCMP: LPCOMP comapre interrupt
  *     @arg RTC_INT_CMP0: compare 0 interrupt
  *     @arg RTC_INT_CMP1: compare 1 interrupt
  *     @arg RTC_INT_CMP2: compare 2 interrupt
  *     @arg RTC_INT_CMP3: compare 3 interrupt
  *     @arg RTC_INT_LPSRC: LPCOMP source interrupt(used in voltage compare)
  * @param  NewState: new state of the specified RTC interrupt.
  *   This parameter can be: ENABLE or DISABLE.
  * @retval None
  */
void RTC_INTConfig(RTC_TypeDef* RTCx, uint32_t RTC_IT, FunctionalState NewState)
{
    if (NewState ==ENABLE)
    {
        /* Enable the selected RTC interrupt */
        RTCx->CR1 |= RTC_IT;
    }
    else
    {
        /* Disable the selected RTC interrupt */
        RTCx->CR1 &= (~(RTC_IT));
    }
}

