/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file		system_rtl8762.c
* @brief	Routines to initialize system.
* @details
* @author	Chuanguo Xue
* @date 	2015-03-27
* @version	v0.1
*********************************************************************************************************
*/

#include "rtl876x.h"
#include "rtl876x_bitfields.h"
#include "rtl876x_it.h"
#include "rtl_endian.h"
#include "rtl876x_gpio.h"
#include "section_config.h"
#include "symboltable_uuid.h"
#include "flash_ota.h"
#include "version.h"
#include "trace.h"
#include "rtl876x_pinmux.h"
#include "legacyperiphapi.h"
#include <string.h>
#include "hal_wdg.h"
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "dlps_platform.h"


#define OTA_FLAG_DEFAULT 0x7f

// the header of user image
const PATCH_HEADER user_flash_header USER_FLASH_HEADER = {sizeof(PATCH_HEADER)/4, Signature_USER  , VERSION_REVISION , 0, 0, OTA_FLAG_DEFAULT, 0xff};
const char user_flash_timestamp[32] USER_FLASH_TIMESTAMP = DEFINE_symboltable_uuid;

//avoid empty trace file
const int trace_version __attribute__((at(0x08030000))) = VERSION_REVISION;

#if defined (RTL8762AX_VA)
extern IRQ_FUN UserIrqFunTable[32+17];
extern IRQ_FUN GPIOIrqFunTable[32];

#elif defined (RTL8762AX_VB)
extern IRQ_FUN UserIrqFunTable[32];
extern uint32_t __Vectors;
#endif

TickType_t gKeepActiveTicks = 0;
TimerHandle_t xTimersDLPSKeepActive = NULL;

#if defined (RTL8762AX_VA)
void System_Init(void)
{
    //SDK version
    DBG_DIRECT("RTL8762AX_VA SDK Version: %s", FILE_VERSION_STR);
    DBG_DIRECT("Build Time:%s", BUILDING_TIME);
	
	UserIrqFunTable[SYSTEM_ON_IRQ]		= (IRQ_FUN)SysOnIntrHandler;
	UserIrqFunTable[WDG_IRQ]				= (IRQ_FUN)WdgIntrHandler;
//	UserIrqFunTable[TIMER0_IRQ]			= (IRQ_FUN)Timer0IntrHandler;			//Timer0 has been used by Lower Stack. It should not be re-mapped.
//	UserIrqFunTable[TIMER1_IRQ]			= (IRQ_FUN)Timer1IntrHandler;
	UserIrqFunTable[TIMER2_IRQ]			= (IRQ_FUN)Timer2IntrHandler;
	UserIrqFunTable[GPIO0_IRQ]			= (IRQ_FUN)Gpio0IntrHandler;
	UserIrqFunTable[GPIO1_IRQ]			= (IRQ_FUN)Gpio1IntrHandler;
//	UserIrqFunTable[LOG_UART_IRQ]			= (IRQ_FUN)LogUartIntrHandler;		//Log Uart should not be re-mapped.
	UserIrqFunTable[UART_IRQ]		        = (IRQ_FUN)DataUartIntrHandler;
	UserIrqFunTable[RTC_IRQ]     			= (IRQ_FUN)RTCIntrHandler;
	UserIrqFunTable[SPI0_IRQ]				= (IRQ_FUN)Spi0IntrHandler;
	UserIrqFunTable[SPI1_IRQ]				= (IRQ_FUN)Spi1IntrHandler;
	UserIrqFunTable[I2C0_IRQ]				= (IRQ_FUN)I2C0IntrHandler;
	UserIrqFunTable[I2C1_IRQ]				= (IRQ_FUN)I2C1IntrHandler;
	UserIrqFunTable[ADC_IRQ] 				= (IRQ_FUN)ADCIntrHandler;
	UserIrqFunTable[PERIPHERAL_IRQ] 		= (IRQ_FUN)PeripheralIntrHandler;
	//UserIrqFunTable[GDMA0_CHANNEL0_IRQ] 	= (IRQ_FUN)Gdma0Ch0IntrHandler;
	//UserIrqFunTable[GDMA0_CHANNEL1_IRQ] 	= (IRQ_FUN)Gdma0Ch1IntrHandler;
	//UserIrqFunTable[GDMA0_CHANNEL2_IRQ] 	= (IRQ_FUN)Gdma0Ch2IntrHandler;
	//UserIrqFunTable[GDMA0_CHANNEL3_IRQ] 	= (IRQ_FUN)Gdma0Ch3IntrHandler;
	//UserIrqFunTable[GDMA0_CHANNEL4_IRQ] 	= (IRQ_FUN)Gdma0Ch4IntrHandler;
	//UserIrqFunTable[GDMA0_CHANNEL5_IRQ] 	= (IRQ_FUN)Gdma0Ch5IntrHandler;
	UserIrqFunTable[KEYSCAN_IRQ] 			= (IRQ_FUN)KeyscanIntrHandler;
	UserIrqFunTable[QDECODE_IRQ] 			= (IRQ_FUN)QdecodeIntrHandler;
	UserIrqFunTable[IR_IRQ] 				= (IRQ_FUN)IRIntrHandler;
	UserIrqFunTable[SPI2WIRE_IRQ]			= (IRQ_FUN)SPI2wireIntrHandler;
	UserIrqFunTable[ANALOG_IRQ] 			= (IRQ_FUN)AnalogComparatorIntrHandler;
	
	//32-63: PERIPHERAL_IRQ
	UserIrqFunTable[SPIFLASH_IRQ-32] 		= (IRQ_FUN)SPIFLASHIntrHandler;
	UserIrqFunTable[GPIO2_IRQ-32] 		= NULL;
	UserIrqFunTable[GPIO3_IRQ-32] 		= NULL;
	UserIrqFunTable[GPIO4_IRQ-32] 		= NULL;
	UserIrqFunTable[GPIO5_IRQ-32] 		= NULL;
	UserIrqFunTable[TIMER3_IRQ-32] 		= (IRQ_FUN)Timer3IntrHandler;
	UserIrqFunTable[TIMER4_IRQ-32] 		= (IRQ_FUN)Timer4IntrHandler;
	UserIrqFunTable[TIMER5_IRQ-32] 		= (IRQ_FUN)Timer5IntrHandler;
	UserIrqFunTable[TIMER6_IRQ-32] 		= (IRQ_FUN)Timer6IntrHandler;
	UserIrqFunTable[TIMER7_IRQ-32] 		= (IRQ_FUN)Timer7IntrHandler;
	UserIrqFunTable[GPIO6To31_IRQ-32] 	= NULL;
	
	GPIOIrqFunTable[2] 			= (IRQ_FUN)Gpio2IntrHandler;
	GPIOIrqFunTable[3] 			= (IRQ_FUN)Gpio3IntrHandler;
	GPIOIrqFunTable[4] 			= (IRQ_FUN)Gpio4IntrHandler;
	GPIOIrqFunTable[5] 			= (IRQ_FUN)Gpio5IntrHandler;
	GPIOIrqFunTable[6] 			= (IRQ_FUN)Gpio6IntrHandler;
	GPIOIrqFunTable[7] 			= (IRQ_FUN)Gpio7IntrHandler;
	GPIOIrqFunTable[8] 			= (IRQ_FUN)Gpio8IntrHandler;
	GPIOIrqFunTable[9] 			= (IRQ_FUN)Gpio9IntrHandler;
	GPIOIrqFunTable[10] 		= (IRQ_FUN)Gpio10IntrHandler;
	GPIOIrqFunTable[11] 		= (IRQ_FUN)Gpio11IntrHandler;
	GPIOIrqFunTable[12] 		= (IRQ_FUN)Gpio12IntrHandler;
	GPIOIrqFunTable[13] 		= (IRQ_FUN)Gpio13IntrHandler;
	GPIOIrqFunTable[14] 		= (IRQ_FUN)Gpio14IntrHandler;
	GPIOIrqFunTable[15] 		= (IRQ_FUN)Gpio15IntrHandler;
	GPIOIrqFunTable[16] 		= (IRQ_FUN)Gpio16IntrHandler;
	GPIOIrqFunTable[17] 		= (IRQ_FUN)Gpio17IntrHandler;
	GPIOIrqFunTable[18] 		= (IRQ_FUN)Gpio18IntrHandler;
	GPIOIrqFunTable[19] 		= (IRQ_FUN)Gpio19IntrHandler;
	GPIOIrqFunTable[20] 		= (IRQ_FUN)Gpio20IntrHandler;
	GPIOIrqFunTable[21] 		= (IRQ_FUN)Gpio21IntrHandler;
	GPIOIrqFunTable[22] 		= (IRQ_FUN)Gpio22IntrHandler;
	GPIOIrqFunTable[23] 		= (IRQ_FUN)Gpio23IntrHandler;
	GPIOIrqFunTable[24] 		= (IRQ_FUN)Gpio24IntrHandler;
	GPIOIrqFunTable[25] 		= (IRQ_FUN)Gpio25IntrHandler;
	GPIOIrqFunTable[26] 		= (IRQ_FUN)Gpio26IntrHandler;
	GPIOIrqFunTable[27] 		= (IRQ_FUN)Gpio27IntrHandler;
	GPIOIrqFunTable[28] 		= (IRQ_FUN)Gpio28IntrHandler;
	GPIOIrqFunTable[29] 		= (IRQ_FUN)Gpio29IntrHandler;
	GPIOIrqFunTable[30] 		= (IRQ_FUN)Gpio30IntrHandler;
	GPIOIrqFunTable[31] 		= (IRQ_FUN)Gpio31IntrHandler;
    
    NVIC_SetPriority(SYSTEM_ON_IRQ, 0);
    NVIC_EnableIRQ(SYSTEM_ON_IRQ);  //Enable SYSTEM_ON Interrupt

    /* Please use SWDTool or MPTool to configure BT address. */
#if 0 
    //Set BT address
    uint8_t addr[6] = {0x11, 0x11, 0x22, 0x22, 0x33, 0x33};
    memcpy((uint8_t *)0x20000266, addr, 6);
#endif

    return;
}

#elif defined (RTL8762AX_VB)
void System_Init(void)
{
    //SDK version
    DBG_DIRECT("RTL8762AX_VB SDK Version: %s", FILE_VERSION_STR);
    DBG_DIRECT("Build Time:%s", BUILDING_TIME);

#ifndef RUN_APP_IN_HCIMODE
    if( ((*(uint32_t*)0x200000F0) & BIT(0)) == 1) //upper_stack_en
    {
        DBG_DIRECT("In SoC Mode");       
    }
    else
    {
        DBG_DIRECT("WARNING: In HCI Mode, will not run APP Task");
        vTaskStartScheduler();
    }      
#endif
	
    uint32_t i;
    for(i = 0; i < 32; ++i)
    {
        if( i == TIMER0_IRQ ||
            i == TIMER1_IRQ ||
            i == BTMAC_BLUEWIZ_IRQ ||
            i == BTMAC_HCIDMA_IRQ ||
            i == BTMAC_BZDMA_IRQ ||
            i == BTMAC_CROSSBAR_IRQ ||
            i == LOG_UART_IRQ
        )
            ; //Should not be remapped
        else
            UserIrqFunTable[i]  = (IRQ_FUN)*(&__Vectors+(16+i));
    }
    
    NVIC_SetPriority(SYSTEM_ON_IRQ, 0);
    NVIC_EnableIRQ(SYSTEM_ON_IRQ);  //Enable SYSTEM_ON Interrupt

    /* Please use SWDTool or MPTool to configure BT address. */
#if 0
    //Set BT address
    uint8_t addr[6] = {0x11, 0x11, 0x22, 0x22, 0x33, 0x33};
    memcpy((uint8_t *)0x20000076, addr, 6);
#endif

    return;
}

void PeripheralIntrHandler(void)
{
    uint32_t PeriIrqStatus, CheckIndex, ExactIrqStatus, TableIndex;
    PeriIrqStatus = PERIPHINT->STATUS;

    /* For GPIO interrupt */
    UINT32 gpio_int = 0x0;
    UINT32 index = 0;

    //Save exact IRQ status
    ExactIrqStatus = PeriIrqStatus & (PERIPHINT->EN);

    //Check exact IRQ function
    for(CheckIndex = 0;CheckIndex<32;CheckIndex++) 
    {
        if (ExactIrqStatus & BIT(CheckIndex)) 
        {
            TableIndex = CheckIndex + 64;
            if (TableIndex == SPIFLASH_IRQ ||
                TableIndex == GPIO2_IRQ ||
                TableIndex == GPIO3_IRQ ||
                TableIndex == GPIO4_IRQ ||
                TableIndex == GPIO5_IRQ ||
                TableIndex == TIMER3_IRQ ||
                TableIndex == TIMER4_IRQ ||
                TableIndex == TIMER5_IRQ ||
                TableIndex == TIMER6_IRQ ||
                TableIndex == TIMER7_IRQ   
            )
            {
                IRQ_FUN pFun = (IRQ_FUN)*(&__Vectors+(TableIndex - 16));
                pFun();
            }
            else if (TableIndex == GPIO6To31_IRQ)
            {
                gpio_int = GPIO->INTSTATUS;
                for (index = 6; index < 32; index++)
                {  
                    if(gpio_int&BIT(index))
                    {
                        IRQ_FUN pFun = (IRQ_FUN)*(&__Vectors+(52 + index));
                        pFun();
                    }
                }
            }
            else
                ;
        }
    }
}
#endif

static void vTimerDLPSKeepActiveCallback(TimerHandle_t pxTimer )
{
    portENTER_CRITICAL();
    
    if(--gKeepActiveTicks)
        xTimerReset(xTimersDLPSKeepActive, 0);
    else
    {  
        xTimerDelete(pxTimer, 0);
        xTimersDLPSKeepActive = NULL;
    }

    portEXIT_CRITICAL();
}

void DLPS_KeepActiveTicks(const TickType_t xTimerPeriodInTicks)
{   
    if(xTimerPeriodInTicks == 0)
        return;
    
    portENTER_CRITICAL();
    
    gKeepActiveTicks = xTimerPeriodInTicks;
    
    if(xTimersDLPSKeepActive == NULL)
    {
        xTimersDLPSKeepActive = xTimerCreate(  "xTimersDLPSKeepActive",     // Just a text name, not used by the kernel.
                                       1,                       // The timer period in ticks.
                                       pdFALSE,                 // The timers will auto-reload themselves when they expire.
                                       ( void *) 0,             // Assign each timer a unique id equal to its array index.
                                       vTimerDLPSKeepActiveCallback
                                       );
        if(xTimersDLPSKeepActive)
        {
            xTimerStart(xTimersDLPSKeepActive, 0);
        }
    }
    else
    {
        if(xTimerPeriodInTicks > gKeepActiveTicks)
            gKeepActiveTicks = xTimerPeriodInTicks;
    }
    
    portEXIT_CRITICAL();
}

void SysOnIntrHandler(void)
{
    DBG_BUFFER(MODULE_APP, LEVEL_INFO, "SysOnIntr", 0);

    //Disable GPIO wakeup Interrupt, open it in DLPS_IO_EnterDlpsCb().
    uint8_t value8 = bee_aon_gp_read(REG_PAD_WK_CTRL_ADDRESS);
    value8 &= ~BIT_WK_INTEN;
    bee_aon_gp_write(REG_PAD_WK_CTRL_ADDRESS, value8);
    
    //Keep Active for a while before enter DLPS
    DLPS_KeepActiveTicks(2);  //20ms
}
 
