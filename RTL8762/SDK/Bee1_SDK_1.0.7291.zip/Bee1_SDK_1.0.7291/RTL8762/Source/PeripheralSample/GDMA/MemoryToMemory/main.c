/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file		main.c
* @brief	This file provides demo code of meomory to memory transfer by GDMA.
* @details
* @author	elliot chen
* @date 	2015-06-04
* @version	v0.1
*********************************************************************************************************
*/

/* Includes ------------------------------------------------------------------*/
#include "rtl876x_gdma.h"
#include "rtl876x_rcc.h"
//#include "rtl876x_it.h"

/*--------------------------GDMA memory to memory transfer demo code----------------------------------*/
void RCC_Configuration(void)
{
	/* turn on GDMA clock */
    RCC_PeriphClockCmd(APBPeriph_GDMA, APBPeriph_GDMA_CLOCK, ENABLE);
}
void GDMA_MemoryToMemory(void)    
{
	GDMA_InitTypeDef GDMA_InitStruct;
    uint8_t i = 0;
	uint8_t GDMA_TestBuffer[100];
    uint8_t GDMA_TestReceiveBuffer[100];
        
     /*test buffer*/
    for(i=0; i<100; i++)
    {   
        GDMA_TestBuffer[i] = i + 1;
    }
    for(i=0; i<100; i++)
    {   
        GDMA_TestReceiveBuffer[i] = 0;
    }
    
	/*GDMA initial*/
    GDMA_InitStruct.GDMA_ChannelNum          = 0;
  	GDMA_InitStruct.GDMA_DIR 			     = GDMA_DIR_MemoryToMemory;
  	GDMA_InitStruct.GDMA_BufferSize 	     = 10;
  	GDMA_InitStruct.GDMA_SourceInc           = DMA_SourceInc_Inc;
	GDMA_InitStruct.GDMA_DestinationInc      = DMA_DestinationInc_Inc;

	GDMA_InitStruct.GDMA_SourceDataSize      = GDMA_DataSize_Word;
	GDMA_InitStruct.GDMA_DestinationDataSize = GDMA_DataSize_Word;
	GDMA_InitStruct.GDMA_SourceMsize	     = GDMA_Msize_8;
	GDMA_InitStruct.GDMA_DestinationMsize    = GDMA_Msize_8;
	
	GDMA_InitStruct.GDMA_SourceAddr 	     = (uint32_t)GDMA_TestBuffer;
	GDMA_InitStruct.GDMA_DestinationAddr     = (uint32_t)GDMA_TestReceiveBuffer;
	GDMA_InitStruct.GDMA_TransferType        = GDMA_TransferType_Other;
	GDMA_InitStruct.GDMA_ChannelPriority     = 0;// it can be 0 to 6 which 6 is highest priority
     
    GDMA_Init(GDMA_Channel0, &GDMA_InitStruct);
    
    GDMA_INTConfig(0, GDMA_INT_Transfer, ENABLE);
   
    /* GDMA IRQ */
    NVIC_ClearPendingIRQ(GDMA0_CHANNEL0_IRQ);
    NVIC_SetPriority(GDMA0_CHANNEL0_IRQ, 1);
    NVIC_EnableIRQ(GDMA0_CHANNEL0_IRQ);
   
    GDMA_Cmd(0, ENABLE);
}

int main(void)
{
    RCC_Configuration();
    GDMA_MemoryToMemory();
    while(1);

}

void Gdma0Ch0IntrHandler(void)
{
    GDMA_ClearAllTypeINT(0);
    GDMA_Cmd(0, ENABLE);
}
