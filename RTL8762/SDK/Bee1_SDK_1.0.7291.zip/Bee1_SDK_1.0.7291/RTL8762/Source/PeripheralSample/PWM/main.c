/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file		main.c
* @brief	This file provides demo code of PWM.
* @details
* @author	elliot chen
* @date 	2015-06-10
* @version	v0.1
*********************************************************************************************************
*/

/* Defines ------------------------------------------------------------------*/
#define TIM_GPIOTEST			P0_5
#define TIM_ID                  TIM2

/* Includes ------------------------------------------------------------------*/
#include "rtl876x_rcc.h"
#include "rtl876x_PWM.h"
#include "rtl876x_nvic.h"
#include "rtl876x_pinmux.h"

/*PWM test code---------------------------------------------------------------*/
void RCC_Configuration(void)
{
	/* turn on SPI clock */
    RCC_PeriphClockCmd(APBPeriph_TIMER, APBPeriph_TIMER_CLOCK, ENABLE);
}

void PWM_PINMUXConfiguration(void)
{
    Pinmux_Config(TIM_GPIOTEST, timer_pwm0);
}

void PWM_PADConfiguration(void)
{
    Pad_Config(TIM_GPIOTEST, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE, PAD_OUT_HIGH);
}

void PWM_InitConfiguration(void)
{
	PWM_InitTypeDef PWM_InitStruct;
	TIM_TimeBaseInitTypeDef TIM_InitStruct;
	
    TIM_StructInit(&TIM_InitStruct);
	TIM_InitStruct.TIM_ClockSrc = TIM_CLOCK_10MHZ;
	TIM_InitStruct.TIM_Period = 1;
	TIM_InitStruct.TIM_Mode = TIM_Mode_UserDefine;
	TIM_TimeBaseInit(TIM_ID, &TIM_InitStruct);
	TIM_Cmd(TIM_ID, ENABLE);

	PWM_InitStruct.PWM_Period = 2;
    PWM_InitStruct.PWM_Duty = 1;
	PWM_InitStruct.PWM_TIMIndex = 2;
	PWM_Init(PWM0, &PWM_InitStruct);
	PWM_Cmd(PWM0, ENABLE);
}

void PWM_TestCode(void)
{
    PWM_PINMUXConfiguration();
    PWM_PADConfiguration();
	PWM_InitConfiguration();
    while(1);
}

int main(void)
{
    PWM_TestCode();
    while(1);
}
