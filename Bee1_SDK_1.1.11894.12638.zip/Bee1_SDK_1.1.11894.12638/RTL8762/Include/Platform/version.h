#define VERSION_MAJOR            1
#define VERSION_MINOR            1
#define VERSION_REVISION         11894
#define VERSION_BUILD            12638
#define NUM4STR(a,b,c,d)         #a "." #b "." #c "." #d
#define VERSIONBUILDSTR(a,b,c,d) NUM4STR(a,b,c,d)
#define FILE_VERSION_STR         VERSIONBUILDSTR(VERSION_MAJOR,VERSION_MINOR,VERSION_REVISION,VERSION_BUILD)
#define SRC_TIME                 "2016/06/30 11:04:19"
#define BUILDING_TIME            "2016/06/30 11:17:29"
