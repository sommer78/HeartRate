#ifndef _BAS_CONFIG_H_
#define _BAS_CONFIG_H_

#define BAS_BATTERY_LEVEL_NOTIFY_SUPPORT



#endif
