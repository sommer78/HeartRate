#ifndef _SPS_CONFIG_H_
#define _SPS_CONFIG_H_


#define SPS_CHAR_SCAN_REFRESH_SUPPORT


#endif
