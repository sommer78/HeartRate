
#ifndef SIMPLEBLEBROADCASTER_H
#define SIMPLEBLEBROADCASTER_H


#include "gap.h"
#include "bee_message.h"
#ifdef __cplusplus
extern "C"
{
#endif

extern void BtStack_Init_Broadcaster(void);

#ifdef __cplusplus
}
#endif

#endif /* SIMPLEBLEBROADCASTER_H */
