#ifndef __ZX_7816_H__
#define __ZX_7816_H__

#include "mxd2660_7816.h"
#ifdef __cplusplus
extern "C"{
#endif /* __cplusplus */
	

	
extern void zx_7816_init(void);
extern uint32 wristband_7816_cmd_proc(void *buffer);

#ifdef __cplusplus
}
#endif /* __cplusplus */	
	
#endif

